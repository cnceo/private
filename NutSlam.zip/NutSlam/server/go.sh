. env.sh
docker rm -v $(docker ps -a -q -f status=exited)
fig up
