Delta Server
============

Make sure you read etc/development.yml and read up on boot2docker, docker, and
docker-compose.  `fig` is set up as an alias for docker-compose.

Installing and starting
-----------------------
Set up your Mac development environment:

    ./install_dev_env          # once to install everything
    . ./env.sh                 # once per shell: start VM, set env vars

Build & run docker images:

    fig build && fig up        # run in the fg
    fig start                  # run in the bg

Initialize/reset database (do initially, and when resetting data):

    fig start cb
    docker exec -it server_cb_1 /app/cli reset

Start server and client separately for easier development:

    # Two server alternatives:
    fig start cb
    # or in another terminal from client:
    fig up cb

    # Two client alternatives:
    fig up --no-deps game
    # or login to container and then run it:
    fig run game /bin/bash -l
    ./run

Accessing game:

    wget -O- http://$DOCKER_IP:8088/test/  # the game

    open http://$DOCKER_IP:8091/           # couchbase admin - user: Administrator, password: password
    wget http://$DOCKER_IP:8092/           # couchbase
    wget http://$DOCKER_IP:11210/          # couchbase

Troubleshooting
---------------
Logging into containers for troubleshooting:

    docker exec -it warnuts_game_1 /bin/bash -l
    docker exec -it warnuts_cb_1 /bin/bash -l

Or equivalent commands using some convenience alias from env.sh:

    game bash -l
    cb bash -l

Tips
----
Do all file editing on Mac, with /app mounted into container.
Stay logged into container, run scripts there.
Some commands that may come in handy:

    boot2docker restart            # if things are messed up
    boot2docker ssh                # check the virtual machine
    fig up cb               	   # just run the db
    fig ps
    fig rm

Regularly free up space in Docker VM by removing containers
that aren't running and images that aren't tagged:

    docker rm $(docker ps -a -q)
    docker rmi $(docker images -q --filter "dangling=true")



Deploy steps
------------
Prepare server:
    Create branch server/vx.x.x
    Create relsease/vx.x.x (release/vx.x.x-splittestX)
    Push if have changes on server/vx.x.x
    Merge server/vx.x.x changes to develop & release/vx.x.x
    Set up the force update version in content spread sheet and export
    Make version-specific content spreadsheet
    Modify the Version Navi sheet to add the s3 address url
    on release/vx.x.x (splittestX): ./Update Assets, unity bundle manager rebuild, push the changes
    Upload from each release/vx.x.x (splittestX) to s3 by different version (test to make sure it's public-read)
    Beta server, pull from release/vx.x.x, stop, build and up docker with develop.yml
    Beta server, init splittest config if needed
    playtest on beta
Deploy server:
    on live chechout release/vx.x.x, copy live_settings.py
    docker stop build up production.yml




* * *

TODO
----
 - Couchbase container:
   - ./cli still not working for more than 'run' and 'create'
 - Consider using CoreOS and/or "eb local" and/or deis to run the dockers (?)
 - Seamless deployment to AWS Elastic Beanstalk or Deis on AWS
