import time
from functools32 import lru_cache
#from gcouchbase.connection import GConnection
from couchbase.connection import Connection as GConnection
from couchbase.exceptions import *
from couchbase.connstr import convert_1x_args
from utils import settings
from utils.log import log


sleep = 3
quiet_retries = 12


def ErrorRetryWrapper(method):
    """Retry on temporary Couchbase errors"""
    def handler_wrapper(*args, **kwargs):
        global quiet_retries
        while True:
            try:
                if quiet_retries>0: quiet_retries -= 1
                return method(*args, **kwargs)
            except CouchbaseTransientError, e:
                if not quiet_retries:
                    log.warn("CouchbaseTransientError (%s): retry in %s secs..." % (e, sleep,))
            except BucketNotFoundError, e:
                if not quiet_retries:
                    log.warn("BucketNotFoundError: retry in %s secs..." % (sleep,))
            time.sleep(sleep)
    return handler_wrapper


db_handles = {}
def get_db(bucket=settings.COUCHBASE_BUCKET):
    global db_handles
    db = db_handles.get(bucket, None)
    if db is not None:
        return db
    db = init_db(bucket=bucket)
    db_handles[bucket] = db
    return db

#@lru_cache(maxsize=8)
def init_db(bucket=settings.COUCHBASE_BUCKET):
    """Initialize DB, and cache resulting connection"""
    host = settings.COUCHBASE_HOST
    if bucket not in settings.SUPPORTED_BUCKETS:
        log.error("no valid bucket configed - check settings")
        return
    @ErrorRetryWrapper
    def connect():
        db_conn = GConnectionExtention(bucket=bucket, timeout=10*1000, host=host, quiet=True)
        log.info("connected to bucket '%s' on host '%s'", bucket, host)
        return db_conn
    return connect()


class GConnectionExtention(GConnection):

    def __init__(self, bucket="default", timeout=None, **kwargs):
        kwargs = convert_1x_args(bucket, **kwargs)
        if timeout is not None:
            kwargs["connection_string"] = "%s?operation_timeout=%s" % (
                kwargs["connection_string"], timeout)
        super(GConnectionExtention, self).__init__(**kwargs)

    @ErrorRetryWrapper
    def load(self, key):
        """Call GConnection simple get and return its value."""
        val = self.get(key)
        return val and val.value

    @ErrorRetryWrapper
    def exist(self, key):
        """Check if an key exist in couchbase.
        Call simple get and check its value:
            None - key does not exist
            Otherwise - key exist
        """
        val = self.load(key)
        return val is not None

    @ErrorRetryWrapper
    def set(self, *args, **kwargs):
        return super(GConnectionExtention, self).set(*args, **kwargs)
