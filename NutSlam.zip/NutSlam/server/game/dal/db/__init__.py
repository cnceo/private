import _couchbase
engine = _couchbase
db = engine.get_db
