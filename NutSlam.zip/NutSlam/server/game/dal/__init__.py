import _cache
import db
from utils.settings import USE_CACHE


def load_data(db_type, key):
    data = None
    if USE_CACHE:
        data = _cache.load(key)
    if not data:
        data = db.db(db_type).load(key)
    return data


def store_data(db_type, key, val):
    if USE_CACHE:
        _cache.store(key, val)
    db.db(db_type).set(key, val)


def delete_data(db_type, key):
    if USE_CACHE:
        _cache.delete(key)
    db.db(db_type).delete(key)