#!/usr/bin/python2.7 -u

from gevent import monkey ; monkey.patch_all()
from admin.admin import AdminResource
from utils.settings import ADMIN_KEY
from script.send_event_pn import start_pn
from flask import Flask
from flask import request


app = Flask(__name__, static_folder="admin/static")
app.config['SECRET_KEY'] = 'Zjlasdf8435sd'
def create_app():
    start_pn()
    return app

#
# Admin portal
#
admin = AdminResource()
@app.route("/%s/" % ADMIN_KEY)
@app.route("/%s/<path>" % ADMIN_KEY)
def _nutslam_admin(path=""):
    return admin.handle(path, request)
