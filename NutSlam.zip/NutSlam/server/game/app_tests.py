#!/usr/bin/python2.7 -u

from utils.log import log

# Test overloaded and maintenance scenarios
def overloaded_app(env, start_response):
    log.critical('test overloaded scenario')
    headers = [ ('Content-type', 'text/html') ]
    start_response('503 Game Overloaded', headers)
    # TODO: Unity doesn't give access to body of return messages,
    # only headers and status code, so the below message is ignored.
    return ['<h1>Server overloaded</h1>\n']

def maintenance_app(env, start_response):
    log.critical('test maintenance scenario')
    headers = [ ('Content-type', 'text/html') ]
    headers.append( ('Retry-After', '3600') )   # OR: datetime
    start_response('503 Game Maintenance', headers)
    # TODO: Unity doesn't give access to body of return messages,
    # only headers and status code, so the below message is ignored.
    return ['<h1>Server maintenance</h1>\n']

def shutdown_app(env, start_response):
    log.critical('test shutdown scenario')
<<<<<<< HEAD
    start_response('410 Nut Slam was shut down April 25, 2015, 23:59 UTC.', headers)
    return []
=======
    headers = [ ('Content-type', 'text/html') ]
    start_response('200 Game Shutdown', headers)
    return ['<h1>Game is shut down</h1>\nGame was shut down April 25, 2015, 23:59 UTC.']
>>>>>>> 0d9847a54627766d434a79f50ab510003a9d1be1

# Test server errors
def error_app(env, start_response):
    log.critical('test internal error scenario')
    raise

# Test bad network scenarios - adding delays to all requests
from app_game import *
def create_slow_app(mindelay=0, maxdelay=10, **kw):
    log.critical('test bad network scenario', **locals())
    from time import sleep
    from random import randint
    app = create_app_with_sampledata(**kw)
    @app.before_request
    def slowdown():
        delay = randint(mindelay, maxdelay)
        log.debug("simulating network delay of {delay}s".format(**locals()))
        sleep(delay)
    return app
