import gevent
import random
from actors.base_actor import BaseActor
from actors.notification import PushNotificationActor
from actors.notification import SNS_ACTION
from dal.base import KeyValue
from models.content import GameRule
from models.event import EventTopic
from models.event import event_type
from utils.misc import local_now
from utils.misc import next_x_days
from utils.misc import time_of_day
from utils.misc import dateformat_with_utc_offset
from utils.misc import utc_now
from utils.settings import CHECK_NEW_UTC_OFFSETS
from utils.settings import UTC_OFFSETS_KEY
from utils.settings import EVENTS_PUSH_NOTIFICATION_TIME
from utils.settings import EVENTS_BOSS
from utils.settings import EventsType
from utils.l10n_keys import DUNGEON_EVENTS_PN
from utils.l10n_keys import GATCHA_EVENTS_PN
from utils.log import log


GameRule.get_content()
e_conf = GameRule._events_conf
pn_actor = PushNotificationActor.get()


class SendEventsPN(BaseActor):
    ttl = CHECK_NEW_UTC_OFFSETS
    dateformat_map = {}

    def on_receive(self, msg):
        gevent.spawn(self.send_all)

    def send_all(self):
        utc_offsets = KeyValue(UTC_OFFSETS_KEY)
        for _offset in utc_offsets.load() or []:
            if _offset not in self.dateformat_map:
                self.dateformat_map[_offset] = \
                    dateformat_with_utc_offset(_offset)
                gevent.spawn(self.send_pn, _offset)
        gevent.sleep(self.ttl)
        self.send_all()

    def do_send_pn(self, utc_offset):
        day_seconds = 60 * 60 * 24
        gevent.spawn_later(day_seconds, self.do_send_pn, utc_offset)
        db_format = self.dateformat_map.get(utc_offset)
        now = utc_now()
        tomorrow = next_x_days(now, days=1)
        incoming_events = e_conf.incoming_events(now, tomorrow, db_format)
        e_map = {}
        for e in incoming_events:
            et = event_type(e)
            if et in EVENTS_BOSS["dungeon_type"]:
                # merge dungeon45 & dungeon556 to dungeon_boss
                et = EVENTS_BOSS["key"]
            el = e_map.get(et) or []
            if e not in el:
                el.append(e)
            e_map[et] = el

        event_topic = EventTopic(utc_offset=utc_offset)
        dungeon_pns = GameRule.l10n.server(DUNGEON_EVENTS_PN)
        gatcha_pns = GameRule.l10n.server(GATCHA_EVENTS_PN)

        for e_name, arn in event_topic.get_topic_map().iteritems():
            evs = e_map.get(e_name)
            if evs:
                evs = [GameRule.l10n.event_name(e.lower()) for e in evs]

                if e_name == EventsType.SPECIAL_GATCHA:
                    pns = gatcha_pns
                elif e_name == EVENTS_BOSS["key"]:
                    pns = dungeon_pns
                else:
                    # Not match any events need to send PN
                    continue
                pn_msg = pns % ", ".join(evs)
                msg = {"action": SNS_ACTION.PUBLISH_TO_TOPIC,
                       "data": {"topic_arn": arn,
                                "msg": pn_msg}}
                log.debug("Send pn to topic(%s): %s" % (arn, pn_msg))
                pn_actor.tell(msg)

    def send_pn(self, utc_offset):
        now = local_now(utc_offset=utc_offset)
        pn_clock = time_of_day(now, **EVENTS_PUSH_NOTIFICATION_TIME)
        if now > pn_clock:
            pn_clock = next_x_days(pn_clock, days=1)
        seconds = (pn_clock - now).total_seconds()
        gevent.spawn_later(seconds, self.do_send_pn, utc_offset)
