import base64
import gevent
import hashlib
import hmac
import re
import simplejson
import urllib
import urllib2
from functools32 import lru_cache
from datetime import datetime
from xml.etree import ElementTree
from utils.log import log
from utils.enum import Enum
from utils.exception import SNSActionError
from utils.gevent_actor import GeventActorWrapper
from utils.misc import to_str
from utils.settings import AWS_ACCESS_KEY_ID
from utils.settings import SNS_APP_ARN
from utils.settings import SNS_SERVER_URL
from utils.settings import SNS_SIGNATURE_METHOD
from utils.settings import SNS_SIGNATURE_VERSION
from utils.settings import SNS_VERSION
from utils.settings import SNS_RETRIES
from utils.settings import SNS_RETRY_SLEEP
from utils.settings import ENABLE_PN


SNS_ACTION = Enum()
SNS_ACTION.CREATE_ENDPOINT = 1
SNS_ACTION.DELETE_ENDPOINT = 2
SNS_ACTION.SEND_TO_ENDPOINT = 3
SNS_ACTION.CREATE_TOPIC = 4
SNS_ACTION.DELETE_TOPIC = 5
SNS_ACTION.SUBSCRIBE = 6
SNS_ACTION.UNSUBSCRIBE = 7
SNS_ACTION.PUBLISH_TO_TOPIC = 8
SNS_ACTION.ENABLE_ENDPOINT = 9


class SNSSender(object):

    def _query_str(self, param):
        return urllib.urlencode(sorted(param.iteritems())).replace("+", "%20")

    def _prepare(self, data, do_signature):
        # update data info
        data["Version"] = SNS_VERSION
        if do_signature:
            data.update({"AWSAccessKeyId": AWS_ACCESS_KEY_ID,
                         "SignatureMethod": SNS_SIGNATURE_METHOD,
                         "SignatureVersion": SNS_SIGNATURE_VERSION,
                         "Timestamp": datetime.utcnow().isoformat()
                         })
            # update Signature
            payload = self._query_str(data)
            s_str = "\n".join(["POST", SNS_SERVER_URL[7:-1], "/", payload])
            dig = hmac.new('AiYXpjI3dpehDZg0VvRVgunxGL/+BQO0JpeT9Z7K',
                           msg=s_str, digestmod=hashlib.sha256).digest()
            data["Signature"] = base64.b64encode(dig)
        return data

    def send(self, data, do_signature=True, retries=0, pn_token=None):
        if not ENABLE_PN:
            return
        data = self._prepare(data, do_signature)
        # send request
        payload = self._query_str(data)
        try:
            req = urllib2.Request(SNS_SERVER_URL, payload)
            resp = urllib2.urlopen(req)
            resp = resp and resp.read()
            return self.response(resp)
        except urllib2.URLError, e:
            msg = self.response(e.read())
            msg = msg and msg.get("Error")
            msg_code = msg.get("Code", "")
            if msg_code == "EndpointDisabled":
                if pn_token:
                    from models.player import PushNotificationToken
                    pn = PushNotificationToken(pn_token=pn_token)
                    pn.disable_endpoint()
            elif retries < SNS_RETRIES:
                gevent.sleep(SNS_RETRY_SLEEP)
                data.pop("Signature", None)
                return self.send(data, do_signature=do_signature,
                                 retries=retries+1)
            action = data.pop("Action", None)
            msg = "%s: %s" % (msg_code, msg.get("Message", ""))
            log.warn("Got error(%s - %s) while %s - data(%s)" %
                     (str(e), msg, action, str(data)))
        return None

    def response(self, resp):
        def _parse(_dom):
            if _dom.getchildren():
                _d = {}
                for c in _dom.getchildren():
                    _d[c.tag] = _parse(c)
                return _d
            else:
                return _dom.text

        result = None
        if resp:
            try:
                dom_str = re.sub(' xmlns="[^"]+"', '', resp, count=1)
                dom = ElementTree.fromstring(dom_str)
                result = _parse(dom)
            except ElementTree.ParseError:
                log.warn("Invalid resp from aws server: %s" % resp)
        return result


class PushNotificationActor(GeventActorWrapper):
    sender = SNSSender()

    def __init__(self, *args, **kwargs):
        super(PushNotificationActor, self).__init__(*args, **kwargs)
        self.action_map = {SNS_ACTION.CREATE_ENDPOINT: self.create_endpoint,
                           SNS_ACTION.DELETE_ENDPOINT: self.delete_endpoint,
                           SNS_ACTION.SEND_TO_ENDPOINT: self.send_endpoint,
                           SNS_ACTION.CREATE_TOPIC: self.create_topic,
                           SNS_ACTION.DELETE_TOPIC: self.delete_topic,
                           SNS_ACTION.SUBSCRIBE: self.subscribe,
                           SNS_ACTION.UNSUBSCRIBE: self.unsubscribe,
                           SNS_ACTION.PUBLISH_TO_TOPIC: self.send_topic,
                           SNS_ACTION.ENABLE_ENDPOINT: self.enable_endpoint,
                           }

    def on_receive(self, msg):
        try:
            action = msg.get("action")
            handler = self.action_map.get(action)
            if handler:
                return handler(**msg.get("data"))
            else:
                raise SNSActionError(msg)
        except Exception, e:
            log.error("Get error while handle PN msg %s. Error: %s"
                      % (str(msg), e), exc_info=True)

    def create_endpoint(self, pn_token=None):
        """
        @param pn_token: push notification token of players
        @return: the endpoint_arn if successfully done.
        """
        if len(pn_token) == 64:
            app_arn = SNS_APP_ARN.get("APN")
        else:
            app_arn = SNS_APP_ARN.get("GCM")
        data = {"PlatformApplicationArn": app_arn,
                "Action": "CreatePlatformEndpoint",
                "Token": pn_token,
                # "CustomUserData": "playerID:111",  # TODO - update this.
                }
        resp = self.sender.send(data) or {}
        return resp and resp.get("CreatePlatformEndpointResult",
                                 {}).get("EndpointArn")

    def delete_endpoint(self, ep_arn=None):
        data = {"Action": "DeleteEndpoint",
                "EndpointArn": ep_arn}
        self.sender.send(data)

    def _publish(self, msg, pn_token=None, badge=None, custom_data=None,
                 **kwargs):
        # IOS
        aps = {"alert": msg}
        if badge:
            aps["badge"] = badge
        apn = custom_data or {}
        apn["aps"] = aps
        # Android
        gcd = custom_data or {}
        gcd["alert"] = msg
        gcm = {"data": gcd}

        msg = {"default": msg,
               "APNS_SANDBOX": simplejson.dumps(apn),
               "GCM": simplejson.dumps(gcm)}
        data = {"Action": "Publish",
                "Message": simplejson.dumps(msg),
                "MessageStructure": "json"
                }
        data.update(kwargs)
        self.sender.send(data, pn_token=pn_token)

    def send_endpoint(self, ep_arn=None, msg=None, pn_token=None, badge=None,
                      custom_data=None):
        self._publish(to_str(msg), pn_token=pn_token, TargetArn=ep_arn,
                      badge=badge, custom_data=custom_data)

    def enable_endpoint(self, ep_arn=None):
        data = {"Action": "SetEndpointAttributes",
                "EndpointArn": ep_arn,
                "Attributes.entry.1.key": "Enabled",
                "Attributes.entry.1.value": True}
        self.sender.send(data)

    def create_topic(self, t_name=None):
        data = {"Action": "CreateTopic",
                "Name": t_name}
        resp = self.sender.send(data)
        return resp and resp.get("CreateTopicResult", {}).get("TopicArn")

    def delete_topic(self, t_arn=None):
        data = {"Action": "DeleteTopic",
                "TopicArn": t_arn}
        self.sender.send(data)

    def subscribe(self, t_arn=None, ep_arn=None):
        data = {"Action": "Subscribe",
                "TopicArn": t_arn,
                "Endpoint": ep_arn,
                "Protocol": "application",
                }
        resp = self.sender.send(data)
        return resp and resp.get("SubscribeResult", {}).get("SubscriptionArn")

    def unsubscribe(self, arn=None):
        data = {"Action": "Unsubscribe",
                "SubscriptionArn": arn}
        self.sender.send(data)

    def send_topic(self, topic_arn=None, msg=None):
        self._publish(msg, TopicArn=topic_arn)


@lru_cache(maxsize=1)
def pn_actor():
    """Return PN actor, and cache results"""
    return PushNotificationActor.get()
