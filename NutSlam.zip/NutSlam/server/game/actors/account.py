#!/usr/bin/python

from datetime import datetime
from base_actor import ChildActor
from base_actor import ParentActor
from base_actor import MessageHandlerWrapper
from utils.log import log
from utils.misc import datetime_to_int
from utils.protocol_pb2 import LinkAccountRep
from utils.protocol_pb2 import LinkAccountResultCode
from utils.protocol_pb2 import LoginAccountRep
from utils.protocol_pb2 import LoginAccountResultCode
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import SignType
from utils.protocol_pb2 import AppTransport
from utils.protocol_pb2 import VersionCheckResult
from utils.protocol_pb2 import SimpleResponse
from utils.protocol_pb2 import ResultCode
from utils.settings import APP_URL
from utils.settings import APP_TRANSPORT
from utils.settings import CUSTOM_RESOURCE_UPDATEER_PATH
from utils.settings import IS_PRODUCTION
from utils.settings import SESSION_TTL_DELTA
from utils.settings import DEVICE_CACHE_PN_TOKEN
from models.content import GameRule
from models.friend import Friend
from models.player import DeviceLink
from models.player import DevicePnToken
from models.player import Player
from models.player import Session
from models.active_player import ActivePlayerHelper
from models.split_test import SplitTestsManager
from models.gift import GiftInbox
from stats import DeltaSignIn, DeltaLinkAccount


class BaseAuth(object):
    os_type = OSType.Value("IOS")

    @property
    def player_index(self):
        raise NotImplementedError

    def get_player_by_pip(self, msg):
        val = msg.pip_id
        data = Player.load_by_attribute(self.player_index, val)
        return data and data[0]

    def get_player_by_device(self, device_id):
        device = DeviceLink(device_id=device_id)
        player_id = device.player_id
        if player_id:
            player = Player(id=player_id)
            return player
        return

    def generate_session(self, player_id, version):
        sessions = Session.load_by_attribute("player_id", player_id)
        for session in sessions:
            # delete previous session - avoid duplicate login.
            session.delete()
        session = Session(player_id=player_id)
        session.version = version
        session.store()
        session.refresh_session()
        return session

    def get_pip_id(self, msg):
        return msg.pip_id

    def player_details(self, msg):
        return {}

    def init_player(self, msg):
        # TODO - verify with 3rd party?
        kwargs = {"is_new": True,
                  self.player_index: self.get_pip_id(msg)}
        details = self.player_details(msg)
        if details:
            kwargs.update(details)
        player = Player(**kwargs)
        player.store()

        # init gift inbox
        kwargs = {"is_new": True,
                  "player_id": player.id}
        inbox = GiftInbox(**kwargs)
        inbox.store()

        #log.info("Create player with basic info: %s" % str(kwargs))
        return player


class BaseLogin(BaseAuth):
    """
    Login account.

    Possible Login cases:
        Only device_id
            1. There's no account with this device
                ==> Create account and login.
            2. There's account with this device
                ==> Do login.
        Device_id + PIP
            1. There's no account with this device and no account with the PIP
                ==> Create account and login.
            2. Device_id and PIP using same account
                ==> Do login.
            3. There's account with this device but no account with the PIP
                ==> Create new account for the PIP, and redirect device_id to
                    the new account.
            4. There's account with this PIP
                ==> Always make the device point to the PIP's account.

    Note:
    If there's pre_device_id
        1. There's no account with pre_device_id -> Ignore
        2. Otherwise -> update pre_device_id with device_id in DB.
    """

    def update_old_device_id(self, msg):
        if msg.pre_device_id and msg.pre_device_id != msg.device_id:
            device = DeviceLink(device_id=msg.pre_device_id)
            if device.exist():
                device.device_id = msg.device_id
                device.store()
                log.debug("Device %s updated to %s" %
                          (msg.pre_device_id, msg.device_id))
            if DEVICE_CACHE_PN_TOKEN:
                d_pn = DevicePnToken(device_id=msg.pre_device_id)
                if d_pn.exist():
                    d_pn.device_id = msg.device_id
                    d_pn.store()
                    log.debug("Pn_token updated.",
                              new_device=msg.device_id,
                              old_device_id=msg.pre_device_id)

    def update_device_player_id(self, device_id, player_id):
        device = DeviceLink(device_id=device_id)
        #log.info("Will redirect device(%s) from player(%s) to player(%s)" %
        #         (device_id, device.player_id, player_id))
        device.player_id = player_id
        device.store()

    def init_device_link(self, device_id, player_id):
        device = DeviceLink(device_id=device_id, player_id=player_id)
        #log.info("Device(%s) playing player(%s)" % (device_id, player_id))
        device.store()

    def update_player(self, player, msg):
        player.login_time = datetime.now()
        if msg.os_type:
            player.os_type = msg.os_type
        client_info = msg.client
        if client_info.utc_offset:
            player.utc_offset = client_info.utc_offset
        if client_info.timezone_name:
            player.timezone = client_info.timezone_name
        if not player.device_id and msg.device_id:
            player.device_id = msg.device_id

    def handle_login(self, msg):
        ip = msg.get('ip')
        data = {'player': {}, 'client': {'ip_address': ip}}
        version = msg.get("version")
        msg = msg.get('data')
        version = version or msg.client.client_version
        resp = LoginAccountRep()
        # update previous device_id to new device_id
        self.update_old_device_id(msg)
        device_player = self.get_player_by_device(msg.device_id)
        if msg.pip_id:
            pip_player = self.get_player_by_pip(msg)
            if device_player and device_player.exist():
                if pip_player and pip_player.exist():
                    player = pip_player
                    data['action'] = 'sign_in_device_pip'
                    if device_player.id != player.id:
                        # device not match pip player
                        # redirect device to pip player.
                        self.update_device_player_id(msg.device_id, player.id)
                        data['action'] = 'switch_device'
                else:
                    # create new account for pip and link device to it
                    player = self.init_player(msg)
                    self.update_device_player_id(msg.device_id, player.id)
                    data['action'] = 'sign_up_pip_switch_device'
            else:
                if pip_player and pip_player.exist():
                    player = pip_player
                    data['action'] = 'sign_in_pip'
                else:
                    # create new account
                    player = self.init_player(msg)
                    data['action'] = 'sign_up_pip'
                self.init_device_link(msg.device_id, player.id)
        elif msg.create_account:
            player = self.init_player(msg)
            if device_player and device_player.exist():
                self.update_device_player_id(msg.device_id, player.id)
            else:
                self.init_device_link(msg.device_id, player.id)
            data['action'] = 'sign_up_device_force'
        else:
            player = device_player
            data['action'] = 'sign_in_device'
            if not (player and player.exist()):
                # create new account
                player = self.init_player(msg)
                self.init_device_link(msg.device_id, player.id)
                data['action'] = 'sign_up_device'

        self.update_player(player, msg)
        player.store()
        session = self.generate_session(player.id, version)
        # update player details for log
        log.bind(player_id=player.id,
                session_id=session.id,
                os_type=player.os_type_name())
        a = ActivePlayerHelper()
        a.update(player)

        resp.session_id = session.id
        player.set_info(resp.player_info)
        resp.result_code = LoginAccountResultCode.Value("LOGIN_ACC_SUCCESS")

        # verify client version
        os_type = player.os_type or self.os_type
        try:
            bundle_v = int(msg.bundleVersion or 0)
        except ValueError, e:
            # very old client version, force them to update
            log.warn("Very old client version => force update")
            bundle_v = 0
        if bundle_v < GameRule.version.min_version(os_type):
            resp.versionCheck = VersionCheckResult.Value(
                "VERSION_CHECK_FORCEDUPGRADE")
        elif bundle_v < GameRule.version.recommend_version(os_type):
            resp.versionCheck = VersionCheckResult.Value(
                "VERSION_CHECK_RECOMMENDEDUPGRADE")
        else:
            resp.versionCheck = VersionCheckResult.Value(
                "VERSION_CHECK_SUCCESS")
        data['player']['session'] = session.id
        if player.facebook_id: data['player']['facebook_id'] = player.facebook_id
        if player.agc_id: data['player']['agc_id'] = player.agc_id
        if player.gp_id: data['player']['gp_id'] = player.gp_id
        return resp, (DeltaSignIn, data, player, msg.client)


class BaseLinkAccount(BaseAuth):
    """
    Link PIP account to player data.

    Possible cases:
        1. There's no account with this device.
            ==> Return error code.
        2. Account with this device is same with account with the PIP
            ==> Do noting. Return result_code saying already linked.
        3. Account with this device has no PIP, and on account with the PIP
            ==> Do Link.
        4. Account's PIP with this device is different from PIP
            4.1 There's no account with the PIP
                ==> Return result_code: LINK_ACC_DIFFERENT_PIP_NEW_PIP.
            4.2 There's another account with the PIP
                ==> Return result_code: LINK_ACC_DIFFERENT_PIP
    """

    def handle_link(self, player_id, msg, resp):
        device_player = self.get_player_by_device(msg.device_id)
        if device_player is None:
            # LINK_ACC_DEVICE_ID_NOT_EXIST
            return LinkAccountResultCode.Value("LINK_ACC_OTHER")
        if device_player.id != player_id:
            # LINK_ACC_PLAYER_NOT_MATCH
            return LinkAccountResultCode.Value("LINK_ACC_OTHER")

        player = self.get_player_by_pip(msg)
        if player:
            if player.id == device_player.id:
                # LINK_ACC_ALREADY_LINKED
                result = LinkAccountResultCode.Value("LINK_ACC_OTHER")
            else:
                resp.level = player.level
                resp.gems = player.gems
                resp.login_time = datetime_to_int(player.login_time)
                result = LinkAccountResultCode.Value("LINK_ACC_DIFFERENT_PIP")
        elif device_player.get(self.player_index):
            # LINK_ACC_DIFFERENT_PIP_NEW_PIP
            resp.level = GameRule.player.default.get("attr", {}).get("level")
            resp.gems = GameRule.player.default.get("attr", {}).get("gems")
            resp.login_time = -1
            result = LinkAccountResultCode.Value("LINK_ACC_DIFFERENT_PIP")
        else:
            # Do link -> LINK_ACC_SUCCESS
            setattr(device_player, self.player_index, msg.pip_id)
            device_player.store()
            #log.info("Link %s(%s) to player(id:%s)" %
            #         (self.player_index, msg.pip_id, device_player.id))
            result = LinkAccountResultCode.Value("LINK_ACC_OTHER")
        return result


class BaseAGC(BaseAuth):

    @property
    def player_index(self):
        return "agc_id"


class AGCLogin(BaseLogin, BaseAGC):
    pass


class LinkAGC(BaseLinkAccount, BaseAGC):
    pass


class BaseGoogle(BaseAuth):
    os_type = OSType.Value("Android")

    @property
    def player_index(self):
        return "gp_id"


class GoogleLogin(BaseLogin, BaseGoogle):

    def player_details(self, msg):
        details = super(GoogleLogin, self).player_details(msg)
        if msg.account:
            details["gp_email"] = msg.account
        return details

    def get_player_by_pip(self, msg):
        p = super(GoogleLogin, self).get_player_by_pip(msg)
        if not (p and p.exist()) and msg.account:
            p = Player.load_by_attribute(self.player_index, msg.account)
            p = p and p[0]
            if p and msg.pip_id:
                # update gp_id for older account
                setattr(p, self.player_index, msg.pip_id)
        return p

    def update_player(self, player, msg):
        super(GoogleLogin, self).update_player(player, msg)
        if msg.account and player.gp_email != msg.account:
            player.gp_email = msg.account


class LinkGoogle(BaseLinkAccount, BaseGoogle):
    pass


class BaseFacebook(BaseAuth):

    @property
    def player_index(self):
        return "facebook_id"


class FacebookLogin(BaseLogin, BaseFacebook):
    pass


class LinkFacebook(BaseLinkAccount, BaseFacebook):
    pass


class BaseDevice(BaseAuth):

    @property
    def player_index(self):
        return "device_id"


class DeviceLogin(BaseLogin, BaseDevice):

    def get_pip_id(self, msg):
        return msg.device_id


class Account(ParentActor):
    login_map = {SignType.Value("APPLE"): AGCLogin(),
                 SignType.Value("GOOGLE"): GoogleLogin(),
                 # SignType.Value("FACEBOOK"): FacebookLogin(),
                 SignType.Value("DEVICE"): DeviceLogin(),
                 }

    def LoginAccount(self, msg):
        """
        Process login and generate session_id.

        @param msg: LoginAccount - with device_id, sign_type, pip_id, sign_info
                                   and client_info.
        @return: LoginAccountRep - with session_id, player_info, content
        """
        data = msg.get('data')
        version = self.version(msg) or data.client.client_version
        log_param = {"version": version,
                     "request_id": self.request_id(msg)}
        log.bind(**log_param)
        #log.info("Login account receive %s" % data)
        handler = self.login_map.get(data.type)
        if handler:
            resp, event = handler.handle_login(msg)
            player = event[2]
            log_param["os_type"] = player.os_type_name()
            # add content into login resp
            resp.global_configs.CopyFrom(GameRule.configs_proto)
            resp.global_configs.resourceUpdaterPath = GameRule.asset_version.get_url(msg.get('version'))
            # modify configs for beta:
            if not IS_PRODUCTION and CUSTOM_RESOURCE_UPDATEER_PATH is not None:
                   resp.global_configs.resourceUpdaterPath = CUSTOM_RESOURCE_UPDATEER_PATH
            SplitTestsManager.global_config_test(player, resp.global_configs)

            # update helpers
            friend = Friend(player_id=player.id)
            resp.helpers.extend(friend.get_helpers())
            # update event configs
            player.get_event_proto(resp.eventsConfigs)

            self.send_event(*event)
        else:
            resp = LoginAccountRep()
            if data.type in SignType.values():
                resp.result_code = LoginAccountResultCode.Value(
                    "LOGIN_ACC_DISABLED_SIGN_TYPE")
            else:
                resp.result_code = LoginAccountResultCode.Value(
                    "LOGIN_ACC_MISSING_SIGN_TYPE")

            # add content into login resp
            resp.global_configs.CopyFrom(GameRule.configs_proto)
        # update gacha_trees in handle_login to avoid load player?
        pid = resp.player_info.userId
        utc_offset = Player(id=pid).utc_offset or 0
        resp.gacha_trees.extend(GameRule.get_gacha(utc_offset).slugs)
        resp.app_url_config.APP_URL = APP_URL
        resp.app_url_config.transport = AppTransport.Value(APP_TRANSPORT)
        resp.session_ttl = SESSION_TTL_DELTA
        return self.resp(resp)


class UpdateAccount(ChildActor):
    link_acc_map = {SignType.Value("APPLE"): LinkAGC(),
                    SignType.Value("GOOGLE"): LinkGoogle(),
                    SignType.Value("FACEBOOK"): LinkFacebook(),
                    }

    @MessageHandlerWrapper(LinkAccountRep, LinkAccountResultCode.Value(
        "LINK_ACC_OTHER"))
    def LinkAccount(self, msg, *args, **kwargs):
        """
        Link the pip_id to account.

        @param msg: LinkAccount - with device_id, pip_id and sign_type
        @return: LinkAccountRep
        Note: Only support linking pip_id to account never binding specified
              pip_id.
        """
        #log.info("Link account receive %s" % msg)
        resp = LinkAccountRep()
        link_handler = self.link_acc_map.get(msg.type)
        if link_handler and msg.device_id:
            result = link_handler.handle_link(self.parent.pid, msg, resp)
            resp.result_code = result
            event_data = {'player': {}, 'client': {'ip_address': self.ip}}
            self.send_event(DeltaLinkAccount, event_data, self.parent.player)
        else:
            resp.result_code = LinkAccountResultCode.Value("LINK_ACC_OTHER")
        return self.resp(resp)

    @MessageHandlerWrapper(SimpleResponse, ResultCode.Value(
        "INVALID_SESSION"))
    def AccountAdditional(self, msg, *args, **kwargs):
        resp = SimpleResponse()
        return self.resp(resp)
