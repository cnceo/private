import urllib
import time
from utils.gevent_actor import GeventActorWrapper
from utils.misc import check_actor_qsize
from utils import settings
from utils.log import log


def send_kochava_installs(func, msg, user_agent):
    if not settings.IS_PRODUCTION:
        pass
        #return
    if func != 'LoginAccount':
        return

    data = {
        'origination_ip': msg['ip'],
        'device_ua': user_agent,
    }

    client = msg['data'].client
    if client.device_os.lower() == 'android':
        data['device_id'] = client.android_ifa
        data['device_id_type'] = 'idfa'
        data['app_id'] = settings.KOCHAVA_ANDROID_APP_ID
    elif client.device_os.lower() == 'ios':
        data['device_id'] = client.ios_ifa
        data['device_id_type'] = 'idfa'
        data['app_id'] = settings.KOCHAVA_IOS_APP_ID
    else:
        return

    if not data['device_id']: return

    actor = KochavaInstallActor.get()
    actor.tell(data)


class KochavaInstallActor(GeventActorWrapper):
    """
    Gether the device info and send to Kochava for tracking installs
        - receive events by tell this actor
        - accept json format
    """

    def __init__(self):
        super(KochavaInstallActor, self).__init__()

    def on_receive(self, msg):
        # TODO - validate data & send
        log.bind(msg_=msg, qsize=check_actor_qsize(self))
        try:
            self.do_send(msg)
        except Exception as e:
            log.critical("KochavaInstallActor exception: {exception}".format(exception=repr(e), **locals()), msg=msg, exc_info=e)

    def do_send(self, data):
        url = settings.KOCHAVA_INSTALL_URL % data
        log.bind(url=url)
        self.retry_send(url)

    def retry_send(self, url):
        retry = 0
        while retry < 5:
            retry += 1
            r = urllib.urlopen(url)
            #print retry, url
            if r.code == 200:
                #print 'OK'
                log.info('Send Kochava Install: %s, %s' % (retry, url))
                break
            time.sleep(2)

    def _stop_sender(self):
        #TODO: keep sending, until the self queue is empty
        pass

    def on_stop(self):
        super(KochavaInstallActor, self).on_stop()
        self._stop_sender()

    def on_failure(self, exception_type, exception_value, traceback):
        super(KochavaInstallActor, self).on_failure(exception_type, exception_value,
                                           traceback)
        self._stop_sender()
