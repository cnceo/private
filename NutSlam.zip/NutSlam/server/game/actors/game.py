#!/usr/bin/python

import os, sys
import random
import simplejson
from utils import protocol_pb2 as proto

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from base_actor import ChildActor
from base_actor import MessageHandlerWrapper
from models.reward import BattleReward
from models.content import GameRule
from models.creature import CollectionState
from models.creature import CreatureTeam
from models.creature import CreatureInstance
from models.creature import CreatureState
from models.creature import Nuts
from models.creature import StartupTeams
from models.free_nut import DailyWarnut
from models.free_nut import FreeAkorn
from models.friend import Friend
from models.player import Player
from models.player import RecentlyHelper
from models.player import PassedDungeons
from models.player import GatchaCounter
from utils.constants import TRANS_TYPE
from utils.misc import get_time_key, verify_time_key
from utils.protocol_pb2 import AddEnergyRep
from utils.protocol_pb2 import AddEnergyResultCode
from utils.protocol_pb2 import BattleBeginRepResultCode
from utils.protocol_pb2 import BattleEndRepResultCode
from utils.protocol_pb2 import BuyCreatureSpaceRep
from utils.protocol_pb2 import BuyCreatureSpaceResultCode
from utils.protocol_pb2 import BuyMaterialsRep
from utils.protocol_pb2 import BuyMaterialResultCode
from utils.protocol_pb2 import BuyNutRep
from utils.protocol_pb2 import BuyNutResultCode
from utils.protocol_pb2 import ClaimCollectionRewardRep
from utils.protocol_pb2 import ClaimCollectionRewardResultCode
from utils.protocol_pb2 import CollectedCreatureState
from utils.protocol_pb2 import ConvertMaterialRep
from utils.protocol_pb2 import ConvertMaterialResultCode
from utils.protocol_pb2 import EditTeamRep
from utils.protocol_pb2 import EditTeamRepResultCode
from utils.protocol_pb2 import Element
from utils.protocol_pb2 import GachaShakeResultCode
from utils.protocol_pb2 import GetCollectionsRep
from utils.protocol_pb2 import GetCollectionsResultCode
from utils.protocol_pb2 import OpenNutRep
from utils.protocol_pb2 import OpenNutResultCode
from utils.protocol_pb2 import RenewalRep
from utils.protocol_pb2 import RenewalResultCode
from utils.protocol_pb2 import SimpleResponse
from utils.protocol_utils import assign_value
from utils.settings import MAX_GACHA_AMOUNT
from utils.settings import ENABLE_TEAM_ELEMENT_VERIFY
from stats import DeltaBattleBegin, DeltaBattleEnd, DeltaBattleEndDrop, \
                  DeltaEditTeam, DeltaGacha, DeltaAddEnergy,\
                  DeltaConvertMaterial, DeltaBuyCreatureSpace, DeltaRenewal, \
                  DeltaSignOff, DeltaPutBackground, DeltaBringFront, \
                  DeltaOpenNut, DeltaBuyNut

from utils.log import log


class Game(ChildActor):
    # ======================
    # content
    # ======================
    def RetrieveWorld(self, msg, *args):
        utc_offset = self.parent.player_utc_offset
        return self.resp(GameRule.get_world(utc_offset).proto)

    def RetrieveCreatureType(self, msg, *args):
        return self.resp(GameRule.creature_types.proto)

    def GetGlobalConfigs(self, msg, *args):
        return self.resp(GameRule.configs_proto)

    def GachaTrees(self, msg, *args):
        rep = proto.GachaTreesRep()
        utc_offset = self.parent.player_utc_offset
        rep.tree_slugs.extend(GameRule.get_gacha(utc_offset).slugs)
        return self.resp(rep)

    def GetEventsConfigs(self, msg, *args):
        return self.resp(self.parent.player.get_event_proto())

    def StartupTeams(self, msg, *args):
        rep = proto.EditTeamRep()
        StartupTeams.save(self.parent.pid, msg.chosen)
        rep.result_code = EditTeamRepResultCode.Value('EDIT_TEAM_SUCCESS')
        return self.resp(rep)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def LogoffAccount(self, msg, *args):
        rep = proto.SimpleResponse()
        rep.result_code = proto.ResultCode.Value('SUCCESS')
        event_data = {'player': {'session': self.session_id(),
                                 'id': self.parent.pid}}
        player = self.parent.player
        self.send_event(DeltaSignOff, event_data, player)
        return self.resp(rep)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def PutBackgroundAccount(self, msg, *args):
        rep = proto.SimpleResponse()
        rep.result_code = proto.ResultCode.Value('SUCCESS')
        event_data = {'player': {'session': self.session_id(),
                                 'id': self.parent.pid}}
        self.send_event(DeltaPutBackground, event_data, self.parent.player)
        return self.resp(rep)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def BringFrontAccount(self, msg, *args):
        rep = proto.SimpleResponse()
        rep.result_code = proto.ResultCode.Value('SUCCESS')
        event_data = {'player': {'session': self.session_id(),
                                 'id': self.parent.pid}}
        self.send_event(DeltaBringFront, event_data, self.parent.player)
        return self.resp(rep)

    @MessageHandlerWrapper(proto.BattleBeginRep,
                           BattleBeginRepResultCode.Value("BATTLE_BEGIN_INVALID_SESSION"))
    def BattleBegin(self, msg, *args):
        """
        verify the requirment, generate the reward, consume the energy
        :param msg:
            - dungeonID: the dungeon to play
            - leader_id: the leader creature id of active team
        :return:
            - BattleBeginRep
        """
        rep = proto.BattleBeginRep()
        pid = self.parent.pid
        player = self.parent.player
        event_data = {'player': {'session': self.session_id()}}

        def _error_resp(result_code, log_msg):
            return self.error_resp(rep, BattleBeginRepResultCode,
                                   result_code, log_msg)

        world = GameRule.get_world(self.parent.player_utc_offset)
        if msg.dungeonID not in world.activate_dungeon_ids:
            l_msg = ("select dungeon: %s, all dungeons: %s" %
                     (msg.dungeonID, world.activate_dungeon_ids))
            return _error_resp('BATTLE_BEGIN_UNKNOWN_DUNGEON', l_msg)
        passed_dungeons = PassedDungeons(player_id=pid).ids or []
        if msg.dungeonID in passed_dungeons and \
           msg.dungeonID in world.bonus_dungeon_ids:
            l_msg = ("select dungeons: %s, bonus dungeons: %s" %
                     (msg.dungeonID, world.bonus_dungeon_ids))
            pass
            #return _error_resp("BATTLE_BEGIN_BONUS_PLAYED", l_msg)
        dungeon = world.dungeons[msg.dungeonID]
        p_energy = player.get_energy()
        d_energy = dungeon['requirement']['energy']
        if not player.verify_energy(d_energy):
            l_msg = ("Owned energy: %s, required energy: %s" %
                     (p_energy, d_energy))
            return _error_resp('BATTLE_BEGIN_FAIL_ENERGY', l_msg)
        if player.progress < dungeon['requirement']['progress']:
            l_msg = ("Current progress: %s, required progress: %s" %
                     (player.progress, dungeon['requirement']['progress']))
            return _error_resp('BATTLE_BEGIN_FAIL_PROGRESS', l_msg)
        if not CreatureInstance(player_id=pid, cid=msg.leader_id).exist():
            l_msg = "Leader id: %s" % msg.leader_id
            return _error_resp('BATTLE_BEGIN_LEADER_NOT_EXIST', l_msg)
        c_num = len(CreatureInstance.load_oids_by_attribute('player_id', pid))
        if player.max_creatures < c_num:
            l_msg = "creatures: %s/%s" % (c_num, player.max_creatures)
            return _error_resp('BATTLE_BEGIN_CAMP_BEYOND_SIZE', l_msg)
        last_boss = ()
        # if there is a reward already, overwrite it
        battle_reward = BattleReward(player_id=pid)
        battle_reward.clear()
        battle_reward.progress = dungeon['reward']['progress']
        battle_reward.dungeon_id = msg.dungeonID
        # get enemies and bosses
        enemies = []
        for wave in dungeon['waves']:
            for enemy in wave['enemies']:
                enemies.append(enemy)
            if wave['boss'] and wave['boss']['slug'] != "":
                last_boss = (wave['boss'],)

        # generate battle end reward
        xp = dungeon['reward']['xp']
        if msg.dungeonID in passed_dungeons:
            xp = 0
        rep.xp = xp
        rep.coins = dungeon['reward']['softCurrency']
        battle_reward.xp = rep.xp
        battle_reward.coins = rep.coins

        # generate eggs need to drop
        for egg in dungeon['reward']['eggs_enemy']:
            battle_reward.drop_egg(enemies, egg, rep.enemy_egg, repeated=True)
        if last_boss:
            for egg in dungeon['reward']['eggs_boss']:
                battle_reward.drop_egg(last_boss, egg, rep.boss_egg, repeated=True)
        else:
            last_boss = (enemies[-1],)

        eggs_clearance = dungeon['reward']['eggs_clearance']
        battle_reward.drop_clearance_egg(last_boss, eggs_clearance,
                                         rep.clear_egg)

        # remove boss egg, make speed, luck do not drop boss egg
        battle_reward.remove_self_egg(eggs_clearance)

        battle_reward.drop_speed_egg(last_boss, eggs_clearance,
                                     dungeon['speed_clearance'], rep.speed_egg)
        battle_reward.drop_luck_egg(last_boss, eggs_clearance, pid,
                                    msg.leader_id, rep.luck_egg, msg.dungeonID)
        battle_reward.drop_dungeon_egg(dungeon['reward']['eggs_map'],
                                       rep.dungeon_egg)

        # Update player hearts.
        friend = Friend(player_id=self.parent.pid)
        h_id = msg.helper_id
        reward_hearts = 0
        if h_id and h_id != self.parent.pid and Player(id=h_id).exist():
            h = RecentlyHelper(self.parent.pid, msg.helper_id)
            if not h.exist():
                reward_hearts, ttl = friend.get_social_reward(h_id)
                h.store(ttl)
                rep.reward_hearts = reward_hearts

        if not player.verify_energy(d_energy):
            p_energy = player.get_energy()
            l_msg = ("Owned energy: %s, required energy: %s" %
                     (p_energy, d_energy))
            return _error_resp('BATTLE_BEGIN_FAIL_ENERGY', l_msg)
        player.spend_energy(d_energy, do_store=True)
        battle_key = get_time_key()
        battle_reward.hearts = reward_hearts
        battle_reward.key = battle_key
        battle_reward.helper_id = h_id
        battle_reward.store()
        rep.battle_key = battle_key

        event_data['zone'] = msg.zoneSlug
        event_data['area'] = msg.areaSlug
        event_data['dungeon'] = msg.dungeonID
        event_data['battle_key'] = battle_key
        event_data['hearts'] = reward_hearts
        event_data['energy'] = dungeon['requirement']['energy']

        self.send_event(DeltaBattleBegin, event_data, player)

        rep.result_code = proto.BattleBeginRepResultCode.Value('BATTLE_BEGIN_SUCCESS')
        return self.resp(rep)

    @MessageHandlerWrapper(proto.BattleEndRep,
                           BattleEndRepResultCode.Value("BATTLE_END_INVALID_SESSION"))
    def BattleEnd(self, msg, *args):
        """
        verify the result, generate the reward, consume the energy
        :param msg:
            - dungeonID: the dungeon to play
            - battle_key: the key of the battle begin
            - turns: how many turns to finish battle
            - win: if win or not
            - helper_id: use which player as the helper
        :return:
            - BattleEndRep
        """
        player_id = self.parent.pid
        rep = proto.BattleEndRep()
        end_event_data = {
            'player': {'session': self.session_id(),
                       'id': player_id},
            'zone': msg.zoneSlug,
            'area': msg.areaSlug,
            'dungeon': msg.dungeonID,
            'battle_key': msg.battle_key,
            'turns': msg.turns,
            'cid1': 1 or msg.team.creaturesIds[0],
            'cid2': 1 or msg.team.creaturesIds[1],
            'cid3': 1 or msg.team.creaturesIds[2],
            'helper_id': 1 or msg.helper_id,
            'helper_level': 1 or msg.helper_level,
            'helper_creature_slug': '1' or msg.helper_creature_slug,
            'helper_creature_level': 1 or msg.helper_creature_level,
        }

        def _error_resp(result_code, log_msg):
            return self.error_resp(rep, BattleEndRepResultCode,
                                   result_code, log_msg)

        player = self.parent.player
        reward = BattleReward(player_id=player_id)
        # verify the result
        if not reward.key or (msg.win and not verify_time_key(reward.key)):
            end_event_data['result_code'] = "TIME_WRONG"
            self.send_event(DeltaBattleEnd, end_event_data, player)
            l_msg = "Reward key: %s, client: %s" % (reward.key, msg.battle_key)
            return _error_resp('BATTLE_END_KEY_FAILED', l_msg)
        if (reward.player_id is None or reward.dungeon_id != msg.dungeonID
                or reward.key != msg.battle_key):
            end_event_data['result_code'] = "NOT_FOUND"
            self.send_event(DeltaBattleEnd, end_event_data, player)
            data = {"reward_player_id": reward.player_id,
                    "dungeon_id": {"client": msg.dungeonID,
                                   "server": reward.dungeon_id},
                    "battle_key": {"client": msg.battle_key,
                                   "server": reward.key}}
            return _error_resp("BATTLE_END_UNKNOWN_BATTLE",
                               "Info %s" % simplejson.dumps(data))
        if msg.win:
            # pay the reward to player
            pay_data = reward.pay(msg.turns, player, msg.skippedEggs)
            drops = pay_data.pop('drops')
            drop_event_data = {'player': {'session': self.session_id(),
                                          'id': player_id},
                               'battle_key': msg.battle_key,
                               'drops': drops
            }
            end_event_data['result_code'] = 'WIN'
            end_event_data.update(pay_data)
            rep.result_code = proto.BattleEndRepResultCode.Value(
                'BATTLE_END_SUCCESS_WIN')
            self.send_event(DeltaBattleEndDrop, drop_event_data, player)

            # delete unchoosen startup teams
            if msg.dungeonID == 100:
                cid = msg.team.creaturesIds and msg.team.creaturesIds[0]
                StartupTeams.delete(player.id, cid)
        else:
            rep.result_code = proto.BattleEndRepResultCode.Value(
                'BATTLE_END_SUCCESS_LOSE')
            end_event_data['result_code'] = "LOSE"

        friend = Friend(player_id=player_id)
        player.store()
        reward.delete()
        helpers = friend.get_helpers()
        rep.helpers.extend(helpers)
        self.send_event(DeltaBattleEnd, end_event_data, player)

        # TODO - filter out impossible seen creatures
        for c_slug in msg.seen_creature_types:
            if c_slug:
                c_t = CreatureState(player_id=player_id, slug=c_slug)
                if not c_t.exist():
                    c_t.store()
        return self.resp(rep)

    @MessageHandlerWrapper(EditTeamRep, EditTeamRepResultCode.Value(
        "EDIT_TEAM_INVALID_SESSION"))
    def Teams(self, msg, *args):
        """
        Edit player's team.

        @param msg: EditTeam - with all teams to be saved.
        @return: EditTeamRep.
        Note: Team can't have duplicate creature id.
              The 1st team's 1st creature will be the helper creature.
        """
        rep = proto.EditTeamRep()
        player_id = self.parent.pid
        event_data = {
            'player': {'session': self.session_id(),
                       'id': player_id},
        }

        def _error_resp(result_code, log_msg):
            return self.error_resp(rep, EditTeamRepResultCode,
                                   result_code, log_msg)

        teams = CreatureTeam.get_proto_class(player_id)
        if teams != msg:
            player_cids = CreatureInstance.load_oids_by_attribute("player_id",
                                                                  player_id)
            for ele, team in zip(range(len(msg.team)), msg.team):
                cid_list = list(team.creaturesIds)
                for cid in cid_list[0:]:
                    cid_list.remove(cid)
                    if cid == 0:
                        continue
                    if cid in cid_list:
                        # There's duplicate cid in one team
                        l_msg = "team: %s" % team.creaturesIds
                        return _error_resp("EDIT_TEAM_SAME_TEAM_DUPLICATE_CID",
                                           l_msg)
                    if cid not in player_cids:
                        l_msg = ("not exist cid:%s player creatures: %s" %
                                 (cid, player_cids))
                        return _error_resp("EDIT_TEAM_CREATURE_NOT_EXIST", l_msg)
                    if (ENABLE_TEAM_ELEMENT_VERIFY and cid and ele and
                            ele in Element.values()):
                        c = CreatureInstance(cid=cid, player_id=player_id)
                        if c.element != ele:
                            l_msg = ("cid: %s element: %s, expected element %s"
                                     % (cid, c.element, ele))
                            return _error_resp("EDIT_TEAM_ELEMENT_NOT_MATCH",
                                               l_msg)
            teams = CreatureTeam.store_from_proto(player_id, msg)
            event_data['teams'] = teams
            self.send_event(DeltaEditTeam, event_data, self.parent.player)
        rep.result_code = EditTeamRepResultCode.Value('EDIT_TEAM_SUCCESS')
        return self.resp(rep)


    @MessageHandlerWrapper(OpenNutRep,
                           OpenNutResultCode.Value("OPEN_NUT_INVALID_SESSION"))
    def OpenNut(self, msg, *args):
        """
        Generate(gacha) the creature from nut and return.

        @param msg:
            - nut_id: the nut id planning to open.
        @return:
            - succeed: OpenNutRep with creatureInstance & suspenseCount.
            - failed: response with error code.
        """
        resp = OpenNutRep()
        player_id = self.parent.pid
        event_data = {
            'player': {'session': self.session_id(),
                       'id': player_id},
        }

        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, OpenNutResultCode,
                                   result_code, log_msg)

        def _wrapper_resp(cr):
            creature = resp.creature.add()
            cr.to_proto_class(creature)
            resp.suspense_factor = random.uniform(0.5, 1.5)

        for nut_id in msg.nut_id:
            if not nut_id:
                l_msg = "no nut id specified."
                return _error_resp("OPEN_NUT_MISSING_TARGET", l_msg)

            nut = Nuts(player_id=player_id, cid=nut_id)
            if not nut.exist():
                c = CreatureInstance(player_id=player_id, cid=nut_id)
                if c.exist():
                    _wrapper_resp(c)
                    result = "NUT_ALREADY_OPENED"
                    l_msg = "Nut(%s) already opened." % nut_id
                else:
                    all_nuts = Nuts.load_oids_by_attribute("player_id", player_id)
                    log.bind(owned_nuts=all_nuts)
                    result = "NUT_NOT_EXIST"
                    l_msg = "Nut(%s) not exist." % nut_id
                return _error_resp(result, l_msg)

            # open nut
            c = nut.open()
            _wrapper_resp(c)
            event_data['cid'] = nut.cid
            event_data['slug'] = nut.slug
            event_data['ntype'] = nut.nut
            self.send_event(DeltaOpenNut, event_data, self.parent.player)
        player = self.parent.player
        if not player.gatcha_pulled:
            player.gatcha_pulled = True
            player.store()
        resp.result_code = OpenNutResultCode.Value("OPEN_SUCCESS")
        return self.resp(resp)


    @MessageHandlerWrapper(BuyNutRep,
                           BuyNutResultCode.Value("BUY_NUT_INVALID_SESSION"))
    def BuyNut(self, msg, *args):
        """
        @param msg:
            - tree_slug: need drop which nut.
            - count: how many nuts to drop.
        @Return:
            - succeed: a list of nuts.
            - failed: response with error code.
        """
        resp = BuyNutRep()

        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, BuyNutResultCode, result_code,
                                   log_msg)

        t_slug = msg.tree_slug
        count = msg.count
        if not count or count < 1:
            l_msg = "Invalid count %s, slug: %s" % (count, t_slug)
            return _error_resp("BUY_NUT_MISSING_COUNT", l_msg)

        player_id = self.parent.pid
        player = self.parent.player
        utc_offset = player.utc_offset
        new_g = GameRule.get_new_gacha(utc_offset)
        tree = new_g.get_gacha_tree(t_slug)
        if not tree:
            l_msg = ("slug: %s, utc_offset: %s, valid slugs: %s" %
                     (t_slug, utc_offset, new_g.tree_slugs))
            return _error_resp("BUY_NUT_INVALID_TREE_SLUG", l_msg)

        event_data = {
            'player': {'session': self.session_id(),
                       'id': player_id},
        }
        cost = tree.cost
        free_t = None
        if cost:
            # @cost: gems/hearts
            required = tree.price * count
            v_func = getattr(player, "verify_%s" % cost)
            if not v_func(required):
                owned = player.get(cost)
                l_msg = ("Owned %s: %s, required %s: %s" %
                         (cost, owned, cost, required))
                return _error_resp("BUY_NUT_NOT_ENOUGH_%s" % cost.upper(),
                                   l_msg)
            func = getattr(player, "update_%s" % cost)
            detail = {"nut": tree.slug, "count": count}
            func(-required, TRANS_TYPE.GACHA, **detail)
        else:
            # free nuts
            count = 1
            if tree.tree_type == DailyWarnut.tree_type:
                free_t = DailyWarnut(player_id, utc_offset)
                ttl = free_t.ttl()
            else:
                free_t = FreeAkorn(player_id=player_id)
                ttl = free_t.ttl(tree.ttl)
            if ttl > 0:
                l_msg = ("Need wait %s seconds for free nuts, tree_slug: %s" %
                         (ttl, t_slug))
                return _error_resp("BUY_NUT_CLAIM_NOT_AVAILABLE", l_msg)
        for _ in range(count):
            nut = Nuts.generate(player_id, tree.slug)
            nut.to_proto_class(resp.egg.add())

            event_data['cid'] = nut.cid
            event_data['ntype'] = msg.tree_slug
            event_data['cost'] = cost
            event_data['price'] = tree.price

            self.send_event(DeltaBuyNut, event_data, self.parent.player)
        # update player or free_nut info.
        if free_t:
            free_t.store()
        else:
            player.store()
        resp.result_code = BuyNutResultCode.Value("BUY_NUT_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(proto.GachaShakeRep,
                           proto.GachaShakeResultCode.Value("GACHA_SHAKE_INVALID_SESSION"))
    def GachaShake(self, msg, *args):
        """
        return a creature egg from gachas
        :param msg:
            - tree_slug: need to drop from which gacha list
            - is_big: drop 10 eggs if True else 1
        :return:
            - GachaShakeResult
        """
        rep = proto.GachaShakeRep()
        event_data = {
            'player': {'session': self.session_id(),
                       'id': self.parent.pid},
        }

        def _error_resp(result_code, log_msg):
            return self.error_resp(rep, GachaShakeResultCode,
                                   result_code, log_msg)

        utc_offset = self.parent.player_utc_offset
        gacha = GameRule.get_gacha(self.parent.player_utc_offset)
        if not gacha.valid_tree_slug(msg.tree_slug):
            l_msg = ("slug: %s, utc_offset: %s, valid slugs: %s" %
                     (msg.tree_slug, utc_offset, gacha.slugs))
            return _error_resp("GACHA_SHAKE_INVALID_TREE_SLUG", l_msg)
        gacha_type = gacha.type(msg.tree_slug)
        gacha_price = GameRule.prices.gacha(gacha_type)
        player = self.parent.player
        big_amount = MAX_GACHA_AMOUNT
        if "social" == gacha_type:
            big_amount = min(big_amount, player.hearts / gacha_price)
        amount = big_amount if msg.is_big else 1
        # consume gems or hearts
        consumes = gacha_price * amount
        # verify
        if gacha_type == 'premium' and not player.verify_gems(consumes):
            l_msg = ("Owned gems: %s, required gems: %s" %
                     (player.gems, consumes))
            return _error_resp("GACHA_SHAKE_NOT_ENOUGH_GEMS", l_msg)

        if gacha_type == 'social' and not player.verify_hearts(consumes):
            l_msg = ("Owned hearts: %s, required hearts: %s" %
                     (player.hearts, consumes))
            return _error_resp("GACHA_SHAKE_NOT_ENOUGH_HEARTS", l_msg)

        # generate eggs
        event_data['is_big'] = True if msg.is_big else False
        event_data['gacha_type'] = gacha_type
        event_data['cost'] = gacha_price
        event_data['timestamp'] = get_time_key()

        e = rep.egg.add()
        key = GatchaCounter(self.parent.pid, msg.tree_slug).get_key()
        data = GameRule.gacha(key, msg.tree_slug, utc_offset)
        assign_value(e, data)
        c_data = data['creature']
        slug = c_data.pop("slug", None)
        c = Nuts.create(self.parent.pid, slug, auto_open=True, **c_data)
        c.to_proto_class(e.creature)
        event_data['creature'] = c.get_stats_data()
        self.send_event(DeltaGacha, event_data, self.parent.player)

        # consume currency
        details = {"creature_slug": event_data["creature"].get("slug")}
        if gacha_type == 'premium':
            player.update_gems(-consumes, TRANS_TYPE.GACHA, **details)
        if gacha_type == 'social':
            player.update_hearts(-consumes, TRANS_TYPE.GACHA, **details)

        player.gatcha_pulled = True
        player.store()
        rep.result_code = proto.GachaShakeResultCode.Value("GACHA_SHAKE_SUCCESS")

        return self.resp(rep)

    @MessageHandlerWrapper(AddEnergyRep, AddEnergyResultCode.Value(
        "ADD_ENERGY_INVALID_SESSION"))
    def AddEnergy(self, msg, *args):
        """
        Spend gems to add energy.

        @param msg: AddEnergy.
        @return: AddEnergyRep.
        Note: will add max_energy each time.
        """
        resp = AddEnergyRep()
        event_data = {
            'player': {'session': self.session_id(),
                       'id': self.parent.pid},
        }
        player = self.parent.player
        consume_gems = GameRule.prices.refill_energy()
        if not player.verify_gems(consume_gems):
            l_msg = ("Owned gems: %s, required gems: %s" %
                     (player.gems, consume_gems))
            return self.error_resp(resp, AddEnergyResultCode,
                                   "ADD_ENERGY_NOT_ENOUGH_GEMS", l_msg)
        details = {"orig_energy": player.energy,
                   "level": player.level}
        player.add_energy()
        details["new_energy"] = player.energy
        player.update_gems(-consume_gems, TRANS_TYPE.REFILL_ENERGY, **details)
        player.store()
        log.info("Consume %s gems to buy %s energy." %
                 (consume_gems, player.get_max_energy()))
        event_data['gems_cost'] = consume_gems
        self.send_event(DeltaAddEnergy, event_data, player)
        resp.result_code = AddEnergyResultCode.Value("ADD_ENERGY_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(ConvertMaterialRep, ConvertMaterialResultCode.Value(
        "CONVERT_INVALID_SESSION"))
    def ConvertMaterial(self, msg, *args):
        """
        Convert material.

        @param msg: ConvertMaterial with from_slug, to_slug and amount of 'to'.
        @return: ConvertMaterialRep.
        Note: Only support convert low-level material to high-level ones now.
        """
        resp = ConvertMaterialRep()

        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, ConvertMaterialResultCode,
                                   result_code, log_msg)
        t_m = msg.to_slug
        amount = msg.amount
        l_msg = "Want to convert to get: %s amount: %s" % (t_m, amount)
        if not t_m:
            return _error_resp("CONVERT_MISSING_TO", l_msg)
        if not amount:
            return _error_resp("CONVERT_MISSING_AMOUNT", l_msg)
        rates = GameRule.materials.conversion_rates(t_m)
        if not rates or len(rates) <= 0:
            return _error_resp("CONVERT_NOT_ALLOWED", l_msg)
        player = self.parent.player
        for f_m in rates.keys():
            f_m_required = rates.get(f_m) * amount
            owned_m = player.get(f_m)
            if f_m_required > owned_m:
                l_msg = ("Request: %s. Server: %s: owned %s, required: %s" %
                         (l_msg, f_m, owned_m, f_m_required))
                return _error_resp("CONVERT_NOT_ENOUGH_MATERIAL", l_msg)
        r_msg = "Converted "
        for f_m in rates.keys():
            f_m_required = rates.get(f_m) * amount
            r_msg = ("%s %s(%s)," % (r_msg, f_m, f_m_required))
            player.modify_material(f_m, -f_m_required)
        player.modify_material(t_m, amount)
        player.store()
        log.debug("%s to %s(%s)" % (r_msg, t_m, amount))
        resp.result_code = ConvertMaterialResultCode.Value(
            "CONVERT_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(BuyMaterialsRep,
                           BuyMaterialResultCode.Value(
                               "BUY_MATERIAL_INVALID_SESSION"))
    def BuyMaterials(self, msg, *args):
        """
        Spend gems to buy material.

        @param msg: BuyMaterials.
        @return: BuyMaterialsRep.
        """
        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, BuyMaterialResultCode, result_code,
                                   log_msg)
        resp = BuyMaterialsRep()
        player = self.parent.player
        consume_gems = 0
        m_details = {}
        l_msg = "Want to buy:"
        all_slugs = list(GameRule.materials.materials())
        for m in msg.materials:
            if m.slug not in all_slugs:
                l_msg = "Material slug: %s, support: %s" % (m.slug, all_slugs)
                return _error_resp("BUY_MATERIAL_INVALID_SLUG", l_msg)
            amount = m.count or 0
            l_msg += " %s(%s)" % (m.slug, amount)
            if amount < 0:
                return _error_resp("BUY_MATERIAL_INVALID_AMOUNT", l_msg)
            player.modify_material(m.slug, amount)
            cost = GameRule.materials.price(m.slug) * amount
            consume_gems += cost
            m_details[m.slug] = "count: %s, cost: %s" % (amount, cost)
        if not player.verify_gems(consume_gems):
            l_msg += " required %s, owned %s" % (consume_gems, player.gems)
            return _error_resp("BUY_MATERIAL_NOT_ENOUGH_GEMS", l_msg)
        player.update_gems(-consume_gems, TRANS_TYPE.BUY_MATERIAL, **m_details)
        player.store()
        resp.result_code = BuyMaterialResultCode.Value("BUY_MATERIAL_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(BuyCreatureSpaceRep,
                           BuyCreatureSpaceResultCode.Value(
                               "BUY_CREATURE_SPACE_INVALID_SESSION"))
    def BuyCreatureSpace(self, msg, *args):
        """
        Spend gems to extend max creature space.

        @param msg: BuyCreatureSpace.
        @return: BuyCreatureSpaceRep.
        """
        resp = BuyCreatureSpaceRep()
        player = self.parent.player
        event_data = {
            'player': {'session': self.session_id(),
                       'id': self.parent.pid},
        }
        consume_gems = GameRule.prices.creature_space()
        if not player.verify_gems(consume_gems):
            l_msg = ("Owned gems: %s, required gems: %s." %
                     (player.gems, consume_gems))
            return self.error_resp(resp, BuyCreatureSpaceResultCode,
                                   "BUY_CREATURE_SPACE_NOT_ENOUGH_GEMS", l_msg)
        details = {"origin_space": player.max_creatures}
        player.buy_creature_space()
        details["new_space"] = player.max_creatures
        player.update_gems(-consume_gems, TRANS_TYPE.EXTEND_CREATURE_SPACE,
                           **details)
        player.store()
        log.info("Consume %s gems to extend %s creature space." %
                 (consume_gems, GameRule.player.creature_box_extension))
        event_data['gems_cost'] = consume_gems
        self.send_event(DeltaBuyCreatureSpace, event_data, player)
        resp.result_code = BuyCreatureSpaceResultCode.Value(
            "BUY_CREATURE_SPACE_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(RenewalRep,
                           RenewalResultCode.Value("RENEWAL_INVALID_SESSION"))
    def Renewal(self, msg, *args):
        """
        Spend gems to continue battle.

        @param msg: Renewal - with battle_key.
        @return: RenewalRep.
        """
        resp = RenewalRep()
        player = self.parent.player
        battle_reward = BattleReward(player_id=self.parent.pid)
        event_data = {
            'player': {'session': self.session_id(),
                       'id': self.parent.pid},
        }

        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, RenewalResultCode,
                                   result_code, log_msg)

        # TODO - battle key verify
        if not msg.battle_key or \
           msg.battle_key != battle_reward.key:
            l_msg = ("battle key from client: %s, in server: %s" %
                     (msg.battle_key, battle_reward.key))
            return _error_resp("RENEWAL_MISSING_BATTLE_KEY", l_msg)

        retry_times = battle_reward.retry_times or 0
        consume_gems, next_gems = GameRule.prices.revive_cost(retry_times)
        if not player.verify_gems(consume_gems):
            l_msg = ("Owned gems: %s, required gems: %s." %
                     (player.gems, consume_gems))
            return _error_resp("RENEWAL_NOT_ENOUGH_GEMS", l_msg)
        details = {"battle_key": msg.battle_key,
                   "dungeon": battle_reward.dungeon_id,
                   "retry_times": retry_times + 1}
        player.update_gems(-consume_gems, TRANS_TYPE.RENEWAL, **details)
        player.store()
        event_data['gems_cost'] = consume_gems
        event_data['battle_key'] = msg.battle_key
        self.send_event(DeltaRenewal, event_data, player)
        resp.result_code = RenewalResultCode.Value("RENEWAL_SUCCESS")
        resp.renewal_cost = consume_gems
        resp.next_renewal_cost = next_gems
        battle_reward.retry_times = retry_times + 1
        battle_reward.store()
        return self.resp(resp)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def WarnutsSettings(self, msg, *args):
        player = self.parent.player
        player.notify_energy_full = msg.notify_energy_full
        player.notify_event_weekday = msg.notify_event_weekday
        player.notify_event_xp = msg.notify_event_xp
        player.notify_friends_join = msg.notify_friends_join
        player.notify_inactive = msg.notify_inactive
        player.notify_event_dungeon_boss = (msg.notify_event_dungeon556
                                            or msg.notify_event_dungeon45
                                            or msg.notify_event_dungeon)
        player.feedback = msg.feedback
        player.notify_gatcha_daily = msg.notify_gatcha_daily
        player.notify_gatcha_free = msg.notify_gatcha_free
        player.store()
        resp = SimpleResponse()
        resp.result_code = proto.ResultCode.Value('SUCCESS')
        return self.resp(resp)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def PlayerInfoDebugCheck(self, msg, *args):
        print msg
        rep = SimpleResponse()
        rep.result_code = proto.ResultCode.Value('SUCCESS')
        return self.resp(rep)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def LogStuckedMinigame(self, msg, *args):
        log.warn("LogStuckedMinigame", msg=msg)
        rep = SimpleResponse()
        rep.result_code = proto.ResultCode.Value('SUCCESS')
        return self.resp(rep)

    @MessageHandlerWrapper(GetCollectionsRep, GetCollectionsResultCode.Value(
        "GET_COLLECTION_INVALID_SESSION"))
    def GetCollections(self, msg, *args):
        pid = msg.userId or self.parent.pid
        rep = GetCollectionsRep()
        CreatureState.get_all(pid, rep.my_collection)
        if pid == self.parent.pid:
            CollectionState.get_all(pid, rep.claim_states)
        rep.result_code = GetCollectionsResultCode.Value(
            "GET_COLLECTION_SUCCESS")
        return self.resp(rep)

    @MessageHandlerWrapper(ClaimCollectionRewardRep,
                           ClaimCollectionRewardResultCode.Value(
                               "CLAIM_COLLECTION_REWARD_INVALID_SESSION"))
    def ClaimCollectionReward(self, msg, *args):
        def _error_resp(result_code, log_msg):
            return self.error_resp(resp, ClaimCollectionRewardResultCode,
                                   result_code, log_msg)

        def _state():
            return "%s(%s)" % (CollectedCreatureState.Name(state), state)

        resp = ClaimCollectionRewardRep()
        slug = msg.slug  # collection slug
        collect_conf = GameRule.collection.get(slug)
        if not collect_conf:
            l_msg = "%s not in %s" % (slug, GameRule.collection.all_slug())
            return _error_resp("CLAIM_INVALID_COLLECTION_SLUG", l_msg)
        state = msg.state
        gems = collect_conf.get_reward(state)
        if not gems:
            l_msg = "%s %s" % (slug, _state())
            return _error_resp("CLAIM_COLLECTION_NO_REWARD_STATE", l_msg)

        # check collection state
        player_id = self.parent.pid
        collect_st = CollectionState(player_id=player_id, slug=slug)
        if collect_st.check_reward(state):
            return _error_resp("CLAIM_COLLECTION_ALREADY_REWARDED", slug)

        # check creature state
        for c_slug in collect_conf.creatures:
            c_state = CreatureState(player_id=player_id, slug=c_slug)
            if not c_state.check_state(state):
                l_msg = "%s unreached: %s" % (c_slug, _state())
                return _error_resp("CLAIM_COLLECTION_UNREACHED_STATE", l_msg)

        # pay player reward
        player = Player(id=player_id)
        params = {"slug": slug, "state": _state()}
        player.update_gems(gems, TRANS_TYPE.COLLECTION_REWARD, **params)
        player.store()
        # update collection state
        collect_st.mark_reward(state)
        resp.result_code = ClaimCollectionRewardResultCode.Value(
            "CLAIM_COLLECTION_REWARD_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def PNRequest(self, msg, *args):
        player = self.parent.player
        player.send_pn(msg.data,msg.delay,id=str(msg.pnid))

        resp = SimpleResponse()
        resp.result_code = proto.ResultCode.Value('SUCCESS')
        return self.resp(resp)

    @MessageHandlerWrapper(proto.SimpleResponse,
                           proto.ResultCode.Value("INVALID_SESSION"))
    def Echo(self, msg, *args):
        resp = SimpleResponse()
        resp.result_code = proto.ResultCode.Value('SUCCESS')
        return self.resp(resp)
