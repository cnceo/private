from base_actor import ChildActor
from base_actor import MessageHandlerWrapper
from models.content import GameRule
from models.creature import CreatureInstance
from models.player import Player
from stats import DeltaFuse, DeltaFuseFeeds
from stats import DeltaEvolve
from stats import DeltaSellCreature
from stats import DeltaAscend, DeltaAscendFeeds
from utils.constants import TRANS_TYPE
from utils.misc import response_log
from utils.protocol_pb2 import AscendRep
from utils.protocol_pb2 import AscendResultCode
from utils.protocol_pb2 import EvolveRep
from utils.protocol_pb2 import EvolveResultCode
from utils.protocol_pb2 import FuseRep
from utils.protocol_pb2 import FuseResultCode
from utils.protocol_pb2 import SellCreatureRep
from utils.protocol_pb2 import SellCreatureResultCode
from utils.settings import MIN_CREATURE_NUMBER
from utils.log import log


class CreatureModifyHelper(object):
    _player = None
    _target = None
    _activate_creatures = None
    _all_creatures = None
    resp_proto = None
    result_proto = None
    result_code_map = {}
    check_target_level = False
    check_target_active = False
    check_min_creature_number = False
    lack_coins = None
    coin_cost = None
    trans_type = None

    def __init__(self, msg, player_id, **kwargs):
        super(CreatureModifyHelper, self).__init__()
        self.msg = msg
        self.player_id = player_id
        self.target_id = self.msg.target.cid
        self.event_data = {}
        self._log_msg = ""
        self.lack_coins = 0
        self.coin_cost = 0

    @property
    def player(self):
        if self._player is None:
            self._player = Player(id=self.player_id)
        return self._player

    @property
    def target(self):
        if self._target is None:
            self._target = CreatureInstance(player_id=self.player_id,
                                            cid=self.target_id)
        return self._target

    @property
    def activate_creatures(self):
        if self._activate_creatures is None:
            self._activate_creatures = self.player.get_active_creatures()
        return self._activate_creatures

    def is_activate_creature(self, cid):
        return cid in self.activate_creatures

    @property
    def all_creatures(self):
        if self._all_creatures is None:
            self._all_creatures = CreatureInstance.load_oids_by_attribute(
                "player_id", self.player_id)
        return self._all_creatures

    def _get_resp(self, result_code, log_msg=None):
        result_code = self.result_code_map.get(result_code, result_code)
        resp = self.resp_proto()
        resp.result_code = self.result_proto.Value(result_code)
        if log_msg is not None:
            response_log(result_code, log_msg)
        return resp

    def error_resp(self, error_code):
        resp = self._get_resp(error_code, self._log_msg)
        if self.lack_coins:
            resp.lack_coins = self.lack_coins
        return resp

    def modify_enable(self):
        return True

    def verify_target(self):
        if not self.target_id:
            return "MISSING_TARGET"
        if not self.target.exist():
            self._log_msg = ("target id: %s, owned creatures: %s" %
                             (self.target_id, self.all_creatures))
            return "TARGET_NOT_EXIST"
        if not self.modify_enable():
            self._log_msg = ("target id: %s slug: %s" %
                             (self.target_id, self.target.slug))
            return "DISABLED"
        if self.check_target_active and self.is_activate_creature(
                self.target_id):
            self._log_msg = ("target id: %s, active creatures: %s" %
                             (self.target_id, self.activate_creatures))
            return "TARGET_IN_USE"
        if self.check_target_level and not self.target.is_max_level():
            self._log_msg = ("target id: %s level: %s max_level: %s" %
                             (self.target_id, self.target.level,
                              self.target.max_level))
            return "LEVEL_UNSTATISFIED"

        c_num = len(self.all_creatures)
        if self.check_min_creature_number and c_num <= MIN_CREATURE_NUMBER:
            self._log_msg = ("player owned creature number: %s, min "
                             "limitation: %s, target id: %s" %
                             (c_num, MIN_CREATURE_NUMBER, self.target_id))
            return "MIN_CREATURES_LIMIT"
        self.event_data["creature_before"] = self.target.get_stats_data()

    def verify_cost(self):
        return False

    def verify_currency(self):
        self.coin_cost = self.modify_currency()
        if self.coin_cost and not self.player.verify_coins(self.coin_cost):
            self.lack_coins = self.coin_cost - self.player.coins
            self._log_msg = ("Owned coins: %s required coins: %s" %
                             (self.player.coins, self.coin_cost))
            return "NOT_ENOUGH_COINS"

    def do_verify(self):
        return (self.verify_target() or self.verify_cost() or
                self.verify_currency())

    def modify_currency(self):
        return 0

    def _update_player_currency(self):
        details = {"cid": self.target_id,
                   "slug": self.target.slug}
        self.player.update_coins(-self.coin_cost, self.trans_type, **details)
        self.player.store()
        self.event_data["coins_cost"] = self.coin_cost

    def do_modify(self):
        raise NotImplementedError

    def get_event_data(self, session_id):
        self.event_data["player"] = {"session": session_id,
                                     "id": self.player_id}
        self.event_data["creature_after"] = self.target.get_stats_data()
        return self.event_data


class FuseCreatureHelper(CreatureModifyHelper):
    resp_proto = FuseRep
    result_proto = FuseResultCode
    result_code_map = {"MISSING_TARGET": "FUSE_MISSING_TARGET",
                       "TARGET_NOT_EXIST": "FUSE_TARGET_NOT_EXIST",
                       "TARGET_IN_USE": "FUSE_FEEDER_IN_USE",
                       "NOT_ENOUGH_COINS": "FUSE_NOT_ENOUGH_COINS"}
    trans_type = TRANS_TYPE.FUSE
    feeder_xp = 0
    feeder_plus_hp = 0
    feeder_plus_attack = 0
    feeder_plus_speed = 0
    feeder_plus_luck = 0
    same_element_num = 0

    def verify_cost(self):
        feeders = self.msg.feeders
        if not feeders:
            self._log_msg = "target id: %s" % self.target_id
            return "FUSE_NO_FEEDERS"

        self.feeder_ids = []
        self.feed_event_data = {"feeds": []}
        c_numbers = len(self.all_creatures)
        for f in feeders:
            if c_numbers - len(self.feeder_ids) <= MIN_CREATURE_NUMBER:
                self._log_msg = ("player owned creature number: %s, "
                                 "feeders number: %s, min limitation: %s" %
                                 (c_numbers, len(feeders),
                                  MIN_CREATURE_NUMBER))
                return "FUSE_MIN_CREATURES_LIMIT"
            if f.cid in self.feeder_ids:
                # skip duplicate feeders
                continue
            if f.cid == self.target_id:
                self._log_msg = "target id: %s" % self.target_id
                return "FUSE_FEEDER_SELF"
            f_c = CreatureInstance(player_id=self.player_id, cid=f.cid)
            if not f_c.exist():
                self._log_msg = ("feeder id: %s, owned creatures: %s"
                                 % (f.cid, self.all_creatures))
                return "FUSE_FEEDER_NOT_EXIST"
            if self.is_activate_creature(f.cid):
                self._log_msg = ("feeder id: %s active creatures: %s" %
                                 (f.cid, self.activate_creatures))
                return "FUSE_FEEDER_IN_USE"
            self.feeder_ids.append(f.cid)
            if f_c.is_same_element(self.target):
                self.same_element_num += 1
            self.feeder_xp += f_c.fuse_trans_xp(self.target)
            self.feeder_plus_hp += f_c.fuse_plus_hp(self.target)
            self.feeder_plus_attack += f_c.fuse_plus_attack(self.target)
            self.feeder_plus_speed += f_c.fuse_plus_speed(self.target)
            self.feeder_plus_luck += f_c.fuse_plus_luck(self.target)
            self.feed_event_data["feeds"].append(f_c.get_stats_data())
        self.feed_event_data["target"] = self.target.get_stats_data()

    def modify_currency(self):
        return self.target.fuse_currency() * len(self.feeder_ids)

    def do_modify(self):
        self.event_data["same_element_num"] = self.same_element_num
        self.event_data["mega_factor"] = 1
        got_mega = self.target.fuse_mega_odds(self.same_element_num,
                                              len(self.feeder_ids))
        if got_mega:
            mega_factor = GameRule.creature.mega_factor
            self.feeder_xp *= mega_factor
            self.feeder_plus_hp *= mega_factor
            self.feeder_plus_attack *= mega_factor
            self.feeder_plus_speed *= mega_factor
            self.feeder_plus_luck *= mega_factor
            self.event_data["mega_factor"] = mega_factor

        # TODO - save player & add_xp & remove_feeder in one transaction.
        # do fuse
        log_data = {"before_fuse": self.target.get_stats_data()}

        if self.player.super_cooker is True:
            self.feeder_xp *= 2
        self.target.add_xp(self.feeder_xp)
        self.target.plusHP += self.feeder_plus_hp
        self.target.plusAttack += self.feeder_plus_attack
        self.target.plusSpeed += self.feeder_plus_speed
        self.target.plusLuck += self.feeder_plus_luck
        self.target.store()
        self._update_player_currency()
        log_data["after_fuse"] = self.target.get_stats_data()
        for f_cid in self.feeder_ids:
            fc = CreatureInstance(player_id=self.player_id, cid=f_cid)
            fc.delete()
            log.debug("Feeding %s to %s" %
                     (fc.slug, self.target.slug),
                     feeder_id=f_cid, cid=self.target_id)
        log.info("Paid %s coins to fuse %s" %
                 (self.coin_cost, self.target.slug),
                 **log_data)
        resp = self._get_resp("FUSE_SUCCESS")
        self.target.to_proto_class(resp.updated_creature)
        resp.got_mega = got_mega
        return resp

    def get_event_data(self, session_id):
        super(FuseCreatureHelper, self).get_event_data(session_id)
        self.feed_event_data["player"] = {"session": session_id,
                                          "id": self.player_id}
        return self.event_data, self.feed_event_data


class EvolveCreatureHelper(CreatureModifyHelper):
    check_target_level = True
    resp_proto = EvolveRep
    result_proto = EvolveResultCode
    result_code_map = {"MISSING_TARGET": "EVOLVE_MISSING_TARGET",
                       "TARGET_NOT_EXIST": "EVOLVE_TARGET_NOT_EXIST",
                       "DISABLED": "EVOLVE_DISABLE",
                       "LEVEL_UNSTATISFIED": "EVOLVE_LEVEL_UNSATISFIED",
                       "NOT_ENOUGH_COINS": "EVOLVE_NOT_ENOUGH_COINS"}
    trans_type = TRANS_TYPE.EVOLVE

    def modify_enable(self):
        return self.target.support_evolve()

    def modify_currency(self):
        return self.target.evolve_currency()

    def verify_cost(self):
        self.evolve_material = self.target.evolution_materials()
        for m, amount in self.evolve_material.iteritems():
            own_amount = self.player.get(m)
            if own_amount < amount:
                self._log_msg = ("%s: owned: %s, required: %s" %
                                 (m, own_amount, amount))
                return "EVOLVE_LACK_MATERIAL"
            # update player material but do not save here.
            setattr(self.player, m, own_amount - amount)

    def do_modify(self):
        # TODO - evolve_creature & save player in one transaction.
        old_slug = self.target.slug
        self.target.evolve()
        self._update_player_currency()
        log.info("Paid %s coins to evolve %s to %s" %
                 (self.coin_cost, old_slug, self.target.slug),
                 cid=self.target_id, material=self.evolve_material)
        resp = self._get_resp("EVOLVE_SUCCESS")
        self.target.to_proto_class(resp.new_creature)
        return resp


class AscendCreatureHelper(CreatureModifyHelper):
    check_target_level = True
    resp_proto = AscendRep
    result_proto = AscendResultCode
    result_code_map = {"MISSING_TARGET": "ASCEND_MISSING_TARGET",
                       "TARGET_NOT_EXIST": "ASCEND_TARGET_NOT_EXIST",
                       "DISABLED": "ASCEND_DISABLE",
                       "LEVEL_UNSTATISFIED": "ASCEND_LEVEL_UNSATISFIED",
                       "NOT_ENOUGH_COINS": "ASCEND_NOT_ENOUGH_COINS"}
    trans_type = TRANS_TYPE.ASCEND

    def modify_enable(self):
        return self.target.support_ascend()

    def modify_currency(self):
        return self.target.ascend_currency()

    def verify_cost(self):
        # ascend required creatures map
        required_creatures = {}
        transcend = self.target.get_transcend()
        required_amount = 0
        for req_feeder in transcend.creatureAmount:
            required_creatures[req_feeder.creatureSlug] = req_feeder.amount
            required_amount += req_feeder.amount
        required_msg = str(required_creatures)

        owned_amount = len(self.all_creatures)
        if owned_amount - required_amount < MIN_CREATURE_NUMBER:
            self._log_msg = ("player owned creature number: %s, "
                             "required creature: %s, min limitation: %s" %
                             (owned_amount, required_msg, MIN_CREATURE_NUMBER))
            return "ASCEND_MIN_CREATURES_LIMIT"

        self.feeders = []
        # feed from low level to high level.
        feeders = CreatureInstance.load_by_attribute("player_id", self.player_id)
        c_map = {}
        for f in sorted(feeders, lambda x, y: cmp(x.level, y.level)):
            c_map[f.cid] = {"slug": f.slug, "level": f.level}
            if f.cid == self.target_id:
                # skip self
                c_map[f.cid]["is_self"] = True
                continue
            if self.is_activate_creature(f.cid):
                # skip active creatures
                c_map[f.cid]["active"] = True
                continue
            if required_creatures.get(f.slug, 0) > 0:
                # find one feeder, record it and reduce the requirement.
                self.feeders.append(f)
                required_creatures[f.slug] -= 1

                # clear req
                if required_creatures.get(f.slug) <= 0:
                    required_creatures.pop(f.slug)
                if not required_creatures:
                    break
        if required_creatures:
            self._log_msg = ("Required %s, missing %s, player creatures: %s, "
                             "player active creatures: %s" %
                             (required_msg, required_creatures,
                              c_map, self.activate_creatures))
            return "ASCEND_MISSING_FEEDER"

    def do_modify(self):
        # TODO - save player & transcend & delete feeder in one transaction
        old_slug = self.target.slug
        self.target.transcend()
        self._update_player_currency()

        used_creatures = []
        self.event_data["feeders"] = []
        resp = self._get_resp("ASCEND_SUCCESS")
        for f in self.feeders:
            used_creatures.append(f.get_stats_data())
            self.event_data["feeders"].append(f.get_stats_data())
            resp.used_cids.append(f.cid)
            f.delete()
            log.debug("Feeding %s to %s" % (f.slug, old_slug),
                     feeder_id=f.cid, cid=self.target_id)
        log.info("Paid %s coins to ascend %s to %s" %
                 (self.coin_cost, old_slug, self.target.slug),
                 feeders=str(used_creatures))
        self.target.to_proto_class(resp.new_creature)
        return resp

    def get_event_data(self, session_id):
        super(AscendCreatureHelper, self).get_event_data(session_id)
        player = {"player": {"session": session_id,
                             "id": self.player_id}}
        feed_event_data = {'feeds': self.event_data.pop('feeders'),
                           'target': self.event_data['creature_before']}
        self.event_data.update(player)
        feed_event_data.update(player)
        return self.event_data, feed_event_data


class SellCreatureHelper(CreatureModifyHelper):
    check_target_active = True
    check_min_creature_number = True
    resp_proto = SellCreatureRep
    result_proto = SellCreatureResultCode
    result_code_map = {"MISSING_TARGET": "SELL_MISSING_TARGET",
                       "TARGET_NOT_EXIST": "SELL_TARGET_NOT_EXIST",
                       "TARGET_IN_USE": "SELL_TARGET_IN_USE",
                       "MIN_CREATURES_LIMIT": "SELL_MIN_CREATURES_LIMIT"}
    trans_type = TRANS_TYPE.SELL_CREATURE

    def do_modify(self):
        # TODO - delete & save player in one transaction
        sale_price = self.target.sale_price()
        details = {"cid": self.target_id,
                   "slug": self.target.slug}
        self.player.update_coins(sale_price, self.trans_type, **details)
        self.player.store()
        self.target.delete()
        self.event_data["creature"] = self.target.get_stats_data()
        self.event_data["coins"] = sale_price
        log.info("Sold %s for %s coins" %
                 (self.target.slug, sale_price), cid=self.target_id)
        resp = self._get_resp("SOLD_SUCCESS")
        resp.coins = sale_price
        return resp


class CreatureModify(ChildActor):

    @MessageHandlerWrapper(FuseRep,
                           FuseResultCode.Value("FUSE_INVALID_SESSION"))
    def Fuse(self, msg, *args):
        """
        Feed useless creatures to update the target creature.

        @param msg: Fuse - with feeders & target.
        @return: FuseRep - with updated_creature.
        Note: Can't use active creature as feeder;
              Mega fusion will double EXP gains & Stats from faeries & luck.
        """
        helper = FuseCreatureHelper(msg, self.parent.pid)

        # verify target, feeders, and coins
        error_code = helper.do_verify()
        if error_code:
            return self.resp(helper.error_resp(error_code))

        resp = helper.do_modify()
        fuse_event_data, feed_event_data = helper.get_event_data(self.session_id())
        self.send_event(DeltaFuse, fuse_event_data, self.parent.player)
        self.send_event(DeltaFuseFeeds, feed_event_data, self.parent.player)
        return self.resp(resp)

    @MessageHandlerWrapper(EvolveRep,
                           EvolveResultCode.Value("EVOLVE_INVALID_SESSION"))
    def Evolve(self, msg, *args):
        """
        Use material to upgrade creature.

        @param msg: Evolve - with target.
        @return: EvolveRep - with new_creature.
        Note: Creatures must update to maxLevel to do evolve.
        """
        helper = EvolveCreatureHelper(msg, self.parent.pid)

        # verify target, coins, and materials
        error_code = helper.do_verify()
        if error_code:
            return self.resp(helper.error_resp(error_code))

        resp = helper.do_modify()
        event_data = helper.get_event_data(self.session_id())
        self.send_event(DeltaEvolve, event_data, self.parent.player)
        return self.resp(resp)

    @MessageHandlerWrapper(AscendRep,
                           AscendResultCode.Value("ASCEND_INVALID_SESSION"))
    def Ascend(self, msg, *args):
        """
        Ascend feed specified creatures/faeries to upgrade creature.

        @param msg: Ascend - with target.
        @return: AscendRep - with new_creature.
        Note: will auto gather required feeders.
        """
        # verify target, coins, and feeders
        helper = AscendCreatureHelper(msg, self.parent.pid)
        error_code = helper.do_verify()
        if error_code:
            return self.resp(helper.error_resp(error_code))

        resp = helper.do_modify()
        # TODO: add stats events when implement this
        event_data, feed_event_data = helper.get_event_data(self.session_id())
        self.send_event(DeltaAscend, event_data, self.parent.player)
        self.send_event(DeltaAscendFeeds, feed_event_data, self.parent.player)
        return self.resp(resp)

    @MessageHandlerWrapper(SellCreatureRep, SellCreatureResultCode.Value(
        "SELL_INVALID_SESSION"))
    def SellCreature(self, msg, *args):
        """
        Sell creature for coins.

        @param msg: SellCreature - with target.
        @return: SellCreatureRep - with coins by selling.
        Note: only inactive creature can be sell.
        """
        helper = SellCreatureHelper(msg, self.parent.pid)
        error_code = helper.do_verify()
        if error_code:
            return self.resp(helper.error_resp(error_code))

        resp = helper.do_modify()
        event_data = helper.get_event_data(self.session_id())
        self.send_event(DeltaSellCreature, event_data, self.parent.player)
        return self.resp(resp)
