# -*- coding: utf-8 -*-
import copy

from base_actor import ChildActor
from base_actor import MessageHandlerWrapper
from models.content import GameRule
from models.friend import Friend
from models.friend import FacebookFriendsList
from models.friend import AGCFriendsList
from models.friend import GPFriendsList
from models.player import CurrentHelper
from models.player import ThankHelper
from models.player import DevicePnToken
from models.player import Player
from models.gift import GiftInbox
from models.gift import GiftOutbox
from models.gift import THANKS_HELPER
from models.gift import DAILY_SOCIAL
from models.gift import RECRUIT_FB
from models.gift import RECRUIT_FB_DAILY
from models.player import FacebookRegister
from models.reward import FacebookFriendReward
from utils.protocol_pb2 import FriendAction
from utils.protocol_pb2 import GetFriendsInfoResultCode
from utils.protocol_pb2 import GetFriendsToRecruitMsgRep
from utils.protocol_pb2 import GetHelperRep
from utils.protocol_pb2 import GetHelperResultCode
from utils.protocol_pb2 import ModifyFriendRep
from utils.protocol_pb2 import ModifyFriendResultCode
from utils.protocol_pb2 import GetSocialFriendsInfoRep
from utils.protocol_pb2 import ResultCode
from utils.protocol_pb2 import GetInboxMsgRep
from utils.protocol_pb2 import GiftType
from utils.protocol_pb2 import SendGiftsMsgRep
from utils.protocol_pb2 import OpenGiftMsgRep
from utils.protocol_pb2 import GetFriendsToSendGiftsMsgRep
from utils.protocol_pb2 import EggType
from utils.protocol_pb2 import SimpleResponse
from stats import DeltaSendGift, DeltaOpenGift
from utils.settings import AKORN_TREE_SLUG
from utils.settings import DEVICE_CACHE_PN_TOKEN
from utils.log import log

FAERIE_EGG = EggType.Value('FAERIE_EGG')
GEM_EGG = EggType.Value("GEM_EGG")
SELF_EGG = EggType.Value('SELF_EGG')
NUT_EGG = EggType.Value('NUT_EGG')


class Social(ChildActor):

    @MessageHandlerWrapper(GetSocialFriendsInfoRep,
                           GetFriendsInfoResultCode.Value(
                               "GET_FRIEND_INFO_INVALID_SESSION"))
    def GetSocialFriendsInfo(self, msg, *args):
        fb_id = msg.facebook_id
        refresh_fb = False
        player = self.parent.player
        event_data = {
            'player': {'session': self.session_id(),
                       'id': player.id},
        }
        daily_event_data = {
            'player': {'session': self.session_id(),
                       'id': player.id},
        }
        # cache pn
        if DEVICE_CACHE_PN_TOKEN and msg.pn_token and msg.device_id:
            d_pn = DevicePnToken(device_id=msg.device_id)
            if d_pn.pn_token != msg.pn_token:
                d_pn.pn_token = msg.pn_token
                d_pn.store()

        fb_connect = not player.facebook_id and fb_id
        if player.exist():
            if msg.social_name and msg.social_name != player.name:
                player.name = msg.social_name
            if msg.fb_name and msg.fb_name != player.fb_name:
                player.fb_name = msg.fb_name
            if msg.pn_token and msg.pn_token != player.pn_token:
                player.pn_token = msg.pn_token
            elif (not msg.pn_token and DEVICE_CACHE_PN_TOKEN and msg.device_id
                  and not player.pn_token):
                # get pn token from cache
                d_pn = DevicePnToken(device_id=msg.device_id)
                if d_pn.pn_token:
                    player.pn_token = d_pn.pn_token

            # Update player facebook id & fb business token.
            if fb_id and fb_id != player.facebook_id:
                player.facebook_id = fb_id
                refresh_fb = True
            fb_token = msg.fb_business_token
            if fb_token != player.fb_business_token:
                player.fb_business_token = fb_token
            player.store()

        # prepare friends list
        player_id = self.parent.pid
        fb_friends = msg.fb_friends_ids
        agc_friends = msg.agc_friends_ids
        gp_friends = msg.gp_friends_ids
        fb = FacebookFriendsList(player_id=player_id)
        agc = AGCFriendsList(player_id=player_id)
        gp = GPFriendsList(player_id=player_id)
        if refresh_fb or fb_friends:
            fb.update_get(fb_friends)
        f_ids = fb.get_list(disorder=True)
        fb_ids = copy.copy(f_ids)
        if agc_friends:
            agc.update_get(agc_friends)
        f_ids += agc.get_list(disorder=True, filter_out=f_ids)
        if gp_friends:
            gp.update_get(gp_friends)
        f_ids += gp.get_list(disorder=True, filter_out=f_ids)

        resp = GetSocialFriendsInfoRep()
        fb_player = []
        for friend_id in f_ids:
            p = Player(id=friend_id)
            if p.exist():
                if friend_id in fb_ids:
                    fb_player.append(p)
                p_proto = resp.friends_list.add()
                p.set_info(p_proto, simple_mode=True)

        resp.recruit_friends.result_code = ResultCode.Value("SUCCESS")
        # Recruit friend - for display in client
        fb_reward = FacebookFriendReward(player_id=player_id)
        fb_reward.players_gift_proto(resp.recruit_friends, msg.fb_invitables)

        # Reward fb friends
        if fb_id:
            fb_reg = FacebookRegister(facebook_id=fb_id)
            #fb_rewarded = FacebookConnectRewarded
            if not fb_reg.exist():
                # reward self
                # init the reward when sign up, and will check when open gift

                for p_id in fb.player_list:
                    # reward friends
                    f_fb_reward = FacebookFriendReward(player_id=p_id)
                    c_slug = f_fb_reward.get_facebook_gift(msg.fb_name)
                    inbox = GiftInbox(player_id=p_id)
                    egg_type = GameRule.egg_type(c_slug)
                    gift_event_data = inbox.give_gift(RECRUIT_FB, player_id,
                                                      egg_type, c_slug)
                    if gift_event_data: event_data.update(gift_event_data)
                    self.send_event(DeltaSendGift, event_data, player)
                    daily_gift = f_fb_reward.get_daily_gift()
                    if daily_gift:
                        egg_type = GameRule.egg_type(daily_gift)
                        gift_event_data = inbox.give_gift(RECRUIT_FB_DAILY,
                                                          player_id, egg_type,
                                                          daily_gift)
                        if gift_event_data: daily_event_data.update(gift_event_data)
                        f_fb_reward.daily_gift_send = True
                        f_fb_reward.store()
                        self.send_event(DeltaSendGift, daily_event_data, player)
                fb_reg.store()

        # set up gift inbox
        inbox = GiftInbox(player_id=player_id)
        resp.gift_inbox.result_code = ResultCode.Value('SUCCESS')
        inbox.get_player_gift_list(resp.gift_inbox.inbox, fb_connect)

        outbox = GiftOutbox(player_id=player_id)
        outbox.get_box_proto(player, fb_player, resp.gift_friends)
        resp.gift_friends.result_code = ResultCode.Value('SUCCESS')
        resp.result_code = GetFriendsInfoResultCode.Value(
            "GET_FRIEND_INFO_SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(GetFriendsToRecruitMsgRep,
                           ResultCode.Value("INVALID_SESSION"))
    def GetFriendsToRecruitMsg(self, msg, *args):
        resp = GetFriendsToRecruitMsgRep()
        player_id = self.parent.pid
        fb_reward = FacebookFriendReward(player_id=player_id)
        fb_reward.players_gift_proto(resp, msg.fb_invitables)
        resp.result_code = ResultCode.Value("SUCCESS")
        return self.resp(resp)

    @MessageHandlerWrapper(ModifyFriendRep, ModifyFriendResultCode.Value(
        "MODIFY_FRIEND_INVALID_SESSION"))
    def ModifyFriend(self, msg, *args):
        """
        Modify friends.

        @param msg: ModifyFriend - with friend_id and modify action
        @return: ModifyFriendRep - with modify action
        Note: Now support add_friend, accept_friend, ignore_friend,
                          remove_friend, mark_favorite, unmark_favorite.
        """
        resp = ModifyFriendRep()
        resp.action = msg.action
        if msg.friend_id == self.parent.pid:
            resp.result_code = ModifyFriendResultCode.Value(
                "FRIEND_ON_SELF")
            return self.resp(resp)
        friend = Friend(player_id=self.parent.pid)
        try:
            action = FriendAction.Name(msg.action).lower()
        except ValueError, e:
            log.info("Modify friend get unsupported action - %s" % e)
            resp.result_code = ModifyFriendResultCode.Value(
                "UNSUPPORTED_ACTION")
            return self.resp(resp)
        func = getattr(friend, action)
        if not func:
            log.debug("Modify friend not implement action: %s" % action)
            resp.result_code = ModifyFriendResultCode.Value(
                "UNSUPPORTED_ACTION")
        elif not Player(id=msg.friend_id).exist():
            resp.result_code = ModifyFriendResultCode.Value(
                "FRIEND_NOT_EXIST")
        else:
            resp.result_code = func(msg.friend_id)
        return self.resp(resp)

    @MessageHandlerWrapper(GetHelperRep, GetHelperResultCode.Value(
        "GET_HELPER_INVALID_SESSION"))
    def GetHelper(self, msg, *args):
        """
        Get helper list for battle.

        @param msg: GetHelper.
        @return: GetHelperRep - with helpers(player_info & helper creature).
        """
        rep = GetHelperRep()
        friend = Friend(player_id=self.parent.pid)
        helpers = friend.get_helpers()
        rep.helpers.extend(helpers)
        rep.result_code = GetHelperResultCode.Value("GET_HELPER_SUCCESS")
        return self.resp(rep)

    @MessageHandlerWrapper(GetInboxMsgRep,
                           ResultCode.Value("INVALID_SESSION"))
    def GetInboxMsg(self, msg, *args):
        player = self.parent.player
        resp = GetInboxMsgRep()
        inbox = GiftInbox(player_id=player.id)
        inbox.get_player_gift_list(resp.inbox)

        resp.result_code = ResultCode.Value('SUCCESS')
        return self.resp(resp)

    @MessageHandlerWrapper(SendGiftsMsgRep,
                           ResultCode.Value("INVALID_SESSION"))
    def SendGiftsMsg(self, msg, *args):
        p_id = self.parent.pid
        resp = SendGiftsMsgRep()
        event_data = {
            'player': {'session': self.session_id(),
                       'id': p_id},
        }
        resp.result_code = ResultCode.Value('SUCCESS')
        if msg.type == THANKS_HELPER:
            helper = CurrentHelper(p_id)
            helper_id = helper.load()
            if helper_id and helper_id == msg.ids[0]:
                thx_helper = ThankHelper(p_id, helper_id)
                if thx_helper.thank_able():
                    helper_inbox = GiftInbox(player_id=helper_id)
                    gift_event_data = helper_inbox.give_gift(
                        THANKS_HELPER, p_id, GEM_EGG,
                        GameRule.viral.thank_helper_gem)
                    helper.delete()
                    thx_helper.store()
                    if gift_event_data:
                        event_data.update(gift_event_data)
                    self.send_event(DeltaSendGift, event_data,
                                    self.parent.player)
                else:
                    log.info("Can't thank helper(%s) now." % helper_id)
                    resp.result_code = ResultCode.Value('FAILED')
            else:
                log.info("Helper id not match, msg: %s db: %s" %
                         (msg.ids[0], helper_id))
                resp.result_code = ResultCode.Value('FAILED')
        elif msg.type == DAILY_SOCIAL:
            outbox = GiftOutbox(player_id=p_id)
            for i in msg.ids:
                if i in outbox.friends:
                    success = outbox.set_sent(i)
                    if success:
                        friend_inbox = GiftInbox(player_id=i)
                        gift_event_data = friend_inbox.give_gift(
                            DAILY_SOCIAL, p_id, NUT_EGG, AKORN_TREE_SLUG)
                        if gift_event_data: event_data.update(gift_event_data)
                        self.send_event(DeltaSendGift, event_data, self.parent.player)

                    else:
                        log.info("Invalid friend id %s" % i)
                        resp.result_code = ResultCode.Value('FAILED')
        else:
            g_type = msg.type
            if g_type:
                g_type = "%s(%s)" % (GiftType.Name(g_type), g_type)
            log.info("Invalid gift type %s" % g_type)
            resp.result_code = ResultCode.Value('FAILED')
        return self.resp(resp)

    @MessageHandlerWrapper(OpenGiftMsgRep,
                           ResultCode.Value("INVALID_SESSION"))
    def OpenGiftMsg(self, msg, *args):
        resp = OpenGiftMsgRep()
        event_data = {
            'player': {'session': self.session_id(),
                       'id': self.parent.pid},
        }
        inbox = GiftInbox(player_id=self.parent.pid)
        g_id = msg.gift.gift.id
        success, gift_event_data, l_msg = inbox.open_gift(self.parent.player, g_id)
        if gift_event_data: event_data.update(gift_event_data)
        self.send_event(DeltaOpenGift, event_data, self.parent.player)
        if success:
            resp.result_code = ResultCode.Value('SUCCESS')
            return self.resp(resp)
        return self.error_resp(resp, ResultCode, 'FAILED', l_msg)

    @MessageHandlerWrapper(GetFriendsToSendGiftsMsgRep,
                           ResultCode.Value("INVALID_SESSION"))
    def GetFriendsToSendGiftsMsg(self, msg, *args):
        resp = GetFriendsToSendGiftsMsgRep()
        friends_id = set()
        fb_friends = FacebookFriendsList(player_id=self.parent.pid).get_list()
        #agc_friends = AGCFriendsList(player_id=self.parent.pid).get_list()
        #gp_friends = GPFriendsList(player_id=self.parent.pid).get_list()
        friends_id.update(fb_friends)
        #friends_id.update(agc_friends)
        #friends_id.update(gp_friends)
        friends = []
        for f in friends_id:
            friends.append(Player(id=f))
        outbox = GiftOutbox(player_id=self.parent.pid)
        outbox.get_box_proto(self.parent.player, friends, resp)
        resp.result_code = ResultCode.Value('SUCCESS')
        return self.resp(resp)

    @MessageHandlerWrapper(SimpleResponse,
                           ResultCode.Value("INVALID_SESSION"))
    def RecruitedFriends(self, msg, *args):
        # Not in use API,
        # but client implement it, so give a simple response to avoid error.
        resp = SimpleResponse()
        resp.result_code = ResultCode.Value("SUCCESS")
        return self.resp(resp)
