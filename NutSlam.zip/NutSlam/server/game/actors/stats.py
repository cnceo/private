import simplejson
import time, zmq
from zmq import ZMQError
from utils.log import log
from utils import settings
from utils import stats_pb2, protocol_pb2
from utils.gevent_actor import GeventActorWrapper
from utils.misc import parse_message, check_actor_qsize
from utils.protocol_utils import assign_value
from utils.protocol_pb2 import StatsType

APPLICATION = 'nuts'
VERSION = 1

# keep use same name in stats_pb2
DeltaSignIn              = 'DeltaSignIn'
DeltaAddEnergy           = 'DeltaAddEnergy'
DeltaSellCreature        = 'DeltaSellCreature'
DeltaRenewal             = 'DeltaRenewal'
DeltaBuyCreatureSpace    = 'DeltaBuyCreatureSpace'###
DeltaEvolve              = 'DeltaEvolve'
DeltaFuse                = 'DeltaFuse'
DeltaFuseFeeds           = 'DeltaFuseFeeds'
DeltaGacha               = 'DeltaGacha'
DeltaBattleEndDrop       = 'DeltaBattleEndDrop'
DeltaLinkAccount         = 'DeltaLinkAccount'
DeltaBattleEnd           = 'DeltaBattleEnd'
DeltaRevenueIAP          = 'DeltaRevenueIAP'
DeltaEditTeam            = 'DeltaEditTeam'
DeltaRevenueIAB          = 'DeltaRevenueIAB'
DeltaClientAction        = 'DeltaClientAction'
DeltaBattleBegin         = 'DeltaBattleBegin' # TODO: add energy #TODO: add heart
DeltaBattleEnd           = 'DeltaBattleEnd' #TODO: remove heart
DeltaSendGift            = 'DeltaSendGift'
DeltaOpenGift            = 'DeltaOpenGift'
DeltaLedger              = 'DeltaLedger'
DeltaOpenNut             = 'DeltaOpenNut'
DeltaBuyNut              = 'DeltaBuyNut'

#no test
DeltaSignOff             = 'DeltaSignOff'
DeltaPutBackground       = 'DeltaPutBackground'
DeltaBringFront          = 'DeltaBringFront'
DeltaAscend              = 'DeltaAscend' #add this
DeltaAscendFeeds         = 'DeltaAscendFeeds' #add this

#TODO:
DeltaLevelUp             = 'DeltaLevelUp'
DeltaConvertMaterial     = 'DeltaConvertMaterial'


def get_event_type(name):
    return getattr(stats_pb2.Event, name)

def send_event_message(msg, from_client=False):
    if not settings.IS_PRODUCTION:
        return
    msg['from_client'] = from_client
    actor = StatsActor.get()
    actor.tell(msg)

def send_event(event_name, data, player=None, client=None):
    if player:
        data.setdefault("player", {})
        data['player'].update(player.get_stats_data())
    if client:
        c = data.get('client', {})
        c['device_type'] = client.device_type
        c['conn_type'] = client.conn_type
        c['client_timestamp'] = client.client_timestamp
        c['client_version'] = client.client_version
        c['device_os'] = client.device_os
        c['device_os_version'] = client.device_os_version
        c['openudid'] = client.openudid
        c['odin'] = client.odin
        c['mac_address'] = client.mac_address
        c['ios_ifa'] = client.ios_ifa
        c['android_id'] = client.android_id
        c['imei'] = client.imei
        c['android_ifa'] = client.android_ifa
        data['client'] = c
    msg = {"event_name": event_name,
           "timestamp": time.time(),
           "data": data}
    send_event_message(msg)


def send_client_events(form, user_agent):
    data = form.get('stats')

    if data:
        msg = {'data': data,
               'user_agent': user_agent}
        send_event_message(msg, from_client=True)


class SenderHappyLatte(object):
    """
    The sender to send event to statsServer
    """

    def __init__(self, host=settings.STATS_ZMQ_HOST,
                  port=settings.STATS_ZMQ_PORT):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUSH)
        self.socket.connect("tcp://%s:%d" % (host, port))

    def send(self, data):
        self.socket.send(data)

    def stop(self):
        self.socket.close()
        self.context.term()


def build_client_message(msg, user_agent):
    def assign(raw):
        e = stats_pb2.Event()
        e.FormatVersion = VERSION
        e.Application = APPLICATION
        e.Timestamp = time.time()
        e.EventType = get_event_type(DeltaClientAction)
        e.EventName = DeltaClientAction
        s = e.Extensions[getattr(getattr(stats_pb2, DeltaClientAction), 'event')]
        assign_value(s, raw, stats_pb2)
        return e

    proto_list = []
    for stats in msg.stats:
        # skip SERVER_RESPONSE_DURATION and SERVER_RESPONSE_STATUS
        if stats.type == StatsType.Value("SERVER_RESPONSE_DURATION"):
            continue

        data = {
            'client_version': stats.clientVersion,
            'timestamp': str(stats.timestamp),
            'type': protocol_pb2.StatsType.Name(stats.type),
            'player': {'id': msg.userId,
                       'session': msg.sessionId,
                       'level': stats.player_info.level,
                       'xp': stats.player_info.xp,
                       'gems': stats.player_info.gems,
                       'coins': stats.player_info.coins,
                       'hearts': stats.player_info.hearts,
                       'energy': stats.player_info.energy,
                       'maxCreatures': stats.player_info.maxCreatures,
                       'progress': stats.player_info.progress,
                       'agc_id': stats.player_info.agc_id,
                       'gp_id': stats.player_info.gp_id,
            },
            'client_info': {'user_agent': user_agent,
                            'os_type': msg.os
            },
            'content_version': msg.content_version,
            'postdump': stats.postdump,
            'mid': stats.mid,
            'dungeon_id': stats.dungeon_info.id,
            'dungeon_slug': stats.dungeon_info.slug,
            'dungeon_energy': stats.dungeon_info.energy,
            'dungeon_req_progress': stats.dungeon_info.req_progress,
            'dungeon_curr_team_slug': stats.dungeon_info.curr_team_slug,
            'dungeon_curr_team_stars': stats.dungeon_info.curr_team_stars,
            'dungeon_req_team_slug': stats.dungeon_info.req_team_slug,
            'dungeon_req_team_stars': stats.dungeon_info.req_team_stars,
            'badge_gatcha': stats.badge_count.gatcha,
            'badge_collection': stats.badge_count.collection,
            'badge_inbox': stats.badge_count.inbox,
            'badge_ship': stats.badge_count.ship,
        }
        for t in stats.teams_info:
            if t.slug == 'MIXED': data['team_star_mixed'] = t.stars;
            elif t.slug == 'FIRE': data['team_star_fire'] = t.stars;
            elif t.slug == 'WATER': data['team_star_water'] = t.stars;
            elif t.slug == 'WOOD': data['team_star_wood'] = t.stars;
            elif t.slug == 'DARK': data['team_star_dark'] = t.stars;
            elif t.slug == 'LIGHT': data['team_star_light'] = t.stars;

        if stats.context:
            data['context'] = protocol_pb2.StatsGameContext.Name(stats.context)
        if stats.dungeon:
            data['selected_dungeon'] = stats.dungeon
        if stats.type == StatsType.Value("SERVER_RESPONSE_STATUS"):
            d1 = data.copy()
            d1['key'] = 'foreground_start'
            d1['value'] = str(int(stats.foreground_start)) or 0
            proto_list.append(assign(d1))

            d2 = data.copy()
            d2['key'] = 'foreground_secs'
            d2['value'] = str(round(stats.foreground_secs, 2)) or 0
            proto_list.append(assign(d2))
        else:
            d = data.copy()
            # log error for missing art and localization
            if stats.type in (StatsType.Value("MISSING_ART"),
                              StatsType.Value("MISSING_LOCALIZATION")):
                d['parameters'] = [str(i) for i in stats.parameters]
                log.warn("MISSING_CONTENT", **d)
            if stats.type in (StatsType.Value("IAB"),):
                log.info("IAB_INIT: %s" % str(d))
            if stats.parameters:
                for p in stats.parameters:
                    if p.key == 'stack': continue
                    d['key'] = p.key
                    d['value'] = p.value
                    proto_list.append(assign(d))
                    d = data.copy()
            else:
                proto_list.append(assign(d))

    return proto_list


class StatsActor(GeventActorWrapper):
    """
    Gether the stats event and send to analytics platform.
        - receive events by tell this actor
        - accept json format
        - now just send to hl stats platform, will convert into protobuf message
    """
    _sender = None

    def __init__(self):
        super(StatsActor, self).__init__()

    def on_receive(self, msg):
        # TODO - validate data & send event
        log.bind(msg_=msg, qsize=check_actor_qsize(self))
        try:
            from_client = msg.get('from_client', False)
            if from_client:
                self.do_send_client(msg)
            else:
                self.do_send_server(msg)
        except Exception as e:
            log.critical("StatsActor exception: {exception}".format(exception=repr(e), **locals()), msg=msg, exc_info=e)

    @property
    def sender(self):
        if self._sender is None:
            self._sender = SenderHappyLatte()
        return self._sender

    def do_send_client(self, data):
        try:
            user_agent = data.get('user_agent', None)
            data = parse_message('Stats', data.get('data'))
            if not settings.IS_PRODUCTION:
                # log.debug(str(data))
                pass
            data = build_client_message(data, user_agent)
            for i in data:
                self.sender.send(i.SerializeToString())
        except Exception, e:
            log.error("Got error while send data(%s) to stats server: %s" %
                      (str(data), e), exc_info=True)

    def do_send_server(self, data):
        try:
            #print '===11===='
            #for k,v in data.items(): print k, v
            #print '====22==='
            e = stats_pb2.Event()
            e.FormatVersion = VERSION
            e.Application = APPLICATION
            e.Timestamp = data['timestamp']
            e.EventType = get_event_type(data['event_name'])
            e.EventName = data['event_name']
            s = e.Extensions[getattr(getattr(stats_pb2, data['event_name']), 'event')]
            assign_value(s, data['data'], stats_pb2)
            self.sender.send(e.SerializeToString())
            #print e
            #print '===33===='
        except Exception, e:
            log.error("Got error while send data(%s) to stats server: %s" %
                      (str(data), e), exc_info=True)

    def _stop_sender(self):
        #TODO: it will not stop, until the zmq's queue is empty
        if self._sender:
            self._sender.stop()
            self._sender = None

    def on_stop(self):
        super(StatsActor, self).on_stop()
        self._stop_sender()

    def on_failure(self, exception_type, exception_value, traceback):
        super(StatsActor, self).on_failure(exception_type, exception_value,
                                           traceback)
        self._stop_sender()
