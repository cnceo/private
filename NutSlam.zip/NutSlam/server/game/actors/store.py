from base_actor import ChildActor
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import PurchaseResultCode
from utils.protocol_pb2 import PurchaseRep
from models.content import GameRule
from actors.base_actor import INVALID_SESSION_PID
from actors.transaction import IABTransaction
from actors.transaction import IAPTransaction


class PurchaseActor(ChildActor):
    purchase_handle_map = {
        OSType.Value("IOS"): IAPTransaction,
        OSType.Value("Android"): IABTransaction,
    }

    def Purchase(self, msg, *args, **kwargs):
        """
        Do purchase.

        @param msg: Purchase - with purchase product id and
                                  receipt(or signature_list + signed_data_list)
        @return: PurchaseRep - with transaction info list.
        """
        resp = PurchaseRep()
        user_id = self.parent.pid
        product_id = msg.pid
        os_type = GameRule.prices.hc_os_type(product_id)

        def _error(result_code):
            trans_info = resp.trans_infos.add()
            trans_info.result_code = result_code
            return resp

        if user_id == INVALID_SESSION_PID:
            resp = _error(PurchaseResultCode.Value("PURCHASE_INVALID_SESSION"))
        elif not os_type:
            resp = _error(PurchaseResultCode.Value("INVALID_PRODUCT_ID"))
        else:
            handler = self.purchase_handle_map.get(os_type)(
                user_id, msg, self)
            resp.trans_infos.extend(handler.handle_purchase())
        return self.resp(resp, self._log_purchase_response)

    def _log_purchase_response(self, msg):
        for t in msg.trans_infos:
            self._log_resp(t, resp_name=msg.DESCRIPTOR.name)