#!/usr/bin/python
import time

from types import FunctionType
from pykka import ActorRegistry
from models.cached_response import CachedResponse
from stats import send_event
from utils.exception import UnmatchedPlayerInfo
from utils.gevent_actor import GeventActorWrapper as GeventActor
from utils.misc import response_log, check_actor_qsize
from utils.protocol_pb2 import StatsType
from utils.settings import CACHE_RESPONSE
from utils.settings import ENERGY_TOLERANCE
from utils.settings import RAISE_ON_UNMATCHED_PLAYER_INFO

from utils.log import log
from utils.local_content import lct


msg_map = {}
INVALID_SESSION_PID = -1


class BaseActor(GeventActor):
    success_map = {
        0: ['LoginAccountRep', 'ModifyFriendRep', 'GetFriendsInfoRep',
            'GetSocialFriendsInfoRep', 'GetHelperRep', 'FuseRep',
            'EvolveRep', 'AscendRep', 'SellCreatureRep', 'AddEnergyRep',
            'ConvertMaterialRep', 'BuyCreatureSpaceRep', 'PurchaseRep',
            'TransactionInfo', 'OpenNutRep', 'BuyNutRep', 'BuyMaterialsRep'],
        1: ['SimpleResponse', 'EditTeamRep', 'BattleBeginRep', 'BattleEndRep',
            'RenewalRep', 'GachaShakeRep', 'LinkAccountRep', 'GetInboxMsgRep',
            'SendGiftsMsgRep', 'OpenGiftMsgRep', 'GetFriendsToRecruitMsgRep',
            'GetFriendsToSendGiftsMsgRep', 'GetCollectionsRep',
            'ClaimCollectionRewardRep', 'PurchaseRep'],
        2: ['BattleEndRep', 'LinkAccountRep']
    }

    def __init__(self, urn=None):
        super(BaseActor, self).__init__()
        if urn:
            self.actor_urn = self._generate_urn(urn)

    def _generate_urn(self, urn):
        return self._build_urn(self.__class__.__name__, urn)

    def _build_urn(self, name, urn):
        return '%s_%s' % (name, urn)

    def on_receive(self, msg):
        func_name = func_msg = {}
        check_actor_qsize(self)

        try:
            self.ip = msg.get('msg', {}).get('ip')
            request_id = self.request_id(msg)
            session_id = self.session_id(msg)
            # setup log
            param = {"version": self.version(msg),
                    #"session_id": session_id,
                    "request_id": request_id}
            log.bind(**param)
            func_name = msg['func']
            func_msg = msg['msg']
            log.info("Request: "+func_name, msg_=func_msg['data'])
            return getattr(self, func_name)(func_msg)
        except Exception as e:
            log.critical("{func_name} actor exception: {exception}".format(exception=repr(e), **locals()), msg=func_msg, exc_info=e)
            return None

    def on_start(self):
        ActorRegistry.unregister(self.actor_ref)
        self.actor_ref.actor_urn = self.actor_urn
        ActorRegistry.register(self.actor_ref)

    def _log_resp(self, msg, resp_name=None):
        descriptor = msg.DESCRIPTOR
        resp_name = resp_name or descriptor.name
        log_msg = "Reply: %s" % resp_name
        log.bind(resp_name=resp_name, msg_=msg)
        if "result_code" in descriptor.fields_by_name:
            result = msg.result_code
            r_proto = descriptor.fields_by_name["result_code"].enum_type
            result_name = r_proto.values_by_number[result].name
            log.bind(result_code=result, result_name=result_name)
            res = result_name if resp_name not in self.success_map.get(result, []) else "SUCCESS"
            log_msg += " [%s]" % (res,)
            if result == 101:
                log.warn(log_msg)
            else:
                log.info(log_msg)
        else:
            log.info(log_msg)

    def resp(self, msg, log_func=None):
        if not log_func:
            log_func = self._log_resp
        log_func(msg)
        return msg

    def _parse_key(self, msg, key):
        return msg.get(key) or msg.get("msg", {}).get(key)

    def version(self, msg):
        return self._parse_key(msg, "version")

    def request_id(self, msg):
        return self._parse_key(msg, "request_id")

    def session_id(self, msg=None):
        key = "session_id"
        if msg:
            # parse session id and save it.
            session_id = self._parse_key(msg, key)
            setattr(lct, key, session_id)
        else:
            session_id = lct.get(key)
        return session_id

    def send_event(self, event_name, data, player=None, client=None):
        send_event(event_name, data, player, client)


class ActorMeta(type):
    base_func = dir(BaseActor)

    def __new__(cls, name, basses, attrs):
        global msg_map
        instance = type.__new__(cls, name, basses, attrs)
        for a_name, a_v in attrs.iteritems():
            if a_name.startswith("_"):
                # skip internal func
                continue
            if a_name in cls.base_func:
                # skip overwrite func
                continue
            if isinstance(a_v, FunctionType):
                msg_map[a_name] = instance
        return instance


class ParentActor(BaseActor):
    pass


class ChildActor(BaseActor):
    __metaclass__ = ActorMeta
    _cache_funcs = ["BattleBegin", "BattleEnd", "BuyNut", "AddEnergy",
                    "BuyCreatureSpace", "Renewal", "Purchase", "OpenGiftMsg",
                    "SendGiftsMsg", "Fuse", "Evolve", "Ascend", "SellCreature",
                    # not in use ones
                    "GachaShake", "ModifyFriend", "ConvertMaterial",
                    ]

    def __init__(self, parent):
        super(ChildActor, self).__init__(parent.pid)
        self.parent = parent
        self.ip = None

    def on_receive(self, msg):
        check_actor_qsize(self)
        self.ip = msg.get('msg', {}).get('ip')
        request_id = self.request_id(msg)
        session_id = self.session_id(msg)
        p_id = self.parent.pid
        # setup log
        param = {"version": self.version(msg),
                 "player_id": p_id,
                 "os_type": self.parent.player.os_type_name(),
                 #"session_id": session_id,
                 "request_id": request_id}
        log.bind(**param)

        func_name = func_msg = {}
        try:
            func_name = msg['func']
            func_msg = msg['msg']['data']
            log.info("Request: "+func_name, msg_=func_msg)

            # try to get from cached
            cached = None
            if (CACHE_RESPONSE and request_id and
                    func_name in self._cache_funcs):
                cached = CachedResponse(player_id=p_id, request=func_name)
                if cached.exist() and cached.request_id == request_id:
                    return cached.response

            pre_info, post_info = self._get_dump_player_info(msg)
            # verify pre dumped player info
            success = self._verify_player_info(pre_info, func_name)
            if RAISE_ON_UNMATCHED_PLAYER_INFO and not success:
                return None

            resp = getattr(self, func_name)(func_msg)
            # verify post dumped player info
            success = self._verify_player_info(post_info, func_name)
            if RAISE_ON_UNMATCHED_PLAYER_INFO and not success:
                return None

            # update cached response
            if cached:
                cached.response = resp
                cached.request_id = request_id
                cached.store()
            return resp
        except Exception as e:
              log.critical("{func_name} actor exception: {exception}".format(exception=repr(e), **locals()), msg=func_msg, exc_info=e)
              return None

    def _get_dump_player_info(self, msg):
        pre_info = []
        post_info = []
        game_stats = msg.get("msg", {}).get("game_stats")
        if self.parent.pid == INVALID_SESSION_PID or not game_stats:
            return pre_info, post_info

        request_id = self.request_id(msg)
        for st in game_stats.stats:
            # Skip other stats
            if st.type != StatsType.Value("PLAYERDUMP"):
                continue
            # Skip other request
            if st.mid and st.mid != request_id:
                continue
            if st.mid and st.postdump:
                post_info.append(st)
            else:
                pre_info.append(st)
        return pre_info, post_info

    def _verify_player_info(self, game_stats, func_name):
        """
        @param game_stats: filter by _get_dump_player_info - all PLAYERDUMP.
        @return: True - player info matched, False - unmatched.
        """
        def _parse_int(val, key):
            try:
                return int(float(val))
            except ValueError:
                log.info("%s should be int but get %s" % (key, val))
                return 0

        success = True
        server = "server"
        client = "client"
        for st in game_stats:
            player = self.parent.player
            matched_data = {}
            unmatched_data = {}
            for attr in st.parameters:
                info = {client: attr.value,
                        server: str(player.get(attr.key, match_client=True))}
                if info[client] == info[server]:
                    matched_data[attr.key] = info
                else:
                    unmatched_data[attr.key] = info
            refill_e = "remainingttoenergy"
            energy = "energy"
            energy_info = unmatched_data.get(energy)
            refill_info = unmatched_data.get(refill_e)
            if refill_info and not energy_info:
                # Ignore energy refill if energy matched.
                unmatched_data.pop(refill_e)
            elif energy_info:
                s_e = int(energy_info[server])
                c_e = _parse_int(energy_info[client], energy)
                # remainingttoenergy & energy might be unmatch due to
                # network delay, ignore them if within tolerance.
                if c_e <= s_e <= c_e + ENERGY_TOLERANCE:
                    unmatched_data.pop(energy)
                    unmatched_data.pop(refill_e, None)

            if unmatched_data:
                e = UnmatchedPlayerInfo(func_name, self.parent.pid,
                                        unmatched_data)
                log.warn("Unmatched data", unmatched_data=unmatched_data)
                success = False

        return success

    def error_resp(self, resp, result_code_proto, result_code, log_msg):
        response_log(result_code, log_msg)
        resp.result_code = result_code_proto.Value(result_code)
        return self.resp(resp)


class MessageHandlerWrapper(object):
    resp_msg = None
    invalid_session_code = None

    def __init__(self, resp_msg, invalid_session_code):
        self.resp_msg = resp_msg
        self.invalid_session_code = invalid_session_code

    def __call__(self, method):
        def handler_wrapper(instance, msg, *args, **kwargs):
            if instance.parent.pid == INVALID_SESSION_PID:
                resp = self.resp_msg()
                resp.result_code = self.invalid_session_code
                return instance.resp(resp)
            else:
                return method(instance, msg, *args, **kwargs)
        return handler_wrapper
