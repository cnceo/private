import gevent
from actors.base_actor import BaseActor
from actors.transaction import IAPTransaction
from actors.transaction import TRANS_STATUS
from models.content import GameRule
from models.player import Player
from models.transaction import PendingTransaction
from models.transaction import PurchaseTransaction
from utils.constants import TRANS_TYPE
from utils.protocol_pb2 import PurchaseResultCode
from utils.settings import VERIFY_PENDING_TTL
from utils.log import log


class HandlePendingIAP(BaseActor):
    ttl = VERIFY_PENDING_TTL

    def on_receive(self, msg):
        gevent.spawn(self.verify)

    def update_player_gem(self, player_id, product_id, trans_id, minus=False):
        player = Player(id=player_id)
        if player.exist():
            p_info = GameRule.prices.hc_info(product_id)
            quantity = p_info and p_info.quantity or 0
            prefix_msg = "Resolve_IAP_pending -"
            if minus:
                qty = -quantity
                log.info("%s Take away %s gems from player(%s)."
                         % (prefix_msg, quantity, player_id))
            else:
                qty = quantity
                log.info("%s Update player(%s) %s gems."
                         % (prefix_msg, player_id, quantity))
            details = {"product_id": product_id,
                       "trans_id": trans_id}
            player.update_gems(qty, TRANS_TYPE.PURCHASE, **details)
            player.store()
            return True
        return False

    def verify(self):
        gevent.sleep(self.ttl)
        valid_status = [TRANS_STATUS.get("PURCHASED_PENDING"),
                        TRANS_STATUS.get("FAILED")]
        pids = PendingTransaction.load_oids_by_attribute("verify_status",
                                                         False)
        for player_id in pids:
            pend_trans = PendingTransaction(player_id=player_id)
            if not pend_trans.exist():
                continue
            if pend_trans.verify_status:
                continue

            # mark verify status to True and begin verify with apple.
            pend_trans.verify_status = True
            pend_trans.store()

            # load purchase transaction
            trans = PurchaseTransaction.load_by_attribute(
                "sk_trans_id", pend_trans.sk_trans_id)
            trans = trans and trans[0]
            status = trans and trans.status
            if not (trans and trans.exist()) or status not in valid_status:
                # purchase not exit or already been handled - pass
                pend_trans.delete()
                continue

            product_id = pend_trans.product_id
            trans_id = pend_trans.sk_trans_id
            verify_kwargs = {"receipt": pend_trans.receipt,
                             "sk_trans_id": trans_id}
            kwargs = {"product_id": product_id,
                      "price": pend_trans.price,
                      "currency": pend_trans.currency}
            iap_trans = IAPTransaction(player_id,
                                       update_pending=False,
                                       actor=self, **kwargs)
            result_code, trans_update = iap_trans.verify(**verify_kwargs)
            if result_code == PurchaseResultCode.Value("APPLE_BUSY"):
                pend_trans.verify_status = False
                pend_trans.store()
                # apply busy - break and retry later
                break
            else:
                if (result_code and
                        status == TRANS_STATUS.get("PURCHASED_PENDING")):
                    # take away the gems if the receipt is invalid
                    if self.update_player_gem(player_id, product_id, trans_id,
                                              minus=True):
                        iap_trans.update_trans_status(
                            trans, TRANS_STATUS.get("FAILED"))
                elif (result_code is None
                      and status == TRANS_STATUS.get("FAILED")):
                    # update player gems.
                    if self.update_player_gem(player_id, product_id, trans_id):
                        iap_trans.update_trans_status(
                            trans, TRANS_STATUS.get("PURCHASED"))
                        iap_trans.send_stats_event()
                elif (result_code is None and
                            status == TRANS_STATUS.get("PURCHASED_PENDING")):
                    iap_trans.update_trans_status(
                        trans, TRANS_STATUS.get("PURCHASED"))
                    iap_trans.send_stats_event()
                pend_trans.delete()
            log.info("Successfully resolve pending transaction: %s"
                     % str(pend_trans.get_status_data()))
        self.verify()