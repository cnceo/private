#!/usr/bin/python

import gevent
from pykka import ActorRegistry

from base_actor import INVALID_SESSION_PID
from base_actor import ParentActor
from account import UpdateAccount
from creature import CreatureModify
from game import Game
from social import Social
from store import PurchaseActor
from base_actor import msg_map
from models.player import Player as PlayerModel
from models.player import Session
from utils.log import log
from utils.settings import DEFAULT_UTC_OFFSET, STOP_PLAYER_DELAY


player_stop_queue = {}
def remove_player_from_stop(pid):
    old_player = player_stop_queue.get(pid)
    if old_player:
        old_player.kill()
        if pid in player_stop_queue:
            del player_stop_queue[pid]

def get_player(session_id, version=None):
    session = Session(id=session_id)
    if session and session.exist():
        session.refresh_session()
        pid = session.player_id
        version = version or session.version
    else:
        pid = INVALID_SESSION_PID
    urn = 'Player_%s' % pid
    player = ActorRegistry.get_by_urn(urn)
    if player is None:
        player = Player.start(pid)

    remove_player_from_stop(pid)
    return player, pid, version

def stop_player(player, pid):
    def stop(p):
        gevent.sleep(STOP_PLAYER_DELAY)
        p.stop()
    remove_player_from_stop(pid)
    player_stop_queue[pid] = gevent.spawn(stop, player)


class Player(ParentActor):
    """
    the root actor for a player's requests after login
    """
    def __init__(self, pid=None):
        super(Player, self).__init__(pid)
        self.pid = pid
        # self._player = None
        self.children = []

    def on_receive(self, msg):
        # setup log
        param = {#"session_id": self.session_id(msg),
                 "player_id": self.pid,
                 "version": self.version(msg),
                 "os_type": self.player.os_type_name(),
                 "request_id": self.request_id(msg)}
        log.bind(**param)
        #TODO: add this if not stop player when finish resp
        # self._player = None
        func = msg.get("func")
        handler = msg_map.get(func)
        if handler:
            return self.call(handler, msg)
        else:
            log.error("UNKNOWN MESSAGE func=%s" % func, msg=msg.get('msg', ''))
            return None

    def call(self, cls, msg):
        c = self._get_cls_actor(cls)
        return c.ask(msg)

    @property
    def player(self):
        # if self._player is None:
        #     player = PlayerModel(id=self.pid)
        #     self._player = player
        # return self._player
        return PlayerModel(id=self.pid)

    @property
    def player_utc_offset(self):
        if self.pid == INVALID_SESSION_PID:
            return DEFAULT_UTC_OFFSET
        return self.player.utc_offset or DEFAULT_UTC_OFFSET

    def _get_cls_actor(self, cls):
        urn = self._build_urn(cls.__name__, self.pid)
        c = ActorRegistry.get_by_urn(urn)
        if not c:
            c= cls.start(self)
            self.children.append(c)
        return c

    def on_stop(self):
        for c in self.children:
            c.stop()
