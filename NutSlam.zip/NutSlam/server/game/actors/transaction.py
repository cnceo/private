import simplejson
import socket
import urllib2
from M2Crypto import RSA, EVP
from datetime import datetime
from actors.stats import DeltaRevenueIAP
from utils.constants import TRANS_TYPE
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import PurchaseResultCode
from utils.protocol_pb2 import TransactionInfo
from utils.settings import IAP_VERIFY_TIMEOUT
from utils.settings import INAPP_PURCHASE_VERIFY_URL
from utils.settings import INAPP_PURCHASE_SANDBOX_VERIFY_URL
from utils.settings import IS_PRODUCTION
from utils.settings import UNITY3D_FLAG
from utils.stats_pb2 import DeltaInAppPurchaseChannel
from models.content import GameRule
from models.player import Player
from models.transaction import PurchaseTransaction
from models.transaction import PendingTransaction
from models.transaction import TRANS_STATUS
from models.transaction import trans_id_count
from utils.log import log


class BaseTransaction(object):
    os_type = None
    trans_type = None
    trans_index = None
    stats_channel = DeltaInAppPurchaseChannel.Value(
        "AppleStore")
    _player = None
    unity_buy = False

    def __init__(self, player_id, msg=None, actor=None, **kwargs):
        super(BaseTransaction, self).__init__()
        self.player_id = player_id
        self.msg = msg
        self.actor = actor
        if not IS_PRODUCTION and UNITY3D_FLAG in msg.receipt:
            pid, pl_id = msg.receipt.split(UNITY3D_FLAG)
            if pid == msg.pid and pl_id == str(player_id):
                self.unity_buy = True
        self.price = msg and msg.price or kwargs.get("price")
        self.currency = msg and msg.currency or kwargs.get("currency")
        self.product_id = msg and msg.pid or kwargs.get("product_id")
        self.trans_id = msg and msg.trans_id or kwargs.get("sk_trans_id")

    @property
    def player(self):
        if self._player is None:
            self._player = Player(id=self.player_id)
        return self._player

    def verify_pending(self, ):
        pending_trans = PendingTransaction(player_id=self.player_id)
        pending = pending_trans.exist()
        if (pending and self.player_id not in
                PendingTransaction.load_oids_by_attribute("checked", False)):
            # Make sure pending trans can been handled.
            pending_trans.store()
        return pending

    def duplicate_trans(self, trans_kw):
        trans = PurchaseTransaction.load_by_attribute(
            self.trans_index, trans_kw.get(self.trans_index))
        return trans and trans[0]

    def create_trans(self, **kw):
        kw.update({"player_id": self.player_id,
                   "status": TRANS_STATUS['STARTED'],
                   "start_time": datetime.now(),
                   "trans_type": self.trans_type,
                   "product_id": self.product_id})
        trans = PurchaseTransaction(**kw)
        trans.store()
        return trans

    def pay_gems(self, qt):
        player = self.player
        if player.exist():
            details = {"product_id": self.product_id,
                       "trans_id": self.trans_id,
                       "gems_qty": qt}
            log.bind(purchase=details)
            player.update_gems(qt, TRANS_TYPE.PURCHASE, **details)
            player.super_cooker = True
            player.store()
            log.info("%s purchase - added %s gems to player(%s)" %
                     (self.os_type, qt, self.player_id))
            return True
        return False

    def update_trans_status(self, trans, status, **kwargs):
        # TODO - check status before update
        for key, val in kwargs.iteritems():
            setattr(trans, key, val)
        trans.status = status
        trans.handle_time = datetime.now()
        trans.store()
        return True

    def handle_purchase(self):
        if not self.unity_buy and self.check_params():
            trans = TransactionInfo()
            trans.result_code = PurchaseResultCode.Value("MISSING_PARAM")
            return [trans]
        return self._handle_purchase()

    def check_params(self):
        raise NotImplementedError

    def _handle_purchase(self):
        raise NotImplementedError

    def verify(self, **kwargs):
        raise NotImplementedError

    def handle_verify_failed(self, trans, failed_reason,
                             quantity, **kwargs):
        return False

    def send_stats_event(self):
        iap = {"Price": self.price,
               "Currency": self.currency,
               "Package": self.product_id,
               "Quantity": 1,
               "Channel": self.stats_channel,
               }
        iap.update(self.stats_data())
        self.actor.send_event(DeltaRevenueIAP, {"IAP": iap}, self.player)

    def stats_data(self):
        return {}

    def handle_transaction(self, trans_kwargs, verify_kwargs):
        product_info = GameRule.prices.hc_info(self.product_id)
        trans_info = TransactionInfo()
        for key, val in trans_kwargs.iteritems():
            setattr(trans_info, key, val)
        if self.verify_pending():
            result_code = PurchaseResultCode.Value("THIRD_PARTY_PENDING")
            msg = "Third party busy, please try again later"
        elif self.duplicate_trans(trans_kwargs):
            result_code = PurchaseResultCode.Value("DUPLICATE_PURCHASE")
            msg = "Duplicate transaction"
            log.info("Got duplicate verification request", **trans_kwargs)
        else:
            quantity = product_info and product_info.quantity or 0
            trans = self.create_trans(**trans_kwargs)
            if self.unity_buy:
                log.warn("Dummy Unity3D purchase",
                         pid=self.product_id, qty=quantity)
                result_code, trans_update = (None, {})
            else:
                result_code, trans_update = self.verify(**verify_kwargs)
            log_data = {"player_id": self.player_id,
                        "purchase_type": self.trans_type,
                        "product_info": {"product_id": self.product_id,
                                         "quantity": quantity}}
            if result_code is None:
                if self.pay_gems(quantity):
                    self.update_trans_status(trans, TRANS_STATUS["PURCHASED"],
                                             **trans_update)
                    result_code = PurchaseResultCode.Value("SUCCESS_PURCHASED")
                    msg = "Purchase successful"
                    log.info("Purchase successful", **log_data)
                else:
                    self.update_trans_status(trans, TRANS_STATUS["UNPAID"],
                                             **trans_update)
                    result_code = PurchaseResultCode.Value("SUCCESS_UNPAID")
                    msg = "Failed to reward player"
                    log.info("Purchase unpaid", **log_data)
                self.send_stats_event()
            else:
                if not self.handle_verify_failed(trans, result_code,
                                                 quantity, **verify_kwargs):
                    self.update_trans_status(trans, TRANS_STATUS["FAILED"])
                msg = "Failed to verify purchase with third party"
                log_data["verify_data"] = verify_kwargs
                log.info("Purchase verification failed", **log_data)
        trans_info.result_code = result_code
        trans_info.msg = msg
        trans_info.product_info.CopyFrom(product_info)
        return trans_info


class IAPTransaction(BaseTransaction):
    os_type = OSType.Value("IOS")
    trans_type = "IAP"
    trans_index = "sk_trans_id"
    stats_channel = "AppleStore"

    def __init__(self, player_id, msg=None, actor=None,
                 update_pending=True, **kwargs):
        super(IAPTransaction, self).__init__(player_id, msg, actor, **kwargs)
        self.update_pending = update_pending

    def _send_verify(self, url, trans_receipt, timeout):
        payload = simplejson.dumps({'receipt-data': trans_receipt})
        req = urllib2.Request(url, payload)
        resp = urllib2.urlopen(req, timeout=timeout)
        resp = simplejson.loads(resp.read())
        return resp

    def do_verify(self, trans_receipt, timeout=IAP_VERIFY_TIMEOUT):
        url = INAPP_PURCHASE_VERIFY_URL
        resp = self._send_verify(url, trans_receipt, timeout)
        if 21007 == resp.get("status"):
            # player use an sendbox account
            log_data = {"player_id": self.player_id,
                        "resp": resp,
                        "receipt": trans_receipt}
            log.warn("IAP - Player use an sendbox account: %s"
                        % str(log_data))
            resp = self._send_verify(INAPP_PURCHASE_SANDBOX_VERIFY_URL,
                                     trans_receipt, timeout)
        return resp

    def verify(self, receipt=None, sk_trans_id=None):
        result_code = None
        receipt_resp = None
        try:
            resp = self.do_verify(receipt)
        except Exception, e:
            log.error("IAP - verify exception: %s" % str(e),
                      exc_info=True)
            result_code = PurchaseResultCode.Value("UNKNOWN")
            if isinstance(e.reason, socket.timeout):
                result_code = PurchaseResultCode.Value("APPLE_BUSY")
        else:
            if 21005 == resp.get("status") or resp.get("status") is None:
                result_code = PurchaseResultCode.Value("APPLE_BUSY")
            else:
                receipt_resp = resp.get("receipt")
                if (resp.get("status") != 0 or receipt_resp is None
                    or self.product_id != receipt_resp.get('product_id')
                    or sk_trans_id != receipt_resp.get('transaction_id')):
                    result_code = PurchaseResultCode.Value("IAP_THIEF")
                    log.info("IAP thief.", receipt_resp=receipt_resp,
                             response_status=resp.get("status"),
                             product_id=self.product_id,
                             trans_id=self.trans_id)

        trans_update = {}
        if result_code is None:
            trans_update["receipt"] = receipt_resp
        return result_code, trans_update

    def record_apple_busy(self, receipt=None, sk_trans_id=None):
        if not self.update_pending:
            return
        param = {"checked": False,
                 "verify_status": False,
                 "receipt": receipt,
                 "sk_trans_id": sk_trans_id,
                 "product_id": self.product_id,
                 "price": self.price,
                 "currency": self.currency,
                 "datetime": datetime.now(),
                 "player_id": self.player_id}
        pending = PendingTransaction(**param)
        pending.store()

    def handle_verify_failed(self, trans, failed_reason, quantity, **kwargs):
        if failed_reason == PurchaseResultCode.Value("APPLE_BUSY"):
            self.record_apple_busy(**kwargs)
            if self.pay_gems(quantity):
                self.update_trans_status(trans,
                                         TRANS_STATUS["PURCHASED_PENDING"])
                log.info("Given player(%s) gems(%s) while apple_busy"
                         % (self.player_id, quantity))
                return True
        return False

    def check_params(self):
        return not self.msg.receipt or not self.msg.trans_id

    def _handle_purchase(self):
        trans_kwargs = {"sk_trans_id": self.msg.trans_id}
        verify_kwargs = {"receipt": self.msg.receipt,
                         "sk_trans_id": self.msg.trans_id}
        trans = self.handle_transaction(trans_kwargs, verify_kwargs)
        return [trans]

    def stats_data(self):
        return {"TransactionId": self.trans_id}


class IABTransaction(BaseTransaction):
    os_type = OSType.Value("Android")
    trans_type = "IAB"
    trans_index = "order_id"
    stats_channel = "GooglePlayStore"

    def verify(self, signature=None, signed_data=None):
        """
        @param signature: the signature in GooglePurchaseTemplate
        @param signed_data: the originalJson in GooglePurchaseTemplate

        * Check signature and signed data with public key
        * Verify orderId match msg.trans_id in request
        * Verify productId match msg.pid in request

        @Return (IAB_CHEATER, {}) if any of above failed, otherwise (None, {}).
        """
        signed_data = str(signed_data)
        signature = str(signature)

        pem_file = "certificate/iab_public_key.pem"
        rsa = RSA.load_pub_key(pem_file)

        pubkey = EVP.PKey()
        pubkey.assign_rsa(rsa)
        pubkey.reset_context(md='sha1')
        pubkey.verify_init()
        try:
            pubkey.verify_update(signed_data)

            signature_padded = signature
            if signature_padded:
                while len(signature_padded) % 4 != 0:
                    signature_padded += '='
            signature_decoded = signature_padded.decode('base64')
            order = simplejson.loads(signed_data)
            v_result = pubkey.verify_final(signature_decoded)
            if (v_result != 1 or order.get("productId") != self.product_id
                    or order.get("orderId") != self.order_id):
                log.info("IAB thief.", verify_result=v_result,
                         order=order, product_id=self.product_id,
                         order_id=self.order_id)
                return PurchaseResultCode.Value("IAB_CHEATER"), {}
            return None, {}
        except Exception, e:
            log.error("IAB verify: %s" % str(e))
            return PurchaseResultCode.Value("UNKNOWN"), {}

    def check_params(self):
        return (not self.msg.token or not self.msg.trans_id or
                not self.msg.receipt)

    def _handle_purchase(self):
        self.order_id = self.msg.trans_id
        trans_kwargs = {"order_id": self.order_id}
        verify_kwargs = {"signature": self.msg.receipt,
                         "signed_data": self.msg.token}
        trans = self.handle_transaction(trans_kwargs, verify_kwargs)
        return [trans]

    def stats_data(self):
        return {"OrderId": self.order_id}
