import os
import jinja2 as jinja
from utils.misc import get_couchbase_url
from utils.settings import ADMIN_KEY


class JinjaLoader(object):
    """
    A Tool for loading Jinja templates.
    """

    def __init__(self, template_dir="templates"):
        super(JinjaLoader, self).__init__()
        self.env = jinja.Environment()
        self.template_dirs = []
        self.dir = os.path.join(os.getcwd(), os.path.dirname(__file__))
        self._set_template_dir(os.path.join(self.dir, template_dir))

    def _set_template_dir(self, directory):
        ldr = jinja.FileSystemLoader(searchpath=directory)
        self.template_dirs = [ldr]
        self.env.loader = jinja.ChoiceLoader(self.template_dirs)


loader = None


def get_loader():
    global loader
    if not loader:
        loader = JinjaLoader()
    return loader


class JinjaRender(object):

    def __init__(self, filename):
        super(JinjaRender, self).__init__()
        self.filename = filename

    def __call__(self, method):
        def decorator(*args, **kwargs):
            result = method(*args, **kwargs)
            if isinstance(result, dict):
                tpl = self.get_template()
                result["couchbase_url"] = get_couchbase_url()
                result["ADMIN_KEY"] = ADMIN_KEY
                return tpl.render(**result)
            else:
                return result
        return decorator

    @property
    def site_path(self):
        return get_loader().dir

    def get_template(self):
        return get_loader().env.get_template(self.filename)