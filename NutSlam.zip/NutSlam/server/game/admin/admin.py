import simplejson
from jinja_util import JinjaRender
from models.content import GameRule
from models.creature import CreatureInstance
from models.creature import Nuts
from models.creature import CreatureTeam
from models.gift import ADMIN_MSG
from models.gift import GiftInbox
from models.ledgers import GemsLedger
from models.ledgers import CoinsLedger
from models.ledgers import HeartsLedger
from models.player import DeviceLink
from models.player import Player
from models.transaction import TRANS_STATUS_REV
from models.transaction import PurchaseTransaction
from utils.constants import TRANS_TYPE
from utils.misc import date_to_str
from utils.misc import to_bool
from utils.protocol_pb2 import EggType
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import GiftType
from utils.settings import default_amdin_msg
from utils.log import log


GameRule.get_content()
INVALID_PLAYER_ID = "Error, Invalid player id."
NOT_FIND_PLAYER_ERROR = "Error, Not find this player."
INVALID_CREATURE_SLUG = "Error, Invalid creature slug."
INVALID_CREATURE_ID = "Error, Invalid creature id."
CREATURE_NOT_EXIST = "Error, player(%s) do not have a creature with id: %s."
CREATURE_LOCKED = "Error, can't remove activate creature."
MISSING_ATTR = "Error, please specify the attribute you want modify."
INVALID_ATTR = "Error, player do not have attribute: %s"
MISSING_VALUE = "Error, please specify the value you want modify to."
NEW_VALUE_INVALID_TYPE = "Error, invalid type for new value."
INVALID_KEYWORD = "Error, didn't specify anything to search"
MISSING_DEVICE_ID = "Error, missing the device id."
INVALID_DEVICE_ID = "Error, device(%s) not exist."
DEVICE_PID_NOT_MATCH = "Error, device(%s) not point to player(%s)."
INVALID_GEM_AMOUNT = "Error, gem amount must be integer."


class AdminResource(object):
    _ledger_map = {"gems_ledger": GemsLedger,
                   "coins_ledger": CoinsLedger,
                   "hearts_ledger": HeartsLedger}
    # ledger in _ordered_ledger must exist in _ledger_map
    _ordered_ledger = ["gems_ledger", "coins_ledger", "hearts_ledger"]

    def handle(self, path, request):
        if path.isdigit():
            return self.player_info(int(path))
        if path == "search":
            return self.search_player(request)
        if path == "search_id":
            return self.search_player_by_id(request)
        if path == "remove_creature":
            return self.remove_creature(request)
        if path == "add_creature":
            return self.add_creature(request)
        if path == "modify_player":
            return self.modify_player(request)
        if path == "update_device":
            return self.update_device(request)
        if path == "send_gift":
            return self.send_gift(request)
        # player details: creatures, gem_purchases, gift_inbox, ledgers
        if path == "creatures":
            return self._player_response(request, self.creatures)
        if path == "gem_purchases":
            return self._player_response(request, self.gem_purchases)
        if path == "gift_inbox":
            return self._player_response(request, self.gift_inbox)
        if path in self._ledger_map:
            return self._player_response(request, self.get_ledger, path)
        l_name = path.replace("adjust_", "")
        if l_name in self._ledger_map:
            return self._player_response(
                request, self.get_ledger, l_name, adjust=True)
        return self.main_page()

    def _player_info(self, player, simple_mode=True):
        p_info = {"id": player.id,
                  "name": player.pip_name,
                  "fb_name": player.fb_name,
                  "os_type": OSType.Name(player.get_os_type()),
                  "facebook_id": player.facebook_id,
                  "device_id": player.device_id,
                  "create_time": date_to_str(player.create_time),
                  "login_time": date_to_str(player.login_time),
                  "utc_offset": player.utc_offset}
        if simple_mode:
            p_info["social_id"] = player.get_social_id()
        else:
            p_info.update({
                "agc_id": player.agc_id,
                "gp_id": player.gp_id,
                "gp_email": player.gp_email,
                # basic info
                "xp": player.xp,
                "level": player.level,
                "max_energy": player.maxenergy,
                "energy": player.energy,
                "progress": player.progress,
                "max_creatures": player.max_creatures,
                "coins": player.coins,
                "hearts": player.hearts,
                "gems": player.gems,
                "super_cooker": player.super_cooker,
                "gatcha_pulled": player.gatcha_pulled,
                # material
                "stone_s": player.stone_s,
                "stone_m": player.stone_m,
                "stone_l": player.stone_l,
                "stone_x": player.stone_x,
                "stone_fire_s": player.stone_fire_s,
                "stone_fire_l": player.stone_fire_l,
                "stone_wood_s": player.stone_wood_s,
                "stone_wood_l": player.stone_wood_l,
                "stone_water_s": player.stone_water_s,
                "stone_water_l": player.stone_water_l,
                "stone_light_s": player.stone_light_s,
                "stone_light_l": player.stone_light_l,
                "stone_dark_s": player.stone_dark_s,
                "stone_dark_l": player.stone_dark_l,
                # settings
                "notify_energy_full": player.notify_energy_full,
                "notify_event_dungeon_boss": player.notify_event_dungeon_boss,
                "notify_event_weekday": player.notify_event_weekday,
                "notify_event_xp": player.notify_event_xp,
                "notify_friends_join": player.notify_friends_join,
                "notify_inactive": player.notify_inactive,
                "feedback": player.feedback,
                })

            p_info["ledgers"] = self._ledger_index()
            p_info["linked_device"] = DeviceLink.load_oids_by_attribute(
                "player_id", player.id)
            c_slugs = sorted(GameRule.creature_types.all_slugs())
            p_info["creature_slugs"] = c_slugs
            p_info["inbox_msg"] = default_amdin_msg
        return p_info

    @JinjaRender("player_info.tpl")
    def player_info(self, player_id):
        p = Player(id=player_id)
        if not p.exist():
            return NOT_FIND_PLAYER_ERROR
        return {"player": self._player_info(p, simple_mode=False)}

    @JinjaRender("search_player.tpl")
    def search_player_by_id(self, request):
        player_id = request.args.get("player_id")
        p = Player(id=player_id)
        if p.exist():
            return {"players": [self._player_info(p)]}
        return NOT_FIND_PLAYER_ERROR

    @JinjaRender("search_player.tpl")
    def search_player(self, request):
        pids = set()
        detail = request.args.get("detail")
        if not detail:
            return INVALID_KEYWORD
        for index_attr in Player.index_attribute:
             pids.update(Player.load_oids_by_attribute(index_attr, detail))
        if pids:
            return {"players": [self._player_info(Player(id=pid))
                                for pid in pids]}
        return NOT_FIND_PLAYER_ERROR

    def _player_response(self, request, handler, *args, **kwargs):
        # valid player id and call handler
        player_id = request.args.get("player_id")
        err_msg = self._valid_player_id(player_id)
        if err_msg:
            return err_msg
        return handler(player_id, *args, **kwargs)

    @JinjaRender("gift.tpl")
    def gift_inbox(self, player_id):
        gifts = []
        g_inbox = GiftInbox(player_id=player_id)
        for g in g_inbox.get_gifts():
            egg = g.e_v
            if g.c_id:
                egg = "%s(%s)" % (egg, g.c_id)
            gifts.append({"gift_id": g.g_id,
                          "gift_type": GiftType.Name(g.g_type),
                          "sender": g.sender,
                          "egg_type": EggType.Name(g.e_t),
                          "egg_value": egg})
        return {"gifts": gifts}

    @JinjaRender("creature.tpl")
    def creatures(self, player_id):
        creatures = []
        c_team_map = CreatureTeam(player_id=player_id).creature_team_map()
        for c in CreatureInstance.load_by_attribute("player_id", player_id):
            creatures.append({"cid": c.cid,
                              "slug": c.slug,
                              "xp": c.xp,
                              "level": c.level,
                              "plusHP": c.plusHP,
                              "plusAttack": c.plusAttack,
                              "plusSpeed": c.plusSpeed,
                              "plusLuck": c.plusLuck,
                              "team": c_team_map.get(c.cid, "")})
        return {"creatures": creatures,
                "player_id": player_id}

    @JinjaRender("gem_purchase.tpl")
    def gem_purchases(self, player_id):
        trans = []
        for t in PurchaseTransaction.load_by_attribute(
                "player_id", player_id):
            p = GameRule.prices.hc_info(t.product_id)
            trans.append({"trans_type": t.trans_type,
                          "trans_id": t.sk_trans_id or t.order_id,
                          "product_id": t.product_id,
                          "status": TRANS_STATUS_REV[t.status],
                          "quantity": p and p.quantity or 0,
                          "start_time": date_to_str(t.start_time),
                          "handle_time": date_to_str(t.handle_time),
                          })
        trans.reverse()
        return {"purchases": trans}

    def _ledger_index(self):
        ledgers = []
        for l_slug in self._ordered_ledger:
            l_name = l_slug.capitalize().replace("_", " ")
            ledgers.append({"slug": l_slug, "name": l_name})
        return ledgers

    @JinjaRender("ledger.tpl")
    def get_ledger(self, player_id, ledger_name, adjust=False):
        def _trans_info(ledger, b):
            b += ledger.qty
            t_type = ledger.trans_type or TRANS_TYPE.UNKNOWN
            t_type = TRANS_TYPE.name(t_type).lower()
            return {"trans_type": t_type,
                    "qty": ledger.qty,
                    "details": ledger.details or "",
                    "datetime": date_to_str(ledger.datetime),
                    "balance": b}, b

        ledgers = []
        balance = 0
        l_cls = self._ledger_map.get(ledger_name)
        for l in l_cls.load_by_attribute("player_id", player_id):
            t_info, balance = _trans_info(l, balance)
            ledgers.append(t_info)
        ledgers.reverse()
        resp = {"ledger": ledgers,
                "ledger_slug": ledger_name}
        player = Player(id=player_id)
        p_val = getattr(player, "%ss" % l_cls.ledger_type.lower())
        if p_val != balance:
            if adjust:
                adjustment = player.update_ledger(
                    l_cls, TRANS_TYPE.BALANCE_ADJUSTMENT, p_val - balance)
                ledgers.insert(0, _trans_info(adjustment, balance)[0])
            else:
                resp["balance"] = {"player": p_val, "ledger": balance}
        return resp

    @JinjaRender("main.tpl")
    def main_page(self):
        return {}

    def _render_json_resp(self, err_msg, **kwargs):
        if err_msg:
            result = {"msg": err_msg,
                      "success": False}
        else:
            result = {"success": True}
        if kwargs:
            result.update(kwargs)
        return simplejson.dumps(result)

    def remove_creature(self, request):
        def _handle(player_id, c_id):
            if not (player_id and player_id.isdigit()):
                return INVALID_PLAYER_ID
            if not c_id.isdigit():
                return INVALID_CREATURE_ID
            player_id = int(player_id)
            c_id = int(c_id)
            activate_c = CreatureTeam(player_id=player_id).get_creatures()
            if c_id in activate_c:
                return CREATURE_LOCKED
            c = CreatureInstance(player_id=player_id, cid=c_id)
            if not c.exist():
                return CREATURE_NOT_EXIST % (player_id, c_id)
            c.delete()
            log.info("Admin delete creature", cid=c_id, player_id=player_id)
        msg = _handle(request.args.get("player_id"),
                      request.args.get("cid"))
        return self._render_json_resp(msg)

    def add_creature(self, request):
        kwargs = {}
        player_id = request.args.get("player_id")
        c_slug = request.args.get("c_slug")
        if c_slug not in GameRule.creature_types.all_slugs():
            msg = INVALID_CREATURE_SLUG
        else:
            msg = self._valid_player_id(player_id)
            if not msg:
                c = Nuts.create(player_id, c_slug, auto_open=True)
                kwargs["c_info"] = c.get_stats_data()
        return self._render_json_resp(msg, **kwargs)

    def modify_player(self, request):
        def _handle(player_id, attr, value):
            if not (player_id and player_id.isdigit()):
                return INVALID_PLAYER_ID
            player_id = int(player_id)
            if not attr:
                return MISSING_ATTR
            a_type = Player.attr_type(attr)
            if not a_type:
                return INVALID_ATTR % attr
            if not value:
                return MISSING_VALUE
            try:
                if a_type.type is bool:
                    value = to_bool(value)
                else:
                    value = a_type.type(value)
            except TypeError:
                return NEW_VALUE_INVALID_TYPE
            p = Player(id=player_id)
            if not p.exist():
                return NOT_FIND_PLAYER_ERROR
            if attr in p.ledger_map:
                func = getattr(p, "update_%s" % attr)
                func(value - p.get(attr), TRANS_TYPE.SUPPORT)
            else:
                setattr(p, attr, value)
            p.store()

        msg = _handle(request.args.get("player_id"),
                      request.args.get("attr"),
                      request.args.get("value"))
        return self._render_json_resp(msg)

    def _valid_player_id(self, player_id):
        if not (player_id and player_id.isdigit()):
            return INVALID_PLAYER_ID
        p = Player(id=player_id)
        if not p.exist():
            return NOT_FIND_PLAYER_ERROR

    def update_device(self, request):
        d_id = request.args.get("device_id", "")
        orig_pid = request.args.get("orig_pid", "")
        new_pid = request.args.get("new_pid", "")
        if not d_id:
            return self._render_json_resp(MISSING_DEVICE_ID)
        d_link = DeviceLink(device_id=d_id)
        if not d_link.exist():
            msg = INVALID_DEVICE_ID % d_id
            return self._render_json_resp(msg)
        if str(d_link.player_id) != orig_pid:
            msg = DEVICE_PID_NOT_MATCH % (d_id, orig_pid)
            return self._render_json_resp(msg)
        err_msg = self._valid_player_id(new_pid)
        if not err_msg:
            d_link.player_id = new_pid
            d_link.store()
        return self._render_json_resp(err_msg)

    def send_gift(self, request):
        player_id = request.args.get("player_id")
        gems = request.args.get("gems")
        c_slug = request.args.get("creature")
        gift_msg = request.args.get("gift_msg") or ""
        gift_pn = request.args.get("gift_pn") or ""

        def _verify():
            _err_msg = self._valid_player_id(player_id)
            if _err_msg:
                return _err_msg
            if gems and not gems.isdigit():
                return INVALID_GEM_AMOUNT
            if c_slug and c_slug not in GameRule.creature_types.all_slugs():
                return INVALID_CREATURE_SLUG
        err_msg = _verify()
        if not err_msg:
            inbox = GiftInbox(player_id=player_id)
            if gems and int(gems):
                egg_type = EggType.Value("GEM_EGG")
                g_val = int(gems)
            elif c_slug:
                egg_type = GameRule.egg_type(c_slug)
                g_val = c_slug
            else:
                # no reward.
                egg_type = None
                g_val = None
            inbox.give_gift(ADMIN_MSG, player_id, egg_type, g_val,
                            message=gift_msg, pn_msg=gift_pn)
        return self._render_json_resp(err_msg)
