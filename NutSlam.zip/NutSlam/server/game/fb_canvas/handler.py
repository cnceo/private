from jinja_util import JinjaRender
from utils.settings import APP_ID, NUTSSLAM_FACEBOOK_URL, SITE_NAME, APP_URL
from models.content import GameRule
from utils.protocol_pb2 import TriggerType

NOT_FIND_PLAYER_ERROR = 'Sorry, can not find this creature.'


class FbCanvasResource(object):

    @JinjaRender("review_page.tpl")
    def handle(self):
        resource_path = GameRule.configs.get('resourceUpdaterPath') or APP_URL
        return {'MEDIA_URL': resource_path + 'media/fb_canvas/'}
