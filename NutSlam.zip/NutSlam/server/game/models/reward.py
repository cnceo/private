import simplejson
from datetime import datetime
from dal.base import *
from dal.db import db
from models.player import Player, PassedDungeons, PlayerStatic
from models.content import GameRule
from models.creature import CreatureInstance
from models.creature import Nuts
from models.gift import build_gift_msg
from models.gift import RECRUIT_FB_DAILY_AD
from models.gift import RECRUIT_FB_TO_SEND
from models.player import CurrentHelper
from utils.constants import TRANS_TYPE
from utils.misc import random_number
from utils.misc import next_x_days
from utils.misc import time_of_day
from utils.protocol_utils import assign_value
from utils.settings import RECRUIT_FB_FRIEND_TTL_DAY
from utils.settings import RECRUIT_FB_FRIEND_DATE_FORMAT
from utils.settings import FAERIE_EGG, SELF_EGG, MATERIAL_EGG, COIN_EGG, GEM_EGG
from utils.settings import NUT_EGG
from utils.settings import DEFAULT_UTC_OFFSET


class BattleReward(Base):
    _oid_key = "player_id"

    player_id = IntAttr()
    xp = IntAttr()
    coins = LongAttr()
    hearts = IntAttr()
    dungeon_reward = TextAttr()
    eggs = ListAttr(TextAttr())
    _speed_eggs = ListAttr(TextAttr())
    _speed_turns = ListAttr(IntAttr())
    _dungeon_eggs = ListAttr(TextAttr())
    progress = IntAttr()
    dungeon_id = IntAttr()
    key = LongAttr()
    retry_times = IntAttr()
    helper_id = IntAttr()

    def __init__(self, **kw):
        super(BattleReward, self).__init__(**kw)
        self.__egg_id = 0

    def remove_self_egg(self, configs):
        if not configs:
            return
        for i in range(len(configs['loots'])):
            if configs['loots'][i]['type'] == SELF_EGG:
                configs['loots'].remove(configs['loots'][i])
                configs['rates'].pop(i)
                break

    def _egg_id(self):
        self.__egg_id += 1
        return self.__egg_id

    def add_egg(self, egg, egg_data, speed=None, dungeon=False):
        egg_data["id"] = self._egg_id()
        # since egg id is local variable for battle, save nut id to creature.
        if egg_data['type'] in [FAERIE_EGG, SELF_EGG, NUT_EGG]:
            egg_data['creature']['cid'] = Nuts.get_id(self.player_id)
        assign_value(egg, egg_data)
        if not self.eggs: self.eggs = []
        if not self._speed_eggs: self._speed_eggs = []
        if not self._speed_turns: self._speed_turns = []
        if not self._dungeon_eggs: self._dungeon_eggs = []
        if speed:
            self._speed_eggs.append(simplejson.dumps(egg_data))
            self._speed_turns.append(speed)
        elif dungeon:
            self._dungeon_eggs.append(simplejson.dumps(egg_data))
        else:
            self.eggs.append(simplejson.dumps(egg_data))

    def drop_egg(self, droppers, config, rep, repeated=False, speed=False, dungeon_reward=False):
        egg_data =  GameRule.battle_drop_egg(droppers, config, dungeon_reward)
        if not egg_data: return
        egg = rep.add() if repeated else rep
        self.add_egg(egg, egg_data, speed=speed, dungeon=dungeon_reward)

    def drop_clearance_egg(self, droppers, configs, rep, repeated=False, speed=False):
        if not configs:
            return
        number = random_number(configs['total'])
        index = 0
        for i in range(len(configs['rates'])):
            if configs['rates'][i] >= number:
                index = i
                break
        config = configs['loots'][index]
        self.drop_egg(droppers, config, rep, repeated=repeated, speed=speed)

    def drop_luck_egg(self, dropper, configs, pid, leader_id, rep, dungeon_id):
        utc_offset = Player(id=pid).utc_offset or DEFAULT_UTC_OFFSET
        luck = CreatureInstance(cid=leader_id, player_id=pid).plusLuck or 0
        luck *= GameRule.get_world(utc_offset).dungeon_luck(dungeon_id)
        if not GameRule.battle_drop_luck_egg(luck): return
        self.drop_clearance_egg(dropper, configs, rep)

    def drop_speed_egg(self, dropper, configs, speed_configs, rep):
        if not speed_configs: return
        for i in range(len(speed_configs)):
            speed_egg = rep.add()
            speed_egg.param.append(speed_configs[i])
            egg = speed_egg.egg.add()
            self.drop_clearance_egg(dropper, configs, egg, speed=speed_configs[i])

    def drop_dungeon_egg(self, configs, rep):
        #TODO: discuss if we need check passed_dungeons when battle begin or not
        passed_dungeons = PassedDungeons(player_id=self.player_id).ids or []
        if self.dungeon_id in passed_dungeons: return
        for config in configs:
            self.drop_egg('', config, rep, repeated=True, dungeon_reward=True)

    def calc_speed_eggs(self, turns):
        if not turns: return
        for i in sorted(self._speed_turns, reverse=True):
            if turns <= i and self._speed_eggs:
                self.eggs.append(self._speed_eggs.pop(0))
            else:
                break

    def pay(self, speed_turns, player=None, skipped_eggs=None):
        skipped_eggs = skipped_eggs or []
        pay_data = {'drops':[]}
        player = player or Player(id=self.player_id)
        passed_dungeons = PassedDungeons(player_id=self.player_id)
        if not passed_dungeons.ids: passed_dungeons.ids = []
        gems = 0
        hearts = self.hearts or 0
        if self.dungeon_id not in passed_dungeons.ids:
            passed_dungeons.ids.append(self.dungeon_id)
            passed_dungeons.store()
            self.eggs.extend(self._dungeon_eggs)
            gems += GameRule.prices.finish_dungeon_reward()
        coins = self.coins
        self.calc_speed_eggs(speed_turns)
        # give player reward from egg:
        for egg in self.eggs:
            egg = simplejson.loads(egg)
            if egg.get("id") in skipped_eggs:
                continue
            if egg['type'] == FAERIE_EGG or egg['type'] == SELF_EGG:
                c_data = egg['creature']
                c_slug = c_data.pop("slug", None)
                if c_slug:
                    Nuts.create(self.player_id, c_slug, auto_open=True,
                                **c_data)
                pay_data['drops'].append({'type': egg['type'], 'slug': c_slug,
                                          'cid': c_data.get('cid')})
            elif egg['type'] == NUT_EGG:
                # since egg id is local variable for battle,
                # we save nut id to creature.
                nut = egg["nut"]
                c_id = egg.get("creature", {}).get("cid")
                n = Nuts.generate(self.player_id, nut, cid=c_id)
                pay_data['drops'].append({"type": egg['type'],
                                          "nut": nut,
                                          "nut_id": n.cid})
            elif egg['type'] == MATERIAL_EGG:
                m = egg.get('material')
                player.modify_material(m, 1)
                pay_data['drops'].append({'type': egg['type'], 'slug': m})
            elif egg['type'] == COIN_EGG:
                coins += egg.get('coins')
            elif egg['type'] == GEM_EGG:
                gems += egg.get('gems')
        # give player normal reward
        details = {"dungeon": self.dungeon_id,
                   "player_progress": player.progress,
                   "dungeon_progress": self.progress}
        player.set_progress(self.progress)
        player.add_xp(self.xp)
        player.update_coins(coins, TRANS_TYPE.FINISH_DUNGEON, **details)
        player.update_gems(gems, TRANS_TYPE.FINISH_DUNGEON, **details)
        player.update_hearts(hearts, TRANS_TYPE.USING_HELPER, **details)
        pay_data['xp'] = self.xp
        pay_data['coins'] = self.coins
        pay_data['gems'] = gems
        player.store()

        if self.helper_id:
            helper_static = PlayerStatic(id=self.helper_id)
            if helper_static.facebook_id:
                CurrentHelper(player.id).store(self.helper_id)

        return pay_data


class FacebookFriendReward(Base):
    player_id = LongAttr()
    update_time = DateTimeAttr()
    daily_gift = TextAttr()
    daily_gift_send = BoolAttr(default=False)
    _oid_key = "player_id"

    def store(self):
        now = datetime.utcnow()
        self.update_time = now
        super(FacebookFriendReward, self).store()
        db(self._db_type).touch(self._get_key(), self.ttl(now))

    def exist(self):
        return (super(FacebookFriendReward, self).exist() and
                datetime.utcnow() < self.ttl_time(self.update_time))

    def ttl_time(self, now):
        return time_of_day(next_x_days(now, days=RECRUIT_FB_FRIEND_TTL_DAY),
                           hour=0, minute=0)

    def ttl(self, now=None):
        if not now:
            now = datetime.utcnow()
        return int((self.ttl_time(now) - now).total_seconds()) + 1

    def generate_gift(self, facebook_name):
        key = "RecruitFB_%s_%s" % (self.player_id, facebook_name)
        return GameRule.viral.recruit_friend_gift(key)

    def _now_str(self):
        return datetime.utcnow().strftime(RECRUIT_FB_FRIEND_DATE_FORMAT)

    def players_gift_proto(self, proto, facebook_names):
        daily_gift = self.get_daily_gift(do_store=True)
        if daily_gift:
            proto.gift.egg.type = GameRule.egg_type(daily_gift)
            proto.gift.egg.creature.slug = daily_gift
            proto.gift.message = build_gift_msg(RECRUIT_FB_DAILY_AD)
            proto.gift_ttl = self.ttl()

        for fb_name in facebook_names[:GameRule.viral.recruit_fb_limit]:
            p = proto.friends.add()
            p.fb_name = fb_name
            c_slug = self.generate_gift(fb_name)
            p.gift.egg.type = GameRule.egg_type(c_slug)
            p.gift.egg.creature.slug = c_slug
            p.gift.message = build_gift_msg(RECRUIT_FB_TO_SEND, who=fb_name)
        return proto

    def get_facebook_gift(self, facebook_name):
        """
        Return the gift for player recruit friend: facebook_id
        """
        return self.generate_gift(facebook_name)

    def get_daily_gift(self, do_store=False):
        exist = self.exist()
        if exist and self.daily_gift_send:
            return ""
        if not exist or not self.daily_gift:
            # not exist(expired) - also need to refresh daily_gift.
            key = "DAILY_GIFT_%s_%s" % (self.player_id, self._now_str())
            self.daily_gift = GameRule.viral.recruit_daily_gift(key)
            if do_store:
                self.store()
        return self.daily_gift
