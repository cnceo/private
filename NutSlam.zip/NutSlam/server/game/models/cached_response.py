from dal.base import *
from utils.settings import MEMCACHED_BUCKET
from utils.settings import CACHED_RESPONSE_TTL
from utils.misc import generate_message
from utils.misc import parse_message


class CachedResponse(Base):
    _db_type = MEMCACHED_BUCKET
    _oid_key = "request"
    _parent_key = "player_id"
    player_id = LongAttr()
    request = TextAttr()
    request_id = IntAttr()

    # Notice - never assign _resp & _resp_name directly, to response.
    _resp = TextAttr()
    _resp_name = TextAttr()

    @property
    def response(self):
        return self._resp and parse_message(self._resp_name, self._resp)

    @response.setter
    def response(self, resp):
        self._resp_name = resp.DESCRIPTOR.name
        self._resp = generate_message(resp)

    def store(self):
        super(CachedResponse, self).store()
        db(self._db_type).touch(self._get_key(), CACHED_RESPONSE_TTL)
