from creature import CreatureInstance, CreatureTeam
from player import Player
