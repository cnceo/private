import simplejson, datetime
from dal.base import *
from models.player import Player, PassedDungeons
from models.content import GameRule
from models.creature import CreatureInstance
from utils.misc import random_number
from utils.protocol_utils import assign_value
from utils.settings import MEMCACHED_BUCKET


class SplitTestsManager(object):
    _oid_value = 1

    # make sure split test tag will be not be used again
    archived_test_tags = KeyValue('archived_split_test_tags')

    @classmethod
    def active_tests(self):
        for gcst in GlobalConfigSplitTest.load_by_attribute('tests_oid', self._oid_value):
            if gcst.active:
                print '>>>', gcst._data

    @classmethod
    def finished_tests(self):
        for gcst in GlobalConfigSplitTest.load_by_attribute('tests_oid', self._oid_value):
            if gcst.finished:
                print '>>>', gcst._data

    @classmethod
    def active_tags(self):
        tags = []
        for gcst in GlobalConfigSplitTest.load_by_attribute('tests_oid', self._oid_value):
            if gcst.active:
                tags.append(gcst.tag)
        return tags

    @classmethod
    def archived_tags(self):
        print self.archived_test_tags.load()

    @classmethod
    def add_test(self, d):
        '''
        d = {
             'control_weight': 1,
             'test_weight': 1,
             'start_time': datetime.datetime(2016, 1, 22, 0, 0, 0, 155691),
             'end_time': datetime.datetime(2016, 2, 23, 0, 0, 0, 262465),
             'replace_dict': {'resourceUpdaterPath': 'https://s3.amazonaws.com/hl-delta-live/assetbundle/v2.7.0-star-gate/'},
             'tag': 'v2.7.0-star-gate'}
        '''

        failed = False
        for i in ('tag', 'start_time', 'end_time', 'replace_dict', 'control_weight', 'test_weight'):
            if i not in d:
                failed = True
                print '>> missing %s' % i
        if not d.get('replace_dict', None) or type(d.get('replace_dict')) != dict:
            failed = True
            print '>> replace_dict should be a dict'
        if not d.get('start_time', None) or type(d['start_time']) != datetime.datetime:
            failed = True
            print '>> start_time should be datetime.datetime'
        if not d.get('end_time', None) or type(d['end_time']) != datetime.datetime:
            failed = True
            print '>> end_time should be datetime.datetime'
        if not d.get('control_weight', None) or type(d['control_weight']) != int:
            failed = True
            print '>> control_weight should be int'
        if not d.get('test_weight', None) or type(d['test_weight']) != int:
            failed = True
            print '>> test_weight should be int'
        if failed: return


        for gcst in GlobalConfigSplitTest.load_by_attribute('tests_oid', self._oid_value):
            if d['start_time'] <= gcst.start_time <= d['end_time'] <= gcst.end_time or \
                gcst.start_time <= d['start_time'] <= gcst.end_time <= d['end_time']:
                print 'time conflict with test: %s ' % gcst._data
                return
        d['replace_dict'] = simplejson.dumps(d['replace_dict'])
        d['tests_oid'] = self._oid_value
        gsct = GlobalConfigSplitTest(**d)
        gsct.store()
        print '>> new test added: %s' % gsct._data

    @classmethod
    def remove_test(cls, tag):
        gcst = GlobalConfigSplitTest(tag=tag)
        gcst.delete()

    @classmethod
    def global_config_test(cls, player, config):
        #print '1111111', player.split_test_tag, player.split_test_group

        if player.split_test_tag in cls.active_tags() and player.split_test_group != 'Control':
            gcst = GlobalConfigSplitTest(tag=player.split_test_tag)
            gcst.update_data(player, config, in_active=True)
            #print 'player in active'
            return

        if not player.is_new:
            #print 'player is not new, return'
            return

        for gcst in GlobalConfigSplitTest.load_by_attribute('tests_oid', cls._oid_value):
            if gcst.active:
                gcst.update_data(player, config)
                #print 'add new test users'


class GlobalConfigSplitTest(Base):
    _oid_key = "tag"
    _index_attributes = ["tests_oid"]

    _control = 'Control'
    _test = 'Test'

    tag = TextAttr()
    tests_oid = TextAttr()
    start_time = DateTimeAttr()
    end_time = DateTimeAttr()
    replace_dict = TextAttr() # {"resourceUpdaterPath": "https://split_test_1.cloudfront.net/"}
    control_weight = IntAttr()
    test_weight = IntAttr()


    @property
    def finished(self):
        return self.end_time < datetime.datetime.now()

    @property
    def active(self):
        return self.start_time < datetime.datetime.now() < self.end_time

    def set_replace_dict(self, d):
        self.replace_dict = simplejson.dumps(d)

    def get_weight(self, key):
        if key == self._control: return self.control_weight
        # TODO: refactor this if have more than one test group
        else: return self.test_weight

    def init_counter(self):
        # (control_weight to count down, test weight to count down, index pointer)
        return [self.control_weight, self.test_weight, 0]

    def switch_pointer(self, p):
        return 0 if p == 1 else 1

    def count_once(self, v, p, c):
        v -= 1
        c[p] = v
        p = self.switch_pointer(p)
        c[2] = p
        KeyValue('Counter:'+self.tag, MEMCACHED_BUCKET).store(c)
        # print 'changed:', c, p
        # switch back of the p
        return self.switch_pointer(p)

    def put_into_test(self):
        counter = KeyValue('Counter:'+self.tag, MEMCACHED_BUCKET).load() or self.init_counter()
        #print counter
        p = counter[2]
        value = counter[p]
        if value > 0:
            #print 'first choice', str(counter), p, value
            return self.count_once(value, p, counter)
        else:
            p = self.switch_pointer(p)
            value = counter[p]
            if value > 0:
                #print 'second choice', str(counter), p, value
                return self.count_once(value, p, counter)
            else:
                counter = self.init_counter()
                p = counter[2]
                value = counter[p]
                #print 'init choice', str(counter), p, value
                return self.count_once(value, p, counter)

    def update_data(self, player, config, in_active=False):
        if in_active:
            assign_value(config, simplejson.loads(self.replace_dict))
            return
        player.split_test_tag = self.tag
        player.split_test_group = self._control
        if self.put_into_test():
            #print 'go into update !!!'
            assign_value(config, simplejson.loads(self.replace_dict))
            player.split_test_group = self._test
        player.store()
