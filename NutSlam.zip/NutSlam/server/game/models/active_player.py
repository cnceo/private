import random

from dal.base import *
from models.content import GameRule
from utils.settings import ACTIVE_PLAYER_COUNT_FACTOR, ACTIVE_PLAYER_LEVEL_INTERVAL



class ActivePlayerHelper(object):

    def get_key(self, level):
        return 'ActivePlayerLevel:%s' % level

    def remove(self, p_id, level):
        key = self.get_key(level)
        active = KeyValue(key)
        active_data = active.load()
        if not active_data:
            return
        if p_id in active_data['p_ids']:
            try:
                active_data['p_ids'].remove(p_id)
                del active_data['creatures'][p_id]
            except:
                pass
        active.store(active_data)

    def update(self, player):
        key = self.get_key(player.level)
        active = KeyValue(key)
        active_data = active.load() or {}

        if 'p_ids' not in active_data: active_data['p_ids'] = []
        if 'creatures' not in active_data: active_data['creatures'] = {}

        max_count = GameRule.player.helper_limitation(player.level)

        # only put facebook linked player into active player list
        # if the list is not empty
        if not player.fb_linked and len(active_data['p_ids']) >= max_count:
            return

        if player.id in active_data['p_ids']:
            active_data['p_ids'].remove(player.id)
        elif len(active_data['p_ids']) > max_count * ACTIVE_PLAYER_COUNT_FACTOR:
            pid = active_data['p_ids'].pop()
            if pid in active_data['creatures']:
                del active_data['creatures'][pid]
        creature = player.get_help_creature()
        active_data['p_ids'].insert(0, player.id)
        active_data['creatures'][player.id] = (creature.cid, creature.slug)
        active.store(active_data)

    def get_by_level(self, player_level, amount, filter_out=None):
        if filter_out:
            filter_out = set(filter_out)
        else:
            filter_out = set()

        amount = int(round(amount * 2))
        interval = ACTIVE_PLAYER_LEVEL_INTERVAL
        lower_level = player_level
        higher_level = player_level
        higher_amount = max(amount*2/3, 1)

        higher_ids = set()
        lower_ids = set()
        helper_creature = {}

        while higher_level <= GameRule.player.max_level():
            for level in range(higher_level, higher_level + interval):
                key = self.get_key(level)
                data = KeyValue(key).load()
                if not data: continue
                higher_ids.update(set(data['p_ids']) - filter_out)
                helper_creature.update(data['creatures'])
            if len(higher_ids) >= higher_amount:
                break
            higher_level += interval

        higher_helpers = set(random.sample(higher_ids, min(len(higher_ids), higher_amount)))
        lower_amount = amount - len(higher_helpers)
        while lower_level > 0:
            for level in range(lower_level - interval, lower_level):
                key = self.get_key(level)
                data = KeyValue(key).load()
                if not data: continue
                lower_ids.update(set(data['p_ids']) - filter_out)
                helper_creature.update(data['creatures'])
            if len(lower_ids) >= lower_amount:
                break
            lower_level -= interval

        lower_helpers = set(random.sample(lower_ids, min(len(lower_ids), lower_amount)))

        higher_helpers.update(lower_helpers)
        creatures = {}
        for i in higher_helpers:
            creatures[i] = helper_creature[str(i)]
        return higher_helpers, creatures
