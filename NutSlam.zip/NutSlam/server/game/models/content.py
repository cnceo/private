import csv
import random
import simplejson
import os
import gevent
import glob
from math import ceil
from dal.base import Base
from dal.base import IntAttr, ListAttr, TextAttr, DictAttr
from models.event import EventConfig
from models.event import EventHelper
from utils.log import log
from utils import protocol_pb2 as proto
from utils.protocol_pb2 import CollectedCreatureState
from utils.protocol_pb2 import EggType
from utils.protocol_pb2 import Element
from utils.protocol_pb2 import HardCurrency
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import TreeEventType
from utils.protocol_utils import assign_value
from utils.misc import parse_version
from utils.misc import random_number
from utils.misc import content_error
from utils.misc import correct_json_string
from utils.misc import gen_weight_list
from utils.misc import gen_weight_list_map_list
from utils.misc import get_by_weight
from utils.misc import material_egg_cmp
from utils.misc import string_to_int
from utils.misc import load_content_json
from utils.settings import LOAD_CONTENT_INTERVAL
from utils.settings import FAERIE_EGG, SELF_EGG, MATERIAL_EGG, COIN_EGG, GEM_EGG
from utils.settings import NUT_EGG
from utils.settings import ENABLE_EVENTS
from utils.settings import EventsType
from utils.settings import DEFAULT_UTC_OFFSET
from utils.settings import IS_PRODUCTION
from utils.settings import CUSTOM_RESOURCE_UPDATEER_PATH
from utils.settings import L10N_FILE_NAME
from utils.settings import L10N_FILE_NAME_ID_MAP
from utils.settings import L10N_EVENT_NAME
from utils.settings import L10N_CREATURE_NAME
from utils.settings import L10N_SKILL
from utils.settings import L10N_CUSTOM
from utils.settings import L10N_SERVER
from utils.settings import L10N_MSG_SPLIT


OID = 0
file_path = os.path.dirname(os.path.abspath(__file__)).replace('models', 'content_csv')


class Content(Base):
    version_id = IntAttr()
    world = ListAttr(TextAttr())
    configs = TextAttr()
    creature_types = ListAttr(TextAttr())
    referenced_skills = ListAttr(TextAttr())
    events = TextAttr()
    asset_version = ListAttr(TextAttr())
    l10n = DictAttr(TextAttr())
    _oid_key = "version_id"


class AssetVersionHelper(object):
    def __init__(self, configs=None):
        if not configs: return
        _map = {}
        for i in configs:
            v = load_content_json(i, 'AssetVersion')
            _map[v['version']] = v['url']
        self._map = _map

    def get_url(self, version='default'):
        if version not in self._map:
            version = 'default'
        return self._map[version]


class CreatureHelper(object):
    # Mocked data - TODO: read from content.
    mega_factor = 2

    def __init__(self, **kwargs):
        super(CreatureHelper, self).__init__()
        self._init_sell(kwargs.get("sellingParams", {}))
        self._init_level_up(kwargs.get("creatureLevelParams", {}))
        self._init_fuse(kwargs.get("fusingParams", {}))
        self._init_evolve(kwargs.get("evolutionDefinition", []))
        self._init_ascend(kwargs.get("ascendingRequirement", []))

    def _init_sell(self, config):
        # selling params
        self._sell_a = config.get("paramA", 2.42)
        self._sell_b = config.get("paramB", 100)
        self._sell_c = config.get("paramC", 100)

    def _init_level_up(self, config):
        # level up params
        self._level_exponent = config.get("levelExponent", 1.45)
        self._level_scale = config.get("levelScale", 4.75)
        self._star_rank_scale = config.get("starRankScale", 1)
        self._xp_incr_per_level = config.get("xpIncrementPerLevel", 300)

    def _init_fuse(self, config):
        # fuse params
        self._fuse_currency_a = config.get("softCurrencyCostParamA", 2.42)
        self._fuse_currency_b = config.get("softCurrencyCostParamB", 1)
        self._fuse_currency_c = config.get("softCurrencyCostParamC", 100)
        self._mega_chance_a = config.get("megaFusionChanceParamA", 0.4)
        self._mega_chance_b = config.get("megaFusionChanceParamB", 0.1)
        self._trans_xp_a = config.get("xpGainParamA", 300)
        self._trans_xp_b = config.get("xpGainParamB", 120)
        self._trans_xp_c = config.get("xpGainParamC", 1)
        self._trans_xp_d = config.get("xpGainParamD", 0.25)
        self._hp_inherit_a = config.get("plusHPInheritParamA", 0.25)
        self._hp_inherit_b = config.get("plusHPInheritParamB", 2)
        self._attack_inherit_a = config.get("plusAtkInheritParamA", 0.25)
        self._attack_inherit_b = config.get("plusAtkInheritParamB", 2)
        self._speed_inherit_a = config.get("plusSpdInheritParamA", 0.25)
        self._speed_inherit_b = config.get("plusSpdInheritParamB", 2)
        self._luck_inherit_a = config.get("plusLuckInheritParamA", 1)
        self._luck_inherit_b = config.get("plusLuckInheritParamB", 0)
        self._luck_inherit_c = config.get("plusLuckInheritParamC", 1)
        self._luck_inherit_d = config.get("plusLuckInheritParamD", 0)

    def _init_evolve(self, config):
        # evolve params
        # evolve_conf - {<star_rank>: {<element>: <required_materials>,
        #                              ...
        #                              "currency": <required_currency>}}
        evolve_conf = {}
        for evolve_info in config or []:
            _conf = {}
            star_rank = evolve_info.get("fromStarRank")
            evolve_conf[star_rank] = _conf
            _conf["currency"] = evolve_info.get("softCurrency")

            non_ele_material = {}
            for m_info in evolve_info.get("cost"):
                non_ele_material[m_info.get("slug")] = m_info.get("count")

            for e_name, e_val in Element.items():
                if "NONE" != e_name:
                    materials = {}
                    for m_info in evolve_info.get("elementalCost", []):
                        slug = GameRule.materials.get_material(
                            e_name, m_info.get("tier"))
                        materials[slug] = m_info.get("count")
                    materials.update(non_ele_material)
                    _conf[e_val] = materials
        self._evolve_conf = evolve_conf

    def _init_ascend(self, config):
        # ascend params
        ascend_conf = {}  # {<star_rank>: currency}
        for conf in config:
            ascend_conf[conf.get("starRank")] = conf.get("softCurrency")
        self._ascend_conf = ascend_conf

    def sell_param(self):
        return self._sell_a, self._sell_b, self._sell_c

    def level_param(self):
        return (self._level_exponent, self._level_scale, self._star_rank_scale,
                self._xp_incr_per_level)

    def fuse_currency_param(self):
        return (self._fuse_currency_a, self._fuse_currency_b,
                self._fuse_currency_c)

    def mega_param(self):
        return self._mega_chance_a, self._mega_chance_b

    def trans_xp_param(self):
        return (self._trans_xp_a, self._trans_xp_b, self._trans_xp_c,
                self._trans_xp_d)

    def inherit_hp_param(self):
        return self._hp_inherit_a, self._hp_inherit_b

    def inherit_attack_param(self):
        return self._attack_inherit_a, self._attack_inherit_b

    def inherit_speed_param(self):
        return self._speed_inherit_a, self._speed_inherit_b

    def inherit_luck_param(self):
        return (self._luck_inherit_a, self._luck_inherit_b,
                self._luck_inherit_c, self._luck_inherit_d)

    def _evolve_rank(self, star_rank):
        return self._evolve_conf.get(star_rank, {})

    def evolve_currency(self, star_rank):
        return self._evolve_rank(star_rank).get("currency", 2000)

    def evolve_materials(self, star_rank, element):
        return self._evolve_rank(star_rank).get(element, {})

    def ascend_currency(self, star_rank):
        return self._ascend_conf.get(star_rank, 3000)


class CreatureTypesHelper(object):
    # Skills with follow trigger type must have at least one parameter.
    _verify_trigger_type = [proto.TriggerType.Value("ONACTIVATE"),
                            proto.TriggerType.Value("ONENEMYATTACK"),
                            proto.TriggerType.Value("ONBOSSATTACK")]

    def __init__(self, creature_types=None, referenced_skills=None):
        super(CreatureTypesHelper, self).__init__()
        c_proto = proto.RetrieveCreatureTypeRep()
        slug_map = {}  # {<slug>: <creature_type>}
        series_map = {}  # {<slug>: <series_creature_slug_list>}
        first_stage_map = {}  # {<slug>: <first_stage_slug>}
        upgrade_history = {}
        count = 0
        for creature in creature_types or []:
            count += 1
            if count <= 1:
                version = load_content_json(creature,'CreatureType')

                c_proto.versions.append(version['version'])
                continue
            c = c_proto.creatures.add()
            c_info = load_content_json(creature, 'CreatureType')
            ascend_amount = [a for a in c_info["transcend"]["creatureAmount"]
                             if a.get("creatureSlug")]

            c_info["transcend"]["creatureAmount"] = ascend_amount
            assign_value(c, c_info)
            slug = c.slug.lower()
            if slug in slug_map:
                content_error("Duplicate creature - slug(%s): %s %s" %
                              (slug, c, slug_map.get(slug)))
                continue
            slug_map[slug] = c

            # series
            evolve_slug = c.evolutionSlug
            evolve_slug = evolve_slug and evolve_slug.lower()
            ascend_slug = c.transcend.transcendSlug
            ascend_slug = ascend_slug and ascend_slug.lower()
            if evolve_slug:
                self._update_series(slug, evolve_slug, series_map)
            if ascend_slug:
                self._update_series(slug, ascend_slug, series_map)

            # prepare to gen first stage map
            if evolve_slug and evolve_slug not in upgrade_history:
                upgrade_history[evolve_slug] = slug
            if ascend_slug and ascend_slug not in upgrade_history:
                upgrade_history[ascend_slug] = slug

        # first stage
        for slug, series in series_map.iteritems():
            if slug not in slug_map:
                # Missing the definition for evolved/ascend result creature.
                content_error("Missing creature - slug: %s" % slug)
            if slug not in upgrade_history.keys():
                for _slug in series:
                    first_stage_map[_slug] = slug

        count = 0
        for skills in referenced_skills or []:
            count += 1
            if count <= 1:
                version = load_content_json(skills, 'CreatureSkill')
                c_proto.versions.append(version['version'])
                continue
            skills = load_content_json(skills, 'CreatureSkill')
            for skill in skills:
                s = c_proto.referencedSkills.add()
                assign_value(s, skill)
                t = s.trigger
                if t.type in self._verify_trigger_type and not t.parameters:
                    content_error("Invalid skill - SkillTrigger missing "
                                  "parameters\n%s" % s)

        self.proto = c_proto
        self._slug_map = slug_map
        self._all_slugs = slug_map.keys()
        self._series_map = series_map
        self._first_stage_map = first_stage_map
        self.numbers = len(self._all_slugs)

    def _update_series(self, slug_a, slug_b, series_map):
        series_a = series_map.get(slug_a)
        series_b = series_map.get(slug_b)
        if not series_a and not series_b:
            series = [slug_a, slug_b]
            series_map[slug_a] = series
            series_map[slug_b] = series
        elif series_a and not series_b:
            series_a.append(slug_b)
            series_map[slug_b] = series_a
        elif series_b and not series_a:
            series_b.append(slug_a)
            series_map[slug_a] = series_b
        else:
            series_a.extend(series_b)
            for _s in series_b:
                series_map[_s] = series_a
        return series_map

    def series(self, slug):
        return self._series_map.get(slug, [slug])

    def first_stage(self, slug):
        return self._first_stage_map.get(slug, slug)

    def get(self, slug):
        return self._slug_map.get(slug)

    def all(self):
        return self._slug_map.values()

    def all_slugs(self):
        return self._all_slugs


class FaerieHelper(object):
    def __init__(self, faeries=None):
        super(FaerieHelper, self).__init__()

        slug_map = {}  # {<slug>: <faerie>}
        element_tier_map = {}  # {<element>_<tier>: <faerie>}
        for f in faeries or []:
            f_slug = f.get("slug")
            if f_slug in slug_map:
                content_error("Duplicate faerie - slug(%s): %s %s" %
                              (f_slug, str(f), str(slug_map.get(f_slug))))
                continue
            slug_map[f_slug] = f
            element_tier_map[self._element_tier_key(f)] = f
        self._slug_map = slug_map
        self._element_tier_map = element_tier_map
        self._all_slug = slug_map.keys()

    def _element_tier_key(self, faerie=None, **kwargs):
        param = faerie or kwargs
        return "%(element)s_%(tier)s" % param

    def by_slug(self, slug):
        return self._slug_map.get(slug)

    def by_element_tier(self, element, tier):
        key = self._element_tier_key(element=element, tier=tier)
        return self._element_tier_map.get(key)

    def all(self):
        return self._slug_map

    def all_slug(self):
        return self._all_slug

    def _stats(self, slug):
        faerie = self.by_slug(slug)
        return faerie and faerie.get("stats") or {}

    def attack(self, slug):
        return self._stats(slug).get("plusAttack", 0)

    def hp(self, slug):
        return self._stats(slug).get("plusHP", 0)

    def luck(self, slug):
        return self._stats(slug).get("plusLuck", 0)

    def speed(self, slug):
        return self._stats(slug).get("plusSpeed", 0)

    def currency(self, slug):
        return self._stats(slug).get("softCurrency", 0)

    def xp(self, slug):
        return self._stats(slug).get("xp", 0)


class MaterialHelper(object):
    def __init__(self, configs=None):
        super(MaterialHelper, self).__init__()

        conversion_map = {}  # {<to_slug>: {<from_slug>: num_of_from}}
        element_tier_map = {}  # {<element>_<tier>: <material_slug>}
        price_map = {}
        slugs = set()  # all slugs
        for material in configs or []:
            slug = material.get("slug")
            slugs.add(slug)
            element_tier_map[self._element_tier_key(material)] = slug
            price_map[slug] = material.get("price", 0)

            conversion = {}
            for conv in material.get("conversion", []):
                conversion[conv.get("slug")] = conv.get("count")
            if conversion:
                conversion_map[slug] = conversion

        self._slugs = slugs
        self._element_tier_map = element_tier_map
        self.conversion = conversion_map
        self.price_map = price_map

    def _element_tier_key(self, material):
        return "%(element)s_%(tier)s" % material

    def materials(self):
        return self._slugs

    def conversion_rates(self, to_slug):
        convert_info = self.conversion.get(to_slug, {})
        return convert_info

    def get_material(self, element, tier):
        param = {"element": element.upper(), "tier": tier}
        return self._element_tier_map.get(self._element_tier_key(param))

    def price(self, slug):
        return self.price_map.get(slug, 0)


class PlayerHelper(object):
    default = {
        "attr": {"level": 1,
                 "xp": 0,
                 "coins": 100,
                 "gems": 10,
                 "hearts": 0,
                 "progress": 0,
                 "max_creatures": 40,
                 },
        "creatures": [],
        "teams": {}
    }

    def __init__(self, c_slugs=[], **kwargs):
        super(PlayerHelper, self).__init__()
        settings = kwargs.get("playerLevel", [])
        level_settings = dict(zip(range(1, len(settings) + 1), settings))
        self._level_settings = level_settings
        self.energy_countdown = kwargs.get("energyRecoverSpeed", 5) * 60
        self.creature_box_extension = kwargs.get("creatureBoxExtension", 5)
        self._prepare_default_settings(c_slugs,
                                       kwargs.get("newPlayerData", {}))

        self._max_level = max(self._level_settings.keys() or (100,))

    def _filter_creatures(self, c_slugs, creature_sets):
        _sets = []
        for c in creature_sets:
            slug = c.pop("slug", None)
            if slug and slug in c_slugs:
                _sets.append((slug, c))
        return _sets

    def _prepare_default_settings(self, c_slugs, configs):
        attr = {"level": configs.get("playerLevel", 1),
                "xp": configs.get("playerXP", 0),
                "coins": configs.get("softCurrency", 10000),
                "gems": configs.get("hardCurrency", 0),
                "hearts": configs.get("socialCurrency", 0),
                "progress": configs.get("progress", 0),
                "max_creatures": configs.get("creatureBoxCapacity", 30),
                "energy": self.max_energy(1)
        }
        for key, value in configs.get('materials', {}).iteritems():
            attr[key] = value

        # teams
        teams = {}
        team_index = 1
        for t_set in configs.get("newPlayerTeamSets", []):
            t = self._filter_creatures(c_slugs, t_set.get("team", []))
            if t:
                teams["team%s" % team_index] = t
                team_index += 1

        # creatures not in a team
        creatures = configs.get("creaturesNotInTeam", [])
        creatures = self._filter_creatures(c_slugs, creatures)

        self.default = {"attr": attr,
                        "creatures": creatures,
                        "teams": teams}

    def _by_level(self, level):
        return self._level_settings.get(level, {})

    def max_energy(self, level):
        return self._by_level(level).get("maxEnergy", 1200)

    def max_friend(self, level):
        return self._by_level(level).get("maxFriend", 2100)

    def helper_limitation(self, level):
        return self._by_level(level).get("helperListSize", 10)

    def level_up_xp(self, level):
        return self._by_level(level).get("xp", 1000000)

    def max_level(self):
        return self._max_level


class HelperConfig(object):
    def __init__(self, **kwargs):
        super(HelperConfig, self).__init__()
        self._init_weight(kwargs.get("helperTypeWeight", {}))
        self._init_social_reward(kwargs.get("socialCurrencyReward", {}))

        self.thank_helper_gem = kwargs.get("thankYouGiftGem", 1)

    def _init_weight(self, config):
        fb_weight = config.get("FacebookFriend", 2)
        os_weight = config.get("OSFriend", 2)
        fv_weight = config.get("FavoratedInGameFriend", 1)
        ig_weight = config.get("InGameFriend", 1)
        nor_weight = config.get("ActivePlayer", 1)
        _total = fb_weight + os_weight + fv_weight + ig_weight + nor_weight
        _total = float(_total)
        self._fb = fb_weight / _total
        self._os_weight = os_weight / _total
        self._favorite = fv_weight / _total
        self._in_game = ig_weight / _total

    def _init_social_reward(self, config):
        social_reward = {}  # {<reward_type>: (ttl, hearts)}
        for action, reward in config.iteritems():
            social_reward[action] = (reward.get("SocialCurrencyReward"),
                                     reward.get("RewardIntervalSeconds"))
        self._social_reward = social_reward

    def _get_number(self, total, ratio, max_num=0):
        return min(int(total * ratio), max_num)

    def facebook_number(self, total, max_num):
        return self._get_number(total, self._fb, max_num)

    def os_number(self, total, max_num):
        # agc/gp friend number
        return self._get_number(total, self._os_weight, max_num)

    def favorite_number(self, total, max_num):
        return self._get_number(total, self._favorite, max_num)

    def friend_number(self, total, max_num):
        return self._get_number(total, self._in_game, max_num)

    def _get_reward(self, key):
        return self._social_reward.get(key, (10, 0))

    def add_friend_reward(self):
        return self._get_reward("sendFriendRequest")

    def fb_reward(self):
        return self._get_reward("selectFacebookFriend")

    def favorite_reward(self):
        return self._get_reward("selectFavoratedIngameFriend")

    def os_reward(self):
        # Social(AGC/GC) friend reward
        return self._get_reward("selectOSFriend")

    def friend_reward(self):
        return self._get_reward("selcetIngameFriend")

    def active_reward(self):
        return self._get_reward("selectActivePlayer")


class PriceHelper(object):
    hc_map = {}
    hc_os_type_map = {}

    def __init__(self, prices=None):
        super(PriceHelper, self).__init__()
        prices = prices or {}
        hc_prices = prices.get("prices", {})
        sc_prices = prices.get("socialPrices", {})
        self._energy = hc_prices.get("energyRefillCost", 1)
        self._creature_space = hc_prices.get("creatureBoxExpension", 5)
        self._level_up_reward = hc_prices.get("levelUpGemReward", 1)
        self._finish_dungeon_reward = hc_prices.get("clearanceGemReward", 1)
        self._revive = hc_prices.get("reviveCost", [1])
        self._revive_index_max = len(hc_prices.get("reviveCost", [1])) - 1
        self._premium_gacha = hc_prices.get("premiumGatcha", 5)
        self._social_gacha = sc_prices.get("socialGatcha", 100)
        self._init_hard_currency(prices)

    def _init_hard_currency(self, prices):
        hc_map = {}
        hc_os_type_map = {}
        os_type_map = {"IAP": OSType.Value("IOS"),
                       "IAB": OSType.Value("Android")}
        hc_settings = prices.pop("hardCurrency", [])
        for key, prefix in prices.get("productIDPrefixes", {}).iteritems():
            prices[key] = []
            os_type = os_type_map.get(key[-3:])
            for hc_info in hc_settings:
                if not hc_info.get("visible", False) or hc_info.get("key") != key:
                    # Skip invisible pids
                    continue
                product_id = "%s.%s" % (prefix, hc_info.get("product_id"))
                hc = {}
                hc.update(hc_info)
                hc.pop("visible")
                hc.pop("key")
                hc["product_id"] = product_id
                hc_map[product_id] = HardCurrency(**hc)
                hc_os_type_map[product_id] = os_type
                prices[key].append(hc)
        self.hc_map = hc_map
        self.hc_os_type_map = hc_os_type_map

    def hc_os_type(self, product_id):
        return self.hc_os_type_map.get(product_id)

    def hc_info(self, product_id):
        return self.hc_map.get(product_id)

    def refill_energy(self):
        return self._energy

    def creature_space(self):
        return self._creature_space

    def revive_cost(self, index):
        curr = min(index, self._revive_index_max)
        nxt = min(index+1, self._revive_index_max)
        return self._revive[curr], self._revive[nxt]

    def gacha(self, gacha_type):
        if gacha_type == "premium":
            return self._premium_gacha
        return self._social_gacha

    def level_up_reward(self):
        return self._level_up_reward

    def finish_dungeon_reward(self):
        return self._finish_dungeon_reward


class ViralHelper(object):

    def __init__(self, viral=None):
        super(ViralHelper, self).__init__()
        viral = viral or {}
        self._number_configs = viral.get("NumberConfigs", {})
        self._akorn_gift = self._gen_weight_list(viral.get("akornGift", []))
        self._recruit_friend_reward = self._gen_weight_list(
            viral.get("recruitFriendReward", []))
        self._recruit_daily_reward = viral.get("firstRecruitDaily", [])
    @property
    def facebook_connect_gem(self):
        return self._number_configs.get("facebookConnectingGemReward", 5)

    @property
    def thank_helper_gem(self):
        return self._number_configs.get("thankYouGiftGem", 1)

    @property
    def enable_pn_gem(self):
        return self._number_configs.get("enablePNGem", 1)

    @property
    def recruit_fb_limit(self):
        return self._number_configs.get("RecruitFBLimit", 50)

    def _gen_weight_list(self, weight_map):
        return gen_weight_list_map_list(weight_map)

    def get_an_akorn_gift(self):
        if self._akorn_gift:
            total = self._akorn_gift[-1][0]
            index = random.randint(1, total)
            return get_by_weight(self._akorn_gift, index)
        return None

    def recruit_friend_gift(self, key):
        if self._recruit_friend_reward:
            total = self._recruit_friend_reward[-1][0]
            index = string_to_int(key) % total
            return get_by_weight(self._recruit_friend_reward, index)
        return None

    def recruit_daily_gift(self, key):
        if self._recruit_daily_reward:
            total = len(self._recruit_daily_reward)
            index = string_to_int(key) % total
            return self._recruit_daily_reward[index]
        return None


class Collection(object):
    _reward_map = {}

    def __init__(self, slug=None, creature_slugs=None, enabled=None,
                 seen_reward=None, owned_reward=None, maxedout_reward=None):
        self.slug = slug
        self.creatures = creature_slugs
        self.enabled = enabled
        self._reward_map = {
            CollectedCreatureState.Value("CT_MAXEDOUT"): maxedout_reward,
            CollectedCreatureState.Value("CT_OWNED"): owned_reward,
            CollectedCreatureState.Value("CT_SEEN"): seen_reward,
            }

    def get_reward(self, state):
        return self._reward_map.get(state) or 0


class CollectionHelper(object):
    _collection_map = {}

    def __init__(self, configs=None):
        _map = {}
        for c in configs or []:
            collect = Collection(**c)
            if collect.enabled:
                _map[collect.slug] = collect
        self._collection_map = _map

    def get(self, slug):
        return self._collection_map.get(slug)

    def all_slug(self):
        return self._collection_map.keys()


class GachaTree(object):
    cost_map = {TreeEventType.Value("PREMIUM"): "gems",
                TreeEventType.Value("SOCIAL"): "hearts"}
    first_drop_flag = 2

    def __init__(self, slug, tree_type, price, drops,
                 start_timestamp=None, end_timestamp=None, prefab=None):
        super(GachaTree, self).__init__()
        self.slug = slug
        self._tree_type = tree_type
        self.price = price
        self.tree_type = TreeEventType.Value(self._tree_type)
        if self.tree_type == TreeEventType.Value("TTL"):
            self.ttl = int(self.slug.split("_")[1])
        else:
            self.ttl = -1
        self.start_timestamp = start_timestamp or 0
        self.end_timestamp = end_timestamp or 0
        first_drops = [c for c in drops
                       if c.get("featured") == self.first_drop_flag]
        self.first_drops = gen_weight_list_map_list(first_drops)
        self.drops = gen_weight_list_map_list(drops)
        self._featured_creatures = [c["creatureSlug"] for c in drops
                                    if c.get("featured")]
        self.prefab = prefab

    def _shuffle(self, c_list):
        random.shuffle(c_list)
        return c_list

    @property
    def creatures(self):
        return self._shuffle([c[1] for c in self.drops])

    @property
    def featured_creatures(self):
        return self._shuffle(self._featured_creatures)

    @property
    def cost(self):
        return self.cost_map.get(self.tree_type)

    def proto_info(self):
        proto = {"slug": self.slug,
                "tree_type": self._tree_type,
                "creature_slug": self.creatures,
                "featured_creature": self.featured_creatures,
                "price": self.price,
                "ttl": self.ttl,
                "start_timestamp": self.start_timestamp,
                "end_timestamp": self.end_timestamp}
        if self.prefab:
            proto['prefab'] = self.prefab
        return proto

    def _drop(self, drop_list):
        random_num = random_number(drop_list[-1][0])
        return get_by_weight(drop_list, random_num)

    def drop(self):
        return self._drop(self.drops)

    def first_drop(self):
        return self._drop(self.first_drops)


class NewGachaHelper(object):
    trees = {}
    event_trees = {}
    proto_info = []

    def __init__(self, configs=None, event_conf=None, events=None):
        super(NewGachaHelper, self).__init__()
        trees = {}
        event_trees = {}
        proto_info = []

        # activate event
        for e in events.new_gacha:
            g_tree = GachaTree(e.slug, e.tree_type, e.price, e.drops,
                               e.start_timestamp, e.end_timestamp, e.prefab)
            trees[g_tree.slug] = g_tree
            proto_info.append(g_tree.proto_info())

        # static gacha tree.
        for t_conf in configs or []:
            g_tree = GachaTree(t_conf.get("slug"), t_conf.get("tree_type"),
                               t_conf.get("price"), t_conf.get("drops"))
            trees[g_tree.slug] = g_tree
            if t_conf.get("display", True):
                proto_info.append(g_tree.proto_info())

        # prepare all event trees for open nuts.
        all_event = event_conf and event_conf.get_all(EventsType.EVENT_TREE)
        for t_slug, t_conf in all_event or []:
            if t_slug in trees:
                continue
            g_tree = GachaTree(t_slug, t_conf.get("tree_type"),
                               t_conf.get("price"), t_conf.get("drops"))
            event_trees[g_tree.slug] = g_tree

        self.trees = trees
        self.event_trees = event_trees
        self.proto_info = proto_info

    def get_gacha_tree(self, tree_slug):
        return self.trees.get(tree_slug, None)

    def get_nut_tree(self, tree_slug, element=None):
        return (element and self.get_gacha_tree("%s_%s" % (tree_slug, element))
                or self.get_gacha_tree(tree_slug) or
                self.event_trees.get(tree_slug, None))

    @property
    def tree_slugs(self):
        return self.trees.keys()


class GachaHelper(object):
    PREMIUM = 'premium'
    SOCIAL = 'social'

    def __init__(self, configs=None, events=None):
        super(GachaHelper, self).__init__()
        e_trees = events and events.gacha_trees or []
        finished_e_trees = events and events.finished_gacha_trees or []
        g_luck = events and events.gacha_luck or []
        attr_map = {}  # {<tree_index>: <init_attr>}
        for l in g_luck:
            attr_map[l.tree_slug] = l.init_attr()

        # {<tree_slug>: {"type": <g_type>, "map": [(<weight>, <c_slug>), ...]}}
        settings = {}
        trees = []
        need_base_premium = True
        for g in configs or []:
            slug = g.get("slug")
            g_type = slug.split("_")[0].lower()

            c_map = {}
            for d in g.get("drops"):
                c_slug = d.get("creatureSlug")
                if not c_slug:
                    continue
                c_map[c_slug] = d.get("weight", 0)

            if g_type == self.PREMIUM:
                # merge finished gacha trees
                for e_t in finished_e_trees:
                    for c_slug, attr in e_t.creatures.iteritems():
                        if not c_slug:
                            continue
                        c_map[c_slug] = attr.get("normal_weight")

            drops = gen_weight_list(c_map)
            setting = {"type": g_type,
                       "drops": drops,
                       }
            if g_type == self.PREMIUM and e_trees:
                need_base_premium = False
                for e_t in e_trees:
                    # update event_drops
                    v_func = lambda item: item[1].get("weight")
                    event_drops = gen_weight_list(e_t.creatures,
                                                  val_func=v_func)
                    setting["event_drops"] = event_drops
                    # update gacha luck event
                    setting["creature_attr"] = attr_map.get(e_t.tree_index)
                    settings[e_t.slug] = setting

                    tree = e_t.get_proto_dict()
                    tree['supporting_slug'] = [drop[1] for drop in drops]
                    trees.append(tree)
            else:
                settings[slug] = setting

            # insert social tree
            if g_type != self.PREMIUM:
                creature_key1 = 'acorn'
                creature_key2 = '03'
                creature_slug = []
                supporting_slug = []

                for drop in drops:
                    if creature_key1 in drop[1] and creature_key2 in drop[1]:
                        creature_slug.append(drop[1])
                    else:
                        supporting_slug.append(drop[1])
                tr = {"slug": slug,
                      "tree_type": g_type.upper(),
                      "creature_slug": creature_slug,
                      "supporting_slug": supporting_slug,
                      "prefab": 'Prefabs/GatchaTreeSocial',
                      }
                trees.insert(0, tr)
            # update base premium tree if no events trees
            if need_base_premium and g_type == self.PREMIUM:
                tr = {"slug": slug,
                      "tree_type": g_type.upper(),
                      "supporting_slug": [drop[1] for drop in drops],
                      "prefab": '',
                      }
                trees.append(tr)

        self.trees = trees
        self._settings = settings
        self.slugs = settings.keys()

    def _by_slug(self, slug):
        return self._settings.get(slug, {})

    def drops(self, rand_key, tree_slug):
        """
        get drops by tree slug, and random one.
         * First drop from event-drops, then from drops.

        HOW TO:
            1. while init drops:
               drops = [(w1, slug1), (w1+w2, slug2), ...(w1+...+wn, slug_n)]
               event_drops = [(w1, e_slug1), (w1+w2, e_slug2),
                              ...(w1+...+wn, e_slug_n)]
            2. we random an int(random_num) from w1+w2+...+wn or 100
            3. go through the drops to find the first weight_x(w1+w2+...+wx)
               satisfy random_num <= weight_x.
            4. return the slug
        """
        # first drop from event_drops
        e_drops = self._by_slug(tree_slug).get("event_drops", [])
        if e_drops:
            random_num = random_number(100, rand_key)
            c_slug = get_by_weight(e_drops, random_num)
            if c_slug:
                return c_slug

        # drop from normal drops
        drops = self._by_slug(tree_slug).get("drops", [])
        if drops:
            random_num = random_number(drops[-1][0], rand_key)
            c_slug = get_by_weight(drops, random_num)
            if c_slug:
                return c_slug
        return None

    def creature_init_attribute(self, slug):
        return self._by_slug(slug).get("creature_attr")

    def type(self, slug):
        return self._by_slug(slug).get("type", self.PREMIUM)

    def valid_tree_slug(self, tree_slug):
        return tree_slug in self._settings


class ClientVersionHelper(object):
    _min = "min_version"
    _recommend = "recommend_version"

    def __init__(self, config=None):
        config = config or {}
        ios_version = self._init_version(
            config.get("iosMinVersion"), config.get("iosRecommendedVersion"))
        android_version = self._init_version(
            config.get("gpMinVersion"), config.get("gpRecommendedVersion"))
        v_map = {OSType.Value("IOS"): ios_version,
                 OSType.Value("Android"): android_version,
                 OSType.Value("WP"): ios_version,
                 OSType.Value("Other"): ios_version,
        }
        self.v_map = v_map

    def _init_version(self, min_version=None, recommended_version=None):
        min_version = min_version or "1.0.0 (1)"
        recommended_version = recommended_version or "1.1.0 (1)"
        return {self._min: parse_version(min_version),
                self._recommend: parse_version(recommended_version)}

    def min_version(self, os_type):
        return self.v_map.get(os_type).get(self._min)

    def recommend_version(self, os_type):
        return self.v_map.get(os_type).get(self._recommend)


class WorldHelper(object):
    all_dungeon_ids = []
    _progress_to_element_map = {}

    def __init__(self, content_world=None, creature_types=None, events=None):
        super(WorldHelper, self).__init__()
        if not content_world or not creature_types:
            return
        old_dungeon_events = events and events.old_dungeons or []
        new_dungoen_events = events and events.new_dungeons or []

        energy_map = {}
        coin_map = {}
        luck_map = {}
        droprate_map = {}

        world, events_world = self._parse_content_world(content_world)
        for e in old_dungeon_events:
            if e.event_type == EventsType.EVENTS_ENERGY:
                discount = e.multiplier
                for d in e.dungeons:
                    energy_map[d] = discount
            elif e.event_type == EventsType.EVENTS_COIN:
                mul = e.multiplier
                for d in e.dungeons:
                    coin_map[d] = mul
            elif e.event_type == EventsType.EVENTS_DUNGEON_LUCK:
                mul = e.multiplier
                for d in e.dungeons:
                    luck_map[d] = mul
            elif e.event_type == EventsType.EVENTS_DROPRATE:
                for d in e.dungeons:
                    droprate_map[d] = e

        self._luck_map = luck_map

        _dungeon_ids = []
        dungeons = {}
        event_dungeons = {}
        bonus_dungeon_ids = []
        progress_to_element_map = {}
        element = Element.keys()
        # build normal dungeons dict
        for z in world.get('zones'):
            for a in z.get('areas'):
                a['dungeons'] = a.get('area').get('dungeons')
                for d in a.get('dungeons'):
                    d_id = d["ID"]
                    if 'bonus' in d['slug']:
                        bonus_dungeon_ids.append(d_id)
                    self._check_dup_d(_dungeon_ids, d_id)
                    if d_id < 700:
                        self._build_dungeon(d, creature_types, {}, {}, {})
                    else:
                        self._build_dungeon(d, creature_types, energy_map, coin_map, droprate_map)
                    dungeons[d_id] = d
                    # build progress to element map
                    p = d.get("requirement", {}).get("progress")
                    e = d.get("gatcha_elements")
                    e = e and e[0] or ""
                    if p and e in element:
                        progress_to_element_map[p] = e.lower()
        self.bonus_dungeon_ids = bonus_dungeon_ids

        for d in events_world.get('dungeons', []):
            d = d['dungeon']
            d['slug'] = d['slug'] + '.' + d['difficulty']
            self._build_dungeon(d, creature_types, energy_map, coin_map, droprate_map)
            event_dungeons[d['ID']] = d
            # print d['ID'], d['slug']
        # update air battle dungeons, also update events
        for e in new_dungoen_events:
            e.dungeons = []
            for i in e.dungeon_ids:
                if i in event_dungeons:
                    e.dungeons.append(event_dungeons[i])
                    if e.started(buffer_start=True):
                        # * only add started xp event(skip the coming one).
                        # * check with buffer to fit devices runs faster.
                        dungeons[i] = event_dungeons[i]

        self._progress_to_element_map = progress_to_element_map
        self.dungeons = dungeons
        self.activate_dungeon_ids = dungeons.keys()
        self.all_dungeon_ids = event_dungeons.keys() + dungeons.keys()
        self.proto = proto.World()
        world['version'] = world['world']['version']
        assign_value(self.proto, world)

    def element_by_progress(self, progress):
        return self._progress_to_element_map.get(progress)

    def _build_dungeon(self, d, creature_types, energy_map, coin_map, droprate_map):
        # Send possible material loots
        enemy_element = []
        material_eggs = []

        # energy
        energy_discount = energy_map.get(d['ID'])
        if energy_discount:
            d["requirement"]["energy"] = \
                int(ceil(energy_discount * d["requirement"]["energy"]))

        coin_multiplier = coin_map.get(d['ID'], 1)
        d["reward"]["softCurrency"] *= coin_multiplier
        droprate = droprate_map.get(d['ID'], None)
        # waves
        for w in d['waves']:
            for e in w['enemies']:
                if e['slug'] == '':
                    continue
                e['element'] = proto.Element.Name(
                    creature_types.get(e['slug']).element)
                if e['element'] not in enemy_element:
                    enemy_element.append(e['element'])
            if w.get('boss') and w.get('boss').get('slug'):
                w['boss']['element'] = proto.Element.Name(
                    creature_types.get(w['boss']['slug']).element)
                if w['boss']['element'] not in enemy_element:
                    enemy_element.append(w['boss']['element'])
        # rewards
        for e in ('eggs_enemy', 'eggs_boss', 'eggs_map'):
            d['reward'][e] = self._build_egg_from_content(
                e, d['reward'][e], coin_multiplier, droprate)
        d['reward']['eggs_clearance'] = self._build_eggs_clearance(
            d['reward']['eggs_clearance'], coin_multiplier, droprate)
        # should be eggs_map for area clean up reward, but now using for
        # show each dungeon's material egg type
        #d['reward']['eggs'] = d['reward']['eggs_map']
        d['reward']['eggs'] = []
        for e in d['reward']['eggs_enemy'] + d['reward']['eggs_boss']:
            if e['type'] == MATERIAL_EGG and int(e.get('tier', 0)) < 4:
                t = (e['element'], int(e['tier']))
                if t not in material_eggs:
                    material_eggs.append(t)
        if d['reward']['eggs_clearance']:
            for e in d['reward']['eggs_clearance']['loots']:
                if e['type'] == MATERIAL_EGG and int(e.get('tier', 0)) < 4:
                    t = (e['element'], int(e['tier']))
                    if t not in material_eggs:
                        material_eggs.append(t)
        materials = []
        for egg in material_eggs:
            if egg[0] == 'None':
                material = GameRule.materials.get_material(egg[0], egg[1])
                materials.append(material)
            else:
                for ele in enemy_element:
                    material = GameRule.materials.get_material(ele, egg[1])
                    materials.append(material)

        for m in sorted(materials, cmp=material_egg_cmp):
            d['reward']['eggs'].append({'type': MATERIAL_EGG, 'material': m})

    def _check_dup_d(self, _dungeon_ids, did):
        if did in _dungeon_ids:
            content_error("Duplicate dungeon id: %s." % did)
            raise
        else:
            _dungeon_ids.append(did)

    def _build_eggs_clearance(self, data, coin_multiplier=1, droprate=None):
        # becase the content data from gdrive is not normal format,
        # need convert into normal format
        if not data: return data
        ret = {'loots': [], 'rates':[], 'total':0}
        for d in data:
            loot = d.split('-')
            rate = int(loot[-1])
            ret['total'] += rate
            ret['rates'].append(ret['total'])
            loot[-1] = '100'
            ret['loots'].append('-'.join(loot))
        ret['loots'] = self._build_egg_from_content('', ret['loots'],
                                                    coin_multiplier, droprate)
        return ret

    def _build_egg_from_content(self, e, data, coin_multiplier=1, droprate=None):
        # read the content data from gdrive, convert into protobuf format
        if not data: return data
        eggs_map = (e == 'eggs_map')
        rets = []
        for d in data:
            ret = {}
            d = d.split('-')
            t = d[0]
            t = t.lower()
            if t == FAERIE_EGG.replace('_', '').lower():
                ret['type'] = FAERIE_EGG
                if eggs_map:
                    ret['creature'] = {'slug': d[1]}
                else:
                    ret['tier'] = str(d[1])
                    ret['rate'] = float(d[2])/100
            elif t == SELF_EGG.replace('_', '').lower():
                ret['type'] = SELF_EGG
                if eggs_map:
                    ret['creature'] = {'slug': d[1]}
                else:
                    ret['rate'] = float(d[1])/100
            elif t == MATERIAL_EGG.replace('_', '').lower():
                ret['type'] = MATERIAL_EGG
                if eggs_map:
                    ret['material'] = d[1]
                else:
                    sub = d[1].split('_')
                    ret['element'] = sub[0]
                    ret['tier'] = str(sub[1])
                    ret['rate'] = float(d[2])/100
            elif t == COIN_EGG.replace('_', '').lower():
                ret['type'] = COIN_EGG
                ret['coins'] = int(d[1]) * coin_multiplier
                ret['rate'] = eggs_map or float(d[2])/100
            elif t == GEM_EGG.replace('_', '').lower():
                ret['type'] = GEM_EGG
                ret['gems'] = int(d[1])
                ret['rate'] = eggs_map or float(d[2])/100
            elif t == NUT_EGG.replace('_', "").lower():
                ret['type'] = NUT_EGG
                ret['nut'] = d[1]
                ret['rate'] = float(d[2])/100
            rets.append(ret)
        if droprate:
            # only support materialEgg for now, need to refactor if need to support other types
            elm_tier_map = {}
            for egg in droprate.eggs:
                e_type, e_elm_tier = egg.split('-')
                e_elm, e_tier = e_elm_tier.split('_')
                e_elm_key = e_elm if e_elm == 'None' else 'Elemental'
                e_elm_tier = '_'.join((e_elm_key, e_tier))
                elm_tier_map[e_elm_tier] = e_elm
            for ret in rets:
                if ret['type'] == droprate.egg_type and not eggs_map:
                    r_key = '_'.join((ret['element'], ret['tier']))
                    if r_key in elm_tier_map:
                        ret['bunos_element'] = elm_tier_map[r_key]
                        ret['multiplier'] = droprate.multiplier
        return rets

    def _parse_content_world(self, content):
        def __get_include_key(d):
            return d.values()[0]['include']

        normal_world = None
        event_world = None
        include_dict = None
        for i in range(len(content)):
            ci = content[i]
            data = load_content_json(ci, 'Dungeons')
            if 'world' in data.keys() and data['world']['slug'] == 'normal_world':
                normal_world = data
            if 'world' in data.keys() and data['world']['slug'] == 'event_world':
                event_world = data
            if include_dict and __get_include_key(include_dict) == data.keys()[0]:
                key = __get_include_key(include_dict) + 's'
                subs = include_dict.get(key, [])
                subs.append(data)
                include_dict[key] = subs
            if 'include' in data.values()[0].keys():
                include_dict = data
        return normal_world, event_world

    def dungeon_luck(self, dungeon_id):
        return self._luck_map.get(dungeon_id, 1)


class L10nHelper(object):
    _l10n_map = {}

    def __init__(self, config=None):
        l_map = {}
        config = config or {}
        for key, data in config.iteritems():
            l_map[key] = load_content_json(data, "l10n_%s" % key)
        self._l10n_map = l_map

    def get_by_tag(self, l10n_tag, key=None, default=None):
        _map = self._l10n_map.get(l10n_tag, {})
        if key is None:
            return _map
        return _map.get(key, default)

    def event_name(self, e_slug):
        return self.get_by_tag(L10N_EVENT_NAME, e_slug)

    def creature_name(self, c_slug):
        return self.get_by_tag(L10N_CREATURE_NAME, c_slug)

    def custom(self, key):
        return self.get_by_tag(L10N_CUSTOM, key)

    def server(self, key):
        ret = self.get_by_tag(L10N_SERVER, key)
        if type(ret) is list:
            ret = random.choice(ret)
        return ret

    def skills(self, creature_slug, skill_slug):
        def build_key(c, s):
            return 'creature.%s.skill.%s.name' % (c, s), \
                   'creature.%s.skill.%s.description' % (c, s)
        name, desc = build_key(creature_slug.lower(), skill_slug.lower())

        return (self.get_by_tag(L10N_SKILL, name, skill_slug),
                self.get_by_tag(L10N_SKILL, desc, skill_slug))


class GameRule(object):

    # game design
    configs_proto = None
    creature_types = CreatureTypesHelper()
    world = WorldHelper()
    _world_cont = None
    # world_map = {<utc_offset>: <WorldHelper instance>}
    _world_map = {}
    _events_conf = None
    # events_map = {<utc_offset>: <EventHelper instance>}
    _events_map = {}
    # events_proto_map = {<utc_offset>: <events_proto>}
    _events_proto_map = {}
    faeries = FaerieHelper()
    player = PlayerHelper()
    _gacha_config = None
    _new_gacha_config = None
    # gacha_map = {<utc_offset>: <GachaHelper instance>}
    _gacha_map = {}
    _new_gacha_map = {}
    creature = CreatureHelper()
    materials = MaterialHelper()
    helper = HelperConfig()
    prices = PriceHelper()
    viral = ViralHelper()
    version = ClientVersionHelper()
    asset_version = AssetVersionHelper()
    l10n = L10nHelper()
    gacha_required_progress = 7
    collection = CollectionHelper()

    @classmethod
    def init(cls, extract=True, auto_reload=False):
        if extract:
            cls.extract_content()
        cls.get_content()

        if auto_reload:
            def _load_content():
                while True:
                    gevent.sleep(LOAD_CONTENT_INTERVAL)
                    cls.get_content()
            gevent.spawn(_load_content)

    @classmethod
    def extract_content(cls):
        # read csv file from content_csv/*.csv, and put into couchbase
        def _read_csv_data(_name, key_func=None, val_func=None):
            _data = {}
            with open(_name, "ro") as _csv_f:
                for r in csv.reader(_csv_f):
                    key = r[0]
                    if key == "Keys":
                        continue
                    if key_func:
                        key = key_func(key)
                    if key:
                        _data[key] = val_func and val_func(r[1]) or r[1]
            return simplejson.dumps(_data)

        def _gen_name(key):
            name = key.split(".")
            name = len(name) == 3 and name[2] == "name" and name[1]
            return name

        def _split_val(val):
            if L10N_MSG_SPLIT in val:
                val = [v.strip("\n") for v in val.split(L10N_MSG_SPLIT) if v]
            return val

        fs = glob.glob(os.path.join(file_path, '*.csv'))
        content = Content(version_id=OID)
        l10n_prefix = L10N_FILE_NAME % ""
        l10n = {}
        for f in fs:
            f_name = f.split('/')[-1].split('.')[0]
            if f_name == 'Navi': continue
            if f_name == "Configs":
                data = open(f).readlines()
                content.configs = correct_json_string(data[0])
                content.world = [correct_json_string(d) for d in data[1:]]
            elif f_name == "CreatureType":
                data = [correct_json_string(line.rstrip())
                        for line in open(f).readlines()]
                content.creature_types = data
            elif f_name == "Events":
                data = open(f).readlines()
                content.events = correct_json_string(data[0])
            elif f_name == "ReferencedSkills":
                data = [correct_json_string(line.rstrip())
                        for line in open(f).readlines()]
                content.referenced_skills = data
            elif f_name == "AssetVersion":
                data = [correct_json_string(line.rstrip())
                        for line in open(f).readlines()]
                content.asset_version = data
            elif f_name in L10N_FILE_NAME_ID_MAP:
                l10n_name = f_name.replace(l10n_prefix, "")
                key_f, val_f = (None, None)
                if l10n_name in [L10N_EVENT_NAME, L10N_CREATURE_NAME]:
                    key_f = _gen_name
                if l10n_name == L10N_SERVER:
                    val_f = _split_val
                l10n[l10n_name] = _read_csv_data(f, key_f, val_f)
        content.l10n = l10n
        content.store()


    @classmethod
    def get_content(cls):
        try:
            content = Content(version_id=OID)
            # load asset version from db
            cls.load_asset_version(content.asset_version)

            # load creatures from db
            if content.creature_types:
                cls.load_creatures(content.creature_types, content.referenced_skills)
            cls._update_content(content)

        except Exception, e:
            log.error('can not load content: %s', e, exc_info=True)

    @classmethod
    def _update_content(cls, content):
        # Note: load configs after load creatures
        # player use creatures_types to setup default player settings.
        if content.configs:
            cls.load_configs(content.configs)

        # load world from db
        # !!! NOTICE: always load_world after load_creatures and events!!!
        if content.world:
            cls.load_world(content.world)

        if content.l10n:
            cls.l10n = L10nHelper(content.l10n)

        # Events must load after world & creatures & l10n
        #  - to verify dungeons & creatures & name_localization in events.
        if content.events:
            cls.load_events(content.events)


    @classmethod
    def load_asset_version(cls, configs):
        asset_version = AssetVersionHelper(configs)
        cls.asset_version = asset_version

    @classmethod
    def load_configs(cls, configs):
        # load global configs from db
        configs = load_content_json(configs, 'GlobalConfigs')['globalConfigs']
        if not IS_PRODUCTION:
            if CUSTOM_RESOURCE_UPDATEER_PATH:
                configs['resourceUpdaterPath'] = CUSTOM_RESOURCE_UPDATEER_PATH
            else:
                del configs['resourceUpdaterPath']

        # player
        cls.player = PlayerHelper(cls.creature_types.all_slugs(), **configs)

        # materials
        cls.materials = MaterialHelper(configs.get("craftingMaterial"))

        # creature params - must comes after generate material helper
        cls.creature = CreatureHelper(**configs)

        # prices
        cls.prices = PriceHelper(configs.get("prices", {}))

        # viral
        cls.viral = ViralHelper(configs.get("viral", {}))

        # helper conf
        cls.helper = HelperConfig(**configs.get("helperPicking", {}))

        # build faeries dict
        cls.faeries = FaerieHelper(configs.get("faeries", []))

        # build gacha machines
        cls._gacha_config = configs.get("gatchaMachine")
        cls._verify_gacha_conf(cls._gacha_config)
        cls._new_gacha_config = configs.get("newGacha")
        cls._verify_gacha_conf(cls._new_gacha_config)
        cls.gacha_required_progress = configs.get("gatchaMinProgress", 7)

        # collection
        cls.collection = CollectionHelper(configs.get("collection"))

        # build client version
        cls.version = ClientVersionHelper(configs.get("versionSettings"))
        cls.configs = configs

        # format change for client needed
        configs['prices']['prices']['reviveCost'] = configs['prices']['prices']['reviveCost'][0]
        # update proto at the end in case we need update configs
        cls.configs_proto = proto.GlobalConfigs()
        assign_value(cls.configs_proto, configs)

    @classmethod
    def load_creatures(cls, creature_types, referenced_skills):
        cls.creature_types = CreatureTypesHelper(creature_types, referenced_skills)

    @classmethod
    def all_creatures(cls):
        return cls.creature_types.all_slugs()

    @classmethod
    def _verify_gacha_conf(cls, conf):
        creatures = cls.all_creatures()
        for t in conf:
            t_slug = t.get("slug")
            for c in t.get("drops"):
                c_slug = c.get("creatureSlug")
                if c_slug and c_slug not in creatures:
                    content_error("Gacha not exist creature(%s) - "
                                  "tree slug(%s)" % (c, t_slug))

    @classmethod
    def load_world(cls, world):
        # Only include old dungeon events for resource update.
        cls._world_cont = world
        cls.world = WorldHelper(world, cls.creature_types)

    @classmethod
    def _get_utc_offset(cls, utc_offset):
        if not isinstance(utc_offset, int):
            return DEFAULT_UTC_OFFSET
        day_minutes = 60 * 24
        if utc_offset > day_minutes:
            utc_offset %= day_minutes
        if utc_offset < -day_minutes:
            utc_offset %= -day_minutes
        return utc_offset

    @classmethod
    def get_world(cls, utc_offset=DEFAULT_UTC_OFFSET):
        utc_offset = cls._get_utc_offset(utc_offset)
        world = cls._world_map.get(utc_offset)
        if not world:
            world = WorldHelper(cls._world_cont,
                                cls.creature_types, cls.get_events(utc_offset))
            cls._world_map[utc_offset] = world
        return world

    @classmethod
    def get_base_world(cls):
        world = WorldHelper(cls._world_cont, cls.creature_types)
        return world.proto

    @classmethod
    def get_gacha(cls, utc_offset=DEFAULT_UTC_OFFSET):
        utc_offset = cls._get_utc_offset(utc_offset)
        gachas = cls._gacha_map.get(utc_offset)
        if not gachas:
            gachas = GachaHelper(cls._gacha_config, cls.get_events(utc_offset))
            cls._gacha_map[utc_offset] = gachas
        return gachas

    @classmethod
    def get_new_gacha(cls, utc_offset=DEFAULT_UTC_OFFSET):
        utc_offset = cls._get_utc_offset(utc_offset)
        gacha = cls._new_gacha_map.get(utc_offset)
        if not gacha:
            gacha = NewGachaHelper(cls._new_gacha_config,
                                   cls._events_conf,
                                   cls.get_events(utc_offset))
            cls._new_gacha_map[utc_offset] = gacha
        return gacha

    @classmethod
    def load_events(cls, events):
        if ENABLE_EVENTS:
            e_name_map = cls.l10n.get_by_tag(L10N_EVENT_NAME)
            cls._events_conf = EventConfig(events_str=events,
                                           world=cls.world,
                                           all_creatures=cls.all_creatures(),
                                           name_map=e_name_map)

    @classmethod
    def get_events(cls, utc_offset=DEFAULT_UTC_OFFSET):
        utc_offset = cls._get_utc_offset(utc_offset)
        events = cls._events_map.get(utc_offset)
        if not events:
            events = EventHelper(cls._events_conf, utc_offset)
            cls._events_map[utc_offset] = events

            def _refresh():
                """
                Just clear events related maps,
                it will reload if events not exist.
                """
                refresh_seconds = events.get_refresh_seconds()
                if refresh_seconds:
                    gevent.sleep(refresh_seconds)
                    cls._events_map.pop(utc_offset, None)
                    cls._events_proto_map.pop(utc_offset, None)
                    cls._gacha_map.pop(utc_offset, None)
                    cls._world_map.pop(utc_offset, None)
            gevent.spawn(_refresh)
        return events

    @classmethod
    def _build_event_config_proto(cls, utc_offset=DEFAULT_UTC_OFFSET):
        events_proto = proto.EventsConfigs()
        events = cls.get_events(utc_offset)
        gacha = cls.get_gacha(utc_offset)
        new_gacha = cls.get_new_gacha(utc_offset)
        cls.get_world(utc_offset)  # load world to update ari battle dungeons
        data = {
            'refresh_timestamp': events.get_refresh_timestamp(),
            'version': events.version,
            'airbattle_events': events.get_airbattle_events(),
            'dungeon_bonus_events': events.get_dungeon_bonus_events(),
            'upgrade_events': events.build_upgrade_proto_dict(),
            'tree_events': gacha.trees,
            # 'gacha_luck': events.get_gacha_luck(),
            'gacha_trees': new_gacha.proto_info,
        }
        assign_value(events_proto, data)
        return events_proto

    @classmethod
    def get_event_proto(cls, utc_offset=DEFAULT_UTC_OFFSET):
        utc_offset = cls._get_utc_offset(utc_offset)
        e_proto = cls._events_proto_map.get(utc_offset)
        if not e_proto:
            e_proto = cls._build_event_config_proto(utc_offset)
            cls._events_proto_map[utc_offset] = e_proto
        return e_proto

    @classmethod
    def true_from_ratio(cls, ratio):
        # only support the ratio is percentage
        return random.randint(1, 100) <= ratio * 100

    @classmethod
    def random_get_from_list(cls, l):
        return random.choice(l)

    @classmethod
    def list_with_ratio(cls, d):
        ls = []
        for k, v in d.iteritems():
            ls.extend((k,) * v)
        return cls.random_get_from_list(ls)

    @classmethod
    def get_creature_id_by_slug(cls, slug):
        return cls.creature_types.get(slug).id

    @classmethod
    def battle_drop_luck_egg(cls, luck):
        #TODO: need to design how to drop luck egg based on luck
        return cls.true_from_ratio(float(luck)/100)

    @classmethod
    def battle_drop_egg(cls, droppers, configs, dungeon_reward=False):

        # dungeon_reward only give when finish the dungeon the first time
        # dropper is to define drop what level of the egg
        # configs controls drop what kind if egg and ratio
        if not dungeon_reward:
            dropper = cls.random_get_from_list(droppers)
            rate = configs['rate']
            #print '===='
            #print dropper['element']
            #print configs.get('bunos_element')
            #print configs
            #print dungeon_reward
            #print rate
            if dropper['element'] == configs.get('bunos_element'):
                rate *= configs.get('multiplier')
            #print rate
            if not cls.true_from_ratio(rate): return None
        if configs['type'] == SELF_EGG:
            if dungeon_reward:
                slug = configs['creature']['slug']
            else:
                slug = cls.creature_types.first_stage(dropper['slug'])
            return {'type': SELF_EGG, 'creature':
                {'level': 1, 'slug': slug, 'xp': 0}
            }
        elif configs['type'] == FAERIE_EGG:
            if dungeon_reward:
                f = cls.faeries.by_slug(configs['creature']['slug'])
            else:
                # TODO make all faeries into 'DARK', in case of drop acornmagician
                f = cls.faeries.by_element_tier('DARK',
                                                configs['tier'])
            faerie = {'type': FAERIE_EGG,
                               'creature': {'level': 1, 'slug': f['slug']}}
            faerie['creature'].update(f['stats'])
            return faerie
        elif configs['type'] == MATERIAL_EGG:
            if dungeon_reward:
                material = configs['material']
            else:
                element = 'NONE' if configs['element'] == 'None' else dropper['element']
                material = cls.materials.get_material(element, configs["tier"])
            return {'type': MATERIAL_EGG, 'material': material}
        elif configs['type'] == COIN_EGG:
            return {'type': COIN_EGG, 'coins': configs['coins']}
        elif configs['type'] == GEM_EGG:
            return {'type': GEM_EGG, 'gems': configs['gems']}
        elif configs['type'] == NUT_EGG:
            return {'type': NUT_EGG, 'nut': configs['nut'], 'creature': {}}
        return None

    @classmethod
    def gacha(cls, rand_key, tree_slug, utc_offset=0):
        gachas = cls.get_gacha(utc_offset)
        slug = gachas.drops(rand_key, tree_slug)
        if slug in cls.faeries.all():
            result = {'type': FAERIE_EGG,
                      'creature': {'level': 1, 'slug': slug}}
            result["creature"].update(cls.faeries.by_slug(slug).get("stats"))
        else:
            slug = cls.creature_types.first_stage(slug)
            result = {'type': SELF_EGG,
                      'creature': {'level': 1, 'slug': slug, 'xp': 0}}
        default_attr = gachas.creature_init_attribute(tree_slug)
        if default_attr:
            result["creature"].update(default_attr)
        return result

    @classmethod
    def egg_type(cls, slug):
        e_type = slug in cls.faeries.all_slug() and "FAERIE_EGG" or "SELF_EGG"
        return EggType.Value(e_type)
