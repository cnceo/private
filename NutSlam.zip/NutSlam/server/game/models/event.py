import logging
import cPickle
import simplejson
from datetime import datetime
from datetime import timedelta
from pytz import utc
from actors.notification import SNS_ACTION
from actors.notification import pn_actor
from dal.base import Base
from dal.base import IntAttr, TextAttr
from dal.base import KeyValue
from utils.enum import Enum
from utils.misc import content_error
from utils.misc import content_log
from utils.misc import datetime_to_int
from utils.misc import dateformat_with_utc_offset
from utils.misc import parse_date
from utils.misc import utc_now
from utils.protocol_pb2 import Element
from utils.settings import IS_PRODUCTION, FULL_EVENTS, EVENTS_SCHEDULE
from utils.settings import EventsType
from utils.settings import EVENTS_DEFAULT_REFRESH_TIME
from utils.settings import EVENTS_END_BUFFER
from utils.settings import EVENTS_START_BUFFER
from utils.settings import DEFAULT_UTC_OFFSET
from utils.settings import UTC_OFFSETS_KEY
from utils.settings import EVENT_END_TIME_OFFSET_SEC


EventEffect = Enum()
EventEffect.new_dungeon = 1
EventEffect.old_dungeon = 2
EventEffect.gacha_tree = 3
EventEffect.upgrade = 4
EventEffect.gacha_luck = 5
EventEffect.new_gacha = 6


def event_type(event_name):
    return event_name.split("-")[0]


class EventBase(object):
    def __init__(self, slug, start_time, event_index, **kwargs):
        super(EventBase, self).__init__()
        self.start_time = start_time
        self.slug = slug
        self.event_index = event_index
        duration = kwargs.get("duration", 0)
        self.end_time = start_time + timedelta(hours=duration)

    def started(self, buffer_start=False):
        start_time = buffer_start and self.buffer_start_time or self.start_time
        return start_time <= utc_now()

    def is_active(self, buffer_end=False):
        end_time = buffer_end and self.buffer_end_time or self.end_time
        return self.start_time <= utc_now() < end_time

    def finished(self):
        return self.end_time < utc_now()

    @property
    def buffer_start_time(self):
        return self.start_time - timedelta(seconds=EVENTS_START_BUFFER)

    @property
    def buffer_end_time(self):
        return self.end_time + timedelta(seconds=EVENTS_END_BUFFER)

    @property
    def start_timestamp(self):
        return datetime_to_int(self.start_time)

    @property
    def end_timestamp(self):
        return datetime_to_int(self.end_time)

    @property
    def event_type(self):
        raise NotImplementedError

    @property
    def effect(self):
        raise NotImplementedError


class NewDungeonBase(EventBase):
    def __init__(self, *args, **kwargs):
        super(NewDungeonBase, self).__init__(*args, **kwargs)
        self.creature_slug = kwargs.get('creature_slug')
        self.dungeon_ids = kwargs.get('dungeons')
        self.dungeons = []  # dungeons info, will update while loading world


class NewDungeonXP(NewDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_XP

    @property
    def effect(self):
        return EventEffect.new_dungeon


class NewDungeonWeekDay(NewDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_WEEKDAY

    @property
    def effect(self):
        return EventEffect.new_dungeon


class NewDungeon556(NewDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_D556

    @property
    def effect(self):
        return EventEffect.new_dungeon


class NewDungeon45(NewDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_D45

    @property
    def effect(self):
        return EventEffect.new_dungeon


class OldDungeonBase(EventBase):
    def __init__(self, *args, **kwargs):
        super(OldDungeonBase, self).__init__(*args, **kwargs)
        self.dungeons = kwargs.get("dungeons", [])
        self.multiplier = kwargs.get("multiplier", 1)


class DungeonDropRate(OldDungeonBase):
    """
    this only affect enemy loot and boss loot, not for clearance, map reward
    """
    def __init__(self, *args, **kwargs):
        super(DungeonDropRate, self).__init__(*args, **kwargs)
        self.element = kwargs.get("element", None)
        self.egg_type = kwargs.get("egg_type", None)
        if self.egg_type: self.egg_type.upper()
        self.eggs = kwargs.get("eggs", [])

    @property
    def event_type(self):
        return EventsType.EVENTS_DROPRATE

    @property
    def effect(self):
        return EventEffect.old_dungeon


class DungeonEnergy(OldDungeonBase):
    def __init__(self, *args, **kwargs):
        super(DungeonEnergy, self).__init__(*args, **kwargs)
        self.multiplier = kwargs.get("discount", 100) / 100.0

    @property
    def event_type(self):
        return EventsType.EVENTS_ENERGY

    @property
    def effect(self):
        return EventEffect.old_dungeon


class DungeonLuck(OldDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_DUNGEON_LUCK

    @property
    def effect(self):
        return EventEffect.old_dungeon


class DungeonCoin(OldDungeonBase):
    @property
    def event_type(self):
        return EventsType.EVENTS_COIN

    @property
    def effect(self):
        return EventEffect.old_dungeon


class Upgrade(EventBase):
    def __init__(self, *args, **kwargs):
        super(Upgrade, self).__init__(*args, **kwargs)
        chances = kwargs.get("chances")
        chances_converted = {}
        for k, v in chances.items():
            chances_converted[Element.Value(k.upper())] = float(v) / 100
        self.chances = chances_converted
        self.multiplier = kwargs.get("multiplier", 1)

    @property
    def event_type(self):
        return EventsType.EVENTS_UPGRADE

    @property
    def effect(self):
        return EventEffect.upgrade


class GachaLuck(EventBase):
    def __init__(self, *args, **kwargs):
        super(GachaLuck, self).__init__(*args, **kwargs)
        self.luck = kwargs.get("init_luck")
        self.tree_slug = kwargs.get("tree_slug")

    @property
    def event_type(self):
        return EventsType.EVENTS_TREE_LUCK

    @property
    def effect(self):
        return EventEffect.gacha_luck

    def init_attr(self):
        return {"plusLuck": self.luck}


class GachaBase(EventBase):
    def __init__(self, *args, **kwargs):
        super(GachaBase, self).__init__(*args, **kwargs)
        self.tree_index = self.event_index
        self.prefab = kwargs.get("prefab")
        self.creatures = {}

    def get_proto_dict(self):
        return {
                "slug": self.slug,
                "tree_type": 'PREMIUM',
                "start_timestamp": self.start_timestamp,
                "end_timestamp": self.end_timestamp,
                "creature_slug": self.creatures.keys(),
                "prefab": self.prefab,
            }


class GachaFeature(GachaBase):
    def __init__(self, *args, **kwargs):
        super(GachaFeature, self).__init__(*args, **kwargs)
        slug = kwargs.get("creature_slug")
        creatures = {slug: {"weight": kwargs.get("percentage") or 0,
                            "normal_weight": kwargs.get("normal_weight") or 0}}
        self.creatures = creatures

    @property
    def event_type(self):
        return EventsType.EVENTS_FEATURE_TREE

    @property
    def effect(self):
        return EventEffect.gacha_tree


class GachaTheme(GachaBase):
    def __init__(self, *args, **kwargs):
        super(GachaTheme, self).__init__(*args, **kwargs)
        creatures = {}
        for c in kwargs.get("data"):
            slug = c.get("creature_slug")
            if not slug:
                continue
            creatures[slug] = {"weight": c.get("feature_weights") or 0,
                               "normal_weight": c.get("normal_weight") or 0}
        self.creatures = creatures


    @property
    def event_type(self):
        return EventsType.EVENTS_THEME_TREE

    @property
    def effect(self):
        return EventEffect.gacha_tree


class EventTree(EventBase):
    def __init__(self, *args, **kwargs):
        super(EventTree, self).__init__(*args, **kwargs)
        self.price = int(kwargs.get("price", 0))
        self.drops = kwargs.get("drops", [])
        self.tree_type = kwargs.get("tree_type")
        self.prefab = kwargs.get("prefab")

    @property
    def event_type(self):
        return EventsType.EVENT_TREE

    @property
    def effect(self):
        return EventEffect.new_gacha

class SpecialGatcha(EventTree):
    def __init__(self, *args, **kwargs):
        super(SpecialGatcha, self).__init__(*args, **kwargs)

    @property
    def event_type(self):
        return EventsType.SPECIAL_GATCHA

event_handler_map = {
    EventsType.EVENTS_XP: NewDungeonXP,
    EventsType.EVENTS_WEEKDAY: NewDungeonWeekDay,
    EventsType.EVENTS_D556: NewDungeon556,
    EventsType.EVENTS_D45: NewDungeon45,

    EventsType.EVENTS_DROPRATE: DungeonDropRate,
    EventsType.EVENTS_ENERGY: DungeonEnergy,
    EventsType.EVENTS_DUNGEON_LUCK: DungeonLuck,
    EventsType.EVENTS_COIN: DungeonCoin,

    EventsType.EVENTS_UPGRADE: Upgrade,
    EventsType.EVENTS_TREE_LUCK: GachaLuck,
    EventsType.EVENTS_FEATURE_TREE: GachaFeature,
    EventsType.EVENTS_THEME_TREE: GachaTheme,
    EventsType.EVENT_TREE: EventTree,
    EventsType.SPECIAL_GATCHA: SpecialGatcha,
}


class EventConfig(object):
    def __init__(self, events_str=None, world=None, all_creatures=[],
                 name_map=None):
        super(EventConfig, self).__init__()
        if not events_str:
            return
        _events = events_str and simplejson.loads(events_str) or {}
        world_dungeons = world.all_dungeon_ids
        event_map = {}
        key_events = {}
        scheduled_events = set()
        for s in _events.get(EVENTS_SCHEDULE, []):
            scheduled_events.update(s.get('events').values())
        scheduled_events.discard("")

        for key, handler in event_handler_map.iteritems():
            verify_name = issubclass(handler, NewDungeonBase)
            for e in _events.get(key, []):
                e_slug = e.pop("slug")
                if not e_slug:
                    content_error("Missing event slug %s, %s" % (key, str(e)))
                    continue
                if e_slug in event_map:
                    content_error("Duplicate event - slug(%s): %s %s" %
                                  (e_slug, str(e), str(event_map.get(e_slug))))
                    continue

                log_level = (e_slug in scheduled_events and
                             logging.ERROR or logging.WARNING)
                if verify_name and e_slug not in name_map:
                    content_log("Missing localization - event slug(%s)"
                                % e_slug, log_level)
                # for get all events for client testing
                d = key_events.get(key, [])
                d.append(e_slug)
                key_events[key] = d

                # verify dungeons
                dungeons = e.get("dungeons")
                if dungeons:
                    e["dungeons"] = self.filter_out_first_area(dungeons)
                    self.verify_dungeons(e_slug, dungeons, world_dungeons,
                                         log_level)

                # verify creatures
                creatures = []
                if key == EventsType.EVENTS_THEME_TREE:
                    for c in e.get("data", []):
                        creatures.append(c.get("creature_slug"))
                if key == EventsType.EVENT_TREE:
                    for c in e.get("drops", []):
                        creatures.append(c.get("creatureSlug"))
                if key == EventsType.SPECIAL_GATCHA:
                    for c in e.get("drops", []):
                        creatures.append(c.get("creatureSlug"))
                elif e.get("creature_slug"):
                    creatures = [e.get("creature_slug")]
                if creatures:
                    self.verify_creatures(e_slug, creatures, all_creatures,
                                          log_level)

                event_map[e_slug] = e
        # schedules
        if not IS_PRODUCTION and FULL_EVENTS:
            datetime_parsed = True
            schedule = self.build_full_events_schedule(key_events)
        else:
            datetime_parsed = False
            schedule = _events.get(EVENTS_SCHEDULE, [])
            # verify schedule and filter undefined events
            for s in schedule:
                start_time = s.get("start_date")
                _ets = s.get("events", {})
                for e_tag, e_name in _ets.copy().iteritems():
                    if e_name not in event_map:
                        content_error("Undefined event name (%s) - "
                                      "start_date:%s, column:%s" %
                                      (e_name, start_time, e_tag))
                        _ets.pop(e_tag)

        self.event_map = event_map
        self._schedule = cPickle.dumps(schedule)
        self.event_type_map = key_events
        self.datetime_parsed = datetime_parsed
        self.version = _events['version']

    @property
    def schedule(self):
        return cPickle.loads(self._schedule)

    def verify_dungeons(self, event_slug, dungeons, world_dungeons, log_level):
        if len(set(dungeons)) != len(dungeons):
            content_log("Event duplicate dungeons - event slug(%s) "
                        "dungeons(%s)" % (event_slug, str(dungeons)),
                        log_level)
        for d_id in dungeons[:]:
            if d_id not in world_dungeons:
                content_log("Event not exist dungeon(%s) - event slug(%s)" %
                            (d_id, event_slug), log_level)
                dungeons.remove(d_id)

    def verify_creatures(self, event_slug, creatures, all_creatures, log_level):
        for c in creatures:
            if c not in all_creatures:
                content_log("Event not exist creature(%s) - event slug(%s)" %
                            (c, event_slug), log_level)

    def filter_out_first_area(self, ds):
        for i in (100, 200, 300, 400, 500, 600):
            if i in ds:
                ds.remove(i)
        return ds

    def build_full_events_schedule(self, key_events):
        # for get all events for client testing
        schedule = []
        d = datetime.now()
        start_date = datetime(d.year, d.month, d.day,0,0,0,0,utc)
        for key, events in key_events.iteritems():
            for e in events:
                schedule.append({
                    'start_date':start_date,
                    'events':{key:e}})
        return schedule

    def incoming_events(self, start, end, date_format):
        events = []
        for s in self.schedule:
            s_d = parse_date(s.get("start_date"), date_format)
            if s_d < start:
                continue
            if s_d > end:
                break
            events.extend(s.get("events", {}).values())
        return events

    def get(self, event_name):
        return self.event_map.get(event_name)

    def get_all(self, e_type):
        """
        @return all (<event_slug>, <event_config>) for specified event type.
        """
        return [(e_name, self.get(e_name))
                for e_name in self.event_type_map.get(e_type, [])]


class EventHelper(object):
    refresh_time = None
    server_refresh_time = None
    finished_gacha_trees = []
    gacha_trees = []
    gacha_luck = []
    new_dungeons = []
    old_dungeons = []
    new_gacha = []
    special_gatcha = []
    version = None
    _upgrade = None
    _next_xp_time = None

    def __init__(self, event_conf=None, utc_offset=0):
        super(EventHelper, self).__init__()
        if not event_conf:
            return

        self._date_format = dateformat_with_utc_offset(utc_offset)

        active_events = []
        finished_gacha_trees = {}
        refresh_time = None
        server_refresh_time = None
        active_xp_event = False
        active_xp_event_next = False
        schedule = event_conf.schedule

        if not event_conf.datetime_parsed:
            for s in schedule:
                s['start_date'] = self._parse_date(s['start_date'])
            sorted(schedule, key=lambda d: d['start_date'])

        for s in schedule:
            start_time = s.get("start_date")
            refresh_time = self._gen_refresh_time(refresh_time, start_time)
            for e_index, e_name in s.get("events", {}).iteritems():
                _type = event_type(e_name)
                e_kw = event_conf.get(e_name) or {}
                e = event_handler_map.get(_type)(e_name, start_time, e_index,
                                                 **e_kw)

                if _type == EventsType.EVENTS_XP and start_time > utc_now():
                    if not active_xp_event:
                        # client need the coming xp event for display.
                        active_events.append(e)
                        active_xp_event = True
                        server_refresh_time = self._gen_refresh_time(
                            server_refresh_time, e.buffer_start_time)
                    elif not active_xp_event_next:
                        # client need the next coming xp event for display.
                        #TODO: remove the next coming xp event, check requirment and clean active_xp_event_next
                        # active_events.append(e)
                        active_xp_event_next = True

                # We give all events(except upgrade) a end buffer in server
                # side to make sure player always get the event bonus they see.
                buffer_end = e.effect != EventEffect.upgrade
                if e.is_active(buffer_end=buffer_end):
                    active_events.append(e)
                    # check end time to update refresh time for active events.
                    refresh_time = self._gen_refresh_time(refresh_time,
                                                          e.end_time)
                    if e.finished():
                        # check buffer end time to update server refresh time.
                        server_refresh_time = self._gen_refresh_time(
                                server_refresh_time, e.buffer_end_time)
                    elif _type == EventsType.EVENTS_XP:
                        active_xp_event = True

                if e.effect == EventEffect.gacha_tree and e.finished():
                    finished_gacha_trees[e_name] = e
        self.version = event_conf.version
        self.refresh_time = refresh_time
        self.server_refresh_time = server_refresh_time

        self.finished_gacha_trees = finished_gacha_trees.values()
        self.new_dungeons = [e for e in active_events
                             if e.effect == EventEffect.new_dungeon]
        self.old_dungeons = [e for e in active_events
                             if e.effect == EventEffect.old_dungeon]
        self.gacha_trees = [e for e in active_events
                            if e.effect == EventEffect.gacha_tree]
        self.gacha_luck = [e for e in active_events
                           if e.effect == EventEffect.gacha_luck]
        self.new_gacha = [e for e in active_events
                          if e.effect == EventEffect.new_gacha]
        _upgrades = [e for e in active_events
                     if e.effect == EventEffect.upgrade]
        self._upgrade = _upgrades[0] if _upgrades else None

    @property
    def date_format(self):
        return self._date_format or "%s +0000"

    def _parse_date(self, date_str):
        return parse_date(date_str, self.date_format)

    def _gen_refresh_time(self, refresh_time, new_time):
        now = utc_now()
        if new_time <= now:
            return refresh_time
        if refresh_time is None or refresh_time < now:
            return new_time
        if refresh_time < new_time:
            return refresh_time
        return new_time

    def get_refresh_timestamp(self):
        now = utc_now()
        if self.refresh_time and self.refresh_time > now:
            return datetime_to_int(self.refresh_time)
        return datetime_to_int(now) + EVENTS_DEFAULT_REFRESH_TIME

    def get_refresh_seconds(self):
        now = utc_now()
        if self.server_refresh_time:
            refresh_time = self._gen_refresh_time(self.refresh_time,
                                                  self.server_refresh_time)
        else:
            refresh_time = self.refresh_time

        if refresh_time and refresh_time > now:
            return (refresh_time - now).total_seconds()
        return 0

    def upgrade_chance(self, element):
        if not self._upgrade: return 0
        return self._upgrade.chances.get(element, 0)

    def build_upgrade_proto_dict(self):
        if not self._upgrade:
            return
        return {
            'slug': self._upgrade.slug,
            'start_timestamp': self._upgrade.start_timestamp,
            'end_timestamp': self._upgrade.end_timestamp,
            'chance': [{'element_index': k, 'ratio': v} for k,v in self._upgrade.chances.iteritems()]
        }

    def get_bonus_type(self, event_type):
        if event_type == EventsType.EVENTS_DROPRATE:
            return 'droprate_multiply'
        elif event_type == EventsType.EVENTS_ENERGY:
            return 'energy_multiply'
        elif event_type == EventsType.EVENTS_DUNGEON_LUCK:
            return 'luck_multiply'
        elif event_type == EventsType.EVENTS_COIN:
            return 'coin_multiply'

    def _filter_out_finished_events(self, events_list):
        return [e for e in events_list if not e.finished()]

    def get_dungeon_bonus_events(self):
        extend_list = []
        # one dungeon only have one event at same time
        for old in self._filter_out_finished_events(self.old_dungeons):
            data = {'slug': old.slug,
                    'start_timestamp': old.start_timestamp,
                    'end_timestamp': old.end_timestamp,
                    'dungeon_ids': old.dungeons,
                    'dungeon_bonus': {
                        'type': self.get_bonus_type(old.event_type),
                        'value': old.multiplier,
                    }}
            if old.event_type == EventsType.EVENTS_DROPRATE:
                data['dungeon_bonus']['payload'] = [{'key': 'droprate_egg_type', 'value': old.egg_type}]
            extend_list.append(data)
        return extend_list

    def get_airbattle_events(self):
        airbattle_events = []
        for d in self._filter_out_finished_events(self.new_dungeons):
            airbattle_events.append({'slug': d.slug,
                                     'creature_slug': d.creature_slug,
                                     'start_timestamp': d.start_timestamp,
                                     'end_timestamp': d.end_timestamp - EVENT_END_TIME_OFFSET_SEC,
                                     'dungeons': d.dungeons})
        return airbattle_events

    def get_gacha_luck(self):
        g_lucks = []
        for g_l in self.gacha_luck:
            g_lucks.append({"tree_index": g_l.tree_slug,
                            "init_luck": g_l.luck,
                            })
        return g_lucks


class EventTopic(Base):
    utc_offset = IntAttr()
    # topic_name: json of {<topic_name>: <arn>}
    topic_map = TextAttr()
    _oid_key = "utc_offset"

    def get_topic_map(self):
        if self.topic_map:
            return simplejson.loads(self.topic_map)
        return {}

    def update_topic_map(self, event_name, arn):
        t_map = self.get_topic_map()
        t_map[event_name] = arn
        self.topic_map = simplejson.dumps(t_map)
        self.store()

    def store(self):
        super(EventTopic, self).store()
        # update UTC_OFFSETS
        utc_offsets = KeyValue(UTC_OFFSETS_KEY)
        _offsets = utc_offsets.load() or []
        if self.utc_offset not in _offsets:
            _offsets.append(self.utc_offset)
            utc_offsets.store(_offsets)


_events_pn_topic_map = {}
def get_event_pn_topic(event_type, utc_offset=DEFAULT_UTC_OFFSET):
    global _events_pn_topic_map
    t_name = "%s_%s" % (event_type, utc_offset)
    if not IS_PRODUCTION:
        t_name = "test_%s" % t_name
    topic = _events_pn_topic_map.get(event_type)
    if not topic:
        et = EventTopic(utc_offset=utc_offset)
        t_map = et.get_topic_map()
        topic = t_map.get(event_type)
        if not topic:
            msg = {"action": SNS_ACTION.CREATE_TOPIC,
                   "data": {"t_name": t_name}}
            topic = pn_actor().ask(msg)
            et.update_topic_map(event_type, topic)
        _events_pn_topic_map[t_name] = topic
    return topic
