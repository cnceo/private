# -*- coding: utf-8 -*-

import gevent
import random
import uuid
import M2Crypto
from datetime import datetime
from time import time
from dal.base import *
from dal.db import db
from models.content import GameRule
from models.creature import CreatureInstance
from models.creature import CreatureTeam
from models.creature import Nuts
from models.event import get_event_pn_topic
from models.free_nut import DailyWarnut
from models.free_nut import FreeAkorn
from models.ledgers import CoinsLedger
from models.ledgers import GemsLedger
from models.ledgers import HeartsLedger
from utils.constants import TRANS_TYPE
from utils.exception import PlayerAssignDisabled
from utils.exception import UnsupportedPlayerAction
from utils.protocol_pb2 import EventsConfigs
from utils.protocol_pb2 import OSType
from utils.protocol_pb2 import PlayerInfo
from utils.l10n_keys import FRIEND_PASS_ME_PN
from utils.misc import string_to_int
from utils.settings import DEFAULT_UTC_OFFSET
from utils.settings import EVENTS_BOSS
from utils.settings import EventsType
from utils.settings import CACHE_HELPER_TTL
from utils.settings import THANK_SAME_HELPER_TTL
from utils.settings import VERIFY_SEND_TANK_HELPER_PROGRESS
from utils.settings import SEND_THANK_HELPER_TTL
from utils.settings import IS_PRODUCTION
from utils.settings import MEMCACHED_BUCKET
from utils.settings import NOTIFY_WHEN_FRIEND_PASS
from utils.settings import SESSION_TTL_DELTA
from utils.settings import TEST_MODE
from utils.settings import TIMEZONE_TTL_DELTA
from utils.settings import VERIFY_PLAYER_STATUS
from utils.settings import GEM_MINUS_MAX
from utils.settings import ENERGY_MINUS_MAX
from utils.settings import COINS_MINUS_MAX
from utils.settings import HEART_MINUS_MAX
from actors.notification import SNS_ACTION
from actors.notification import pn_actor
from actors.stats import send_event
from actors.stats import DeltaLedger
from actors.stats import DeltaLevelUp
from utils.local_content import lct
from utils.log import log


player_id_initial = 11888111
id_count = KeyValue('id_count')


class PlayerStatic(Base):
    _oid_key = "id"
    id = LongAttr()
    name = UnicodeAttr(default="")
    agc_id = TextAttr(default="")
    gp_id = TextAttr(default="")
    gp_email = TextAttr(default="")
    facebook_id = TextAttr(default="")
    fb_name = UnicodeAttr(default="")
    fb_business_token = TextAttr(default="")
    device_id = TextAttr(default="")  # Record the device create the player
    _index_attributes = ["agc_id", "gp_id", "facebook_id", "device_id",
                         "gp_email"]


class PlayerLoginInfo(Base):
    _oid_key = "id"
    id = LongAttr()
    os_type = IntAttr()
    pn_token = TextAttr()
    login_time = DateTimeAttr()
    create_time = DateTimeAttr()


class PlayerSettings(Base):
    _oid_key = "id"
    id = LongAttr()

    # Push notification settings
    notify_energy_full = BoolAttr(default=False)
    notify_event_dungeon_boss = BoolAttr(default=False)
    notify_event_weekday = BoolAttr(default=False)
    notify_event_xp = BoolAttr(default=False)
    notify_friends_join = BoolAttr(default=False)
    notify_inactive = BoolAttr(default=False)
    notify_get_gift = BoolAttr(default=True)
    feedback = BoolAttr(default=False)
    notify_gatcha_daily = BoolAttr(default=False)
    notify_gatcha_free = BoolAttr(default=False)

    def update_proto(self, settings):
        settings.notify_energy_full = self.notify_energy_full
        settings.notify_event_dungeon45 = self.notify_event_dungeon_boss
        settings.notify_event_dungeon556 = self.notify_event_dungeon_boss
        settings.notify_event_dungeon = self.notify_event_dungeon_boss
        settings.notify_event_weekday = self.notify_event_weekday
        settings.notify_event_xp = self.notify_event_xp
        settings.notify_friends_join = self.notify_friends_join
        settings.notify_inactive = self.notify_inactive
        settings.feedback = self.feedback
        settings.notify_gatcha_daily = self.notify_gatcha_daily
        settings.notify_gatcha_free = self.notify_gatcha_free


class PlayerGameInfo(Base):
    _oid_key = "id"
    id = LongAttr()

    # game process
    xp = IntAttr()
    level = IntAttr()
    energy = IntAttr()
    energy_update_time = IntAttr()
    progress = IntAttr()
    max_creatures = IntAttr()

    # monetary
    coins = LongAttr(default=0)
    hearts = IntAttr(default=0)
    gems = IntAttr(default=0)

    # materials
    stone_s = IntAttr()
    stone_m = IntAttr()
    stone_l = IntAttr()
    stone_x = IntAttr()
    stone_fire_s = IntAttr()
    stone_fire_l = IntAttr()
    stone_wood_s = IntAttr()
    stone_wood_l = IntAttr()
    stone_water_s = IntAttr()
    stone_water_l = IntAttr()
    stone_light_s = IntAttr()
    stone_light_l = IntAttr()
    stone_dark_s = IntAttr()
    stone_dark_l = IntAttr()

    achievements = ListAttr(TextAttr())

    # split test tags, one player only set up once when sign up
    split_test_tag = TextAttr()
    split_test_group = TextAttr()

    super_cooker = BoolAttr(default=False)
    gatcha_pulled = BoolAttr(default=False)
    first_drop = DictAttr(BoolAttr(default=False), default={})


class PlayerTimeZone(Base):
    _oid_key = "id"
    id = LongAttr()
    timezone = TextAttr()
    utc_offset = IntAttr(default=DEFAULT_UTC_OFFSET)
    ttl = IntAttr()

    def store(self):
        if self.timezone or self.utc_offset is not None:
            self.ttl = int(time()) + TIMEZONE_TTL_DELTA
        super(PlayerTimeZone, self).store()

    def exist(self):
        return super(PlayerTimeZone, self).exist() and self.ttl > time()


class Player(object):
    static_attr = PlayerStatic._data_attrs.keys()
    login_attr = PlayerLoginInfo._data_attrs.keys()
    game_attr = PlayerGameInfo._data_attrs.keys()
    timezone_attr = PlayerTimeZone._data_attrs.keys()
    settings_attr = PlayerSettings._data_attrs.keys()
    _data_type_map = {}
    old_pn_token = None
    pn_token_updated = False
    ledger_map = {"coins": CoinsLedger,
                  "gems": GemsLedger,
                  "hearts": HeartsLedger,}
    index_attribute = (PlayerStatic._index_attributes +
                       PlayerLoginInfo._index_attributes +
                       PlayerGameInfo._index_attributes +
                       PlayerTimeZone._index_attributes +
                       PlayerSettings._index_attributes)

    @classmethod
    def attr_type(cls,  attr):
        if not cls._data_type_map:
            cls._data_type_map.update(PlayerStatic._data_attrs)
            cls._data_type_map.update(PlayerLoginInfo._data_attrs)
            cls._data_type_map.update(PlayerGameInfo._data_attrs)
            cls._data_type_map.update(PlayerTimeZone._data_attrs)
            cls._data_type_map.update(PlayerSettings._data_attrs)
        return cls._data_type_map.get(attr)

    def __getattr__(self, attr):
        if attr in self.static_attr:
            return getattr(self.static, attr)
        elif attr in self.login_attr:
            return getattr(self.login, attr)
        elif attr in self.game_attr:
            return getattr(self.game, attr)
        elif attr in self.timezone_attr:
            return getattr(self.tz, attr)
        elif attr in self.settings_attr:
            return getattr(self.settings, attr)
        return super(Player, self).__getattribute__(attr)

    def __setattr__(self, key, value):
        if not TEST_MODE and key in self.ledger_map:
            raise PlayerAssignDisabled(key)
        if (key == 'pn_token' and self.pn_token != value
                and not self.pn_token_updated):
            self.old_pn_token = self.pn_token
            self.pn_token_updated = True
        if key in self.static_attr:
            setattr(self.static, key, value)
            self.static_modified = True
        elif key in self.login_attr:
            setattr(self.login, key, value)
            self.login_modified = True
        elif key in self.game_attr:
            setattr(self.game, key, value)
            self.game_modified = True
        elif key in self.settings_attr:
            setattr(self.settings, key, value)
            self.settings_modified = True
        elif key in self.timezone_attr:
            # TODO: timezone not inited in is_new, so the timezone key can nerver be updated
            # only update timezone info if there's no such value.
            #if not self.tz.exist():
            setattr(self.tz, key, value)
            self.timezone_modified = True
        else:
            super(Player, self).__setattr__(key, value)

    def __init__(self, **kw):
        self.is_new = kw.get("is_new") and True or False
        if not kw.get("id"):
            kw["id"] = id_count.incr(1, initial=player_id_initial)
        if self.is_new:
            # update player id for log
            log.bind(player_id=kw.get("id"))
            now = datetime.now()
            kw.setdefault("login_time", now)
            kw.setdefault("create_time", now)
            for key, val in GameRule.player.default.get("attr").iteritems():
                kw.setdefault(key, val)
            for material in GameRule.materials.materials():
                kw.setdefault(material, 0)
        self.static = PlayerStatic(**kw)
        self.login = PlayerLoginInfo(**kw)
        self.game = PlayerGameInfo(**kw)
        self.tz = PlayerTimeZone(**kw)
        self.settings = PlayerSettings(**kw)
        self._update_modified(self.is_new)

        if self.is_new:
            self.init_detials(kw.get("default_creatures"))

            # Update init ledgers
            for attr, l_cls in self.ledger_map.iteritems():
                val = self.get(attr)
                if val:
                    self.update_ledger(l_cls, TRANS_TYPE.INIT_PLAYER, val)

    def _update_modified(self, val):
        self.static_modified = val
        self.login_modified = val
        self.game_modified = val
        self.timezone_modified = val
        self.settings_modified = val

    def load(self):
        self.static.load()
        self.login.load()
        self.game.load()
        self.tz.load()
        self.settings.load()
        return self

    def store(self):
        if self.static_modified:
            self.static.store()
        if self.login_modified:
            self.login.store()
        if self.game_modified:
            self.game.store()
        if self.timezone_modified:
            self.tz.store()
        if self.settings_modified:
            self.settings.store()
        if self.pn_token_updated:
            self._update_pn_token()
            self.old_pn_token = None
            self.pn_token_updated = False
        if ((self.timezone_modified or self.settings_modified) and
                not self.pn_token_updated):
            self._refresh_pn()
        self._update_modified(False)

    def _refresh_pn(self):
        def _refresh(player_id, pn_token, settings, utc_offset):
            if pn_token:
                pn = PushNotificationToken(pn_token=pn_token,
                                           new_utc_offset=utc_offset,
                                           settings=settings)
                if player_id in pn.player_ids:
                    pn.store()
        gevent.spawn(_refresh, self.id, self.pn_token, self.settings,
                     self.utc_offset)

    def _update_pn_token(self):
        def _update(player_id, old_token, new_token, settings, utc_offset):
            if old_token:
                old_pn = PushNotificationToken(pn_token=old_token,
                                               new_utc_offset=utc_offset,
                                               settings=settings)
                old_pn.remove_player(player_id)
            if new_token:
                pn = PushNotificationToken(pn_token=new_token,
                                           new_utc_offset=utc_offset,
                                           settings=settings)
                pn.add_player(player_id)
        gevent.spawn(_update, self.id, self.old_pn_token, self.pn_token,
                     self.settings, self.utc_offset)

    @property
    def name(self):
        return self.static.fb_name or self.static.name

    @property
    def pip_name(self):
        return self.static.name or ''

    def send_pn(self, msg, delay=0, badge=None, **kwargs):
        def _send(_msg, pn_token, pn_badge, **custom_data):
            log.info("SEND_PN", msg=_msg)
            pn = PushNotificationToken(pn_token=pn_token,
                                       new_utc_offset=self.utc_offset,
                                       settings=self.settings)
            pn.send_msg(_msg, badge=pn_badge, **custom_data)

        if self.pn_token:
            if delay:
                gevent.spawn_later(delay, _send, msg, self.pn_token, badge,
                                   **kwargs)
            else:
                _send(msg, self.pn_token, badge, **kwargs)

    def exist(self):
        return self.static.exist()

    @classmethod
    def load_oids_by_attribute(cls, attr, val):
        if attr in cls.static_attr:
            return PlayerStatic.load_oids_by_attribute(attr, val)
        if attr in cls.login_attr:
            return PlayerLoginInfo.load_oids_by_attribute(attr, val)
        if attr in cls.game_attr:
            return PlayerGameInfo.load_oids_by_attribute(attr, val)
        return []

    @classmethod
    def load_by_attribute(cls, attr, val):
        resp = []
        for player_id in cls.load_oids_by_attribute(attr, val):
            data = {attr: val,
                    "id": player_id}
            obj = cls(**data)
            obj.load()
            resp.append(obj)
        return resp

    def init_detials(self, default_creatures):
        def _create_creatures(c_sets):
            c_ids = []
            for slug, attr in c_sets:
                c = Nuts.create(self.id, slug, auto_open=True, **attr)
                c_ids.append(c.oid)
            return c_ids

        if default_creatures:
            # for sample player using
            c_ids = _create_creatures(default_creatures)
            CreatureTeam.create(self.id, team1=c_ids)
        else:
            # for real player using
            # in team creatures
            teams = {}
            for t, c_sets in GameRule.player.default.get("teams").iteritems():
                # shuffle creatures then player may get multiple creatures
                # from helper pane at begging.
                # --hugo: do not shuffle the team index
                # because client tutorial need index to be fixed.
                # will think about helper in other ways --hugo
                #random.shuffle(c_sets)
                teams[t] = _create_creatures(c_sets)
            CreatureTeam.create(self.id, **teams)
            # normal creatures
            _create_creatures(GameRule.player.default.get("creatures"))

    def add_xp(self, xp):
        def _level_up_xp():
            return GameRule.player.level_up_xp(self.level)

        origin_level = self.level
        self.xp += xp
        level_up_xp = _level_up_xp()
        while self.xp >= level_up_xp:
            self.xp -= level_up_xp
            self.level += 1
            level_up_xp = _level_up_xp()
            event_data = {
                'player': {
                    'session': lct.get("session_id"),
                    'id': self.id
                },
                'level_to':self.level,
            }
            send_event(DeltaLevelUp, event_data, self)
        if origin_level != self.level:
            self.refill_energy()
            details = {"origin_level": origin_level,
                       "new_level": self.level}
            self.update_gems(GameRule.prices.level_up_reward(),
                             TRANS_TYPE.LEVEL_UP, **details)

    def set_info(self, rep, simple_mode=False):
        pid = int(self.id)
        rep.userId = pid
        rep.social_name = self.pip_name
        rep.fb_name = self.fb_name or ""
        rep.xp = self.xp or 0
        rep.level = self.level or 1
        rep.progress = self.progress or 0
        rep.timeZoneOffset = self.utc_offset * 60
        if self.agc_id:
            rep.agc_id = self.agc_id
        if self.gp_id:
            rep.gp_id = self.gp_id
        if self.facebook_id:
            rep.facebook_id = self.facebook_id

        if not simple_mode:
            rep.coins = self.regulate_coins
            rep.gems = self.regulate_gems
            rep.hearts = self.regulate_hearts
            rep.energy = self.regulate_energy
            rep.maxCreatures = self.max_creatures or 40
            rep.energy_countdown = self.get_energy_countdown()
            rep.superCooker = self.super_cooker or False
            rep.pulledGatcha = self.gatcha_pulled or False
            for slug in GameRule.materials.materials():
                count = self.get(slug)
                if count:
                    rep.materialbox.add(slug=slug, count=count)

            creatures = CreatureInstance.get_all_by_player(self.id)
            rep.creaturebox.extend(creatures)
            nuts = Nuts.get_all(self.id)
            rep.nutsbox.extend(nuts)

            CreatureTeam.get_proto_class(self.id, rep.teams)
            self.settings.update_proto(rep.settings)
            passed_dungeons = PassedDungeons(player_id=pid)
            if passed_dungeons.ids:
                for i in passed_dungeons.ids:
                    rep.passed_dungeons.append(i)
        return rep

    def to_proto_class(self, simple_mode=False):
        player_info = PlayerInfo()
        return self.set_info(player_info, simple_mode)

    def delete(self):
        if TEST_MODE:
            self.static.delete()
            self.login.delete()
            self.game.delete()
            self.tz.delete()
            self.settings.delete()
        else:
            raise UnsupportedPlayerAction("Can't delete player instance.")

    def get_help_creature(self):
        """
        Player's active team's 1st creature will be the default help creature.
        If all team is empty, use the first creature of this player.
        """
        teams = CreatureTeam(player_id=self.id)
        active_team = teams.get_active_team()
        creature = None
        for cid in active_team:
            data = {"cid": cid,
                    "player_id": self.id}
            creature = CreatureInstance(**data)
            if creature.exist():
                break
        if creature is None or not creature.exist():
            creatures = CreatureInstance.load_by_attribute("player_id",
                                                           self.id)
            creature = creatures and creatures[0]
        return creature

    def get_active_creatures(self):
        teams = CreatureTeam(player_id=self.id)
        return teams.get_creatures()

    @property
    def energy(self):
        return self.get_energy()

    @energy.setter
    def energy(self, value):
        self.game.energy = value

    @property
    def maxenergy(self):
        return self.get_max_energy()

    @property
    def remainingttoenergy(self):
        return self.get_energy_countdown()

    @property
    def fb_linked(self):
        return True if self.facebook_id else False

    @property
    def nuts(self):
        return len(Nuts.load_oids_by_attribute("player_id", self.id))

    @property
    def creatures(self):
        return len(CreatureInstance.load_oids_by_attribute("player_id",
                                                           self.id))

    def get(self, attr, default=None, match_client=False):
        if match_client and attr in ["coins", "energy", "gems", "hearts"]:
            # return the regulate value if it is try to match client info.
            return getattr(self, "regulate_%s" % attr, default)
        return getattr(self, attr, default)

    # @regulate_XXX -  When VERIFY_PLAYER_STATUS set to True,
    # energy, coins, gems, coins might be minus.
    # But we should send client 0 if it is minus.
    def _regulate(self, val=0):
        val = val or 0
        if val < 0:
            val = 0
        return val

    def _verify_status(self, owned, required, minus_max=0):
        if (VERIFY_PLAYER_STATUS and owned < required) or owned < minus_max:
            return False
        return True

    @property
    def regulate_energy(self):
        return self._regulate(self.get_energy())

    def verify_energy(self, required_v):
        return self._verify_status(self.get_energy(), required_v, ENERGY_MINUS_MAX)

    @property
    def regulate_coins(self):
        return self._regulate(self.coins)

    def verify_coins(self, required_v):
        return self._verify_status(self.coins, required_v, COINS_MINUS_MAX)

    @property
    def regulate_hearts(self):
        return self._regulate(self.hearts)

    def verify_hearts(self, required_v):
        return self._verify_status(self.hearts, required_v, HEART_MINUS_MAX)

    @property
    def regulate_gems(self):
        return self._regulate(self.gems)

    def verify_gems(self, required_v):
        return self._verify_status(self.gems, required_v, GEM_MINUS_MAX)

    def get_max_energy(self):
        return GameRule.player.max_energy(self.level)

    def _energy_update_time(self):
        return self.energy_update_time or int(time())

    def _update_energy_update_time(self, count_down=0):
        self.energy_update_time = int(time()) - count_down

    def refill_energy(self):
        energy = self.get_energy()
        max_energy = self.get_max_energy()
        if energy < max_energy:
            self.energy = max_energy
            self._update_energy_update_time()

    def _update_energy(self, val, do_store=False):
        energy, countdown = self.get_energy(with_countdown=True)
        self.energy = energy + val

        if self.energy < self.get_max_energy():
            # deduction the countdown if not met max energy
            self._update_energy_update_time(countdown)
        else:
            self._update_energy_update_time()
        if do_store:
            self.store()

    def get_energy(self, with_countdown=False):
        energy, countdown = self._get_energy()
        if with_countdown:
            return energy, countdown
        return energy

    def _get_energy(self):
        energy = self.game.energy or 0
        max_energy = self.get_max_energy()
        if energy >= max_energy:
            return energy, 0

        # calculate countdown if not meet max energy
        since_last_update = int(time()) - self._energy_update_time()
        energy_delta = since_last_update / GameRule.player.energy_countdown
        energy += energy_delta
        if energy >= max_energy:
            return max_energy, 0
        countdown = since_last_update % GameRule.player.energy_countdown
        return energy, countdown

    def get_energy_countdown(self):
        """
        Return the countdown time to refill one energy.
        """
        energy, countdown = self.get_energy(with_countdown=True)
        if energy >= self.get_max_energy():
            return 0
        return GameRule.player.energy_countdown - countdown

    def add_energy(self):
        # add max energy each time.
        return self._update_energy(self.get_max_energy())

    def spend_energy(self, val, do_store=False):
        return self._update_energy(-val, do_store=do_store)

    def set_progress(self, p):
        p = self.progress if p < self.progress else p
        old_progress = self.progress
        self.progress = p
        gevent.spawn(self._notify_friend, old_progress)

    def _notify_friend(self, old_progress):
        # check if passed any friends, send pn if need.
        if NOTIFY_WHEN_FRIEND_PASS and old_progress < self.progress:
            from models.friend import FriendAhead
            ahead_fs = FriendAhead(player_id=self.id)
            passed_fs = []
            for f_id in ahead_fs.get_list():
                f = Player(id=f_id)
                if f.progress >= old_progress and f.progress < self.progress:
                    # Add self to friend ahead list
                    f_ahead = FriendAhead(player_id=f_id)
                    f_ahead.add_to_list(self.id)
                    if f.notify_friends_join:
                        # Send pn
                        msg = GameRule.l10n.server(FRIEND_PASS_ME_PN)
                        msg = msg % {"name": self.name}
                        f.send_pn(msg)
                if f.progress < self.progress:
                    # friend to remove from self ahead list
                    passed_fs.append(f_id)
            if passed_fs:
                # remove from self ahead list
                for f_id in passed_fs:
                    ahead_fs.remove_from_list(f_id, do_store=False)
                ahead_fs.store()

    def modify_material(self, slug, val):
        setattr(self, slug, self.get(slug) + val)

    def buy_creature_space(self):
        self.max_creatures += GameRule.player.creature_box_extension

    def get_os_type(self):
        return self.os_type or OSType.Value("IOS")

    def os_type_name(self):
        return OSType.Name(self.get_os_type())

    def get_stats_data(self):
        ret = {}
        ret.update(self.static.get_stats_data())
        ret.update(self.login.get_stats_data())
        ret.update(self.game.get_stats_data())
        ret.pop('login_time', None)
        ret.pop('energy_update_time', None)
        ret.pop('achievements', None)
        ret['energy'] = self.get_energy()
        return ret

    def get_helper_list_size(self):
        # only return 4 helpers for now
        return 4
        # return GameRule.player.helper_limitation(self.level)

    def get_friend_limition(self):
        return GameRule.player.max_friend(self.level)

    def get_social_id(self):
        social_id = self.agc_id
        if self.get_os_type() == OSType.Value("Android"):
            social_id = self.gp_id
        return social_id

    def update_ledger(self, ledger_cls, trans_type, qty, details=None):
        kwargs = {"player_id": self.id,
                  "trans_type": trans_type,
                  "qty": qty,
                  "datetime": datetime.now()}
        if details:
            kwargs["details"] = details
        l = ledger_cls(**kwargs)
        l.store()
        data = {"trans_type": trans_type,
                "trans_value": str(qty),
                "ledger_type": ledger_cls.ledger_type}
        send_event(DeltaLedger, data, self)
        return l

    def update_gems(self, modified_val, trans_type, **kwargs):
        if modified_val:
            self.game.gems += modified_val
            self.game_modified = True
            self.update_ledger(GemsLedger, trans_type, modified_val, kwargs)

    def update_coins(self, modified_val, trans_type, **kwargs):
        if modified_val:
            self.game.coins += modified_val
            self.game_modified = True
            self.update_ledger(CoinsLedger, trans_type, modified_val, kwargs)

    def update_hearts(self, modified_val, trans_type, **kwargs):
        if modified_val:
            self.game.hearts += modified_val
            self.game_modified = True
            self.update_ledger(HeartsLedger, trans_type, modified_val, kwargs)

    def get_event_proto(self, proto=None):
        if proto is None:
            proto = EventsConfigs()
        proto.CopyFrom(GameRule.get_event_proto(self.utc_offset))
        if self.progress < GameRule.gacha_required_progress:
            proto.ClearField('airbattle_events')
            proto.ClearField('dungeon_bonus_events')
            proto.ClearField('upgrade_events')
        for tree in proto.gacha_trees:
            if tree.tree_type == DailyWarnut.tree_type:
                daily_w = DailyWarnut(self.id, self.utc_offset)
                tree.ttl = daily_w.ttl()
            elif tree.tree_type == FreeAkorn.tree_type:
                free_a = FreeAkorn(player_id=self.id)
                tree.ttl = free_a.ttl(tree.ttl)
        return proto


class Session(Base):
    _db_type = MEMCACHED_BUCKET
    _oid_key = "id"
    _index_attributes = ["player_id"]

    id = TextAttr()
    player_id = LongAttr()
    version = TextAttr()

    def __init__(self, **kw):
        if "id" not in kw:
            kw["id"] = self.generate_session()
        super(Session, self).__init__(**kw)

    def generate_session(self):
        return str(uuid.UUID(bytes=M2Crypto.m2.rand_bytes(16)))

    def refresh_session(self):
        ttl = int(time()) + SESSION_TTL_DELTA
        db(self._db_type).touch(Session(id=self.id)._get_key(), ttl)
        db(self._db_type).touch(Session._get_index_key("player_id",
                                                       self.player_id), ttl)
        return


class DeviceLink(Base):
    _oid_key = "device_id"
    _index_attributes = ["player_id"]

    device_id = TextAttr()
    player_id = LongAttr()


class DevicePnToken(Base):
    _oid_key = "device_id"
    device_id = TextAttr()
    pn_token = TextAttr(default="")


class PassedDungeons(Base):
    _oid_key = "player_id"
    # TODO - Design - define dungeon id

    player_id = LongAttr()
    ids = ListAttr(IntAttr())


class PushNotificationToken(Base):
    _oid_key = "pn_token"
    pn_token = TextAttr()
    endpoint_arn = TextAttr()
    player_ids = ListAttr(IntAttr(), default=[])
    endpoint_enabled = BoolAttr(default=False)
    update_product = BoolAttr(default=False)

    event_dungeon_boss_arn = TextAttr()
    event_weekday_arn = TextAttr()
    event_special_gatcha_arn = TextAttr()

    # different utc_offset event have different pn topic
    utc_offset = IntAttr(default=DEFAULT_UTC_OFFSET)
    _utc_offset = DEFAULT_UTC_OFFSET
    _removing_player = False

    def __init__(self, **kw):
        super(PushNotificationToken, self).__init__(**kw)
        self._utc_offset = kw.get("new_utc_offset", DEFAULT_UTC_OFFSET)
        self._settings = kw.get("settings")

    def add_player(self, player_id):
        if self.player_ids and player_id not in self.player_ids:
            self.player_ids.append(player_id)
        elif not self.player_ids:
            self.player_ids = [player_id]
        self.store()

    def remove_player(self, player_id):
        if self.player_ids and player_id in self.player_ids:
            self.player_ids.remove(player_id)

        if self.player_ids:
            self._removing_player = True
            self.store()
        else:
            self.delete()

    def send_msg(self, msg, badge=None, **custom_data):
        if self.exist():
            self._refresh_live_pn(update=True)
        # only send msg if the pn token exist and ep_arn created.
        if self.exist() and self.endpoint_arn and self.endpoint_enabled:
            msg = {"action": SNS_ACTION.SEND_TO_ENDPOINT,
                   "data": {"ep_arn": self.endpoint_arn,
                            "msg": msg,
                            "pn_token": self.pn_token,
                            "badge": badge,
                            "custom_data": custom_data}}
            pn_actor().tell(msg)

    def _subscribe(self, event_name):
        topic = get_event_pn_topic(event_name, self.utc_offset)
        msg = {"action": SNS_ACTION.SUBSCRIBE,
               "data": {"t_arn": topic,
                        "ep_arn": self.endpoint_arn}}
        return pn_actor().ask(msg)

    def _subscribe_endpoints(self):
        if self.pn_token and self.endpoint_arn and self._settings:
            if self.utc_offset != self._utc_offset:
                # utc offset updated, remove from old topic and add to new one.
                self._unsubscribe_endpoints()
                self.utc_offset = self._utc_offset
            # event_boss
            if (self._settings.notify_event_dungeon_boss and
                    not self.event_dungeon_boss_arn):
                self.event_dungeon_boss_arn = self._subscribe(
                    EVENTS_BOSS["key"])
            elif (not self._settings.notify_event_dungeon_boss and
                  self.event_dungeon_boss_arn):
                self._unsubscribe(self.event_dungeon_boss_arn)
                self.event_dungeon_boss_arn = ""
            # event_weekday
            if (self._settings.notify_event_weekday and
                    not self.event_weekday_arn):
                self.event_weekday_arn = self._subscribe(
                    EventsType.EVENTS_WEEKDAY)
            elif (not self._settings.notify_event_weekday and
                  self.event_weekday_arn):
                self._unsubscribe(self.event_weekday_arn)
                self.event_weekday_arn = ""

            # event_special_gatcha TODO: NO configs from client, force to send for now
            if not self.event_special_gatcha_arn:
                self.event_special_gatcha_arn = self._subscribe(
                    EventsType.SPECIAL_GATCHA)

    def _unsubscribe(self, arn):
        msg = {"action": SNS_ACTION.UNSUBSCRIBE,
               "data": {"arn": arn}}
        pn_actor().tell(msg)

    def _unsubscribe_endpoints(self):
        if self.event_dungeon_boss_arn:
            self._unsubscribe(self.event_dungeon_boss_arn)
            self.event_dungeon_boss_arn = ""
        if self.event_weekday_arn:
            self._unsubscribe(self.event_weekday_arn)
            self.event_weekday_arn = ""

    def _clear_endpoint(self):
        self._unsubscribe_endpoints()
        if self.endpoint_arn:
            msg = {"action": SNS_ACTION.DELETE_ENDPOINT,
                   "data": {"ep_arn": self.endpoint_arn}}
            pn_actor().tell(msg)
            self.endpoint_arn = ""

    def delete(self):
        self._clear_endpoint()
        super(PushNotificationToken, self).delete()

    def _refresh_live_pn(self, update=False):
        refresh = (IS_PRODUCTION or True and not self.update_product and
                   self.endpoint_arn)
        self.update_product = True
        if refresh:
            self._clear_endpoint()
            if update:
                self._create_ep()
                self._subscribe_endpoints()
                super(PushNotificationToken, self).store()

    def _create_ep(self):
        if self.pn_token and not self.endpoint_arn:
            msg = {"action": SNS_ACTION.CREATE_ENDPOINT,
                   "data": {"pn_token": self.pn_token}}
            ep_arn = pn_actor().ask(msg)
            if ep_arn:
                self.endpoint_arn = ep_arn

    def store(self):
        self._refresh_live_pn()
        self._create_ep()
        # enable endpoint
        if (self.endpoint_arn and not self._removing_player and
                not self.endpoint_enabled):
            msg = {"action": SNS_ACTION.ENABLE_ENDPOINT,
                   "data": {"ep_arn": self.endpoint_arn}}
            pn_actor().tell(msg)
            self.endpoint_enabled = True
        self._subscribe_endpoints()
        super(PushNotificationToken, self).store()

    def disable_endpoint(self):
        self.endpoint_enabled = False
        super(PushNotificationToken, self).store()


class RecentlyHelper(object):
    """
    Cache all recently used helpers - multiple records.
    """
    def __init__(self, player_id, helper_id):
        self.player_id = player_id
        self.helper_id = helper_id

    @property
    def key(self):
        key = "RecentlyHelper:%s-%s" % (self.player_id, self.helper_id)
        return KeyValue(key, MEMCACHED_BUCKET)

    def exist(self):
        return self.key.exist()

    def store(self, ttl=0):
        if ttl:
            self.key.store("", ttl=ttl)


class CurrentHelper(KeyValue):
    """
    Cache the last helper been used - one record at most.
    """
    def __init__(self, player_id):
        key = 'LastHelper:%s' % player_id
        super(CurrentHelper, self).__init__(key, db_type=MEMCACHED_BUCKET)

    def store(self, helper_id, **kwargs):
        return super(CurrentHelper, self).store(helper_id, ttl=CACHE_HELPER_TTL)


class ThankHelper(object):
    _db_type = MEMCACHED_BUCKET
    _player = None

    def __init__(self, player_id, helper_id, player=None):
        self.player_id = player_id
        self.helper_id = helper_id
        self._player = player

    @property
    def player(self):
        if self._player is None:
            self._player = Player(id=self.player_id)
        return self._player

    def cache_send_helper(self):
        return self.player.progress >= VERIFY_SEND_TANK_HELPER_PROGRESS

    def same_helper(self):
        return KeyValue("PLAYER_%s_THANK_%s" %
                        (self.player_id, self.helper_id), self._db_type)

    def send_thank(self):
        return KeyValue("SEND_HELPER_%s" % self.player_id, self._db_type)

    def store(self):
        self.same_helper().store("", ttl=THANK_SAME_HELPER_TTL)
        if self.cache_send_helper():
            self.send_thank().store("", ttl=SEND_THANK_HELPER_TTL)

    def thank_able(self):
        if self.same_helper().exist():
            return False
        if self.cache_send_helper():
            return not self.send_thank().exist()
        return True


class GatchaCounter(object):

    def __init__(self, player_id, tree_slug):
        self.player_id = str(player_id)
        self.tree_slug = tree_slug

    @property
    def key(self):
        key = "GatchaCounter:%s-%s" % (self.player_id, self.tree_slug)
        return KeyValue(key)

    def exist(self):
        return self.key.exist()

    def get_key(self, preload=False):
        counter = self.key.load() or 0
        rand_key = string_to_int(str(self.tree_slug)+self.player_id+str(counter))
        if not preload:
            counter += 1
            self.key.store(counter)
        return rand_key


class FacebookRegister(Base):
    facebook_id = TextAttr(default="")
    _oid_key = "facebook_id"
