import time
from datetime import date, timedelta
from dal.base import *
from models.player import Player
from models.content import GameRule
from models.creature import CreatureInstance
from models.creature import Nuts
from utils.constants import TRANS_TYPE
from utils.protocol_pb2 import EggType, GiftType
from utils.protocol_pb2 import NotificationIDs
from utils.l10n_keys import DAILY_SOCIAL_PN
from utils.l10n_keys import THANKS_HELPER_PN
from utils.l10n_keys import RECRUIT_FB_PN
from utils.l10n_keys import RECRUIT_FB_DAILY_PN
from utils.l10n_keys import GIFT_MSG_THANKS_HELPER
from utils.l10n_keys import GIFT_MSG_DAILY_SOCIAL
from utils.l10n_keys import GIFT_MSG_RECRUIT_FB
from utils.l10n_keys import GIFT_MSG_RECRUIT_FB_DAILY
from utils.l10n_keys import GIFT_MSG_CONNECT_FB
from utils.l10n_keys import GIFT_MSG_ENABLE_PN
from utils.l10n_keys import GIFT_MSG_DAILY_SOCIAL_TO_SEND
from utils.l10n_keys import GIFT_MSG_RECRUIT_FB_TO_SEND
from utils.l10n_keys import GIFT_MSG_RECRUIT_FB_DAILY_AD
from utils.l10n_keys import GIFT_MSG_ADMIN_MSG
from utils.l10n_keys import GIFT_MSG_CONNECT_FB_TO_SEND
from utils.settings import AKORN_TREE_SLUG
from utils.settings import RECRUIT_FB_DAILY_PN_DELAY
from utils.settings import SHARE_AKORNS_TTL
from utils.settings import default_amdin_msg
from utils.log import log


FAERIE_EGG = EggType.Value('FAERIE_EGG')
GEM_EGG = EggType.Value("GEM_EGG")
SELF_EGG = EggType.Value('SELF_EGG')
NUT_EGG = EggType.Value('NUT_EGG')

THANKS_HELPER = GiftType.Value('THANKS_HELPER')
DAILY_SOCIAL = GiftType.Value('DAILY_SOCIAL')
RECRUIT_FB = GiftType.Value('RECRUIT_FB')
RECRUIT_FB_DAILY = GiftType.Value('RECRUIT_FB_DAILY')
CONNECT_FB = GiftType.Value('CONNECT_FB')
ENABLE_PN = GiftType.Value('ENABLE_PN')
DAILY_SOCIAL_TO_SEND = GiftType.Value('DAILY_SOCIAL_TO_SEND')
RECRUIT_FB_TO_SEND = GiftType.Value('RECRUIT_FB_TO_SEND')
RECRUIT_FB_DAILY_AD = GiftType.Value('RECRUIT_FB_DAILY_AD')
CONNECT_FB_TO_SEND = GiftType.Value('CONNECT_FB_TO_SEND')
ADMIN_MSG = GiftType.Value('ADMIN_MSG')

DEFAULT_PN_ID = NotificationIDs.Value("PNID_GIFT_DEFAULT")
pn_id_map = dict(NotificationIDs.items())
pn_map = {
    DAILY_SOCIAL: DAILY_SOCIAL_PN,
    THANKS_HELPER: THANKS_HELPER_PN,
    RECRUIT_FB: RECRUIT_FB_PN,
    RECRUIT_FB_DAILY: RECRUIT_FB_DAILY_PN,
}
pn_delay_map = {
    RECRUIT_FB_DAILY: RECRUIT_FB_DAILY_PN_DELAY,
}
trans_map = {
    CONNECT_FB: TRANS_TYPE.FACEBOOK_CONNECT,
    THANKS_HELPER: TRANS_TYPE.THANKS_GIFT,
    ENABLE_PN: TRANS_TYPE.ENABLE_PUSH_NOTIFICATION,
    ADMIN_MSG: TRANS_TYPE.SUPPORT,
}

init_gifts = {
    CONNECT_FB_TO_SEND: {"egg_type": GEM_EGG,
                         "gift_value": GameRule.viral.facebook_connect_gem},
    ENABLE_PN: {"egg_type": GEM_EGG,
                "gift_value": GameRule.viral.enable_pn_gem},
}


def build_gift_msg(g_type, sender=None, c_slug=None, msg=None, who=None, what=None):

    #TODO: deal with the unicode
    if g_type == THANKS_HELPER:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_THANKS_HELPER) % {'who': name or ' '}

    elif g_type == DAILY_SOCIAL:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_DAILY_SOCIAL) % {'who': name or ' '}

    elif g_type == RECRUIT_FB:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_RECRUIT_FB) % {'who': name or ' '}

    elif g_type == RECRUIT_FB_DAILY:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_RECRUIT_FB_DAILY) % {'who': name or ' '}

    elif g_type == CONNECT_FB:
        return GameRule.l10n.custom(GIFT_MSG_CONNECT_FB)

    elif g_type == DAILY_SOCIAL_TO_SEND:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_DAILY_SOCIAL_TO_SEND) % {'who': name or ' '}

    elif g_type == RECRUIT_FB_TO_SEND:
        name = who or Player(id=sender).name
        return GameRule.l10n.custom(GIFT_MSG_RECRUIT_FB_TO_SEND) % {'who': name or ' '}

    elif g_type == RECRUIT_FB_DAILY_AD:
        return GameRule.l10n.custom(GIFT_MSG_RECRUIT_FB_DAILY_AD)

    elif g_type == ENABLE_PN:
        return GameRule.l10n.custom(GIFT_MSG_ENABLE_PN)

    elif g_type == CONNECT_FB_TO_SEND:
        return GameRule.l10n.custom(GIFT_MSG_CONNECT_FB_TO_SEND)

    elif g_type == ADMIN_MSG:
        return GameRule.l10n.custom(GIFT_MSG_ADMIN_MSG) % {'what': msg or ' '}

    else:
        return ''

# Notice: don't forget to update parse_player_id if generate_gift_id modified.
def generate_gift_id(player_id):
    id_count = KeyValue('GiftId:%s' % player_id)
    return '%s_%s' % (player_id, id_count.incr(1, initial=1))


def parse_player_id(gift_id):
    return gift_id.split("_")[0]


class Gift(Base):
    _oid_key = "g_id"
    g_id = TextAttr()
    sender = IntAttr()
    e_t = IntAttr()  # egg_type
    e_v = TextAttr()  # egg_value
    g_type = IntAttr()
    c_id = IntAttr()  # creature id if it's a creature
    message = TextAttr(default=default_amdin_msg)  # for gift from admin portal

    def could_open(self, player):
        if self.g_type == CONNECT_FB and not player.facebook_id:
            return False
        return True

    def is_valid(self):
        if self.exist() and self.g_type:
            return True
        log.warn("Got invalid gift info %s" % self._data)
        return False

    def get_proto(self, proto):
        proto.id = self.g_id
        proto.type = self.g_type
        proto.message = build_gift_msg(self.g_type, sender=self.sender,
                                       c_slug=self.e_v, msg=self.message)
        if self.e_t:
            proto.egg.type = self.e_t
            if self.e_t == GEM_EGG:
                proto.egg.gems = int(self.e_v)
            if self.e_t == NUT_EGG:
                n = Nuts(player_id=parse_player_id(self.g_id),
                         cid=self.c_id, nut=self.e_v)
                n.to_proto_class(proto.egg)
            elif self.e_t in [SELF_EGG, FAERIE_EGG]:
                if self.g_type == DAILY_SOCIAL:
                    proto.egg.type = NUT_EGG
                    proto.egg.nut = AKORN_TREE_SLUG
                c = CreatureInstance(player_id=parse_player_id(self.g_id),
                                     cid=self.c_id, slug=self.e_v)
                c.to_proto_class(proto.egg.creature)
            else:
                # TODO - we only have creature & gems as gift currently.
                pass
        return proto


class GiftInbox(Base):
    _oid_key = "player_id"
    player_id = LongAttr()
    gifts = ListAttr(TextAttr(), default=[])

    def __init__(self, **kw):
        super(GiftInbox, self).__init__(**kw)
        if kw.get('is_new', False):
            for g_type, g_conf in init_gifts.iteritems():
                self._init_gift(g_type, **g_conf)

    def _init_gift(self, g_type, egg_type=None, gift_value=None):
        self.give_gift(g_type, self.player_id, egg_type, gift_value)

    def _send_pn(self, gift_type, gift, pn_msg=None):
        def _gen_msg():
            param = {"creature": GameRule.l10n.creature_name(gift.e_v)}
            if gift_type != RECRUIT_FB_DAILY:
                sender = Player(id=gift.sender)
                param["sender"] = sender.name
                if gift_type == THANKS_HELPER:
                    h_slug = p.get_help_creature().slug
                    param["creature"] = GameRule.l10n.creature_name(h_slug)
            return GameRule.l10n.server(pn_map.get(gift_type)) % param

        p = Player(id=self.player_id)
        if p.notify_get_gift:
            msg = pn_msg or _gen_msg()
            delay = pn_delay_map.get(gift_type, 0)
            key = "PNID_GIFT_%s" % GiftType.Name(gift_type)
            pn_id = pn_id_map.get(key) or DEFAULT_PN_ID
            p.send_pn(msg, delay, badge=len(self.gifts), id=str(pn_id))

    def get_player_gift_list(self, p_proto, fb_connect=False):
        need_update = False
        if self.gifts:
            for g_id in self.gifts:
                g = Gift(g_id=g_id)
                if not g.is_valid():
                    self.gifts.remove(g_id)
                    need_update = True
                    continue
                if g.g_type == CONNECT_FB_TO_SEND and fb_connect:
                    g.g_type = CONNECT_FB
                    g.store()
                p_info = p_proto.add()
                p = Player(id=g.sender)
                g.get_proto(p_info.gift)
                if g.g_type != CONNECT_FB:
                    p.set_info(p_info, simple_mode=True)
        if need_update:
            self.store()

    def get_gifts(self):
        gifts = []
        for g_id in self.gifts:
            g = Gift(g_id=g_id)
            gifts.append(g)
        return gifts

    def give_gift(self, gift_type, sender_id=None, egg_type=None,
                  gift_value=None, message=None, pn_msg=None):
        g_id = generate_gift_id(self.player_id)
        g = Gift(g_id=g_id)
        g.sender = sender_id or self.player_id
        g.g_type = gift_type
        if egg_type:
            g.e_t = int(egg_type)
        if gift_value:
            g.e_v = gift_value
        if message:
            g.message = message
        if g.e_t in [SELF_EGG, FAERIE_EGG, NUT_EGG]:
            g.c_id = Nuts.get_id(self.player_id)
        if not self.gifts:
            self.gifts = []
        self.gifts.append(g_id)
        # create gift first then add the g_id to gifts
        with db(self._db_type).pipeline():
            g.store()
            self.store()
        if pn_msg or gift_type in pn_map:
            self._send_pn(gift_type, g, pn_msg)

        event_data = {'receiver': self.player_id,
                      'gift_id': g.g_id,
                      'gift_type': g.g_type,
                      'egg_type': g.e_t,
                      'egg_value': str(g.e_v),
                      'cid': g.c_id
                     }
        return event_data

    def open_gift(self, player, g_id):
        msg = ""
        if g_id not in self.gifts:
            msg = "Invalid gift id(%s), all gift %s" % (g_id, self.gifts)
            return False, None, msg
        g = Gift(g_id=g_id)
        if not g.could_open(player):
            msg = "Not connect to facebook."
            return False, None, msg
        event_data = {'sender_id': g.sender,
                      'gift_id': g.g_id,
                      'gift_type': g.g_type,
                      'egg_type': g.e_t,
                      'egg_value': str(g.e_v),
                      'cid': g.c_id
                     }
        if g.e_t in (FAERIE_EGG, SELF_EGG):
            c_slug = g.e_v
            params = {"cid": g.c_id}
            if g.g_type == DAILY_SOCIAL:
                params["nut"] = AKORN_TREE_SLUG
            else:
                params["auto_open"] = True
            Nuts.create(self.player_id, c_slug, **params)
        elif g.e_t == NUT_EGG:
            Nuts.generate(self.player_id, g.e_v, cid=g.c_id)
        elif g.e_t == GEM_EGG:
            details = {"sender_id": g.sender,
                       "gift_type": g.g_type}
            t_type = trans_map.get(g.g_type)
            if t_type is None:
                log.err("Missing trans type for %s" % g.g_type)
            player.update_gems(int(g.e_v), t_type, **details)
            player.store()
        elif g.e_t:
            msg = "Invalid gift type %s" % g.e_t
            return False, None, msg
        self.gifts.remove(g_id)
        # delete g_id from gifts first then delete the gift itself.
        with db(self._db_type).pipeline():
            self.store()
            g.delete()
        return True, event_data, msg


class GiftOutbox(Base):
    _oid_key = "player_id"
    player_id = IntAttr()
    gift = TextAttr()
    friends = ListAttr(IntAttr())  # friend ids that haven't send gift.
    sent_ids = ListAttr(IntAttr())
    update_timestamp = IntAttr()

    def need_refresh(self):
        now = int(time.time())
        if (not self.update_timestamp or
                now - self.update_timestamp > SHARE_AKORNS_TTL):
            self.update_timestamp = now
            return True, now + SHARE_AKORNS_TTL
        else:
            return False, self.update_timestamp + SHARE_AKORNS_TTL

    def refresh(self, player, friends):
        fb_id_map = {}
        for f in friends:
            if f.facebook_id == player.facebook_id:
                continue
            d = fb_id_map.get(f.facebook_id, f)
            if f.progress > d.progress:
                d = f
            fb_id_map[f.facebook_id] = d
        f_ids = [f.id for f in fb_id_map.values()]
        need_store, next_timestamp = self.need_refresh()
        if need_store:
            self.friends = f_ids
            self.sent_ids = []
            self.gift = GameRule.viral.get_an_akorn_gift()
        else:
            new_friends = list(set(f_ids) - set(self.sent_ids))
            if new_friends != self.friends:
                self.friends = new_friends
                need_store = True
        if need_store:
            self.store()

        return next_timestamp

    def get_box_proto(self, player, friends, resp):
        resp.refresh_timestamp = self.refresh(player, friends)
        for friend_id in self.friends:
            p_info = resp.friends.add()
            p = Player(id=friend_id)
            p.set_info(p_info, simple_mode=True)
            p_info.gift.egg.type = FAERIE_EGG
            p_info.gift.egg.creature.slug = self.gift
            p_info.gift.message = build_gift_msg(g_type=DAILY_SOCIAL_TO_SEND,
                                                 sender=p.id, c_slug=self.gift)
        return resp

    def set_sent(self,friend_id):
        if friend_id not in self.friends:
            return False
        self.friends.remove(friend_id)
        self.sent_ids.append(friend_id)
        self.store()
        return True
