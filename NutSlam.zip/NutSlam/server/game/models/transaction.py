from dal.base import *


trans_id_count = KeyValue("purchase_trans_id_count")
TRANS_STATUS = {"STARTED": 1,
                "PURCHASED": 2,
                "UNPAID": 3,
                "FAILED": 4,  # Third party rejected.
                "PURCHASED_PENDING": 5,  # Pay gems while third party busy.
                }
TRANS_STATUS_REV = {}
for key, val in TRANS_STATUS.iteritems():
    TRANS_STATUS_REV[val] = key


class PurchaseTransaction(Base):
    tid = LongAttr()
    sk_trans_id = TextAttr()
    receipt = TextAttr()
    order_id = TextAttr()
    player_id = IntAttr()
    status = IntAttr()
    trans_type = TextAttr()
    product_id = TextAttr()
    start_time = DateTimeAttr()
    handle_time = DateTimeAttr()
    _oid_key = "tid"
    _index_attributes = ["player_id", "sk_trans_id", "order_id"]

    def __init__(self, **kwargs):
        if not kwargs.get("tid"):
            kwargs["tid"] = trans_id_count.incr(1, initial=1)
        super(PurchaseTransaction, self).__init__(**kwargs)


class PendingTransaction(Base):
    player_id = IntAttr()
    sk_trans_id = TextAttr()
    receipt = TextAttr()
    product_id = TextAttr()
    price = FloatAttr()
    currency = TextAttr()
    datetime = DateTimeAttr()
    checked = BoolAttr()
    verify_status = BoolAttr()  # True - been verifying, False - empty.
    _oid_key = "player_id"
    _index_attributes = ["checked", "verify_status"]

    def get_status_data(self):
        return self._data
