import random
from dal.base import *
from models.player import Player
from models.player import RecentlyHelper
from models.player import ThankHelper
from models.active_player import ActivePlayerHelper
from models.creature import CreatureInstance
from models.content import GameRule
from utils.constants import TRANS_TYPE
from utils.exception import UnsupportedFriendAction
from utils.protocol_pb2 import Helper
from utils.protocol_pb2 import ModifyFriendResultCode
from utils.protocol_pb2 import OSType
from utils.settings import IS_PRODUCTION
from utils.settings import FB_SAMPLE_ID
from utils.settings import MEMCACHED_BUCKET

class FriendBase(Base):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])
    _player = None

    def get_list(self, disorder=False, filter_out=None):
        if not self.player_list:
            self.player_list = []
        p_list = self.player_list
        if filter_out:
            p_list = list(set(p_list) - set(filter_out))
        if disorder and p_list:
            random.shuffle(p_list)
        return p_list

    def in_list(self, player_id):
        return player_id in self.get_list()

    def add_to_list(self, player_id, do_store=True):
        if player_id not in self.get_list():
            self.player_list.append(player_id)
            if do_store:
                self.store()

    def remove_from_list(self, player_id, do_store=True):
        if player_id in self.get_list():
            self.player_list.remove(player_id)
            if do_store:
                self.store()

    def generate_proto(self, player_id):
        player = Player(id=player_id)
        return player.to_proto_class(simple_mode=True)

    def to_proto_list(self):
        return [self.generate_proto(p_id) for p_id in self.get_list()]

    @property
    def player(self):
        if self._player is None:
            self._player = Player(id=self.player_id)
        return self._player


class FriendList(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])
    _favorite_list = None

    def get_favorite_list(self):
        if self._favorite_list is None:
            favorite_l = FavoriteList(player_id=self.player_id)
            self._favorite_list = favorite_l.get_list()
        return self._favorite_list

    def generate_proto(self, player_id):
        friend = 0
        return friend

    def meet_limitation(self):
        return len(self.get_list()) >= self.player.get_friend_limition()

    def add_to_list(self, player_id):
        super(FriendList, self).add_to_list(player_id)

        # add social currency.
        reward_hearts = GameRule.helper.add_friend_reward()[0]
        details = {"friend_id": player_id}
        self.player.update_hearts(reward_hearts, TRANS_TYPE.ADD_IN_GAME_FRIEND,
                                  **details)
        self.player.store()


class FavoriteList(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])

    def to_proto_class(self):
        raise UnsupportedFriendAction("FavoriteList to protocol")


class SendPendingList(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])


class ReceivePendingList(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])


class SocialFriendList(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])
    _pn_msg = "Good news! %s just joined Nut Slam too!"

    @property
    def social_name(self):
        raise NotImplementedError

    def update_get(self, social_ids):
        p_list = []
        for s_id in social_ids:
            p_ids = Player.load_oids_by_attribute(self.social_name, s_id)
            if p_ids:
                p_list += p_ids
        orig_list = set(self.get_list())
        p_list = set(p_list)
        if self.player_id in p_list:
            p_list.remove(self.player_id)
        if orig_list != p_list:
            new_ahead_f = []
            for f_id in p_list - orig_list:
                f_social = self.__class__(player_id=f_id)
                f = Player(id=f_id)
                if not f_social.in_list(self.player_id):
                    # add player to social friend's list.
                    f_social.add_to_list(self.player_id)
                    if f.notify_friends_join:
                        f.send_pn(self._pn_msg % self.player.name)

                if f.progress <= self.player.progress:
                    # add player to friend's ahead list
                    f_ahead = FriendAhead(player_id=f_id)
                    f_ahead.add_to_list(self.player_id)
                if f.progress >= self.player.progress:
                    new_ahead_f.append(f_id)
            if new_ahead_f:
                # update player's ahead friend
                p_ahead = FriendAhead(player_id=self.player_id)
                for f_id in new_ahead_f:
                    p_ahead.add_to_list(f_id, do_store=False)
                p_ahead.store()

            self.player_list = list(p_list)
            self.store()
        return self.get_list()


class FacebookFriendsList(SocialFriendList):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])
    _pn_msg = "Good news! %s just joined Nut Slam too!"

    @property
    def social_name(self):
        return "facebook_id"

    def get_list(self, *args, **kwargs):
        _list = super(FacebookFriendsList, self).get_list(*args, **kwargs)
        if IS_PRODUCTION:
            return _list
        return _list or Player.load_oids_by_attribute("facebook_id",
                                                      FB_SAMPLE_ID)


class AGCFriendsList(SocialFriendList):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])
    _pn_msg = "%s just joined Nut Slam from Apple Game Center."

    @property
    def social_name(self):
        return "agc_id"


class GPFriendsList(SocialFriendList):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])

    @property
    def social_name(self):
        return "gp_id"


class FriendAhead(FriendBase):
    _oid_key = "player_id"
    player_id = LongAttr()
    player_list = ListAttr(LongAttr(), default=[])

    def all_friends(self):
        fb_friend = FacebookFriendsList(player_id=self.player_id)
        agc_friend = AGCFriendsList(player_id=self.player_id)
        gp_friend = GPFriendsList(player_id=self.player_id)
        f_ids = (fb_friend.get_list() + agc_friend.get_list()
                 + gp_friend.get_list())
        return list(set(f_ids) - set([self.player_id]))

    def get_list(self, *args, **kwargs):
        if not self.exist():
            self.player_list = self.all_friends()
            self.store()
        return self.player_list


class Friend(object):
    player_id = None
    _friend_list = None
    _send_list = None
    _receive_list = None
    _favorite_list = None
    friend_id = None
    _other_friend_list = None
    _other_send_list = None
    _other_receive_list = None
    _other_favorite_list = None
    _player = None

    def __init__(self, player_id):
        super(Friend, self).__init__()
        self.player_id = player_id

    @property
    def player(self):
        if self._player is None:
            self._player = Player(id=self.player_id)
        return self._player

    @property
    def friend_list(self):
        if self._friend_list is None:
            self._friend_list = FriendList(player_id=self.player_id)
        return self._friend_list

    @property
    def send_list(self):
        if self._send_list is None:
            self._send_list = SendPendingList(player_id=self.player_id)
        return self._send_list

    @property
    def receive_list(self):
        if self._receive_list is None:
            self._receive_list = ReceivePendingList(player_id=self.player_id)
        return self._receive_list

    @property
    def favorite_list(self):
        if self._favorite_list is None:
            self._favorite_list = FavoriteList(player_id=self.player_id)
        return self._favorite_list

    @property
    def other_friend_list(self):
        if self._other_friend_list is None:
            self._other_friend_list = FriendList(player_id=self.friend_id)
        return self._other_friend_list

    @property
    def other_send_list(self):
        if self._other_send_list is None:
            self._other_send_list = SendPendingList(player_id=self.friend_id)
        return self._other_send_list

    @property
    def other_receive_list(self):
        if self._other_receive_list is None:
            self._other_receive_list = ReceivePendingList(
                player_id=self.friend_id)
        return self._other_receive_list

    @property
    def other_favorite_list(self):
        if self._other_favorite_list is None:
            self._other_favorite_list = FavoriteList(player_id=self.friend_id)
        return self._other_favorite_list

    def init_other_list(self, friend_id):
        self.friend_id = friend_id

    def check_limit(self):
        # check if the self already reach the max friend number
        if self.friend_list.meet_limitation():
            return ModifyFriendResultCode.Value("SELF_REACH_LIMIT")
        # check if the opponent already reach the max friend number
        if self.other_friend_list.meet_limitation():
            return ModifyFriendResultCode.Value("OPP_REACH_LIMIT")
        return None

    def add_friend(self, friend_id):
        self.init_other_list(friend_id)
        # check if player already have this friend
        if self.friend_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("FRIEND_FRIEND")
        if self.receive_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("FRIEND_RECEIVING")
        # check if reach the limits
        code = self.check_limit()
        if code: return code
        # add player to friend's receive pending list
        self.other_receive_list.add_to_list(self.player_id)
        # add friend to player's send pending list
        if self.send_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("FRIEND_SENDING")
        else:
            self.send_list.add_to_list(friend_id)
            return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def accept_friend(self, friend_id):
        self.init_other_list(friend_id)
        if not self.receive_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("ACCEPT_NOT_RECEIVING")

        # check if reach the limits
        code = self.check_limit()
        if code: return code
        # remove from other's send pending
        self.other_send_list.remove_from_list(self.player_id)
        # add friend to each other's friend list
        self.friend_list.add_to_list(friend_id)
        self.other_friend_list.add_to_list(self.player_id)
        # remove from receive pending
        self.receive_list.remove_from_list(friend_id)
        return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def ignore_friend(self, friend_id):
        self.init_other_list(friend_id)
        # remove from other's send pending list
        self.other_send_list.remove_from_list(self.player_id)
        # remove from player's receive pending list
        if not self.receive_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("IGNORE_NOT_RECEIVING")
        else:
            self.receive_list.remove_from_list(friend_id)
            return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def remove_friend(self, friend_id):
        self.init_other_list(friend_id)
        if not self.friend_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("REMOVE_STRANGER")
        # remove from each other's favorite & friend list
        self.favorite_list.remove_from_list(friend_id)
        self.friend_list.remove_from_list(friend_id)
        self.other_favorite_list.remove_from_list(self.player_id)
        self.other_friend_list.remove_from_list(self.player_id)
        return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def mark_favorite(self, friend_id):
        if not self.friend_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("FAVORITE_STRANGER")
        if self.favorite_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("FAVORITE_FAVORITE")
        self.favorite_list.add_to_list(friend_id)
        return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def unmark_favorite(self, friend_id):
        if not self.favorite_list.in_list(friend_id):
            return ModifyFriendResultCode.Value("UNFAVORITE_NOT_FAVORITE")
        self.favorite_list.remove_from_list(friend_id)
        return ModifyFriendResultCode.Value("MODIFY_SUCCESS")

    def get_facebook_list(self):
        fb = FacebookFriendsList(player_id=self.player_id)
        return fb.get_list(disorder=True)

    def get_os_friend_list(self, os_type=None):
        if os_type is None:
            os_type = self.player.get_os_type()
        if os_type == OSType.Value("Android"):
            return GPFriendsList(player_id=self.player_id).get_list()
        else:
            return AGCFriendsList(player_id=self.player_id).get_list()

    def _helper_thank_able(self, helper):
        thx_helper = ThankHelper(self.player_id, helper.id, self.player)
        return helper.facebook_id and thx_helper.thank_able() or False

    def select_friends(self, creature_slugs, friends, limit):
        helpers = []
        fids = []
        count = 0
        raw_len = len(friends)
        for i in range(raw_len):
            fid = friends[i]
            hearts = self._get_helper_hearts(fid)
            if (hearts > 0 or i == raw_len - 1) and count < limit:
                count += 1
                fids.append(fid)

                h = Helper()
                h.reward_hearts = hearts
                helper = Player(id=fid)
                helper.set_info(h.player_info, simple_mode=True)
                helper_creature = helper.get_help_creature()
                if helper_creature:
                    helper_creature.to_proto_class(h.creature)
                    helpers.append(h)
                    creature_slugs.append(helper_creature.slug)

                h.thankable = self._helper_thank_able(helper)

        return fids, sorted(helpers, self.helper_sort_cmp)

    def select_strangers(self, stranger_num, helper_num, helper_ids, creature_slugs):
        helpers = []
        a = ActivePlayerHelper()
        active_players, active_creatures = a.get_by_level(
            self.player.level, stranger_num, helper_ids + [self.player_id])

        active_players = list(active_players)
        count = len(active_players)
        for pid in active_players:
            if count <= stranger_num:
                break
            recently = RecentlyHelper(self.player_id, pid)
            if recently.exist() or active_creatures[pid][1] in creature_slugs:
                active_players.remove(pid)
                del active_creatures[pid]
            count -= 1

        for pid in active_players[:helper_num-len(helpers)]:
            h = Helper()
            h.reward_hearts = self._get_helper_hearts(pid)
            stranger = Player(id=pid)
            stranger.set_info(h.player_info, simple_mode=True)
            h.thankable = self._helper_thank_able(stranger)
            helper_creature = CreatureInstance(player_id=pid,
                                               cid=active_creatures[pid][0])
            if not helper_creature.slug:
                a.update(stranger)
                helper_creature = self.player.get_help_creature()
            if helper_creature:
                helper_creature.to_proto_class(h.creature)
                helpers.append(h)
        return sorted(helpers, self.helper_sort_cmp)

    def helper_sort_cmp(self, x, y):
        x_star = GameRule.creature_types.get(x.creature.slug).starRating
        y_star = GameRule.creature_types.get(y.creature.slug).starRating
        return y_star - x_star

    def get_helpers(self):
        """
        Note: fb_friend, in_game_friend, activate_players may have different
              weight.
              Bigger weight takes more chance been chose as helper.
        e.g.:
            facebook_friend have weight 2, activate_players have weight: 1
            facebook_friend will get double chance to been a helper.
        """

        # 1. get helper num
        # 2. get facebook helpers
        # 3. get os helpers
        # 4. fill in will strangers

        player = self.player
        creature_slugs = []
        helpers = []
        helper_ids = []
        helper_num = player.get_helper_list_size()

        fb_friends = self.get_facebook_list()
        fb_num = GameRule.helper.facebook_number(helper_num, len(fb_friends))
        ids, players = self.select_friends(creature_slugs, fb_friends, fb_num)
        helper_ids.extend(ids)
        helpers.extend(players)

        os_friends = list(set(self.get_os_friend_list(player.get_os_type())) - set(helper_ids))
        os_num = GameRule.helper.os_number(helper_num, len(os_friends))
        ids, players = self.select_friends(creature_slugs, os_friends, os_num)
        helper_ids.extend(ids)
        helpers.extend(players)

        stranger_num = max(0, helper_num - len(helper_ids))
        players = self.select_strangers(stranger_num, helper_num, helper_ids, creature_slugs)
        helpers.extend(players)
        return helpers

    def _get_helper_hearts(self, helper_id):
        reward_hearts = 0
        recently = RecentlyHelper(self.player_id, helper_id)
        if not recently.exist():
            reward_hearts = self.get_social_reward(helper_id)[0]
        return reward_hearts

    def get_social_reward(self, helper_id):
        if helper_id in self.get_facebook_list():
            return GameRule.helper.fb_reward()
        if helper_id in self.get_os_friend_list():
            return GameRule.helper.os_reward()
        if helper_id in self.favorite_list.get_list():
            return GameRule.helper.favorite_reward()
        if helper_id in self.friend_list.get_list():
            return GameRule.helper.friend_reward()
        return GameRule.helper.active_reward()
