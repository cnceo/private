from dal.base import *
from utils.settings import LEDGERS_BUCKET


class LedgersBase(Base):
    _db_type = LEDGERS_BUCKET
    _id_tpl = NotImplemented
    _oid_key = "id"
    id = LongAttr()

    def get_id(self):
        id_count = KeyValue(self._id_tpl % self.parent_key)
        return id_count.incr(1, initial=1)

    def _get_oid_val(self, kw):
        return super(LedgersBase, self)._get_oid_val(kw) or self.get_id()


class GemsLedger(LedgersBase):
    _id_tpl = "gems_ledger_%s"
    _oid_key = "id"
    _parent_key = "player_id"
    _index_attributes = ["player_id"]
    id = LongAttr()
    player_id = LongAttr()
    trans_type = IntAttr()
    qty = IntAttr()
    details = DictAttr(TextAttr(), default={})
    datetime = DateTimeAttr()
    ledger_type = "Gem"


class CoinsLedger(LedgersBase):
    _id_tpl = "coins_ledger_%s"
    _oid_key = "id"
    _parent_key = "player_id"
    _index_attributes = ["player_id"]
    id = LongAttr()
    player_id = LongAttr()
    trans_type = IntAttr()
    qty = IntAttr()
    details = DictAttr(TextAttr(), default={})
    datetime = DateTimeAttr()
    ledger_type = "Coin"


class HeartsLedger(LedgersBase):
    _id_tpl = "hearts_ledger_%s"
    _oid_key = "id"
    _parent_key = "player_id"
    _index_attributes = ["player_id"]
    id = LongAttr()
    player_id = LongAttr()
    trans_type = IntAttr()
    qty = IntAttr()
    details = DictAttr(TextAttr(), default={})
    datetime = DateTimeAttr()
    ledger_type = "Heart"
