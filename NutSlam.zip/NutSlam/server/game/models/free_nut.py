from datetime import datetime
from dal.base import *
from utils.misc import local_now
from utils.misc import next_x_days
from utils.misc import time_of_day
from utils.settings import DAILY_WARNUT_TIME
from utils.protocol_pb2 import TreeEventType


class DailyWarnut(object):
    tree_type = TreeEventType.Value("DAILY")

    def __init__(self, player_id, utc_offset):
        self.player_id = player_id
        self.utc_offset = utc_offset

    @property
    def key(self):
        return KeyValue("DailyWarnut:%s" % self.player_id)

    def store(self):
        self.key.store("", ttl=self._next_ttl())

    def _next_ttl(self):
        now = local_now(self.utc_offset)
        r_clock = time_of_day(now, **DAILY_WARNUT_TIME)
        if now > r_clock:
            r_clock = next_x_days(r_clock, days=1)
        return int((r_clock - now).total_seconds())

    def ttl(self):
        if self.key.exist():
            return self._next_ttl()
        return 0


class FreeAkorn(Base):
    tree_type = TreeEventType.Value("TTL")
    _oid_key = "player_id"
    player_id = LongAttr()
    update_time = DateTimeAttr()

    def store(self):
        self.update_time = datetime.utcnow()
        super(FreeAkorn, self).store()

    def ttl(self, ttl):
        if self.exist():
            now = datetime.utcnow()
            t_delta = int((now - self.update_time).total_seconds())
            if t_delta < ttl:
                return ttl - t_delta
        return 0