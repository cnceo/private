import math
import random
from dal.base import *
from utils.exception import CreatureDisabledAction
from utils.protocol_pb2 import CreatureInstance as CreatureProto
from utils.protocol_pb2 import Egg
from utils.protocol_pb2 import EggType
from utils.protocol_pb2 import Teams
from utils.protocol_pb2 import CollectedCreatureState
from utils.protocol_pb2 import Element
from models.content import GameRule
from utils.settings import MEMCACHED_BUCKET
from utils.settings import ELEMENT_BEATEN_MAP
from utils.log import log


class Nuts(Base):
    _oid_key = "cid"
    _index_attributes = ["player_id"]
    _parent_key = "player_id"
    oid_key_tpl = "creature_id:%s"

    player_id = LongAttr()
    cid = IntAttr()
    nut = TextAttr(default="wood_nut")

    slug = TextAttr()
    xp = IntAttr(default=0)
    level = IntAttr(default=1)
    plusHP = IntAttr(default=0)
    plusAttack = IntAttr(default=0)
    plusSpeed = IntAttr(default=0)
    plusLuck = IntAttr(default=0)

    @classmethod
    def get_id(cls, pid):
        id_count = KeyValue(cls.oid_key_tpl % pid)
        return id_count.incr(1, initial=1)

    @classmethod
    def create(cls, player_id, slug, cid=None, level=1, xp=0, plusHP=0,
               plusAttack=0, plusSpeed=0, plusLuck=0, auto_open=False,
               nut=None, **kwargs):
        slug = slug.lower()
        cid = cid or cls.get_id(player_id)
        kwargs.update({"cid": cid,
                       "nut": nut,
                       "player_id": player_id,
                       "slug": slug,
                       "xp": xp,
                       "level": level,
                       "plusHP": plusHP,
                       "plusAttack": plusAttack,
                       "plusSpeed": plusSpeed,
                       "plusLuck": plusLuck})
        obj = cls(**kwargs)
        if auto_open:
            return obj.open()
        obj.store()
        return obj

    @classmethod
    def generate(cls, player_id, nut, cid=None):
        params = {"cid": cid or cls.get_id(player_id),
                  "player_id": player_id,
                  "nut": nut}
        obj = cls(**params)
        obj.store()
        return obj

    @property
    def creature_slug(self):
        if not self.slug:
            from models.player import Player
            p = Player(id=self.player_id)
            ele = GameRule.world.element_by_progress(p.progress)

            # check the player ship,
            # if already have enough elemental creatures, will skip elemental gatcha
            # TODO: it loads a lot from cb, need to notice
            if ele:
                beat_ele = ELEMENT_BEATEN_MAP.get(ele.lower())
                if beat_ele:
                    cids = CreatureInstance.load_oids_by_attribute('player_id', self.player_id)
                    cids.reverse()
                    ele_creatures_count = 0
                    for cid in cids:
                        c = CreatureInstance(player_id=self.player_id, cid=cid)
                        c_ele = Element.Name(c.type.element).lower()
                        if c_ele == beat_ele:
                            ele_creatures_count +=1
                            if ele_creatures_count >= 3:
                                ele = None
                                break
            t = GameRule.get_new_gacha(p.utc_offset).get_nut_tree(self.nut, ele)
            p_drops = p.first_drop or {}
            if t.first_drops and not p_drops.get(self.nut):
                self.slug = t.first_drop()
                p_drops[self.nut] = True
                p.first_drop = p_drops
                p.store()
            else:
                self.slug = t.drop()
        return self.slug

    def open(self):
        param = {"cid": self.cid,
                 "player_id": self.player_id,
                 "slug": self.creature_slug,
                 "xp": self.xp,
                 "level": self.level,
                 "plusHP": self.plusHP,
                 "plusAttack": self.plusAttack,
                 "plusSpeed": self.plusSpeed,
                 "plusLuck": self.plusLuck}
        c = CreatureInstance(**param)
        c_t = CreatureState(player_id=self.player_id, slug=self.creature_slug)
        if not c_t.exist() or not c_t.owned:
            c_t.owned = True
            c_t.store()
        c.store()
        log.info("Opened nut %s" % (c.slug,),
            cid=self.cid, slug=c.slug, owner_id=self.player_id)
        if self.exist():
            self.delete()
        return c

    @classmethod
    def get_all(cls, player_id):
        rep = []
        for n in cls.load_by_attribute("player_id", player_id):
            rep.append(n.to_proto_class())
        return rep

    def to_proto_class(self, proto=None):
        proto = proto or Egg()
        proto.type = EggType.Value("NUT_EGG")
        proto.id = self.cid
        proto.nut = self.nut
        return proto


class CreatureInstance(Base):
    _oid_key = "cid"
    _index_attributes = ["player_id"]
    _parent_key = "player_id"
    _loaded = False
    _type = None

    player_id = LongAttr()
    cid = IntAttr()

    slug = TextAttr()
    xp = IntAttr(default=0)
    level = IntAttr(default=1)
    plusHP = IntAttr(default=0)
    plusAttack = IntAttr(default=0)
    plusSpeed = IntAttr(default=0)
    plusLuck = IntAttr(default=0)

    def store(self):
        if self.level == self.max_level:
            self.xp = self.max_xp
            c_t = CreatureState(player_id=self.player_id, slug=self.slug)
            if not c_t.maxed:
                c_t.maxed = True
                c_t.owned = True
                c_t.store()
        super(CreatureInstance, self).store()

    def _upgrade(self, new_slug):
        # update slug, reset xp & level.
        self.slug = new_slug.lower()
        self.xp = 0
        self.level = 1
        c_t = CreatureState(player_id=self.player_id, slug=self.slug)
        if not c_t.owned:
            c_t.owned = True
            c_t.store()
        self.store()

    @classmethod
    def get_all_by_player(cls, pid):
        rep = []
        for c in cls.load_by_attribute('player_id', pid):
            rep.append(c.to_proto_class())
        return rep

    def to_proto_class(self, c=None):
        c = c or CreatureProto()
        c.cid = self.cid
        c.slug = self.slug or ''
        c.xp = self.xp or 0
        c.level = self.level or 1
        c.plusHP = int(self.plusHP or 0)
        c.plusAttack = self.plusAttack or 0
        c.plusSpeed = self.plusSpeed or 0
        c.plusLuck = self.plusLuck or 0
        return c

    @property
    def type(self):
        if self._type is None:
            self._type = GameRule.creature_types.get(self.slug)
        return self._type

    @property
    def element(self):
        return self.type.element

    @property
    def star(self):
        return self.type.starRating

    def sale_price(self):
        # faeries currency
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.currency(self.slug) or 0

        # normal currency
        param_a, param_b, param_c = GameRule.creature.sell_param()
        price = (round(math.pow(self.star, param_a)) * param_b +
                 self.level * param_c)
        return int(price)

    def fuse_currency(self):
        param_a, param_b, param_c = GameRule.creature.fuse_currency_param()
        return int(self.star * param_a + (self.level - param_b) * param_c)

    def evolve_currency(self):
        return GameRule.creature.evolve_currency(self.star)

    def ascend_currency(self):
        return GameRule.creature.ascend_currency(self.star)

    @property
    def max_level(self):
        return self.type.maxLevel

    def is_max_level(self):
        return self.level == self.max_level

    def is_same_element(self, other):
        if isinstance(other, str):
            # handle slug
            c_type = GameRule.creature_types.get(other)
            return self.element == c_type.element
        else:
            # handle CreatureInstance
            return self.element == other.element

    def is_same_series(self, other):
        slug = isinstance(other, str) and other or other.slug
        series = GameRule.creature_types.series(self.slug)
        return slug in series

    def fuse_mega_odds(self, same_ele_num, feeders_num):
        param_a, param_b = GameRule.creature.mega_param()
        odds_mego = param_a * same_ele_num / feeders_num + param_b

        from models.player import Player
        p = Player(id=self.player_id)
        events = GameRule.get_events(p.utc_offset)
        chance = events.upgrade_chance(self.element)
        odds_mego += chance

        if random.random() <= odds_mego:
            return True
        return False

    def fuse_trans_xp(self, eater):
        """
        Transform creature to xp to fuse others.
        """
        # faeries xp
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.xp(self.slug) or 0

        # normal xp
        star = self.star
        param_a, param_b, param_c, param_d = GameRule.creature.trans_xp_param()
        if self.is_same_element(eater):
            param_c += param_d
        return int((star * param_a + star * self.level * param_b) * param_c)

    def fuse_plus_hp(self, eater):
        # faeries hp
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.hp(self.slug) or 0

        # normal hp
        if self.plusHP:
            param_a, param_b = GameRule.creature.inherit_hp_param()
            if self.is_same_element(eater):
                param_b += 1
            return round(param_a * param_b * self.plusHP)
        return 0

    def fuse_plus_attack(self, eater):
        # faeries attack
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.attack(self.slug) or 0

        # normal attack
        if self.plusAttack:
            param_a, param_b = GameRule.creature.inherit_attack_param()
            if self.is_same_element(eater):
                param_b += 1
            return param_a * param_b * self.plusAttack
        return 0

    def fuse_plus_speed(self, eater):
        # faeries speed
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.speed(self.slug) or 0

        # normal speed
        if self.plusSpeed:
            param_a, param_b = GameRule.creature.inherit_speed_param()
            if self.is_same_element(eater):
                param_b += 1
            return param_a * param_b * self.plusSpeed
        return 0

    def fuse_plus_luck(self, eater):
        # faeies luck
        if GameRule.faeries.by_slug(self.slug):
            return GameRule.faeries.luck(self.slug) or 0

        # normal luck
        p_a, p_b, p_c, p_d = GameRule.creature.inherit_luck_param()
        inherit_ratio = p_b
        additional_luck = p_d
        if self.is_same_series(eater):
            inherit_ratio = p_a
            additional_luck = p_c
        return inherit_ratio * (self.plusLuck or 0) + additional_luck

    @property
    def max_xp(self):
        l_exp, l_scale, star_scale, xp_incr = GameRule.creature.level_param()
        return int(l_scale * self.max_level * star_scale *
                   math.pow(self.level, l_exp) + xp_incr * self.level)

    def add_xp(self, xp):
        if self.level >= self.max_level:
            return
        self.xp += xp
        next_level = self.level + 1
        level_up_xp = self.max_xp
        while self.xp >= level_up_xp and next_level <= self.max_level:
            self.xp -= level_up_xp
            self.level = next_level
            level_up_xp = self.max_xp
            next_level += 1

    def support_evolve(self):
        return bool(self.type.evolutionSlug)

    def evolution_materials(self):
        return GameRule.creature.evolve_materials(self.star, self.element)

    def evolve(self):
        evolution_slug = self.type.evolutionSlug
        if not evolution_slug:
            raise CreatureDisabledAction(slug=self.slug, action="evolution")
        self._upgrade(evolution_slug)

    def get_transcend(self):
        return self.type.transcend

    def support_ascend(self):
        transcend = self.get_transcend()
        return transcend and transcend.transcendSlug

    def transcend(self):
        transcend = self.get_transcend()
        transcend_slug = transcend and transcend.transcendSlug
        if not transcend_slug:
            raise CreatureDisabledAction(slug=self.slug, action="transcend")
        self._upgrade(transcend_slug)


class CreatureTeam(Base):
    _oid_key = "player_id"
    placeholder_cid = 0
    team_length = 3
    default_team = [placeholder_cid] * team_length

    player_id = IntAttr()
    active = IntAttr()
    team1 = ListAttr(IntAttr())
    team2 = ListAttr(IntAttr())
    team3 = ListAttr(IntAttr())
    team4 = ListAttr(IntAttr())
    team5 = ListAttr(IntAttr())
    team6 = ListAttr(IntAttr(), default=default_team)
    team_num = 6

    @classmethod
    def _prepare_team(cls, cids):
        t_length = len(cids)
        if t_length < cls.team_length:
            team = cids + [cls.placeholder_cid] * (cls.team_length - t_length)
        else:
            team = cids[:cls.team_length]
        return team

    @classmethod
    def create(cls, pid, team1=default_team, team2=default_team,
               team3=default_team, team4=default_team, team5=default_team,
               team6=default_team):
        data = {'player_id': pid,
                'active': 0,
                'team1': cls._prepare_team(team1),
                'team2': cls._prepare_team(team2),
                'team3': cls._prepare_team(team3),
                'team4': cls._prepare_team(team4),
                'team5': cls._prepare_team(team5),
                'team6': cls._prepare_team(team6),
        }
        teams = CreatureTeam(**data)
        teams.store()

    @classmethod
    def store_from_proto(cls, pid, proto):
        t = cls(player_id=pid)
        t.active = proto.active
        old_teams = [t.team1, t.team2, t.team3, t.team4, t.team5, t.team6]
        for t_index, _team in zip(range(1, cls.team_num + 1),
                                  proto.team[:cls.team_num]):
            setattr(t, "team%s" % t_index,
                    cls._prepare_team(_team.creaturesIds[:cls.team_length]))
        for t_index in range(len(proto.team), cls.team_num):
            setattr(t, "team%s" % (t_index + 1), cls.default_team)
        t.store()

        new_teams = [t.team1, t.team2, t.team3, t.team4, t.team5, t.team6]
        ret = []

        teams = zip(old_teams, new_teams)
        creatures = {}
        for index in range(len(teams)):
            i, j = teams[index]
            if i != j:
                for cid in i + j:
                    if cid not in creatures:
                        creature = CreatureInstance(player_id=pid, cid=cid)
                        creatures[cid] = creature.exist() and creature.star or 0
                # TODO: set star for creature_id
                ret.append({'old':{'creature_id': [creatures[c] for c in i]},
                            'new':{'creature_id': [creatures[c] for c in j]},
                            })

        # for i, j in zip(old_teams, new_teams):
        #     if i != j:
        #         ret.append({'old':{'creature_id': i}, 'new':{'creature_id': j}})
        return ret

    @classmethod
    def get_proto_class(cls, pid, proto=None):
        proto = proto or Teams()
        def _assign_ids(ct, pt):
            if not ct:
                return
            t = pt.add()
            for i in ct:
                t.creaturesIds.append(i)
        ts = cls(player_id=pid)
        _assign_ids(ts.team1, proto.team)
        _assign_ids(ts.team2, proto.team)
        _assign_ids(ts.team3, proto.team)
        _assign_ids(ts.team4, proto.team)
        _assign_ids(ts.team5, proto.team)
        _assign_ids(ts.team6, proto.team)
        proto.active = ts.active or 0
        return proto

    def get_active_team(self):
        """
        Get team by active value.
        If this team is empty, return the first not empty one.
        """
        active_team = getattr(self, "team%s" % (self.active + 1))
        if active_team != self.default_team:
            return active_team

        for index in range(1, self.team_num + 1):
            active_team = getattr(self, "team%s" % index)
            if active_team and active_team != self.default_team:
                return active_team
        return []

    def get_teams(self):
        teams = []
        for index in range(1, self.team_num + 1):
            team = getattr(self, "team%s" % index)
            if team:
                teams.append(team)
        return teams

    def get_creatures(self):
        teams = self.get_teams()
        creatures = set()
        for t in teams:
            creatures.update(t)
        creatures.discard(self.placeholder_cid)
        return creatures

    def creature_team_map(self):
        c_map = {}
        for i in range(1, self.team_num + 1):
            t = "team%s" % i
            team = getattr(self, t, [])
            for c in team:
                if c != self.placeholder_cid and c not in c_map:
                    c_map[c] = t
        return c_map


class StartupTeams(object):
    @classmethod
    def save(cls, pid, chosen):
        startup = KeyValue('StartupTeams:%s' % pid, MEMCACHED_BUCKET)
        startup.store(chosen)

    @classmethod
    def delete(cls, pid, used_cid=None):
        startup = KeyValue('StartupTeams:%s' % pid, MEMCACHED_BUCKET)
        chosen = startup.load()
        if chosen is None and used_cid:
            # get select team by leader id if StartupTeams not cached.
            cid_to_team = CreatureTeam(player_id=pid).creature_team_map()
            t_name = cid_to_team.get(used_cid)
            chosen = t_name and int(t_name.replace("team", "")) - 1
        if chosen is None:
            return

        teams = CreatureTeam.get_proto_class(pid)
        delete_cids = []
        select_cids = []
        for i in range(len(teams.team)):
            cids = list(teams.team[i].creaturesIds)
            if i == chosen:
                select_cids = cids
            else:
                for cid in cids:
                    if cid != 0 and cid not in delete_cids:
                        delete_cids.extend(cids)

        for i in range(len(select_cids)):
            teams.team[0].creaturesIds[i] = select_cids[i]
        for i in range(3):
            teams.team[1].creaturesIds[i] = 0
            teams.team[2].creaturesIds[i] = 0
            teams.team[3].creaturesIds[i] = 0
            teams.team[4].creaturesIds[i] = 0

        teams.active = 0
        CreatureTeam.store_from_proto(pid, teams)

        player_cids = CreatureInstance.load_oids_by_attribute("player_id", pid)
        for cid in delete_cids:
            if cid in player_cids:
                f_c = CreatureInstance(player_id=pid, cid=cid)
                f_c.delete()
                player_cids.remove(cid)
                log.info("Deleted startup creature after d0",
                               cid=cid, slug=f_c.slug, player_id=pid)
        CreatureState.cleanup(pid)
        startup.delete()


CT_MAXEDOUT = CollectedCreatureState.Value("CT_MAXEDOUT")
CT_OWNED = CollectedCreatureState.Value("CT_OWNED")
CT_SEEN = CollectedCreatureState.Value("CT_SEEN")


class CreatureState(Base):
    _oid_key = "slug"
    _parent_key = "player_id"
    _index_attributes = ["player_id"]
    player_id = LongAttr()
    slug = TextAttr()
    owned = BoolAttr(default=False)
    maxed = BoolAttr(default=False)

    @classmethod
    def get_all(cls, player_id, proto):
        for c_t in cls.load_by_attribute("player_id", player_id) or []:
            s_p = proto.add()
            s_p.creature_slug = c_t.slug
            if c_t.maxed:
                s_p.state = CT_MAXEDOUT
            elif c_t.owned:
                s_p.state = CT_OWNED
            else:
                s_p.state = CT_SEEN
        return proto

    def check_state(self, state):
        if state == CT_SEEN:
            return self.exist()
        elif state == CT_OWNED:
            return self.owned
        elif state == CT_MAXEDOUT:
            return self.maxed
        return False

    @classmethod
    def cleanup(cls, player_id):
        """
        Should ony been run while delete StartupTeams.
        For removing the not selected leaders in tutorial.
        """
        all_slug = [c.slug for c in
                    CreatureInstance.load_by_attribute("player_id", player_id)]
        for c_t in cls.load_by_attribute("player_id", player_id) or []:
            if c_t.slug not in all_slug:
                c_t.delete()


class CollectionState(Base):
    """
    @slug - collection slug
    @reward_state - use "|" to store state and use "&" to read state.
        0 => default(never reward this collection)
        1 => seen rewarded
        2 => owned rewarded
        3 => seen + owned rewarded
        4 => maxed rewarded
        5 => maxed + seen rewarded
        6 => maxed + owned rewarded
        7 => maxed + owned + seen rewarded
    """
    _oid_key = "slug"
    _parent_key = "player_id"
    _index_attributes = ["player_id"]
    player_id = LongAttr()
    slug = TextAttr()
    reward_state = IntAttr(default=0)

    def mark_reward(self, state):
        self.reward_state |= state
        self.store()

    def check_reward(self, state):
        return self.reward_state & state

    @classmethod
    def get_all(cls, player_id, proto):
        for c_t in cls.load_by_attribute("player_id", player_id) or []:
            p = proto.add()
            p.slug = c_t.slug
            p.state = c_t.reward_state
        return proto
