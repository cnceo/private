from common import add_script_path
add_script_path()


from utils.constants import TRANS_TYPE
from models.player import Player
from models.player import id_count
from models.player import player_id_initial


def adjust():
    for p_id in range(player_id_initial, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist():
            for attr, l_cls in p.ledger_map.iteritems():
                current_val = getattr(p, attr)
                balance = 0
                for g_l in l_cls.load_by_attribute("player_id", p_id):
                    balance += g_l.qty
                if balance != current_val:
                    p.update_ledger(l_cls, TRANS_TYPE.BALANCE_ADJUSTMENT,
                                    current_val - balance)

adjust()