import argparse
from time import sleep
from common import add_script_path
add_script_path()
from models.friend import FriendAhead
from models.player import id_count
from models.player import player_id_initial
from models.player import Player


def do_update(player):
    f_ahead = FriendAhead(player_id=player.id)
    for f_id in f_ahead.all_friends():
        f = Player(id=f_id)
        if f.progress >= player.progress:
            f_ahead.add_to_list(f_id, do_store=False)
        else:
            f_ahead.remove_from_list(f_id, do_store=False)
    f_ahead.store()
    print ("Update ahead friends for player: %s, ahead friends: %s" %
           (player.id, f_ahead.player_list))


def update(start_pid):
    if start_pid < player_id_initial:
        start_pid = player_id_initial
    for p_id in range(start_pid, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist():
            do_update(p)
            sleep(.5)


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="ahead-friends")
    parser.add_argument("-s", "--start_pid", default=player_id_initial,
                        type=int)
    args = parser.parse_args()
    update(args.start_pid)