import os, sys, glob
from PIL import Image
import subprocess


if __name__ == "__main__":
    root = os.path.dirname(os.path.dirname(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from_path = os.path.join(root, 'client/Assets/ResourcesForStreaming/Sprite/Creature/')
    to_path = os.path.join(root, 'server/game/media/creatures/')
    print 'from path:', from_path
    print 'to path', to_path
    size = 512, 512
    subprocess.call('rm %s/*' % to_path, shell=True)
    for infile in glob.glob(from_path+'*.png'):
        print 'file in:', infile
        outfile = os.path.join(to_path, infile.split('.')[0].split('/')[-1] + ".jpg")
        print 'file out', outfile
        if infile != outfile:
            try:
                im = Image.open(infile)
                #im.thumbnail(size, Image.ANTIALIAS)
                x,y = im.size
                p = Image.new('RGBA', im.size, (255,255,255))
                p.paste(im, (0, 0, x, y), im)
                p.save(outfile, "JPEG")
            except IOError:
                print "cannot create thumbnail for '%s'" % infile

