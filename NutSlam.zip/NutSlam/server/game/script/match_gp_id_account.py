from models.player import Player
from models.creature import Nuts

def add_creature(data):
    data = [
        {"player_id": 11894513, "slug": "mermaidqueen_02",  "level": 9,  "xp": 1268,    "plusHP": 0},
        {"player_id": 11894513, "slug": "owl_02",           "level": 14, "xp": 3872,    "plusHP": 0},
        {"player_id": 11894513, "slug": "wolfman_01",       "level": 10, "xp": 3502,    "plusHP": 0},
        {"player_id": 11894513, "slug": "westwitch_01",     "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "alien_02",         "level": 3,  "xp": 229,     "plusHP": 20},
        {"player_id": 11894513, "slug": "snowqueen_01",     "level": 20, "xp": 8871,    "plusHP": 0},
        {"player_id": 11894513, "slug": "grumpy_01",        "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "mouse_01",         "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "fox_01",           "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "unicorn_01",       "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "monkey_01",        "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "bear_01",          "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "rabbit_01",        "level": 1,  "xp": 0,       "plusHP": 0},
        {"player_id": 11894513, "slug": "acornidol_02",     "level": 1,  "xp": 204,     "plusHP": 0},
        {"player_id": 11894513, "slug": "acornidol_02",     "level": 1,  "xp": 204,     "plusHP": 0},
    ]
    from models.creature import CreatureInstance
    from models.content import GameRule
    GameRule.get_content()
    for i in data:
        Nuts.create(auto_open=True, **i)


def search():
    from models.player import Player
    from models.creature import CreatureInstance
    old_email = {}
    new_email = {}
    for i in range(11888111, 11899999):
        p = Player(id=i)
        if not p.exist():
            continue
        if p.gp_id:
            if '@' in p.gp_id:
                old_email[p.gp_id] = p.id
            else:
                new_email[p.gp_email] = p.id
    for i in old_email:
        if i in new_email:
            print new_email[i], old_email[i]

if __name__ == "__main__":
    search()
