import argparse
from time import sleep
from common import add_script_path
add_script_path()
from models.content import GameRule

from models.creature import CreatureInstance
from models.creature import CreatureState
from models.player import id_count
from models.player import player_id_initial
from models.player import Player


def do_update(player_id):
    # init old players.
    for c in CreatureInstance.load_by_attribute("player_id", player_id):
        c_t = CreatureState(player_id=player_id, slug=c.slug)
        if not c_t.exist() or not c_t.owned:
            c_t.owned = True
            c_t.maxed = c.is_max_level()
            c_t.store()
        elif not c_t.maxed and c.is_max_level():
            c_t.maxed = True
            c_t.store()


def update_players(start_pid):
    GameRule.get_content()
    if start_pid < player_id_initial:
        start_pid = player_id_initial
    for p_id in range(start_pid, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist():
            do_update(p_id)
            print "Update create state for player: %s" % p.id
            sleep(1)


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="creature-state")
    parser.add_argument("-s", "--start_pid", default=player_id_initial,
                        type=int)
    args = parser.parse_args()
    update_players(args.start_pid)