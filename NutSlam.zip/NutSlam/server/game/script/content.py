import os, sys, urllib2, csv, base64, gdata
import gdata.docs.data
from oauth2client import tools
import httplib2
from oauth2client.file import Storage
from oauth2client.client import flow_from_clientsecrets
from oauth2client.tools import run_flow
import gflags
import gdata.docs.service
import argparse


sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.content import GameRule
from utils.settings import CONTENT_VERSION_NAVI_KEY, CONTENT_VERSION_NAVI_ID,\
                           ASSET_VERSION_NAVI_ID
from utils.settings import LOCALIZATION_NAVI_KEY
from utils.settings import L10N_FILE_NAME_ID_MAP

file_path = os.path.dirname(os.path.abspath(__file__)).replace('script', 'content_csv')
csv.field_size_limit(sys.maxsize)

DIRNAME = os.path.dirname(os.path.abspath(__file__))

class VersionNaviSheet(object):
    def __init__(self, key, gid, client):
        super(VersionNaviSheet, self).__init__()
        self.key = key
        self.gid = gid
        self.cls_name = 'VerNavi'
        self.rows = []
        self.client = client

    def select(self, version):
        file_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        csv_file = self.client.download(self, file_name)
        for row in csv.reader(csv_file):
            print row
            self.rows.append(row)
            if row[0] == version:
                return row[1:]
        return None

class AssetVersionSheet(object):
    def __init__(self, key, gid, client):
        super(AssetVersionSheet, self).__init__()
        self.key = key
        self.gid = gid
        self.cls_name = 'AssetVersion'
        self.rows = []
        self.client = client

    def download(self):
        file_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        self.client.download(self, file_name)

class DataNaviSheet(object):
    def __init__(self, key, gid, client):
        super(DataNaviSheet, self).__init__()
        self.key = key
        self.gid = gid
        self.cls_name = 'Navi'
        self.rows = []
        self.client = client

    def download(self):
        # file_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        # csv_file = self.client.download(self, file_name)
        # with open(file_name, 'w') as w:
        #     writer = csv.writer(w)
        #     for row in csv.reader(csv_file):
        #         print '>', row
        #         writer.writerow(row)
        #         self.rows.append(row)
        # rows = self.rows[1:]
        # for r in rows:
        #     ds = DataSheet(r[0], r[1], r[2])
        #     ds.download(self.client)

        file_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        csv_file = self.client.download(self, file_name)
        for row in csv.reader(csv_file):
            print '>', row
            self.rows.append(row)
        rows = self.rows[1:]
        for r in rows:
            ds = DataSheet(r[0], r[1], r[2])
            ds.download(self.client)

class DataSheet(object):
    def __init__(self, cls_name, key, gid):
        super(DataSheet, self).__init__()
        self.key = key
        self.gid = gid
        self.cls_name = cls_name

    def download(self, client):
        file_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        client.download(self, file_name)
        # tmp_name = os.path.join(file_path, '%s_tmp.csv' % self.cls_name)
        # finnal_name = os.path.join(file_path, '%s.csv' % self.cls_name)
        # csv_file = client.download(self, tmp_name)
        # with open(finnal_name, 'w') as w:
        #     writer = csv.writer(w)
        #     for row in csv.reader(csv_file):
        #         #row = row[0]
        #         print '>', row
        #         writer.writerow(row)

class Client(object):
    def __init__(self, email, password, flags):
        super(Client, self).__init__()
        self.email = email
        self.password = password
        self.flags = flags

    def download(self, spreadsheet, filename, fmt="csv"):
        #gflags.DEFINE_boolean('noauth_local_webserver', True,
        #             ('Run a local web server to handle redirects during '
        #               'OAuth authorization.'))
        #storage = Storage("creds.dat")
        #credentials = storage.get()
        client_secret = os.path.join(DIRNAME, "client_secret.json")
        storedCreds = os.path.join(DIRNAME, "creds.dat")
        def getGdataCredentials(client_secrets=client_secret, storedCreds=storedCreds, scope=["https://spreadsheets.google.com/feeds"], force=False):
          storage = Storage(storedCreds)
          credentials = storage.get()
          if credentials is None or credentials.invalid or force:
            credentials = run_flow(flow_from_clientsecrets(client_secrets, scope=scope), storage, self.flags)
          if credentials.access_token_expired:
            credentials.refresh(httplib2.Http())
          return credentials

        credentials = getGdataCredentials(client_secrets=client_secret, storedCreds=storedCreds, scope=["https://spreadsheets.google.com/feeds"], force = False)
        client = gdata.docs.service.DocsService(additional_headers={'Authorization' : 'Bearer %s' % credentials.access_token})

        url_format = "https://spreadsheets.google.com/feeds/download/spreadsheets/Export?key=%s&exportFormat=%s&gid=%i"
        url = url_format % (spreadsheet.key, fmt, int(spreadsheet.gid))
        print url
        print filename
        client.Download(url, filename)
        return open(filename)


def download_content(flags, version='dev'):
    print 'Start downloading content data from google drive, version: %s' % version

    # Create client and spreadsheet objects
    client = Client('delta-gdrive@happylatte.com', 'v74NrtcsRkbB', flags)

    ver_navi = VersionNaviSheet(CONTENT_VERSION_NAVI_KEY, CONTENT_VERSION_NAVI_ID, client)
    ret = ver_navi.select(version)
    if not ret:
        print 'No version matchs: %s' % version
    key, pid = ret
    data_navi = DataNaviSheet(key, pid, client)
    data_navi.download()

    asset_ver = AssetVersionSheet(CONTENT_VERSION_NAVI_KEY, ASSET_VERSION_NAVI_ID, client)
    asset_ver.download()

    download_localization(client)

    print 'Finish downloading content data.'


def download_localization(client):
    for file_name, gid in L10N_FILE_NAME_ID_MAP.iteritems():
        d_sheet = DataSheet(file_name, LOCALIZATION_NAVI_KEY, gid)
        d_sheet.download(client)


def upload_s3(bucket, string, file_path):
    try:
        from boto.s3.key import Key
        from boto.s3.connection import S3Connection

        conn = S3Connection(aws_access_key_id='AKIAIB6BNDKTDOL3CYLQ',
                            aws_secret_access_key='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')
        bucket = conn.get_bucket(bucket)
        try:
            k = Key(bucket)
            k.key = os.path.join('assetbundle', file_path)
            k.set_contents_from_string(string, policy='public-read')
            print 'File uploaded to S3 >', k.key
        except Exception, e:
            print "Error: can not upload file: %s to S3!" % file_path

    except Exception, e:
        print "Warning: did not upload files to S3!", e

def gen_asset():
    GameRule.init()
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assetbundle')
    world = base64.b64encode(GameRule.get_base_world().SerializeToString())
    creatures = base64.b64encode(GameRule.creature_types.proto.SerializeToString())
    world_file = open(os.path.join(path, 'world.txt'), 'w')
    world_file.write(world)
    creatures_file = open(os.path.join(path, 'creatures.txt'), 'w')
    creatures_file.write(creatures)
    print 'New content assets generated.'


if __name__ == "__main__":
    argparser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
            parents=[tools.argparser])
    flags = argparser.parse_args(sys.argv[2:])

    action = sys.argv[1].split(',')
    print action
    if "download" == action[0]:
        if len(action) > 1:
            # means version is parsed, such as 1.4
            download_content(flags, action[1])
        else:
            download_content(flags)
    elif "extract" == action[0]:
        GameRule.extract_content()
    elif "gen_asset" == action[0]:
        gen_asset()
    elif "refresh_asset" == action[0]:
        if len(action) > 1:
            # means version is parsed, such as 1.4
            download_content(flags, action[1])
        else:
            download_content(flags)
        GameRule.extract_content()
        gen_asset()
