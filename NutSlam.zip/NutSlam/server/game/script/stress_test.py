from common import add_script_path
add_script_path()

import argparse
import base64
import gevent
import random
import time
import urllib
import urllib2
from utils.protocol_pb2 import *

base_url = "http://localhost:8088"
#base_url = "http://nutslam-beta.happylatte.com"
#base_url = "http://52.70.244.106:8088"
#base_url = "http://52.6.25.186:8088"


c_ids = range(1, 100)  # TODO - adjust this.
player_ids = set()
gacha_slugs = []
dungeon_ids = []
material_conv = {}
material_slugs = []
tree_slug = []

success = 0
fail = 0

def generate_message(e):
    return base64.b64encode(e.SerializeToString())


def prepare():
    print "Prepare settings..."
    global gacha_slugs
    player = MockedPlayer(1)
    player.create_player()
    gacha_tree = player.post_message(GachaTrees(), GachaTreesRep)
    gacha_slugs = gacha_tree.tree_slugs

    global dungeon_ids
    word = player.post_message(RetrieveWorld(), World)
    for zone in word.zones:
        for area in zone.areas:
            for dungeon in area.dungeons:
                dungeon_ids.append(dungeon.ID)

    global material_conv
    global material_slugs
    config = player.post_message(GetGlobalConfigs(), GlobalConfigs)
    for m in config.craftingMaterial:
        material_conv[m.slug] = [c.slug for c in m.conversion]
    material_slugs = material_conv.keys()

    global tree_slug
    e_conf = player.post_message(GetEventsConfigs(), EventsConfigs)
    for e in e_conf.gacha_trees:
        tree_slug.append(e.slug)
    print "=" * 20


class MockedPlayer(object):
    req_interval = (2, 5)
    session_id = None
    req_msgs = []

    def __init__(self, player_index, modify_friend=1, buy_creature_space=3,
                 battle=50, add_energy=4, gacha=10, edit_team=2,
                 convert_material=1, evolve=2, sell=5, fuse=5, **kw):
        self.player_index = player_index
        self.req_msgs = [self.link_account,
                         self.retrieve_settings]
        for _ in range(modify_friend):
            self.req_msgs.append(self.modify_friend)
        for _ in range(buy_creature_space):
            self.req_msgs.append(self.buy_creature_space)
        for _ in range(battle):
            self.req_msgs.append(self.do_battle)
        for _ in range(add_energy):
            self.req_msgs.append(self.add_energy)
        for _ in range(gacha):
            self.req_msgs.append(self.gacha)
        for _ in range(edit_team):
            self.req_msgs.append(self.edit_team)
        for _ in range(convert_material):
            self.req_msgs.append(self.convert_material)
        for _ in range(evolve):
            self.req_msgs.append(self.evolve)
        for _ in range(sell):
            self.req_msgs.append(self.sell)
        for _ in range(fuse):
            self.req_msgs.append(self.fuse)
        self._battle_time = 0
        random.shuffle(self.req_msgs)

    def start(self):
        gevent.sleep(random.uniform(0, 1))
        self.create_player()
        for func in self.req_msgs:
            gevent.sleep(random.uniform(*self.req_interval))
            func()

    def post_message(self, msg, resp_msg=None, sub_url="player"):
        global success, fail
        sub_url = sub_url.strip("/")
        url_param = [base_url, sub_url]
        if "player" == sub_url:
            assert self.session_id is not None, "Missing session_id."
            url_param.append(self.session_id)
        url_param.append("")
        url = "/".join(url_param)
        name = type(msg).__name__
        data = {"name": name,
                "body": generate_message(msg)}
        payload = urllib.urlencode(data)
        req = urllib2.Request(url, payload)
        start_t = time.time()
        resp = urllib2.urlopen(req).read()
        if resp_msg:
            try:
                ret = resp_msg.FromString(base64.b64decode(resp))
                period = round((time.time() - start_t), 2)
                print self.session_id, name, len(resp), success, period
                success += 1
                return ret
            except Exception, e:
                period = round((time.time() - start_t), 2)
                print self.session_id, name, resp, fail, period, e
                fail += 1
        else:
            return resp

    def create_player(self, pre_device_id=None):
        """
        LoginAccount to create a player and return the session id
        """
        acc = LoginAccount()
        acc.device_id = "stress_test_%s" % self.player_index
        acc.type = SignType.Value("DEVICE")
        acc.os_type = OSType.Value("IOS")
        if pre_device_id:
            acc.pre_device_id = pre_device_id
        msg = self.post_message(acc, LoginAccountRep, "account")
        player_id = msg.player_info.userId
        player_ids.add(player_id)
        self.session_id = msg.session_id

    def link_account(self):
        l_acc = LinkAccount()
        l_acc.device_id = "stress_test_%s" % self.player_index
        l_acc.pip_id = str(self.player_index * 10000)
        l_acc.type = random.choice(SignType.values())
        self.post_message(l_acc, LinkAccountRep)

    def retrieve_settings(self):
        # TODO - sleep
        self.post_message(RetrieveWorld(), RetrieveWorldRep)
        self.post_message(RetrieveCreatureType(), RetrieveCreatureTypeRep)
        self.post_message(GetGlobalConfigs(), GlobalConfigs)
        self.post_message(GachaTrees(), GachaTreesRep)
        self.post_message(GetEventsConfigs(), EventsConfigs)

    def do_battle(self):
        self.post_message(GetHelper(), GetHelperRep)
        begin = BattleBegin()
        begin.dungeonID = dungeon_ids[self._battle_time]
        begin.leader_id = 1
        resp = self.post_message(begin, BattleBeginRep)
        gevent.sleep(random.randint(20, 30))
        if random.choice([True, False]):
            end = BattleEnd()
            end.battle_key = resp.battle_key
            end.win = True
            end.turns = 8
            end.dungeonID = begin.dungeonID
            self.post_message(end, BattleEndRep)
            self._battle_time += 1
            self._battle_time %= len(dungeon_ids)

    def gacha(self):
        buy_nut = BuyNut()
        buy_nut.tree_slug = random.choice(tree_slug)
        resp = self.post_message(buy_nut, BuyNutRep)
        open_nut = OpenNut()
        if resp.result_code == BuyNutResultCode.Value("BUY_NUT_SUCCESS"):
            open_nut.nut_id.append(resp.egg[0].id)
        else:
            open_nut.nut_id.append(random.randint(1, 100))
        self.post_message(open_nut, OpenNutRep)

        # old gacha
        # gacha = GachaShake()
        # gacha.tree_slug = random.choice(gacha_slugs)
        # gacha.is_big = random.choice([True, False])
        # self.post_message(gacha, GachaShakeRep)

    def fuse(self):
        fuse = Fuse()
        fuse.target.cid = random.choice(c_ids)
        feeders = []
        for cid in random.sample(c_ids, random.randrange(5)):
            c = CreatureInstance()
            c.cid = cid
            feeders.append(c)
        if feeders:
            fuse.feeders.extend(feeders)
        self.post_message(fuse, FuseRep)

    def evolve(self):
        evolve = Evolve()
        evolve.target.cid = random.choice(c_ids)
        self.post_message(evolve, EvolveRep)

    def sell(self):
        sell = SellCreature()
        sell.target.cid = random.choice(c_ids)
        self.post_message(sell, SellCreatureRep)

    def modify_friend(self):
        return
        # modify_friend = ModifyFriend()
        # modify_friend.friend_id = random.randrange(len(player_ids))
        # modify_friend.action = random.choice(FriendAction.values())
        # self.post_message(modify_friend, ModifyFriendRep)

    def convert_material(self):
        convert = ConvertMaterial()
        convert.amount = 2
        to_slug = random.choice(material_slugs)
        from_slug = random.choice(material_conv.get(to_slug) or material_slugs)
        convert.to_slug = to_slug
        convert.from_slug = from_slug
        self.post_message(convert, ConvertMaterialRep)

    def edit_team(self):
        edit = Teams()
        teams = []
        for _ in range(random.randrange(1, 5)):
            t = Team()
            t.creaturesIds.extend(random.sample(c_ids, 3))
            teams.append(t)
        edit.team.extend(teams)
        self.post_message(edit, EditTeamRep)

    def buy_creature_space(self):
        self.post_message(BuyCreatureSpace(), BuyCreatureSpaceRep)

    def add_energy(self):
        self.post_message(AddEnergy(), AddEnergyRep)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Delta stress test",
                                     add_help=False)
    parser.add_argument("--url", default=base_url,
                        help="The server's url(default: %(default)s).")
    p_help = "How many players to test(default: %(default)s)."
    parser.add_argument("-p", "--player_num", default=100, type=int,
                        help=p_help)
    pi_help = "Player index start number(default: %(default)s)."
    parser.add_argument("-pi", "--player_index_start", default=0, type=int,
                        help=pi_help)
    b_help = "Times of each player battle(default: %(default)s)."
    parser.add_argument("-b", "--battle", default=50, type=int,
                        help=b_help)
    g_help = "Times of each player gacha(default: %(default)s)."
    parser.add_argument("-g", "--gacha", default=10, type=int,
                        help=g_help)
    f_help = "Times of each player fuse(default: %(default)s)."
    parser.add_argument("-f", "--fuse", default=5, type=int,
                        help=f_help)
    e_help = "Times of each player evolve(default: %(default)s)."
    parser.add_argument("-e", "--evolve", default=2, type=int,
                        help=e_help)
    s_help = "Times of each player sell creature(default: %(default)s)."
    parser.add_argument("-s", "--sell", default=5, type=int,
                        help=s_help)
    bc_help = "Times of each player buy creature space(default: %(default)s)."
    parser.add_argument("-bc", "--buy_creature_space", default=1, type=int,
                        help=bc_help)
    a_help = "Times of each player buy energy(default: %(default)s)."
    parser.add_argument("-a", "--add_energy", default=4, type=int,
                        help=a_help)
    c_help = "Times of each player convert materials(default: %(default)s)."
    parser.add_argument("-c", "--convert_material", default=1, type=int,
                        help=c_help)
    m_help = "Times of each player modify friends(default: %(default)s)."
    parser.add_argument("-m", "--modify_friend", default=1, type=int,
                        help=m_help)
    et_help = "Times of each player edit team(default: %(default)s)."
    parser.add_argument("-et", "--edit_team", default=2, type=int,
                        help=et_help)
    parser.add_argument("--help", action="help",
                        help="Show this help message.")

    args = parser.parse_args()
    base_url = args.url
    prepare()
    kwargs = vars(args)
    start = args.player_index_start
    end = start + args.player_num
    jobs = []
    for index in range(start, end):
        p = MockedPlayer(index, **kwargs)
        jobs.append(gevent.spawn(p.start))
    print "Start stress tests..."
    gevent.joinall(jobs)
    time_spend = time.time() - start

    if args.player_num > 0:
        print_msg = ("Finish in %s, %s players, each player do:" %
               (time_spend, args.player_num))
        for key, val in kwargs.iteritems():
            if key in ["player_num", "url", "help", "player_index_start"]:
                continue
            print_msg += "\n    %s: %s" % (key, val)
        print print_msg
