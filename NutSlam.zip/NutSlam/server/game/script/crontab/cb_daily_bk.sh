# daily backup couchbase on nuts-cb1, upload to s3, and set the rule on s3, only keep 7 days.
# 01 01 * * *

rm -r /opt/bk/*
/opt/couchbase/bin/cbbackup http://localhost:8091 /opt/bk/ -m full -u Administrator -p gojirra2011
/usr/local/bin/aws s3 sync /opt/bk/ s3://hl-delta-live/backups/couchbase/