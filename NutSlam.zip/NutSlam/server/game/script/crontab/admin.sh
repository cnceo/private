# daily backup couchbase on nuts-cb1, upload to s3, and set the rule on s3, only keep 7 days.
# 01 01 * * *


01 01 * * * cd /app; python script/live_player_on_beta.py reward >> reward.log