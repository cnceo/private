import argparse
from time import sleep
from common import add_script_path
add_script_path()

from utils.settings import LEDGERS_BUCKET
from utils.settings import COUCHBASE_BUCKET
from models.player import id_count
from models.player import player_id_initial
from models.player import Player


def do_merge(player_id):
    ledgers_info = {}
    for l_cls in Player.ledger_map.itervalues():
        ledgers = []
        # load from normal bucket
        l_cls._db_type = COUCHBASE_BUCKET
        for l in l_cls.load_by_attribute("player_id", player_id):
            # save to ledger bucket
            l_cls._db_type = LEDGERS_BUCKET
            l._db_type = LEDGERS_BUCKET
            l.store()
            # delete from normal bucket
            l_cls._db_type = COUCHBASE_BUCKET
            l._db_type = COUCHBASE_BUCKET
            l.delete()
            ledgers.append(l.id)
        if ledgers:
            ledgers_info[l_cls.__name__] = ledgers
    return ledgers_info


def update_players(start_pid=player_id_initial):
    if start_pid < player_id_initial:
        start_pid = player_id_initial
    for p_id in range(start_pid, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist():
            l_info = do_merge(p_id)
            if l_info:
                print "Merge ledgers for player: %s" % p.id, l_info
                sleep(.5)


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="merge-ledger")
    parser.add_argument("-s", "--start_pid", default=player_id_initial,
                        type=int)
    args = parser.parse_args()
    update_players(args.start_pid)