from gevent import monkey
monkey.patch_all()
import gevent

from common import add_script_path
add_script_path()

import argparse
import codecs
import csv
from dal.base import KeyValue
from models.player import DeviceLink
from models.player import Player
from models.player import id_count
from models.player import player_id_initial
from utils.constants import TRANS_TYPE
from utils.protocol_pb2 import OSType


android = OSType.Value("Android")

# need touch these two files in case of first run
device_player = "live_players_device.csv"
gp_player = "live_players_gp.csv"

gems = 10
pn_msg = ("Sorry about the login problems this weekend. "
          "Please accept 10 gems as a gift.")
rewarded_players = KeyValue("BETA_Android_GEMS")


# collect players from beta
def collect():
    for p_id in range(player_id_initial, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist() and p.os_type == android:
            val = p.gp_id or p.device_id
            if p.gp_id:
                out_file = gp_player
            else:
                out_file = device_player
            if val:
                with codecs.open(out_file, "a", "utf-8") as csv_f:
                    print >> csv_f, val


# reward players on live
def get_rewarded_p():
    return rewarded_players.load() or []


def update_rewarded_p(player_id):
    rewarded = get_rewarded_p()
    rewarded.append(player_id)
    rewarded_players.store(rewarded)


def get_player_by_device_id(device_id):
    device = DeviceLink(device_id=device_id)
    player_id = device.player_id
    if player_id:
        player = Player(id=player_id)
        if player.exist():
            return player
    players = Player.load_by_attribute("device_id", device_id)
    return players and players[-1]


def do_reward_player(player):
    if player.id in get_rewarded_p():
        return
    print "do reward player", player.id
    player.update_gems(10, TRANS_TYPE.SUPPORT,
                       reason="Live AGC players on beta.")
    player.store()
    player.send_pn(pn_msg)
    update_rewarded_p(player.id)


def reward():
    with codecs.open(device_player, "r", "utf-8") as d_f:
        rows = csv.reader(d_f)
        for r in rows:
            d_id = r[0]
            p = get_player_by_device_id(d_id)
            if p:
                do_reward_player(p)

    with codecs.open(gp_player, "r", "utf-8") as gp_f:
        rows = csv.reader(gp_f)
        for r in rows:
            gp_id = r[0]
            p = Player.load_by_attribute("gp_id", gp_id)
            p = p and p[0]
            if p:
                do_reward_player(p)

    # wait for pn send out.
    gevent.sleep(60)


# clear rewarded players
def clear_rewarded_player():
    print "Rewarded player list:", get_rewarded_p()
    rewarded_players.delete()


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="warnuts")
    parser.add_argument("action", choices=["collect", "reward", "clear"],
                        help="")
    args = parser.parse_args()
    if "collect" == args.action:
        collect()
    elif "reward" == args.action:
        g = gevent.spawn(reward)
        g.start()
        g.join()
    elif "clear" == args.action:
        clear_rewarded_player()
    else:
        print "Unknow action %s" % args.action
