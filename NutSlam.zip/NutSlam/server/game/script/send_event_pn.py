#!/usr/bin/python


from gevent import monkey
monkey.patch_all()
import gevent
from common import add_script_path


add_script_path()


from actors.event_pn import SendEventsPN
from utils.settings import ENABLE_PN
from utils.settings import IS_PRODUCTION


def _pn_enable():
    return IS_PRODUCTION and ENABLE_PN


def start_pn():
    if not _pn_enable():
        ep = SendEventsPN.get()
        ep.tell({})


if __name__ == "__main__":
    if not _pn_enable():
        exit()
    g = gevent.spawn(start_pn)
    g.start()
    g.join()
    while True:
        gevent.sleep(60 * 60)
