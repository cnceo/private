import random
from models.content import GameRule
from models.player import Player
from models.active_player import ActivePlayerHelper
from utils.settings import FB_SAMPLE_ID


starRating = 2
# use agc_id to identify players, so agc_id must be different
players = [{"name": "Yan Shanshan", "agc_id": "sample_1",
            "facebook_id": FB_SAMPLE_ID},
           {"name": "Philip Beck", "agc_id": "sample_2",
            "facebook_id": FB_SAMPLE_ID},
           {"name": "Ben Holmes", "agc_id": "sample_3",
            "facebook_id": FB_SAMPLE_ID},
           {"name": "Cindy Chen", "agc_id": "sample_4",
            "facebook_id": FB_SAMPLE_ID},
           {"name": "Barack Obama", "agc_id": "sample_5"},
           {"name": "Fan Bingbing", "agc_id": "sample_6"},
           {"name": "Kate Upton", "agc_id": "sample_7"},
           {"name": "Steve Jobs", "agc_id": "sample_8"},
           ]

gods = [
    {"name": "Michael Jordan",
     "agc_id": "god_1",
     "gp_id": "god_1",
     "device_id": "god_1",
     "facebook_id": FB_SAMPLE_ID,
     "coins": 10000000,
     "energy": 1000,
     "gems": 10000000,
     "hearts": 100,
     "level": 30,
     "max_creatures": 200,
     "progress": 999,
     "stone_dark_l": 1000,
     "stone_dark_s": 1000,
     "stone_fire_l": 1000,
     "stone_fire_s": 1000,
     "stone_l": 1000,
     "stone_light_l": 1000,
     "stone_light_s": 1000,
     "stone_m": 1000,
     "stone_s": 1000,
     "stone_water_l": 1000,
     "stone_water_s": 1000,
     "stone_wood_l": 1000,
     "stone_wood_s": 1000,
     "stone_x": 1000},

    {"name": "Karl Malone",
     "agc_id": "G:1303821772",
     "device_id": "G:1303821772",
     "facebook_id": FB_SAMPLE_ID,
     "coins": 10000000,
     "energy": 1000,
     "gems": 10000000,
     "hearts": 10000000,
     "level": 30,
     "max_creatures": 200,
     "progress": 999,
     "stone_dark_l": 1000,
     "stone_dark_s": 1000,
     "stone_fire_l": 1000,
     "stone_fire_s": 1000,
     "stone_l": 1000,
     "stone_light_l": 1000,
     "stone_light_s": 1000,
     "stone_m": 1000,
     "stone_s": 1000,
     "stone_water_l": 1000,
     "stone_water_s": 1000,
     "stone_wood_l": 1000,
     "stone_wood_s": 1000,
     "stone_x": 1000}
]
creatures = None


def gen_creatures(full=False):
    return [(c.slug, {"level": c.maxLevel})
            for c in GameRule.creature_types.all()
            if c.starRating == starRating or full is True]


def random_creatures():
    global creatures
    if not creatures:
        creatures = gen_creatures()
    c = random.choice(creatures)
    creatures.remove(c)
    return [c]


def init_player(attr, god=False):
    p = Player.load_by_attribute("agc_id", attr.get("agc_id"))
    p = p and p[0]
    if not p:
        # create players if player not exist
        if god:
            params = {"default_creatures": gen_creatures(full=True),
                      "is_new": True}
        else:
            params = {"default_creatures": random_creatures(),
                      "is_new": True}
        params.update(attr)
        p = Player(**params)
        p.store()
    a = ActivePlayerHelper()
    a.update(p)


def create_sample_players():
    for p_info in players:
        init_player(p_info)
    for g_info in gods:
        init_player(g_info, god=True)
