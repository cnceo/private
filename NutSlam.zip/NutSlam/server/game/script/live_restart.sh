#!/bin/bash

docker-compose -f /root/warnuts/server/etc/production.yml stop
docker-compose -f /root/warnuts/server/etc/production.yml build
docker-compose -f /root/warnuts/server/etc/production.yml up -d