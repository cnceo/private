. ../../env.sh
game python script/content.py gen_asset
cp ../assetbundle/*.txt ../../../client/Assets/ResourcesForStreaming/content