from gevent import monkey
monkey.patch_all()
import gevent

from common import add_script_path
add_script_path()

import argparse
from utils.protocol_pb2 import EggType
from utils.protocol_pb2 import GiftType
from dal.base import KeyValue
from models.gift import GiftInbox
from models.player import Player
from models.player import player_id_initial
from models.player import id_count

gems = 200
e_type = EggType.Value("GEM_EGG")
g_type = GiftType.Value('ADMIN_MSG')
msg = "Goodbye gift - Game will shut down March 25"
pn_msg = "You got a 200 gem goodbye gift"
max_player_id = id_count.load()


def do_reward_player(player_id):
    goodbye = KeyValue("Goodbye:%s"%player_id)
    if goodbye.exist():
        print 'already send:%s' % player_id
        return
    print 'send gift: %s' % player_id
    inbox = GiftInbox(player_id=player_id)
    inbox.give_gift(g_type, player_id, e_type, gems,
                    message=msg, pn_msg=pn_msg)
    goodbye.store('1')
    gevent.sleep(1)

def goodbye_gift(start_pid, end_pid):
    if start_pid < player_id_initial:
        start_pid = player_id_initial
    if end_pid > max_player_id:
        end_pid = max_player_id
    for pid in range(start_pid, end_pid):
        p = Player(id=pid)
        if p.exist():
            do_reward_player(pid)


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="google_gift")
    parser.add_argument("-s", "--start_pid", default=player_id_initial,
                        type=int)
    parser.add_argument("-e", "--end_pid", default=max_player_id,
                        type=int)
    args = parser.parse_args()

    g = gevent.spawn(goodbye_gift, args.start_pid, args.end_pid)
    g.start()
    g.join()