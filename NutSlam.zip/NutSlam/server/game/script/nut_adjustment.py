import argparse
from time import sleep
from common import add_script_path
add_script_path()

from models.creature import Nuts
from models.player import id_count
from models.player import player_id_initial
from models.player import Player


# free to update this map if you have new rule.
adjust_map = {
    # <old_slug> : <new_slug>
    "silver_nut_dark": "silver_nut",
    "silver_nut_fire": "silver_nut",
    "silver_nut_light": "silver_nut",
    "silver_nut_water": "silver_nut",
    "silver_nut_wood": "silver_nut",

    "wood_nut_dark": "wood_nut",
    "wood_nut_fire": "wood_nut",
    "wood_nut_light": "wood_nut",
    "wood_nut_water": "wood_nut",
    "wood_nut_wood": "wood_nut",
}


def do_update(player_id):
    msg = []
    for nid in Nuts.load_oids_by_attribute("player_id", player_id):
        nut = Nuts(player_id=player_id, cid=nid)
        nut_slug = adjust_map.get(nut.nut)
        if nut_slug:
            msg.append("nut(%s) from %s to %s" % (nid, nut.nut, nut_slug))
            nut.nut = nut_slug
            nut.store()
    return msg


def update_players(start_pid):
    if start_pid < player_id_initial:
        start_pid = player_id_initial
    for p_id in range(start_pid, id_count.load() + 1):
        p = Player(id=p_id)
        if p.exist():
            msgs = do_update(p_id)
            if msgs:
                print ("Adjust nut slug for player: %s, details:\n    %s" %
                       (p.id, ";\n    ".join(msgs)))
                sleep(0.5)


if "__main__" == __name__:
    parser = argparse.ArgumentParser(prog="Nut-slug")
    parser.add_argument("-s", "--start_pid", default=player_id_initial,
                        type=int)
    args = parser.parse_args()
    update_players(args.start_pid)