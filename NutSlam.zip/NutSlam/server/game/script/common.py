import os
import sys


def add_pythonpath(path, relative=''):
    abspath = os.path.dirname(os.path.realpath(path))
    abspath = os.path.join(abspath, relative)
    abspath = os.path.realpath(abspath)
    if abspath not in sys.path:
        sys.path.insert(1, abspath) # Insert after PWD.


def add_script_path():
    add_pythonpath(__file__, '../')
    add_pythonpath(__file__)