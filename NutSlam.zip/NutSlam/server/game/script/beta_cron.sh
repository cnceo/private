cd ~/delta/
git checkout .
git checkout develop
git pull
git checkout cloud
git pull
git merge develop -m 'auto merge from beta server'
git push


cd ~/delta/common/assetbundle
python prepare_resource.py beta

cd ~/delta/server
fig stop
fig up -d

container_id=`docker ps -a|grep server_game|awk '{print $1}'`
docker exec -it $container_id python script/content.py download
fig stop
fig up -d
container_id=`docker ps -a|grep server_game|awk '{print $1}'`
docker exec -it $container_id python script/content.py upload,beta

