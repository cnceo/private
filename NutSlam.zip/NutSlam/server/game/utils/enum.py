class Enum(object):

    def __init__(self):
        self._members = {}
        self._members_rev = {}

    def _internal_attr(self, name):
        return name.startswith("_")

    def __getattr__(self, name):
        if self._internal_attr(name):
            return super(Enum, self).__getattribute__(name)
        return self._members.get(name)

    def __setattr__(self, name, value):
        if self._internal_attr(name):
            super(Enum, self).__setattr__(name, value)
        else:
            assert name not in self._members, "Duplicate name: %s" % name
            assert value not in self._members_rev, "Duplicate val: %s" % value
            self._members[name] = value
            self._members_rev[value] = name

    def name(self, val):
        return self._members_rev.get(val)
