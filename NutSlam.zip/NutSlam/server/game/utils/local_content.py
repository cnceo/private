from threading import local


class WrapperLocal(local):
    def get(self, key, default=None):
        return getattr(self, key, default)


lct = WrapperLocal()