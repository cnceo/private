import logging
from utils.protocol_pb2 import OSType
from os import getenv
from ast import literal_eval
from utils.enum import Enum
def getenv_py(*args, **kw): return literal_eval(getenv(*args, **kw))


VERSION = 00001

USE_HTTPS = False
LISTEN_HOST = '0.0.0.0'	# listen on all, use docker to map to external IP
LISTEN_PORT = 8080

APP_ID = 1071596179536136
SITE_NAME = 'Nut Slam'
NUTSSLAM_FACEBOOK_URL = "https://www.facebook.com/gonutslam"
#APP_URL = getenv("APP_URL", "https://warnuts-app.happylatte.com/")
TRANSPORT_HTTP = 'HTTP'
TRANSPORT_SOCKETIO = 'SOCKETIO'
APP_URL = getenv("APP_URL", "")
APP_TRANSPORT = getenv("APP_TRANSPORT", TRANSPORT_HTTP)

LOG_LEVEL = logging.DEBUG


# Unity Analyics Product ID
UNITY_ANALYTICS_APP_ID = '6dc879bd-8b2e-4371-af24-abc4989cda50'


# =================== DataBase ==================
COUCHBASE_BUCKET = getenv("COUCHBASE_BUCKET", "CouchbaseBucket")
MEMCACHED_BUCKET = getenv("MEMCACHED_BUCKET", "MemcachedBucket")
LEDGERS_BUCKET = getenv("LEDGERS_BUCKET", "LedgersBucket")

SUPPORTED_BUCKETS = [COUCHBASE_BUCKET, MEMCACHED_BUCKET, LEDGERS_BUCKET]

COUCHBASE_HOST = getenv("COUCHBASE_HOST",
    getenv("COUCHBASE_PORT_8091_TCP_ADDR", "localhost"))
COUCHBASE_PORT = getenv("COUCHBASE_PORT_8091_TCP_PORT", 8091)

USE_CACHE = False  # True
# =================== DataBase end ==============


# ============= Facebook settings ===============
# Facebook mock up - We didn't implement facebook stuff,
# on local we mockup sample player as FB players with same facebook_id
FB_SAMPLE_ID = "1"
# ============= Facebook settings end ===========


# ============= IAB/IAP settings ================
# live
# INAPP_PURCHASE_VERIFY_URL = 'https://buy.itunes.apple.com/verifyReceipt'
INAPP_PURCHASE_VERIFY_URL = 'https://sandbox.itunes.apple.com/verifyReceipt'
INAPP_PURCHASE_SANDBOX_VERIFY_URL = 'https://sandbox.itunes.apple.com/verifyReceipt'
IAP_VERIFY_TIMEOUT = 60
VERIFY_PENDING_TTL = 60 * 30

UNITY3D_FLAG = "_UNITY3D_"
# ============= IAB/IAP settings end ================


# ============= Stats settings ======================
STATS_ZMQ_HOST = "127.0.0.1"
STATS_ZMQ_PORT = 5556
# ============= Stats settings end ==================


# ============= Content settings ======================
EXTRACT_CONTENT = True
AUTO_RELOAD_CONTENT = True
FULL_EVENTS = False
CUSTOM_RESOURCE_UPDATEER_PATH = ''
# Auto reload content from db.
LOAD_CONTENT_INTERVAL = 60 * 60 * 2

CONTENT_VERSION_NAVI_KEY = '17rC-9sXDCtG9GRc800WESPRFES-yecqUdTzvwUjaRm4'
CONTENT_VERSION_NAVI_ID = '0'
ASSET_VERSION_NAVI_ID = '508592491'

LOCALIZATION_NAVI_KEY = '1XEK14Ml9sclGzRAx3b_S6yJ39rM40MqR8Hmz3WrBbBw'
L10N_MSG_SPLIT = "<alt>"

L10N_FILE_NAME = "L10N_%s"
L10N_EVENT_NAME = "event_name"
L10N_CREATURE_NAME = "creature_name"
L10N_SKILL = "skill"
L10N_CUSTOM = "custom"
L10N_SERVER = "server"
L10N_FILE_NAME_ID_MAP = {
    L10N_FILE_NAME % L10N_EVENT_NAME: 830218899,
    L10N_FILE_NAME % L10N_CREATURE_NAME: 1873576898,
    L10N_FILE_NAME % L10N_SKILL: 490916064,
    L10N_FILE_NAME % L10N_CUSTOM: 499034780,
    L10N_FILE_NAME % L10N_SERVER: 240584581,
}

ELEMENT_BEATEN_MAP = {
    'fire': 'water',
    'wood': 'water',
    'water': 'fire',
    'light': 'dark',
    'dark': 'light'
}


# ============= Content settings end ==================


# ============= Game settings ======================
# For running server test cases.
TEST_MODE = False
RELOAD_ENABLED = getenv_py("RELOAD_ENABLED", "True")

# For prepare sample data in local
IS_PRODUCTION = getenv_py("IS_PRODUCTION", "False")
RAISE_ON_UNMATCHED_PLAYER_INFO = True
ENERGY_TOLERANCE = 1

CACHE_RESPONSE = True
CACHED_RESPONSE_TTL = 60 * 60 * 24

# TODO - set to half an hour?, 1 day for testing now.
SESSION_TTL_DELTA = 60 * 60 * 24

# refresh player's timezone info every 3 days.
TIMEZONE_TTL_DELTA = 60 * 60 * 24 * 3
DEFAULT_UTC_OFFSET = 0
# store all exist utc_offsets in db
UTC_OFFSETS_KEY = "UTC_OFFSETS"
CHECK_NEW_UTC_OFFSETS = 60 * 60

ACTIVATE_PLAYER_NUMBER = 50
BATTLE_INVERVAL_MINI = 0
MAX_GACHA_AMOUNT = 10

STOP_PLAYER_DELAY = 60 * 5

SHARE_AKORNS_TTL = 60 * 60 * 6  # 6 hours

CACHE_HELPER_TTL = 60 * 60 * 24 * 7
# Player could thank the same player twice per day
THANK_SAME_HELPER_TTL = 60 * 60 * 24
# Player could send 2 thanks helper per hour if
# progress >= VERIFY_SEND_TANK_HELPER_PROGRESS
VERIFY_SEND_TANK_HELPER_PROGRESS = 15
SEND_THANK_HELPER_TTL = 60 * 60

# how many latest player store for helper using for each level
ACTIVE_PLAYER_COUNT_FACTOR = 2
# how many levels to search for each loop when find active players
ACTIVE_PLAYER_LEVEL_INTERVAL = 5

# How big actor queue should be before we start logging warnings
# Actors must call check_actor_size() in their on_queue()
ACTOR_QUEUE_WARN_SIZE = 50

EVENTS_END_BUFFER = 60 * 5  # 5 mins
EVENTS_START_BUFFER = 60 * 5
EVENT_END_TIME_OFFSET_SEC = 60
ENABLE_EVENTS = True
FAERIE_EGG   = 'FAERIE_EGG'
SELF_EGG     = 'SELF_EGG'
MATERIAL_EGG = 'MATERIAL_EGG'
COIN_EGG     = 'COIN_EGG'
GEM_EGG      = 'GEM_EGG'
NUT_EGG      = 'NUT_EGG'

AKORN_TREE_SLUG = "akorn"

EVENTS_DEFAULT_REFRESH_TIME = 120

EVENTS_SCHEDULE     = 'schedule'

EventsType = Enum()
EventsType.EVENTS_XP = 'xp'
# new dungeons
EventsType.EVENTS_WEEKDAY = 'weekday'
EventsType.EVENTS_D556 = 'dungeon556'
EventsType.EVENTS_D45 = 'dungeon45'
# old dungeons
EventsType.EVENTS_DROPRATE = 'droprate'
EventsType.EVENTS_ENERGY = 'energy'
EventsType.EVENTS_DUNGEON_LUCK = 'dungeon_luck'
EventsType.EVENTS_COIN = 'coin'
# upgrade
EventsType.EVENTS_UPGRADE = 'upgrade'
# gacha
EventsType.EVENTS_TREE_LUCK = 'tree_luck'
EventsType.EVENTS_FEATURE_TREE = 'feature_tree'
EventsType.EVENTS_THEME_TREE = 'theme_tree'
EventsType.EVENT_TREE = "event_tree"
EventsType.SPECIAL_GATCHA = "special_gatcha"

ENABLE_TEAM_ELEMENT_VERIFY = True

ENABLE_PN = False
# Notice: must run init_player_ahead_friends.py every time turn
#         NOTIFY_WHEN_FRIEND_PASS to True
NOTIFY_WHEN_FRIEND_PASS = True
EVENTS_PUSH_NOTIFICATION_TIME = {"hour": 8, "minute": 0}
EVENTS_BOSS = {"key": "dungeon_boss",
               "dungeon_type": [EventsType.EVENTS_D556, EventsType.EVENTS_D45]}

RECRUIT_FB_DAILY_PN_DELAY = 30  # seconds delay for send pn after got gift.

RECRUIT_FB_FRIEND_TTL_DAY = 1
RECRUIT_FB_FRIEND_DATE_FORMAT = "%Y%m%d"

DAILY_WARNUT_TIME = {"hour": 8, "minute": 0}
MIN_CREATURE_NUMBER = 3

default_amdin_msg = "Sys Admin"
ADMIN_KEY = 'n129e8hf23rvb38or32'


# refs https://app.asana.com/0/10142244250289/73352497493087
# Workaround unmatched player by ignoring limits
VERIFY_PLAYER_STATUS = False

DEVICE_CACHE_PN_TOKEN = True


GEM_MINUS_MAX = -1000
ENERGY_MINUS_MAX = -50
COINS_MINUS_MAX = -100000
HEART_MINUS_MAX = -50

# ============= Game settings end ==================


# ============= Push notification system ============
SNS_SERVER_URL = "http://sns.us-east-1.amazonaws.com/"
AWS_ACCESS_KEY_ID = 'AKIAIB6BNDKTDOL3CYLQ'
SNS_SIGNATURE_METHOD = 'HmacSHA256'
SNS_SIGNATURE_VERSION = '2'
SNS_VERSION = '2010-03-31'

SNS_APP_ARN = {
    'APN': 'arn:aws:sns:us-east-1:365926815421:app/APNS_SANDBOX/Warnuts',
    'GCM': 'arn:aws:sns:us-east-1:365926815421:app/GCM/Warnuts',
}
SNS_RETRIES = 3
SNS_RETRY_SLEEP = 2
# ============= Push notification system end ========



# ============= Partner Config Start ========
KOCHAVA_ANDROID_APP_ID = 'kowarnuts-for-android55d14762859bc'
KOCHAVA_IOS_APP_ID = 'kowarnuts-for-ios55d14633ed43d'
KOCHAVA_INSTALL_URL = 'http://control.kochava.com/v1/cpi/startup?device_id=%(device_id)s&app_id=%(app_id)s&origination_ip=%(origination_ip)s&device_ua=%(device_ua)s&device_id_type=%(device_id_type)s'


# ============= Partner Config End ========

try:
    from live_settings import *
except ImportError, e:
    pass

try:
    from local_settings import *
except ImportError, e:
    pass
