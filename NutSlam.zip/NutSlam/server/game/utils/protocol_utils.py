from google.protobuf.descriptor import FieldDescriptor as FD
from utils.exception import ParseError
from utils import protocol_pb2


_ftype2js = {
    FD.TYPE_DOUBLE: float,
    FD.TYPE_FLOAT: float,
    FD.TYPE_INT64: long,
    FD.TYPE_UINT64: long,
    FD.TYPE_INT32: int,
    FD.TYPE_FIXED64: float,
    FD.TYPE_FIXED32: float,
    FD.TYPE_BOOL: bool,
    FD.TYPE_STRING: unicode,
    # FD.TYPE_MESSAGE: pb2json,              #handled specially
    FD.TYPE_BYTES: lambda x: x.encode('string_escape'),
    FD.TYPE_UINT32: int,
    FD.TYPE_ENUM: int,
    FD.TYPE_SFIXED32: float,
    FD.TYPE_SFIXED64: float,
    FD.TYPE_SINT32: int,
    FD.TYPE_SINT64: long,
}


def pb2json(pb):
    """
    convert google.protobuf.descriptor instance to JSON string
    """

    js = {}
    for field, value in pb.ListFields():
        if field.type == FD.TYPE_MESSAGE:
            ftype = pb2json
        elif field.type in _ftype2js:
            ftype = _ftype2js[field.type]
        else:
            raise ParseError("Field %s.%s of type '%d' is not supported"
                             % (pb.__class__.__name__, field.name, field.type))
        if field.label == FD.LABEL_REPEATED:
            js_value = []
            for v in value:
                js_value.append(ftype(v))
        else:
            js_value = ftype(value)
        js[field.name] = js_value
    return {pb.DESCRIPTOR.name: js}


def build_enum_type(name):
    return '_' + name.upper()


def assign_value(inst, data, proto=protocol_pb2):
    for name, value in inst.DESCRIPTOR.fields_by_name.items():
        if not data or name not in data:
            continue
        attr = getattr(inst, name)
        if hasattr(attr, 'DESCRIPTOR'):
            assign_value(attr, data[name], proto)
        else:
            if type(data[name]) is list:
                l = []
                if hasattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type') and getattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type') is not None:
                    enum_type = getattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type').name
                    enum_inst = getattr(proto, build_enum_type(enum_type))
                    for d in data[name]:
                        d = enum_inst.values_by_name[d].number
                        l.append(d)
                elif hasattr(value.message_type, 'name') and getattr(value.message_type, 'name') is not None:
                    cls = getattr(proto, value.message_type.name)
                    for d in data[name]:
                        sub_inst = cls()
                        assign_value(sub_inst, d, proto)
                        l.append(sub_inst)
                else:
                    for d in data[name]:
                        l.append(d)
                getattr(inst, name).extend(l)
            else:
                if hasattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type') and getattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type') is not None:
                        enum_type = getattr(inst.DESCRIPTOR.fields_by_name[name], 'enum_type').name
                        enum_inst = getattr(proto, build_enum_type(enum_type))
                        #print name, data[name], inst, data
                        d = enum_inst.values_by_name[data[name]].number
                        setattr(inst, name, d)
                else:
                    if data[name] is not None:
                        setattr(inst, name, data[name])