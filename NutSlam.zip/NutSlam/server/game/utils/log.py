import inspect
import logging
import logstack
import simplejson as json
import structlog
from google.protobuf.reflection import GeneratedProtocolMessageType
from utils.settings import LOG_LEVEL
from utils.protocol_utils import pb2json
from utils.local_content import lct


def jsonify(*args, **kw):
    def jsonify_custom(o):
        # return JSON-serializable objects, or raise TypeError
        if isinstance(type(o), GeneratedProtocolMessageType):
            return pb2json(o)
    return json.dumps(*args, default=jsonify_custom, **kw)


class LogRenderer(structlog.processors.KeyValueRenderer):
    # Like structlog.processors.KeyValueRenderer but with event info in front
    str = basestring # remove for Pytohon 3.x+
    def __call__(self, _, level, event_dict, **kw):
        def _render(event=None, **kwargs):
            MAX_MULTILINE_EXCEPTIONS_LOG_LEVEL = logging.DEBUG
            # TODO: MAX_NONTRUNCATE_LOG_LEVEL = logging.DEBUG
            MAX_JSON_ATTR_LENGTH = 200
            if event is None: event = ''
            if not isinstance(event, str):
                event = jsonify(event)
            if not kwargs: return event
            if event:
                msg = event + " --"
            else:
                msg = ''
            exception = None
            for key,val in self._ordered_items(kwargs):
                if val is None: continue
                if key in ('exception',):
                    exception = val
                else:
                    val = jsonify(val)
                if key[-1:] == '_':
                    # magic attr - should be stripped (TODO: depending on loglevel)
                    del event_dict[key]
                    key = key[:-1]  # remove _ from end
                    # truncate if too long
                    if len(val) > MAX_JSON_ATTR_LENGTH:
                        val = val[:MAX_JSON_ATTR_LENGTH/4]+'...'+val[-1:]
                msg += " %s=%s" % (key, val)
            if exception:
                if LOG_LEVEL > MAX_MULTILINE_EXCEPTIONS_LOG_LEVEL:
                    # if less verbose than DEBUG, put stacktrace in JSON attr
                    msg += " exception="+jsonify(exception)
                else:
                    # otherwise, show as multi-line for easy reading
                    msg += " -- Exception:\n"+exception
            return msg
        return _render(**event_dict)


class BoundLogger(structlog.stdlib.BoundLogger):

    @property
    def instance(self):
        return lct.get("log", self)

    def bind(self, **kwargs):
        inst = super(BoundLogger, self.instance).bind(**kwargs)
        lct.log = inst
        return inst

    def _process_event(self, method_name, event, event_kw):
        return super(BoundLogger, self.instance)._process_event(
            method_name, event, event_kw)


class Logger(logging.RootLogger):

    def findCaller(self):
        # rewrite to get correct file_path, line_no, func_name
        st = inspect.stack()
        frame,filename,line_number,function_name,lines,index = st[6]
        return filename, line_number, function_name


structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeEncoder(encoding='utf-8', errors='backslashreplace'),
        LogRenderer(key_order=["player_id", "request_id", "version", "os_type", "session_id"]),
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=BoundLogger,
    cache_logger_on_first_use=True,
)


def setup_logger(logger=None):
    """
    Setup logger.
    """
    # TODO: couldn't we just call logging.getLogger() to get and use the root logger?
    if logger is None:
        root = Logger(LOG_LEVEL)
        logging.Logger.root = root
        logging.Logger.manager = logging.Manager(root)
        logger = root

    f = "%(asctime)s [%(process)d] [%(levelname)s] [%(pathname)s:%(lineno)s] %(message)s"
    formatter = logstack.Formatter(f)
    default_handler = logging.StreamHandler()
    default_handler.setFormatter(formatter)
    logger = structlog.wrap_logger(logger)
    logger.addHandler(default_handler)
    return logger


log = setup_logger()
log.msg = log.info
log.err = log.error
