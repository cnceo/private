import base64
import random
import time
import re
import logging
import simplejson

from datetime import datetime
from datetime import timedelta
from dateutil import parser
from dateutil import tz
from hashlib import md5
from pytz import utc
from utils import protocol_pb2
from utils.log import log
from utils.settings import BATTLE_INVERVAL_MINI
from utils.settings import DEFAULT_UTC_OFFSET
from utils.settings import COUCHBASE_HOST, COUCHBASE_PORT


def parse_message(name, body):
    try:
        cls = getattr(protocol_pb2, name)
    except Exception as e:
        log.info("parse_message: couldn't find event cls for '{}'".format(repr(name)), body=body)
        raise ServerError("Unknown event: '{}'".format(repr(name)))
    try:
        event = cls()
        msg=body
        Base64=base64.b64decode(msg)
        event.ParseFromString(Base64)
        return event
    except Exception, e:
        log.info("parse_message: malformed event '{}'".format(repr(e)), name=name, body=body)
        raise ServerError("Malformed event: '%s'" % (e,))


def generate_message(resp):
    # if actor returned an exception, re-raise it
    if (isinstance(resp, Exception)) or resp is None:
        raise ServerError("actor exception")
    _msg = resp.SerializeToString()
    #cnt = resp.ByteSize()
    #msg = base64.b64encode(_msg[:cnt])
    msg = base64.b64encode(_msg)
    return msg


def get_time_key():
    return int(time.time() * 1000000)


def verify_time_key(key):
    if not key: return False
    now = int(time.time() * 1000000)
    return True if now - key > 1000000 * BATTLE_INVERVAL_MINI else False


pattern = r'^.+\((?P<build>\d+)\)$'
def parse_version(version_str):
    return int(re.match(pattern, version_str).groupdict()['build'])


def random_number(number, key=None):
    if number < 1:
        return 0
    if key:
        random.seed(key)
    return random.randint(1, number)


def to_str(s, encoding='utf-8'):
    """
    Returns a bytestring version of 's', encoded as specified in 'encoding'.
    """
    if not isinstance(s, basestring):
        try:
            return str(s)
        except UnicodeEncodeError:
            if isinstance(s, Exception):
                # An Exception subclass containing non-ASCII data that doesn't
                # know how to print itself properly. We shouldn't raise a
                # further exception.
                return ' '.join([to_str(arg, encoding) for arg in s])
            return unicode(s).encode(encoding, errors='strict')
    elif isinstance(s, unicode):
        return s.encode(encoding, 'strict')
    elif s and encoding != 'utf-8':
        return s.decode('utf-8', 'strict').encode(encoding, 'strict')
    else:
        return s


def to_unicode(s, encoding='utf-8'):
    """
    Similar to smart_unicode, except that lazy instances are resolved to
    strings, rather than kept as lazy objects.
    """
    # Handle the common case first, saves 30-40% in performance when s
    # is an instance of unicode. This function gets called often in that
    # setting.
    if isinstance(s, unicode):
        return s
    if not isinstance(s, basestring,):
        if hasattr(s, '__unicode__'):
            s = unicode(s)
        else:
            try:
                s = unicode(str(s), encoding, errors='strict')
            except UnicodeEncodeError:
                if not isinstance(s, Exception):
                    raise
                # If we get to here, the caller has passed in an Exception
                # subclass populated with non-ASCII data without special
                # handling to display as a string. We need to handle this
                # without raising a further exception. We do an
                # approximation to what the Exception's standard str()
                # output should be.
                s = u' '.join([to_unicode(arg, encoding) for arg in s])
    elif not isinstance(s, unicode):
        # Note: We use .decode() here, instead of unicode(s, encoding,
        # errors), so that if s is a SafeString, it ends up being a
        # SafeUnicode at the end.
        s = s.decode(encoding, 'strict')
    return s


def datetime_to_int(date_time):
    return int(time.mktime(date_time.timetuple()))


def correct_json_string(s):
    s = s.replace('""', '"')
    s = s.replace('"{','{')
    s = s.replace('}"','}')
    s = s.replace('"[','[')
    s = s.replace(']"',']')

    s = s.replace(':",',':"",')
    s = s.replace(':"}',':""}')

    return s


def response_log(result_code, log_msg):
    log.info("%s - %s" % (result_code, log_msg.capitalize()))


def content_error(msg):
    log.error("[content_error] %s" % msg)


def content_log(msg, level=logging.ERROR):
    msg = "[content_%s] %s" % (logging.getLevelName(level).lower(), msg)
    log.log(level, msg)


def utc_now():
    return datetime.now(utc)


def local_now(utc_offset=DEFAULT_UTC_OFFSET):
    if utc_offset is None:
        utc_offset = DEFAULT_UTC_OFFSET
    return datetime.now(tz.tzoffset(None, utc_offset * 60))


def next_x_days(origin_date=None, days=0, utc_offset=None):
    if origin_date is None:
        origin_date = local_now(utc_offset)
    return origin_date + timedelta(days=days)


def time_of_day(origin_time=None, hour=None, minute=None, utc_offset=None):
    if origin_time is None:
        origin_time = local_now(utc_offset)
    if hour is None:
        hour = origin_time.hour
    if minute is None:
        minute = origin_time.minute
    return origin_time.replace(hour=hour, minute=minute,
                               second=0, microsecond=0)


def dateformat_with_utc_offset(utc_offset=DEFAULT_UTC_OFFSET):
    if utc_offset is None:
        utc_offset = DEFAULT_UTC_OFFSET
    prefix = utc_offset < 0 and '-' or '+'
    offset = abs(utc_offset)
    h, m = offset / 60 % 24, offset % 60
    return "%%s %s%02d%02d" % (prefix, h, m)


def parse_date(date_str, date_format):
    dt = parser.parse(date_format % date_str)
    return dt.astimezone(utc)


def material_egg_cmp(x, y):
    lx = len(x)
    ly = len(y)
    if lx < ly: return -1
    elif lx > ly: return 1
    else:
        if '_l' in x:
            if '_s' in y or '_m' in y: return -1
            elif '_l' in y: return 0
            else: return 1
        elif '_m' in x:
            if '_s' in y: return -1
            elif '_m' in y: return 0
            else: return 1
        elif '_s' in x:
            if '_s' in y: return 0
            else: return 1


def date_to_str(d, d_format="%Y-%m-%d %H:%M:%S"):
    return d and d.strftime(d_format) or ""


def to_bool(val):
    """
    convert val to boolen
        False value: False, 'False', 'false', 'F', 'f', 0, '0', None, 'None'
        True value: otherwise
    """
    if val in [False, 'False', 'false', 'F', 'f', 0, '0', None, 'None']:
        return False
    return True


def get_couchbase_url():
    return ("http://%s:%s/index.html#sec=documents&viewsBucket=CouchbaseBucket"
            % (COUCHBASE_HOST, COUCHBASE_PORT))


def string_to_int(string):
    h = md5(to_str(string))
    return int(h.hexdigest(), 16)


def gen_weight_list_map_list(weight_map, key_attr="creatureSlug",
                             val_attr="weight"):
    key_fun = lambda item: item.get(key_attr)
    val_fun = lambda item: item.get(val_attr)
    return gen_weight_list(weight_map, key_fun, val_fun, is_dict=False)


def gen_weight_list(weight_map, key_func=None, val_func=None, is_dict=True):
    if not key_func:
        key_func = lambda item: item[0]
    if not val_func:
        val_func = lambda item: item[1]

    weight = 0
    weight_list = []
    for _item in is_dict and weight_map.iteritems() or weight_map:
        ele = key_func(_item)
        w = val_func(_item)
        weight += w
        weight_list.append((weight, ele))
    return weight_list


def get_by_weight(weight_list, random_val):
    for weight, ele in weight_list:
        if random_val <= weight:
            return ele
    return None


def load_content_json(data, name):
    try:
        return simplejson.loads(data)
    except Exception, e:
        log.error("couldn't load %s" % name, data=data)
        raise


def wait_on_db():
    # try to connect to all of the DB buckets,
    # and don't return until successful
    from utils.settings import SUPPORTED_BUCKETS
    from dal import db
    for bucket in SUPPORTED_BUCKETS:
        log.info("waiting for db bucket: " + bucket)
        while True:
            try:
                db.db(bucket)
                break
            except Exception as e:
                log.warn(e)
                time.sleep(1)
                pass
    log.info("all buckets available - continuing")


from settings import ACTOR_QUEUE_WARN_SIZE
def check_actor_qsize(actor):
    qsize = actor.actor_inbox.qsize()
    if qsize > ACTOR_QUEUE_WARN_SIZE:
        log.warn("Actor queue buildup %s qsize=%d" % (str(actor.actor_ref), qsize))
    return qsize


class ServerError(Exception):
    status_code = 500

    def __repr__(self):
        return 'ServerError({})'.format(repr(self.message), self.status_code, repr(self.payload))

    def __init__(self, message, status_code=None, payload=None):
        Exception.__init__(self)
        self.message = message
        if status_code is not None:
            self.status_code = status_code
        self.payload = payload

    def to_dict(self):
        rv = dict(self.payload or ())
        rv['message'] = self.message
        return rv
