from pykka.gevent import GeventActor
from pykka import ActorRegistry


class GeventActorWrapper(GeventActor):

    @classmethod
    def get(cls):
        actor = ActorRegistry.get_by_class(cls)
        actor = actor and actor[0] or cls.start()
        return actor