
class UnsupportedPlayerAction(Exception):
    pass


class UnsupportedFriendAction(Exception):
    pass


class CreatureDisabledAction(Exception):
    def __init__(self, *args, **kwargs):
        slug = kwargs.get("slug")
        action = kwargs.get("action") or ""
        data = {"slug": slug, "action": action.capitalize()}
        msg = "%(action)s is disabled for creature_%(slug)s" % data
        super(CreatureDisabledAction, self).__init__(msg)


class ModelParentKeyMissingValue(Exception):
    def __init__(self, parent_key):
        msg = "Must specify %s since it is the parent key." % parent_key
        super(ModelParentKeyMissingValue, self).__init__(msg)


class SNSActionError(Exception):
    def __init__(self, data):
        msg = "Missing/unsupported action, data: %s" % str(data)
        super(SNSActionError, self).__init__(msg)


class PlayerAssignDisabled(Exception):
    def __init__(self, attr):
        msg = "Please use player.update_%s to modify %s" % (attr, attr)
        super(PlayerAssignDisabled, self).__init__(msg)


class UnmatchedPlayerInfo(Exception):
    def __init__(self, func, player_id, unmatched_data):
        msg = ("%s unmatched player_id=%s info=%s" %
               (func, player_id, unmatched_data))
        super(UnmatchedPlayerInfo, self).__init__(msg)


class ParseError(Exception):
    pass
