#!/usr/bin/python2.7 -u

from gevent import monkey ; monkey.patch_all()
from utils.log import log

from utils import settings
from utils.protocol_pb2 import AppTransport
from utils.protocol_pb2 import AppURLConfig

from app_game import build_request_message
from utils.misc import generate_message
from actors.account import Account
from actors.player import get_player, stop_player
from nuts_review.handler import NutsReviewResource
from fb_canvas.handler import FbCanvasResource

from flask import Flask, request, send_from_directory, redirect, session, render_template
from flask_socketio import SocketIO, emit, disconnect, join_room, leave_room, close_room, rooms


from app_game import app
socketio = SocketIO(app, async_mode='gevent',
                    #max_http_buffer_size=1000000000000,
                    #allow_upgrades=False,
                    #ping_timeout=600,
                    #ping_interval=2,
                    )
# debug=True, logger=True, engineio_logger=True,
# engineio_options={'logger':True})


# EVENTS
@socketio.on('connect')
def socketio_connect():
    session['nutsession'] = request.args.get('nutsession')
    log.info("socketio_connect session = " + session['nutsession'])
    session['version'] = request.args.get('version')
    session['build'] = request.args.get('build')
    session['platform'] = request.args.get('platform')

    # send the AppURLConfig as the first when connection established
    resp = AppURLConfig()
    resp.APP_URL = settings.APP_URL
    resp.transport = AppTransport.Value(settings.APP_TRANSPORT)
    rep = {'name': 'AppURLConfig', 'body': generate_message(resp)}
    emit('serverpush', rep)
    #gevent.spawn(socketio.emit, 'serverpush', rep)

@socketio.on('message')
def socketio_message(message):

    log.info("socketio_message: %s" % message['name'])
    log.info(session)
    msg = build_request_message(request, message, session.get('version'))
    if message['name'] == 'LoginAccount':
        account = Account.get()
        resp = account.ask(msg)
        session['nutsession'] = resp.session_id
        rep = {'name': resp.__class__.__name__, 'body': generate_message(resp)}

    else:
        player, pid, version = get_player(session.get('nutsession'), session.get('version'))
        if not player:
            rep = {'error': 'Need to login first'}
        else:
            resp = player.ask(msg)
            if resp:
                rep = {'name': resp.__class__.__name__, 'body': generate_message(resp)}
            else:
                rep = {'error': 'Server Error'}

        # TODO: if you remove player.stop,
        # Remember to remove check for Player._player in Player.player
        stop_player(player, pid)
    log.info("socketio_message reply: %s" % message['name'])

    return rep # send response as ack


@socketio.on('disconnect')
def socketio_disconnect():
    log.info("socketio_disconnect")
    #disconnect()

@socketio.on_error()        # Handles the default namespace
def socketio_error_handler(e):
    log.error('socketio_error_handler: >>>>>>>>>>>>>>>>>>>>>>>')
    log.error(e)

#
# http handlers
#
@app.route('/test/')
def _test():
    return 'OK'
@app.route('/log/')
def _log():
    return 'Logged!'
@app.route('/')
def _root():
    return redirect(settings.NUTSSLAM_FACEBOOK_URL)
nuts_review_handler = NutsReviewResource()
@app.route('/nuts/<slug>/', methods=['GET'])
def _nuts(slug=None):
    return nuts_review_handler.handle(slug)
fb_canvas_handler = FbCanvasResource()
@app.route('/fbcanvas/', methods=['GET', 'POST'])
def _fbcanvas():
    return fb_canvas_handler.handle()
@app.route('/assets/<path:path>', methods=['GET'])
def _assets(path):
    return send_from_directory('assets', path)
@app.route('/media/<path:path>', methods=['GET'])
def _media(path):
    return send_from_directory('media', path)
# Account handler
@app.route('/account/', methods=['POST'])
@app.route('/account/<version>/', methods=['POST'])
@app.route('/account/<version>/<build_num>/<os_type>/', methods=['POST'])
def _account(version=None, build_num=None, os_type=None):
    # deal with the client version
    msg = build_request_message(request, request.form, version)
    account = Account.get()
    resp = account.ask(msg)
    return generate_message(resp)
# message handler
@app.route('/player/<session_id>/', methods=['POST'])
@app.route('/player/<version>/<session_id>/', methods=['POST'])
def _player(session_id, version=None):
    player, pid, version = get_player(session_id, version)
    if not player:
        return "You need sign in to continue."
    msg = build_request_message(request, request.form, version, session_id)
    resp = player.ask(msg)
    # TODO: if you remove player.stop,
    # Remember to remove check for Player._player in Player.player
    stop_player(player, pid)
    return generate_message(resp)
