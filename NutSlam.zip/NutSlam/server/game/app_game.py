#!/usr/bin/python2.7 -u

from gevent import monkey ; monkey.patch_all()
from utils.log import log, setup_logger

import logstack
from actors.player import get_player, stop_player
from actors.account import Account
from actors.iap import HandlePendingIAP
from actors.stats import send_client_events
from actors.partners import  send_kochava_installs
from nuts_review.handler import NutsReviewResource
from fb_canvas.handler import FbCanvasResource
from script.sample_players import create_sample_players
from utils import settings
from utils.protocol_pb2 import AppTransport
from utils.protocol_pb2 import AppURLConfig
from utils.misc import parse_message, generate_message
from models.content import GameRule

from flask import Flask, request, send_from_directory, redirect, session, render_template

#from app_game_socketio import *

# NOTES:
# - content will only be extracted if create_app_with_sampledata is called
# TODO:
# - refactor into Flask blueprint
# - do we need AUTO_RELOAD_CONTENT?

app = Flask(__name__, template_folder="/app/")
app.config['SECRET_KEY'] = '1234jkl1324'
def create_app(**kw):
    setup_logger(app.logger)    # add custom logging handlers to Flask logger too
    GameRule.init(**kw)
    #extract=settings.EXTRACT_CONTENT,auto_reload=settings.AUTO_RELOAD_CONTENT
    iap = HandlePendingIAP.get()
    iap.tell({})
    return app


def create_app_with_sampledata(**kw):
    if settings.IS_PRODUCTION:
        log.critical('IS_PRODUCTION but trying to add sampledata - ignoring')
        app = create_app(**kw)
    else:
        log.warn('adding sample data')
        app = create_app(extract=True, **kw)
        create_sample_players()
    return app


def build_request_message(request, message, version=None, session_id=None):
    """<= IN
        request: { ip }
        message: { name, data:protobuf, game_stats:protobuf }
        version
    OUT =>
        { func: name, msg: {ip, version, data, game_stats} }
    """
    logstack.push("REQUEST HEADERS:  %s BODY/MESSAGE:  %s" %
                  (request.headers, str(message)))
    func = message.get("name")
    stats = message.get("game_stats") or message.get("stats")
    request_id = message.get("mid")
    msg = {
        "request": request,
        "request_id": request_id and int(request_id),
        "ip": request.access_route[0],   # understands proxies
        "version": version,
        "data": parse_message(func, message.get("body")),
    }
    if session_id:
        msg["session_id"] = session_id
    if stats:
        msg["game_stats"] = parse_message("Stats", stats)
    send_client_events(message, request.user_agent.string)
    send_kochava_installs(func, msg, request.user_agent.string)

    return {"func": func, "msg": msg}

#
# HTTP URL routes
#
@app.route('/test/')
def _test():
    # Called by ELB heartbeat to check if we're alive
    # TODO: Should do a bit more checking to ensure we're alive, e.g., database is working
    return 'OK'
@app.route('/log/')
def _log():
    return 'Logged!'
@app.route('/')
def _root():
    return redirect(settings.NUTSSLAM_FACEBOOK_URL)
nuts_review_handler = NutsReviewResource()
@app.route('/nuts/<slug>/', methods=['GET'])
def _nuts(slug=None):
    return nuts_review_handler.handle(slug)
fb_canvas_handler = FbCanvasResource()
@app.route('/fbcanvas/', methods=['GET', 'POST'])
def _fbcanvas():
    return fb_canvas_handler.handle()
@app.route('/assets/<path:path>', methods=['GET'])
def _assets(path):
    return send_from_directory('assets', path)
@app.route('/media/<path:path>', methods=['GET'])
def _media(path):
    return send_from_directory('media', path)
# Account / login
@app.route('/account/', methods=['POST'])
@app.route('/account/<version>/', methods=['POST'])
@app.route('/account/<version>/<build_num>/<os_type>/', methods=['POST'])
def _account(version=None, build_num=None, os_type=None):
    # deal with client version
    log.bind(version=version, build_num=build_num, os_type=os_type)
    msg = build_request_message(request, request.form, version)
    account = Account.get()
    #log.bind(player_id=account.pid) TODO: bind player id
    resp = account.ask(msg)
    return generate_message(resp)
# All gameplay
@app.route('/player/<session_id>/', methods=['POST'])
@app.route('/player/<version>/<session_id>/', methods=['POST'])
def _player(session_id, version=None):
    log.bind(version=version) #session_id=session_id
    player, pid, version = get_player(session_id, version)
    log.bind(player_id=pid)
    if not player:
        return ServerError("Player not logged in")
    msg = build_request_message(request, request.form, version, session_id)
    resp = player.ask(msg)
    # TODO: if you remove player.stop,
    # Remember to remove check for Player._player in Player.player
    stop_player(player, pid)
    return generate_message(resp)


# Enable views to throw exceptions with payload, e.g.,
# raise ServerError('This view is gone', status_code=410)
from utils.misc import ServerError
@app.errorhandler(Exception) #(ServerError)
def handle_server_error(error):
    from flask import jsonify
    if isinstance(error, ServerError):
        err_dict = error.to_dict()
        log.error(repr(error), exc_info=False)
        response = jsonify(error.to_dict())
        response.status_code = error.status_code
    else:
        log.error("View exception: "+repr(error), exc_info=True)
        response = jsonify(error.__dict__)
        response.status_code = 500
    return response


if __name__ == "__main__":
    # if run, just wait on db to be available, then exit
    from utils.misc import wait_on_db
    wait_on_db()
