====================
Core game tests
====================


  >>> session_id, msg = create_player()
  >>> player_id = msg.player_info.userId
  >>> player = Player(id=player_id)
  >>> gachas = GameRule.get_gacha()


Gacha Tree
====================

  >>> req = GachaTrees()
  >>> resp = post_message(req, GachaTreesRep, session_id=session_id)
  >>> resp.tree_slugs == gachas.slugs
  True


Gacha shake
====================

  >>> def mock_gacha_shake(tree_slug, is_big=False):
  ...     req = GachaShake()
  ...     if tree_slug:
  ...         req.tree_slug = tree_slug
  ...     req.is_big = is_big
  ...     return req


premium gacha:
  >>> small_tree = []
  >>> gacha_tree_types = len(gachas.slugs)
  >>> for t_slug in gachas.slugs:
  ...     gacha_type = gachas.type(t_slug)
  ...     if gacha_type != 'premium':
  ...         gacha_tree_types -= 1
  ...         continue
  ...     player = player.load()
  ...     player.gems = 0
  ...     player.store()
  ...     req = mock_gacha_shake(t_slug)
  ...     resp = post_message(req, GachaShakeRep, session_id=session_id)
  ...     small_tree.append((resp.result_code, len(resp.egg)))
  >>> gacha_code = GachaShakeResultCode.Value("GACHA_SHAKE_NOT_ENOUGH_GEMS")
  >>> small_tree == [(gacha_code, 0)] * gacha_tree_types
  True

  >>> small_tree = []
  >>> gacha_tree_types = len(gachas.slugs)
  >>> for t_slug in gachas.slugs:
  ...     gacha_type = gachas.type(t_slug)
  ...     if gacha_type != 'premium':
  ...         gacha_tree_types -= 1
  ...         continue
  ...     player = player.load()
  ...     player.gems = GameRule.prices.gacha(gacha_type)
  ...     player.store()
  ...     req = mock_gacha_shake(t_slug)
  ...     resp = post_message(req, GachaShakeRep, session_id=session_id)
  ...     small_tree.append((resp.result_code, len(resp.egg)))
  >>> gacha_code = (GachaShakeResultCode.Value("GACHA_SHAKE_SUCCESS"))
  >>> small_tree == [(gacha_code, 1)] * gacha_tree_types
  True

social gacha:
  >>> small_tree = []
  >>> gacha_tree_types = len(gachas.slugs)
  >>> for t_slug in gachas.slugs:
  ...     gacha_type = gachas.type(t_slug)
  ...     if gacha_type != 'social':
  ...         gacha_tree_types -= 1
  ...         continue
  ...     player = player.load()
  ...     player.hearts = 0
  ...     player.store()
  ...     req = mock_gacha_shake(t_slug)
  ...     resp = post_message(req, GachaShakeRep, session_id=session_id)
  ...     small_tree.append((resp.result_code, len(resp.egg)))
  >>> gacha_code = GachaShakeResultCode.Value("GACHA_SHAKE_NOT_ENOUGH_HEARTS")
  >>> small_tree == [(gacha_code, 0)] * gacha_tree_types
  True

  >>> small_tree = []
  >>> gacha_tree_types = len(gachas.slugs)
  >>> for t_slug in gachas.slugs:
  ...     gacha_type = gachas.type(t_slug)
  ...     if gacha_type != 'social':
  ...         gacha_tree_types -= 1
  ...         continue
  ...     player = player.load()
  ...     player.hearts = GameRule.prices.gacha(gacha_type)
  ...     player.store()
  ...     req = mock_gacha_shake(t_slug)
  ...     resp = post_message(req, GachaShakeRep, session_id=session_id)
  ...     small_tree.append((resp.result_code, len(resp.egg)))
  >>> gacha_code = (GachaShakeResultCode.Value("GACHA_SHAKE_SUCCESS"))
  >>> small_tree == [(gacha_code, 1)] * gacha_tree_types
  True


Battle Begin, Renewal & Battle End
====================================

  >>> def mock_battle_begin(z_slug=None, a_slug=None, d_id=None, leader_id=1, helper_id=None):
  ...     req = BattleBegin()
  ...     if z_slug:
  ...         req.zoneSlug = z_slug
  ...     if a_slug:
  ...         req.areaSlug = a_slug
  ...     if d_id:
  ...         req.dungeonID = d_id
  ...     req.leader_id = leader_id
  ...     if helper_id:
  ...         req.helper_id = helper_id
  ...     return req

  >>> dungeons = GameRule.get_world().dungeons
  >>> dungeon_id = random.choice(dungeons.keys())
  >>> dungeon_reward = dungeons.get(dungeon_id).get("reward")
  >>> dungeon_requirement = dungeons.get(dungeon_id).get("requirement")
  >>> required_energy = dungeon_requirement.get("energy")
  >>> required_progress = dungeon_requirement.get("progress")

  >>> friend = Friend(player_id)
  >>> fb_list = friend.get_facebook_list()
  >>> player_this = Player(id=player_id)
  >>> active_players = list(ActivePlayerHelper().get_by_level(player_this.level, 100, fb_list)[0])

Battle with unkonwn dungeon
  >>> player = player.load()
  >>> player.energy = required_energy
  >>> player.progress = required_progress
  >>> player.store()
  >>> req = mock_battle_begin(d_id=-11111)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...     "BATTLE_BEGIN_UNKNOWN_DUNGEON")
  True

Battle with not enough energy
  >>> _ = player.spend_energy(player.get_energy(), do_store=True)
  >>> req = mock_battle_begin(d_id=dungeon_id)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...     "BATTLE_BEGIN_FAIL_ENERGY")
  True

Battle not satisfy the progress
  >>> player = player.load()
  >>> player.energy = required_energy
  >>> player.progress = required_progress - 1
  >>> player.store()
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...     "BATTLE_BEGIN_FAIL_PROGRESS")
  True

Battle with unkonwn leader_id
  >>> player = player.load()
  >>> player.energy = required_energy
  >>> player.progress = required_progress
  >>> player.store()
  >>> req = mock_battle_begin(d_id=dungeon_id, leader_id=1111111111)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...      "BATTLE_BEGIN_LEADER_NOT_EXIST")
  True

Battle with max_creatures < creature_numbers
  >>> creature_number = len(CreatureInstance.load_oids_by_attribute(
  ...                       'player_id', player_id))

  >>> player = player.load()
  >>> player.energy = required_energy
  >>> player.progress = required_progress
  >>> player.max_creatures = creature_number - 1
  >>> player.store()
  >>> req = mock_battle_begin(d_id=dungeon_id)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...      "BATTLE_BEGIN_CAMP_BEYOND_SIZE")
  True

Do Battle - with active player as helper
  >>> helper_id = random.choice(active_players)
  >>> recently_h = RecentlyHelper(player_id, helper_id)
  >>> recently_h.key.delete()
  >>> recently_h.exist()
  False
  >>> player = player.load()
  >>> player.max_creatures = creature_number + 1
  >>> player.store()
  >>> req = mock_battle_begin(d_id=dungeon_id, helper_id=helper_id)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.result_code == BattleBeginRepResultCode.Value(
  ...      "BATTLE_BEGIN_SUCCESS")
  True
  >>> resp.xp == dungeon_reward.get("xp")
  True
  >>> resp.coins == dungeon_reward.get("softCurrency")
  True
  >>> resp.battle_key > 0
  True
  >>> resp.reward_hearts == GameRule.helper.active_reward()[0]
  True
  >>> recently_h.exist()
  False

# Do Battle - with not recently used facebook friends as helper
  >>> player = player.load()
  >>> player.energy = required_energy * 2
  >>> player.store()
  >>> helper_id = random.choice(fb_list)
  >>> recently_h = RecentlyHelper(player_id, helper_id)
  >>> recently_h.key.delete()
  >>> recently_h.exist()
  False
  >>> req = mock_battle_begin(d_id=dungeon_id, helper_id=helper_id)
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.reward_hearts == GameRule.helper.fb_reward()[0]
  True
  >>> recently_h.exist()
  True

# Do Battle - with recently used facebook friends as helper
  >>> resp = post_message(req, BattleBeginRep, session_id=session_id)
  >>> resp.reward_hearts
  0
  >>> battle_key = resp.battle_key


Battle and Renewal
  >>> def mock_renewal(battle_key=None):
  ...     renewal = Renewal()
  ...     if battle_key:
  ...         renewal.battle_key = battle_key
  ...     return renewal

Renewal without battle_key
  >>> req = mock_renewal()
  >>> resp = post_message(req, RenewalRep, session_id=session_id)
  >>> resp.result_code == RenewalResultCode.Value("RENEWAL_MISSING_BATTLE_KEY")
  True

Renewal with not engough gems
  >>> req = mock_renewal(battle_key=battle_key)
  >>> resp = post_message(req, RenewalRep, session_id=session_id)
  >>> resp.result_code == RenewalResultCode.Value("RENEWAL_NOT_ENOUGH_GEMS")
  True

Do Renewal
  >>> player = player.load()
  >>> player.gems += GameRule.prices.revive_cost()
  >>> player.store()
  >>> resp = post_message(req, RenewalRep, session_id=session_id)
  >>> resp.result_code == RenewalResultCode.Value("RENEWAL_SUCCESS")
  True
  >>> player = player.load()
  >>> player.gems == 0
  True

  >>> def mock_battle_end_m(dungeon=None, win=None, turns=None, battle_key=None):
  ...     req = BattleEnd()
  ...     if dungeon: req.dungeonID = dungeon
  ...     if win: req.win = win
  ...     if turns: req.turns = turns
  ...     if battle_key: req.battle_key = battle_key
  ...     req.helper_id = helper_id
  ...     return req

Battle end with unknown dungeon
  >>> req = mock_battle_end_m(dungeon=dungeon_id-1000000, win=False, turns=12, battle_key=battle_key)
  >>> resp = post_message(req, BattleEndRep, session_id=session_id)
  >>> resp.result_code == BattleEndRepResultCode.Value('BATTLE_END_UNKNOWN_BATTLE')
  True

Battle end
  >>> req = mock_battle_end_m(dungeon=dungeon_id, win=True, turns=12, battle_key=battle_key)
  >>> resp = post_message(req, BattleEndRep, session_id=session_id)
  >>> resp.result_code == BattleEndRepResultCode.Value("BATTLE_END_SUCCESS_WIN")
  True
  >>> len(resp.helpers) > 0
  True