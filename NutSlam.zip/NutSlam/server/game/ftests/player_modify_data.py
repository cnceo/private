import random
from data_base import *
from utils.protocol_pb2 import AddEnergy
from utils.protocol_pb2 import AddEnergyRep
from utils.protocol_pb2 import AddEnergyResultCode
from utils.protocol_pb2 import BuyCreatureSpace
from utils.protocol_pb2 import BuyCreatureSpaceRep
from utils.protocol_pb2 import BuyCreatureSpaceResultCode
from utils.protocol_pb2 import ConvertMaterial
from utils.protocol_pb2 import ConvertMaterialRep
from utils.protocol_pb2 import ConvertMaterialResultCode
from utils.protocol_pb2 import Teams
from utils.protocol_pb2 import EditTeamRep
from utils.protocol_pb2 import EditTeamRepResultCode


def globs(globs):
    """Nose injects this as the global var dict"""
    globs.update(globals())
    return globs