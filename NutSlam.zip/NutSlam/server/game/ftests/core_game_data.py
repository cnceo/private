import time
import random
from data_base import *
from utils.protocol_pb2 import BattleBegin
from utils.protocol_pb2 import BattleBeginRep
from utils.protocol_pb2 import BattleBeginRepResultCode
from utils.protocol_pb2 import BattleEnd
from utils.protocol_pb2 import BattleEndRep
from utils.protocol_pb2 import BattleEndRepResultCode
from utils.protocol_pb2 import EditTeamRep
from utils.protocol_pb2 import EditTeamRepResultCode
from utils.protocol_pb2 import GachaTrees
from utils.protocol_pb2 import GachaTreesRep
from utils.protocol_pb2 import GachaShake
from utils.protocol_pb2 import GachaShakeRep
from utils.protocol_pb2 import GachaShakeResultCode
from utils.protocol_pb2 import Renewal
from utils.protocol_pb2 import RenewalRep
from utils.protocol_pb2 import RenewalResultCode
from utils.protocol_pb2 import ResultCode
from models.creature import CreatureInstance
from models.friend import Friend
from models.player import RecentlyHelper


def globs(globs):
    """Nose injects this as the global var dict"""
    globs.update(globals())
    return globs