# Fixtures for creature_modify.rst

import random
from data_base import *
from models.creature import CreatureInstance
from models.creature import Nuts
from utils.protocol_pb2 import Ascend
from utils.protocol_pb2 import AscendRep
from utils.protocol_pb2 import AscendResultCode
from utils.protocol_pb2 import Evolve
from utils.protocol_pb2 import EvolveRep
from utils.protocol_pb2 import EvolveResultCode
from utils.protocol_pb2 import Fuse
from utils.protocol_pb2 import FuseRep
from utils.protocol_pb2 import FuseResultCode
from utils.protocol_pb2 import SellCreature
from utils.protocol_pb2 import SellCreatureRep
from utils.protocol_pb2 import SellCreatureResultCode


def globs(globs):
    """Nose injects this as the global var dict"""
    globs.update(globals())
    return globs
