====================
Account system tests
====================

LoginAccount
====================

Mock up account data and log into game:
  >>> device_id = "test_device_id"
  >>> expected_player_id = (id_count.load() or 0) + 1
  >>> session_id1, msg = create_player(device_id=device_id)

Verify that results from server matches:
  >>> msg.result_code == LoginAccountResultCode.Value("LOGIN_ACC_SUCCESS")
  True
  >>> player = msg.player_info
  >>> player_id = player.userId
  >>> player_id == expected_player_id
  True
  >>> player_id == session_id_to_player_id(session_id1)
  True
  >>> expected_creature_num = len(GameRule.player.default.get("creatures"))
  >>> for c_sets in GameRule.player.default.get("teams").itervalues():
  ...     expected_creature_num += len(c_sets)
  >>> len(player.creaturebox) == expected_creature_num
  True
  >>> device_link = DeviceLink(device_id=device_id)
  >>> device_link.exist()
  True
  >>> device_link.player_id == player_id
  True

Login with pre_device_id
  >>> pre_device_id = device_id
  >>> device_id = "new_device_id"
  >>> session_id2, msg2 = create_player(device_id=device_id,
  ...                                   pre_device_id=pre_device_id)
  >>> msg2.player_info.userId == player_id
  True
  >>> player_id == session_id_to_player_id(session_id2)
  True
  >>> session_id_to_player_id(session_id1)
  >>> device_link1 = DeviceLink(device_id=pre_device_id)
  >>> device_link1.exist()
  False
  >>> device_link2 = DeviceLink(device_id=device_id)
  >>> device_link2.player_id == player_id
  True

Login with pip id and sign_type is AGC
  - Will create a new player and link <device_id> to the new player
  >>> agc_id = "test_agc_id"
  >>> _, msg = create_player(device_id=device_id,
  ...                        sign_type=SignType.Value("APPLE"), pip_id=agc_id)
  >>> agc_player_id = msg.player_info.userId
  >>> agc_player_id != player_id
  True
  >>> agc_player = Player(id=agc_player_id)
  >>> agc_player.agc_id == agc_id
  True
  >>> device_link = DeviceLink(device_id=device_id)
  >>> device_link.player_id == agc_player_id
  True

Login with pre_device_id and another pip id
  - Will update <pre_device_id> to <device_id> and pointed to a new player
  >>> pre_device_id = device_id
  >>> device_id = "new_device_id1"
  >>> pre_agc_id = agc_id
  >>> agc_id = "new_agc_id"
  >>> pre_agc_player_id = agc_player_id
  >>> s_id, msg = create_player(device_id=device_id,
  ...                        sign_type=SignType.Value("APPLE"), pip_id=agc_id,
  ...                        pre_device_id=pre_device_id)
  >>> agc_player_id = msg.player_info.userId
  >>> pre_agc_player_id != agc_player_id
  True
  >>> device_link1 = DeviceLink(device_id=pre_device_id)
  >>> device_link1.exist()
  False
  >>> device_link2 = DeviceLink(device_id=device_id)
  >>> device_link2.player_id == agc_player_id
  True
  >>> player = Player.load_by_attribute("agc_id", pre_agc_id)
  >>> player = player and player[0]
  >>> player and player.exist()
  True

Login & force create account for device_id
  >>> s_id, msg = create_player(device_id=device_id,
  ...                           sign_type=SignType.Value("APPLE"),
  ...                           create_account=True)
  >>> device_link = DeviceLink(device_id=device_id)
  >>> device_link.player_id != agc_player_id
  True
  >>> device_link.player_id == msg.player_info.userId
  True


Update additional info.
============================

Only update name.
  >>> name = "happylatte"
  >>> player = Player(id=msg.player_info.userId)
  >>> player.name
  >>> player.pn_token
  >>> additional = GetSocialFriendsInfo()
  >>> additional.display_name = name
  >>> resp = post_message(additional, SimpleResponse, session_id=s_id)
  >>> resp.result_code == ResultCode.Value("SUCCESS")
  True
  >>> player = player.load()
  >>> player.name == name
  True
  >>> player.pn_token

Only update pn_token
  >>> pn_token = "MOCKED_NOTIFICATION_TOKEN"
  >>> additional.pn_token = pn_token
  >>> additional.display_name = ""
  >>> resp = post_message(additional, SimpleResponse, session_id=s_id)
  >>> resp.result_code == ResultCode.Value("SUCCESS")
  True
  >>> player = player.load()
  >>> player.name == name
  True
  >>> player.pn_token == pn_token
  True

Update name & pn_token
  >>> name = "John Doe"
  >>> pn_token = "MOCKED_NOTIFICATION_TOKEN"
  >>> additional.display_name = name
  >>> additional.pn_token = pn_token
  >>> resp = post_message(additional, SimpleResponse, session_id=s_id)
  >>> resp.result_code == ResultCode.Value("SUCCESS")
  True
  >>> player = player.load()
  >>> player.name == name
  True
  >>> player.pn_token == pn_token
  True
