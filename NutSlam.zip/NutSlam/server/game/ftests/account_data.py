# Fixtures for account.rst

from data_base import *
from models.player import DeviceLink
from models.player import id_count
from utils.protocol_pb2 import GetSocialFriendsInfo
from utils.protocol_pb2 import LoginAccountResultCode
from utils.protocol_pb2 import SimpleResponse
from utils.protocol_pb2 import ResultCode

def globs(globs):
    """Nose injects this as the global var dict"""
    globs.update(globals())
    return globs