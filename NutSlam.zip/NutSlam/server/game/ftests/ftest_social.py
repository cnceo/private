from base import BaseFtest
from models.friend import FriendList
from models.friend import FavoriteList
from models.friend import SendPendingList
from models.friend import ReceivePendingList
from utils.protocol_pb2 import FriendAction
from utils.protocol_pb2 import GetFriendsInfo
from utils.protocol_pb2 import GetFriendsInfoRep
from utils.protocol_pb2 import GetFriendsInfoResultCode
from utils.protocol_pb2 import GetHelper
from utils.protocol_pb2 import GetHelperRep
from utils.protocol_pb2 import GetHelperResultCode
from utils.protocol_pb2 import ModifyFriend
from utils.protocol_pb2 import ModifyFriendRep
from utils.protocol_pb2 import ModifyFriendResultCode


class SocialFtest(BaseFtest):

    def _clear_player(self, player_id):
        for cls in [FriendList, FavoriteList, SendPendingList,
                    ReceivePendingList]:
            instance = cls(player_id=player_id)
            instance.delete()

    def testGetHelper(self):
        req = GetHelper()
        # invalid session
        resp = self.post_message(req, GetHelperRep,
                                 session_id="invalid_session")
        self.assertEquals(resp.result_code, GetHelperResultCode.Value(
            "GET_HELPER_INVALID_SESSION"))

        session_id, msg = self.create_player()
        resp1 = self.post_message(req, GetHelperRep, session_id=session_id)
        self.assertEquals(resp1.result_code,
                          GetHelperResultCode.Value("GET_HELPER_SUCCESS"))

        _, msg2 = self.create_player(device_id="new_device")
        new_player_id = msg2.player_info.userId
        resp2 = self.post_message(req, GetHelperRep, session_id=session_id)
        self.assertEquals(resp2.result_code,
                          GetHelperResultCode.Value("GET_HELPER_SUCCESS"))
        self.assertTrue(len(resp1.helpers) <= len(resp2.helpers))
        if len(resp1.helpers) < len(resp2.helpers):
            help_ids = [h.player_info.userId for h in resp2.helpers]
            self.assertIn(new_player_id, help_ids)

    def testFriendsSys(self):

        def _get_friend_info():
            req = GetFriendsInfo()
            p_resp = self.post_message(req, GetFriendsInfoRep,
                                       session_id=p_session_id)
            f_resp = self.post_message(req, GetFriendsInfoRep,
                                       session_id=f_session_id)
            return p_resp, f_resp

        add_action = FriendAction.Value("ADD_FRIEND")
        req = ModifyFriend()
        req.action = add_action
        p_session_id, msg1 = self.create_player(device_id="DEVICE_1")
        f_session_id, msg2 = self.create_player(device_id="DEVICE_2")
        player_id = msg1.player_info.userId
        friend_id = msg2.player_info.userId

        # Friend self
        req.friend_id = player_id
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.action, add_action)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FRIEND_ON_SELF"))

        # Friend not exist one
        req.friend_id = -1
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FRIEND_NOT_EXIST"))

        # Check friend info
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.send_pending_list), 0)
        self.assertEquals(len(f_friends.receive_pending_list), 0)

        # Add Friend
        req.friend_id = friend_id
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.send_pending_list), 1)
        self.assertEquals(len(f_friends.receive_pending_list), 1)
        self.assertEquals(p_friends.send_pending_list[0].userId, friend_id)
        self.assertEquals(f_friends.receive_pending_list[0].userId, player_id)

        # Try add Friend again
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FRIEND_SENDING"))

        # Try to add the on in receiving list
        f_req = ModifyFriend()
        f_req.action = add_action
        f_req.friend_id = player_id
        resp = self.post_message(f_req, ModifyFriendRep,
                                 session_id=f_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FRIEND_RECEIVING"))

        # Friend accept the req
        accept_action = FriendAction.Value("ACCEPT_FRIEND")
        f_req.action = accept_action
        resp = self.post_message(f_req, ModifyFriendRep,
                                 session_id=f_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        self.assertEquals(resp.action, accept_action)
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.send_pending_list), 0)
        self.assertEquals(len(p_friends.friends_list), 1)
        self.assertEquals(len(f_friends.receive_pending_list), 0)
        self.assertEquals(len(f_friends.friends_list), 1)
        self.assertEquals(p_friends.friends_list[0].player_info.userId, friend_id)
        self.assertFalse(p_friends.friends_list[0].is_favorite)
        self.assertEquals(f_friends.friends_list[0].player_info.userId, player_id)
        self.assertFalse(f_friends.friends_list[0].is_favorite)

        # Try to accept one not in receiving list
        resp = self.post_message(f_req, ModifyFriendRep,
                                 session_id=f_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("ACCEPT_NOT_RECEIVING"))

        # Try to add Friend again
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FRIEND_FRIEND"))

        # Favorite the friend
        favorite_action = FriendAction.Value("MARK_FAVORITE")
        req.action = favorite_action
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        self.assertEquals(resp.action, favorite_action)
        p_friends, f_friends = _get_friend_info()
        self.assertTrue(p_friends.friends_list[0].is_favorite)
        self.assertFalse(f_friends.friends_list[0].is_favorite)

        # Try favorite again
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FAVORITE_FAVORITE"))

        # Unmark favorite
        unmark_action = FriendAction.Value("UNMARK_FAVORITE")
        req.action = unmark_action
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        self.assertEquals(resp.action, unmark_action)
        p_friends, _ = _get_friend_info()
        self.assertFalse(p_friends.friends_list[0].is_favorite)

        # Try unmark again
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code, ModifyFriendResultCode.Value(
            "UNFAVORITE_NOT_FAVORITE"))

        # Remove friend
        remove_action = FriendAction.Value("REMOVE_FRIEND")
        req.action = remove_action
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        self.assertEquals(resp.action, remove_action)
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.send_pending_list), 0)
        self.assertEquals(len(p_friends.friends_list), 0)
        self.assertEquals(len(f_friends.receive_pending_list), 0)
        self.assertEquals(len(f_friends.friends_list), 0)

        # Try remove again
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("REMOVE_STRANGER"))

        # Try favorite stranger
        req.action = favorite_action
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("FAVORITE_STRANGER"))

        # Ignore stranger.
        ignore_action = FriendAction.Value("IGNORE_FRIEND")
        req.action = ignore_action
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("IGNORE_NOT_RECEIVING"))

        # Add a friend and ignore it.
        f_req.action = add_action
        resp = self.post_message(f_req, ModifyFriendRep,
                                 session_id=f_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.receive_pending_list), 1)
        self.assertEquals(len(f_friends.send_pending_list), 1)
        resp = self.post_message(req, ModifyFriendRep, session_id=p_session_id)
        self.assertEquals(resp.result_code,
                          ModifyFriendResultCode.Value("MODIFY_SUCCESS"))
        p_friends, f_friends = _get_friend_info()
        self.assertEquals(len(p_friends.receive_pending_list), 0)
        self.assertEquals(len(p_friends.friends_list), 0)
        self.assertEquals(len(f_friends.send_pending_list), 0)
        self.assertEquals(len(f_friends.friends_list), 0)
