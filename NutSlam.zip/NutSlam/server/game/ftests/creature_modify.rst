====================
Creature system tests
====================


  >>> session_id, msg = create_player()
  >>> player_id = msg.player_info.userId
  >>> player = Player(id=player_id)
  >>> def creature_proto(c_id):
  ...     c = CreatureInstance(player_id=player_id, cid=c_id)
  ...     return c.to_proto_class()
  >>> activate_c_ids = list(Player(id=player_id).get_active_creatures())
  >>> all_creatures = CreatureInstance.load_by_attribute("player_id", player_id)


Fuse
====================

  >>> def mock_fuse(t_id=None, feeder_ids=None):
  ...     fuse = Fuse()
  ...     if t_id:
  ...         fuse.target.CopyFrom(creature_proto(t_id))
  ...     if feeder_ids:
  ...         feeders = [creature_proto(c_id) for c_id in feeder_ids]
  ...         fuse.feeders.extend(feeders)
  ...     return fuse

  >>> target_id = random.choice(activate_c_ids)
  >>> target = CreatureInstance(player_id=player_id, cid=target_id)
  >>> invalid_feeder_ids = set(activate_c_ids) - set([target_id])
  >>> inactive_creatures = [c for c in all_creatures
  ...                       if c.cid not in activate_c_ids]

Fuse without target
  >>> req = mock_fuse()
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_MISSING_TARGET")
  True

Fuse with not exist c_id
  >>> req = mock_fuse(t_id=1000)
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_TARGET_NOT_EXIST")
  True

Fuse without feeders
  >>> req = mock_fuse(t_id=target_id)
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_NO_FEEDERS")
  True

Fuse using not exist c_id as feeders
  >>> req = mock_fuse(t_id=target_id, feeder_ids=[1000])
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_FEEDER_NOT_EXIST")
  True

Fuse using activate creatures as feeders
  >>> req = mock_fuse(t_id=target_id, feeder_ids=invalid_feeder_ids)
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_FEEDER_IN_USE")
  True

Fuse using target as one feeders
  >>> req = mock_fuse(t_id=target_id, feeder_ids=[target_id])
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_FEEDER_SELF")
  True

Fuse but don't have enough coins.
  >>> player.coins = 0
  >>> player.store()
  >>> feeder = random.choice(inactive_creatures)
  >>> feeder_id = feeder.cid
  >>> fuse_coins = target.fuse_currency()
  >>> req = mock_fuse(t_id=target_id, feeder_ids=[feeder_id])
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_NOT_ENOUGH_COINS")
  True
  >>> resp.lack_coins == fuse_coins
  True

Do Fuse
  >>> xp = feeder.fuse_trans_xp(target)
  >>> player.coins += fuse_coins
  >>> player.store()
  >>> resp = post_message(req, FuseRep, session_id=session_id)
  >>> resp.result_code == FuseResultCode.Value("FUSE_SUCCESS")
  True
  >>> feeder.exist()
  False
  >>> if resp.got_mega:
  ...     xp *= 2
  >>> target.add_xp(xp)
  >>> target.xp == resp.updated_creature.xp
  True
  >>> target.level == resp.updated_creature.level
  True
  >>> player = player.load()
  >>> player.coins
  0


Evolve
====================

  >>> all_creatures.remove(feeder)
  >>> inactive_creatures.remove(feeder)
  >>> evolve_creatures = [c for c in all_creatures if c.support_evolve()]
  >>> target = random.choice(evolve_creatures)
  >>> evolve_disabled_creatures = set(all_creatures) - set(evolve_creatures)
  >>> if not evolve_disabled_creatures:
  ...     for c_p in GameRule.creature_types.all():
  ...         if not c_p.evolutionSlug:
  ...           c = Nuts.create(player_id, c_p.slug, auto_open=True)
  ...           evolve_disabled_creatures.add(c)
  ...           all_creatures.append(c)
  ...           break
  >>> evolve_disabled_c = random.choice(list(evolve_disabled_creatures))

  >>> def mock_evolve(t_id=None):
  ...     evo = Evolve()
  ...     if t_id:
  ...         evo.target.CopyFrom(creature_proto(t_id))
  ...     return evo

Evolve without target
  >>> req = mock_evolve()
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_MISSING_TARGET")
  True

Evolve with non exist c_id
  >>> req = mock_evolve(1000)
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_TARGET_NOT_EXIST")
  True

Evolve with creature do not support evolve
  >>> req = mock_evolve(evolve_disabled_c.cid)
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_DISABLE")
  True

Evolve with target not meet the max level
  >>> req = mock_evolve(target.cid)
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_LEVEL_UNSATISFIED")
  True

Evolve but not enough materials
  >>> target.level = GameRule.creature_types.get(target.slug).maxLevel
  >>> target.store()
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_LACK_MATERIAL")
  True

Evolve but not enough coins.
  >>> evolve_coins = target.evolve_currency()
  >>> materials = target.evolution_materials().keys()
  >>> for m, amount in target.evolution_materials().iteritems():
  ...     setattr(player, m, amount)
  >>> player.store()
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_NOT_ENOUGH_COINS")
  True
  >>> resp.lack_coins == evolve_coins
  True

Do Evolve
  >>> evolve_slug = target._type.evolutionSlug.lower()
  >>> player.coins += evolve_coins
  >>> player.store()
  >>> resp = post_message(req, EvolveRep, session_id=session_id)
  >>> resp.result_code == EvolveResultCode.Value("EVOLVE_SUCCESS")
  True
  >>> resp.new_creature.slug == evolve_slug
  True
  >>> player = player.load()
  >>> expected_m = [0] * len(materials)
  >>> result = [getattr(player, m) for m in materials]
  >>> expected_m == result
  True


Ascend
====================
  >>> def mock_ascend(t_id=None):
  ...     ascend = Ascend()
  ...     if t_id:
  ...         ascend.target.CopyFrom(creature_proto(t_id))
  ...     return ascend
  >>> ascend_creatures = [c for c in all_creatures if c.support_ascend()]
  >>> if not ascend_creatures:
  ...     for c_p in GameRule.creature_types.all():
  ...         if c_p.transcend and c_p.transcend.transcendSlug:
  ...             c = Nuts.create(player_id, c_p.slug, auto_open=True)
  ...             ascend_creatures.append(c)
  ...             all_creatures.append(c)
  ...             break
  >>> ascend_disabled_creatures = set(all_creatures) - set(ascend_creatures)
  >>> ascend_disabled_c = random.choice(list(ascend_disabled_creatures))
  >>> if ascend_creatures:
  ...     target = random.choice(ascend_creatures)
  ... else:
  ...     target = None

Ascend without target
  >>> req = mock_ascend()
  >>> resp = post_message(req, AscendRep, session_id=session_id)
  >>> resp.result_code == AscendResultCode.Value("ASCEND_MISSING_TARGET")
  True

Ascend with non exist c_id
  >>> req = mock_ascend(1000)
  >>> resp = post_message(req, AscendRep, session_id=session_id)
  >>> resp.result_code == AscendResultCode.Value("ASCEND_TARGET_NOT_EXIST")
  True

Ascend with creature do not support ascend
  >>> req = mock_ascend(ascend_disabled_c.cid)
  >>> resp = post_message(req, AscendRep, session_id=session_id)
  >>> resp.result_code == AscendResultCode.Value("ASCEND_DISABLE")
  True

Ascend with target not meed the max level
  >>> if target:
  ...     target.level = GameRule.creature_types.get(target.slug).maxLevel - 1
  ...     target.store()
  ...     req = mock_ascend(target.cid)
  ...     resp = post_message(req, AscendRep, session_id=session_id)
  ...     resp.result_code == AscendResultCode.Value("ASCEND_LEVEL_UNSATISFIED")
  ... else:
  ...     True
  True

Ascend but not enough coins
  >>> if target:
  ...     transcend = target.get_transcend()
  ...     for _req in transcend.creatureAmount:
  ...         for _ in range(_req.amount):
  ...             c = Nuts.create(player_id, _req.creatureSlug, auto_open=True)
  ...             all_creatures.append(c)
  ...     target.level = GameRule.creature_types.get(target.slug).maxLevel
  ...     target.store()
  ...     ascend_coins = target.ascend_currency()
  ...     player = player.load()
  ...     resp = post_message(req, AscendRep, session_id=session_id)
  ...     resp.result_code == AscendResultCode.Value("ASCEND_NOT_ENOUGH_COINS")
  ...     resp.lack_coins == ascend_coins
  ... else:
  ...     True
  ...     True
  True
  True

Do Ascend
  >>> if target:
  ...     ascend_slug = transcend.transcendSlug
  ...     player.coins = ascend_coins
  ...     player.store()
  ...     resp = post_message(req, AscendRep, session_id=session_id)
  ...     resp.result_code == AscendResultCode.Value("ASCEND_SUCCESS")
  ...     resp.new_creature.slug == ascend_slug
  ...     player = player.load()
  ...     player.coins
  ...     ascend_used_cids = resp.used_cids
  ... else:
  ...     True
  ...     True
  ...     0
  ...     ascend_used_cids = []
  True
  True
  0

Sell
====================
  >>> def mock_sell(t_id=None):
  ...     req = SellCreature()
  ...     if t_id:
  ...         req.target.CopyFrom(creature_proto(t_id))
  ...     return req
  >>> all_creatures = [c for c in all_creatures if c.cid not in ascend_used_cids]
  >>> inactive_creatures = [c for c in inactive_creatures
  ...                       if c.cid not in ascend_used_cids]

Sell without target
  >>> req = mock_sell()
  >>> resp = post_message(req, SellCreatureRep, session_id=session_id)
  >>> resp.result_code == SellCreatureResultCode.Value("SELL_MISSING_TARGET")
  True

Sell with not exist c_id
  >>> req = mock_sell(t_id=10000)
  >>> resp = post_message(req, SellCreatureRep, session_id=session_id)
  >>> resp.result_code == SellCreatureResultCode.Value("SELL_TARGET_NOT_EXIST")
  True

Sell active creature
  >>> target_id = random.choice(activate_c_ids)
  >>> req = mock_sell(t_id=target_id)
  >>> resp = post_message(req, SellCreatureRep, session_id=session_id)
  >>> resp.result_code == SellCreatureResultCode.Value("SELL_TARGET_IN_USE")
  True

Do Sell
  >>> target = random.choice(inactive_creatures)
  >>> sale_price = target.sale_price()
  >>> player = player.load()
  >>> player.coins == 0
  True
  >>> req = mock_sell(t_id=target.cid)
  >>> resp = post_message(req, SellCreatureRep, session_id=session_id)
  >>> resp.result_code == SellCreatureResultCode.Value("SOLD_SUCCESS")
  True
  >>> resp.coins == sale_price
  True
  >>> player = player.load()
  >>> player.coins == sale_price
  True
