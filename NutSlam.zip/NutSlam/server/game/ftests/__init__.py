# init test settings
from utils import settings
settings.TEST_MODE = True
settings.USE_CACHE = False

if settings.USE_HTTPS:
    base_url = "https://%s:%s" % (settings.LISTEN_HOST, settings.LISTEN_PORT)
else:
    base_url = "http://%s:%s" % (settings.LISTEN_HOST, settings.LISTEN_PORT)
