====================
Creature system tests
====================


  >>> session_id, msg = create_player()
  >>> player_id = msg.player_info.userId
  >>> player = Player(id=player_id)


Add Energy
====================

Add energy with not enough gems
  >>> req = AddEnergy()
  >>> player.gems = 0
  >>> player.store()
  >>> resp = post_message(req, AddEnergyRep, session_id=session_id)
  >>> resp.result_code == AddEnergyResultCode.Value("ADD_ENERGY_NOT_ENOUGH_GEMS")
  True

Do add energy
  >>> player.gems = GameRule.prices.refill_energy()
  >>> player.store()
  >>> old_energy = player.get_energy()
  >>> resp = post_message(req, AddEnergyRep, session_id=session_id)
  >>> resp.result_code == AddEnergyResultCode.Value("ADD_ENERGY_SUCCESS")
  True
  >>> player = player.load()
  >>> player.gems
  0
  >>> player.get_energy() == old_energy + player.get_max_energy()
  True


Buy creature space
====================

Buy creature space with not enough gems
  >>> req = BuyCreatureSpace()
  >>> resp = post_message(req, BuyCreatureSpaceRep, session_id=session_id)
  >>> resp.result_code == BuyCreatureSpaceResultCode.Value(
  ...     "BUY_CREATURE_SPACE_NOT_ENOUGH_GEMS")
  True

Do buy creature space
  >>> player.gems = GameRule.prices.creature_space()
  >>> player.store()
  >>> old_max_crs = player.max_creatures
  >>> resp = post_message(req, BuyCreatureSpaceRep, session_id=session_id)
  >>> resp.result_code == BuyCreatureSpaceResultCode.Value(
  ...     "BUY_CREATURE_SPACE_SUCCESS")
  True
  >>> player = player.load()
  >>> player.gems
  0
  >>> player.max_creatures == old_max_crs + GameRule.player.creature_box_extension
  True


Convert materials
====================

  >>> def prepare_from_to_slug(amount):
  ...     conversion = GameRule.materials.conversion
  ...     t_slug = None
  ...     while not conversion.get(t_slug):
  ...         t_slug = random.choice(conversion.keys())
  ...     from_choice = conversion.get(t_slug)
  ...     f_slug = random.choice(from_choice.keys())
  ...     required_f = from_choice.get(f_slug) * amount
  ...     return f_slug, t_slug, required_f

  >>> def gen_mismatch_from_slug(t_slug):
  ...     conversion = GameRule.materials.conversion
  ...     for _t, conv_info in conversion.iteritems():
  ...         if _t != t_slug and conv_info:
  ...             return random.choice(conv_info.keys())

  >>> amount = 2
  >>> from_slug, to_slug, required_f_m = prepare_from_to_slug(amount)
  >>> mismatch_from_slug = gen_mismatch_from_slug(to_slug)

  >>> def mock_convert_m(from_slug=None, to_slug=None, amount=None):
  ...     req = ConvertMaterial()
  ...     if from_slug:
  ...         req.from_slug = from_slug
  ...     if to_slug:
  ...         req.to_slug = to_slug
  ...     if amount:
  ...         req.amount = amount
  ...     return req

Convert without from
  >>> req = mock_convert_m()
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_MISSING_FROM")
  True

Convert without to
  >>> req = mock_convert_m(from_slug)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_MISSING_TO")
  True

Convert without amount
  >>> req = mock_convert_m(from_slug, to_slug)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_MISSING_AMOUNT")
  True

Convert with invalid from or to
  >>> invalid_from = "test_from"
  >>> invalid_to = "test_to"
  >>> req = mock_convert_m(invalid_from, invalid_to, amount)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_NOT_ALLOWED")
  True
  >>> req = mock_convert_m(from_slug, invalid_to, amount)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_NOT_ALLOWED")
  True
  >>> req = mock_convert_m(invalid_from, to_slug, amount)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_NOT_ALLOWED")
  True
  >>> req = mock_convert_m(mismatch_from_slug, to_slug, amount)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_NOT_ALLOWED")
  True

Convert with not enough materials
  >>> setattr(player, from_slug, 0)
  >>> player.store()
  >>> req = mock_convert_m(from_slug, to_slug, amount)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value(
  ...     "CONVERT_NOT_ENOUGH_MATERIAL")
  True

Do Convert
  >>> setattr(player, from_slug, required_f_m)
  >>> player.store()
  >>> orig_to = getattr(player, to_slug)
  >>> resp = post_message(req, ConvertMaterialRep, session_id=session_id)
  >>> resp.result_code == ConvertMaterialResultCode.Value("CONVERT_SUCCESS")
  True
  >>> player = player.load()
  >>> getattr(player, from_slug)
  0
  >>> getattr(player, to_slug) == orig_to + amount
  True


Edit team
====================
  >>> all_cids = CreatureInstance.load_oids_by_attribute("player_id", player_id)
  >>> def mock_edit_team(cids=[]):
  ...     edit_req = Teams()
  ...     team = None
  ...     for cid in cids:
  ...         if team is None or len(team.creaturesIds) == 3:
  ...             team = edit_req.team.add()
  ...         team.creaturesIds.append(cid)
  ...     return edit_req

Edit team with non exist cid
  >>> req = mock_edit_team([10000])
  >>> resp = post_message(req, EditTeamRep, session_id=session_id)
  >>> resp.result_code == EditTeamRepResultCode.Value(
  ...     "EDIT_TEAM_CREATURE_NOT_EXIST")
  True

Edit team with same cid in one team
  >>> req = mock_edit_team([1, 1, 1])
  >>> resp = post_message(req, EditTeamRep, session_id=session_id)
  >>> resp.result_code == EditTeamRepResultCode.Value(
  ...     "EDIT_TEAM_SAME_TEAM_DUPLICATE_CID")
  True

Edit team
  >>> cids = all_cids[3:16]
  >>> activate_cids = player.get_active_creatures()
  >>> activate_cids == set([1, 2, 3])
  True
  >>> req = mock_edit_team(cids)
  >>> resp = post_message(req, EditTeamRep, session_id=session_id)
  >>> resp.result_code == EditTeamRepResultCode.Value(
  ...     "EDIT_TEAM_SUCCESS")
  True
  >>> activate_cids = player.get_active_creatures()
  >>> activate_cids == set(cids)
  True

