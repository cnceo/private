Client API
====================

1. /account/?name=LoginAccount&body=<login_account_msg>

2. /player/<session_id>/?name=<msg_name>&body=<msg_content>
    * More details for msg_name please check:
    >>> from actors.player import msg_map
    >>> msg_map.keys()

TBC


Server code structure
=====================

root(game)___README.md
          |__listener.py
          |__actors - Multiple actor to handle requests.
          |__content - download & extract contents.
          |__dal___base.py - Base model.
          |     |__db - Couchbase.
          |__ftests - All test cases.
          |__models - Data models.
          |__scripts
          |__utils


Deploy steps
====================
TODO - Hugo

1. prepare:
    - bash warnuts/common/assetbundle/prepare_resource.py
    - in docker: python script/content.py download,<version_id>
    - in docker: python script/content.py extract
    - in docker: python script/content.py upload

2. modify settings ( move warnuts/server/game/utils/live_settings.py.example to live_settings.py):
    - check the host ip of couchbase: COUCHBASE_HOST = os.getenv("COUCHBASE_HOST", os.getenv("COUCHBASE_PORT_8091_TCP_ADDR", "XXXXXXXXXXX"))

