from jinja_util import JinjaRender
from utils.settings import APP_ID, NUTSSLAM_FACEBOOK_URL, SITE_NAME, APP_URL
from models.content import GameRule
from utils.protocol_pb2 import TriggerType

NOT_FIND_PLAYER_ERROR = 'Sorry, can not find this creature.'


class NutsReviewResource(object):

    @JinjaRender("review_page.tpl")
    def handle(self, slug):
        c = GameRule.creature_types.get(slug)
        skill_slug = ''
        for s in c.skills:
            if s.trigger.type == TriggerType.Value('ONACTIVATE'):
                skill_slug = s.localizationSlug
                break
        skill_name, skill_desc = GameRule.l10n.skills(slug, skill_slug)
        stars ='&#11088;' * c.starRating
        resource_path = GameRule.configs.get('resourceUpdaterPath') or APP_URL

        if True:
            info = {"name": stars + GameRule.l10n.creature_name(slug),
                    "app_id": APP_ID,
                    "image_url": resource_path + 'media/creatures/' + slug + '.jpg',
                    "desc": '&#9876; ' + skill_name + '&#8212;' + skill_desc,
                    "redirect_url": NUTSSLAM_FACEBOOK_URL,
                    "site_name": SITE_NAME,
                    "url": APP_URL + 'nuts/%s/' % slug,
                    }
            return {"info": info}
        return NOT_FIND_PLAYER_ERROR
