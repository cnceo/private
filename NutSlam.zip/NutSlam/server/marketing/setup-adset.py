#!/usr/bin/env python

import sys
from os.path import dirname
sys.path.append(dirname(__file__))

from facebookads.api import FacebookAdsApi
from facebookads.objects import AdSet, AdUser, LookalikeAudience, CustomAudience


# Initialize a new Session and instanciate an Api object
my_app_id = '1071596179536136'
my_app_secret = '0eeb1095ff6928d548a4041f64f12b6b'
my_access_token = 'CAAPOnG2fuQgBAD0Q6CZCdQnCe12XD0CWWAUc9MsSYTdRo83wucZB1CcNFuAjEFgWKXBfk2ZBtkKOSQPOT8DvTdDcAwGFigJLE7cmfwbWZBCFHbxMYi9dVGRKoXwZAUBSSp029VUOGWG7Kfhp3PCJDzZBrm1nJPnRVyY64YgP2HmZALZA280E45rF1ZAigS58tnf9jjEApWvcwnbX5rNVyZBljZA'
FacebookAdsApi.init(my_app_id, my_app_secret, my_access_token)

me = AdUser(fbid='me')
my_account = me.get_ad_accounts()
print my_account

# Step 1, create a campaign. Assuming done already.
campaign_id = '6032003600549'

# Step 2, create a seed ad set and run it. Assuming that this is done,
# and this adset has at least 100, ideally over 200 convertors
seed_adset_id = '6032465730149'
expand_adset_id = '6032924134749'
adaccount_id = 'act_104968799682643'

Given a country/platform,
- use country/platform seed
+ new seed
=> create new conversion lookalike audience

=> create new adset - set adset to use custom audience

#print(AdSet(seed_adset_id))
#a = AdSet(expand_adset_id)
#a[AdSet.Field.name] = 'Seed 2 - HK - 18+ - Android - Copy'
#a.remote_update()
#sys.exit(0)
#Seed 2 - HK - 18+ - Android - Copy

# create (name, country, ratio) lookalike from 2 adsets
# edit adsets in lookalike audience

# Step 4, create a campaign/ad set conversion lookalike audience, using
# both those two ad sets.
#CustomAudience('6033677406949')...

lookalike = CustomAudience(parent_id=adaccount_id)
lookalike.update({
    CustomAudience.Field.name: "Test LAL",
    CustomAudience.Field.subtype: CustomAudience.Subtype.lookalike,
#    CustomAudience.Field.origin_audience_id: seed_adset_id,
    CustomAudience.Field.lookalike_spec: {
        'origin_ids': [seed_adset_id, expand_adset_id],
        'conversion_type': 'campaign_conversions',
        'ratio': 0.05,
        'country': 'ZA',
#        'country': ['AU', 'UK', 'ZA', 'CA', 'IE', 'NO', 'NZ', 'HK'],
    },
})
lookalike.remote_create()
print(lookalike)

# Step 5, update the second ad set's targeting with this lookalike audience.
# adset[AdSet.Field.status] = AdSet.Status.active
# custom_audience = {'id': lookalike[Lookalike.Field.id]}
# adset[AdSet.Field.targeting] = {
#     'geo_locations': {
#         'countries': ['US'],
#     },
#     'custom_audiences': [custom_audience],
# }
# adset.remote_update()



# Step 3, create a second ad set with the remaining main part of your budget.
# adset = AdSet(parent_id=adaccount_id)
# fields = {
#     AdSet.Field.name: 'My AdSet',
#     AdSet.Field.bid_type: 'CPA',
#     AdSet.Field.bid_info: {
#         'ACTIONS': 500,
#     },
#     AdSet.Field.promoted_object: {
#         'page_id': '<PAGE_ID>',#TODO
#     },
#     AdSet.Field.status: AdSet.Status.paused,
#     AdSet.Field.daily_budget: 20000,
#     AdSet.Field.campaign_group_id: campaign_id,
#     AdSet.Field.targeting: {
#         'geo_locations': {
#             'countries': ['US'],
#         },
#     },
# }
# adset.update(fields)
# adset.remote_create()
