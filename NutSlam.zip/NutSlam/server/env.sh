alias doma='docker-machine'
alias doco='docker-compose'
alias dosw='docker-swarm'

#
# Create & start VM if necessary
#
VM=warnuts
echo -n "VM $VM "
VM_status="$(docker-machine status $VM 2>&1)"
echo $VM_status
case "$VM_status" in
  *Error*|*exist*)
    echo "Creating & starting VM $VM with port 8088 forwarded from localhost"
    docker-machine create -d virtualbox --virtualbox-hostonly-cidr "192.168.91.1/24" $VM
    docker-machine stop $VM ; sleep 1;
    echo " ... adding port forwarding for localhost:8088"
    VBoxManage modifyvm "$VM" --natpf1 "warnuts8088,tcp,,8088,,8088"; sleep 1
    docker-machine start $VM
    ;;
  Stopped|Saved)
    echo "Starting VM $VM with port 8088 forwarded from localhost"
    docker-machine start $VM
    ;;
  Running)
    #VBoxManage controlvm "$VM" --natpf1 "warnuts8088,tcp,,8088,,8088";
    ;;
  *)
    echo "Unknown status: $VM_status"
    ;;
esac

echo 'Docker Started'
sleep 2	# circumvent "doma env" hanging forever...
eval "$(docker-machine env $VM)"
DOCKER_IP="$(docker-machine ip $VM)"

#
# More convenience aliases
#
alias game='docker exec -it warnuts_game_1'
alias cb='docker exec -it warnuts_cb_1'
alias logspout='docker exec -it warnuts_log_1'
alias elk='docker exec -it warnuts_elk_1'
alias nginx='docker exec -it warnuts_nginx_1'

alias docker-clean='docker rm -f $(docker ps -a -q) ; docker rmi $(docker images -q --filter "dangling=true")'
alias fig='docker-compose'
alias fig-up='docker-compose up --force-recreate'
alias content='game python script/content.py'
alias db-update='content download && content extract'	# update global config & events (& download other content)
alias db-update-assets='../Update\ Assets' 		# world & creature
. ./couchbase/db-env.sh
alias db-web='open "http://$DOCKER_IP:8091/index.html#sec=documents&docId=PlayerGameInfo%3A11888119"'		# edit god_1 player info
alias admin-web='open "http://$DOCKER_IP:8089/"'
alias vm-cert-fix='docker-machine regenerate-certs $VM ; docker-machine ssh $VM sudo /etc/init.d/docker restart'

alias marketing='docker-compose -f docker-compose'

export COMPOSE_PROJECT_NAME=warnuts
export COMPOSE_FILE=$PWD/etc/development.yml

# papertrail - as an example, how to count DAU based on unique player's starting battles
export PAPERTRAIL_API_TOKEN="DGteHtzRr4yP5RUnFUs8"
alias pt='papertrail --color all'
alias pt_qau="pt --min-time '15 minutes ago' 'BattleBeginRep [SUCCESS]' | perl -pe 's/.*player_id=(\d+).*/\1/' | sort -u | wc -l"
alias pt_hau="pt --min-time '1 hour ago' 'BattleBeginRep [SUCCESS]' | perl -pe 's/.*player_id=(\d+).*/\1/' | sort -u | wc -l"
alias pt_dau="pt --min-time '1 day ago' 'BattleBeginRep [SUCCESS]' | perl -pe 's/.*player_id=(\d+).*/\1/' | sort -u | wc -l"
alias pt_abnormal="pt --min-time '1 day ago' -S 'abnormal'"
alias pt_purchases="pt --min-time '1 week ago' -S 'purchases'"
#alias pt_missing_localization=pt MISSING_LOCALIZATION | perl -pe "s/.*\[\'key: (.+?)\\\n\'.*$/\1/"

echo "\$DOCKER_IP = $DOCKER_IP"
alias fig-up
alias cb game content
echo "couchbase-cli='cb couchbase-cli'"
echo "db-reset, db-drop, db-init = recreate, destroy, initialize buckets"
alias db-update db-web admin-web
echo "doma, doco, dosw = docker-machine, docker-compose, docker-swarm"

