export CB_CLUSTER=--cluster=127.0.01:8091
function couchbase-cli()
{
  if [[ $# -ge 1 ]] ; then
    cb_command=$1
    shift
    echo "couchbase-cli $cb_command $*"
  else
    cb_command=
  fi
  cb couchbase-cli $cb_command $CB_CLUSTER $*
}


function db-drop()
{
  echo "* Deleting all buckets"
  couchbase-cli bucket-delete --bucket=CouchbaseBucket
  couchbase-cli bucket-delete --bucket=MemcachedBucket
  couchbase-cli bucket-delete --bucket=LedgersBucket
}

function db-reset()
{
  db-drop
  db-init
}

function db-init()
{
  echo "* Creating all buckets"
  # Create bucket CouchbaseBucket
  couchbase-cli bucket-create		\
	--bucket=CouchbaseBucket 			\
	--bucket-type=couchbase 		\
	--bucket-ramsize=200			\
	--bucket-replica=1			\
	--enable-flush=1			\
	--wait

  # Create bucket MemcachedBucket
  couchbase-cli bucket-create		\
	--bucket=MemcachedBucket 			\
	--bucket-type=memcached 		\
	--bucket-ramsize=70			\
	--bucket-replica=1			\
	--enable-flush=1			\
	--wait

  # Create bucket LedgersBucket
  couchbase-cli bucket-create	\
	--bucket=LedgersBucket 			\
	--bucket-type=couchbase 		\
	--bucket-ramsize=200			\
	--bucket-replica=1			\
	--enable-flush=1			\
	--wait

  # Adding self to cluster
  # NOTE: ramsize should be more than sum of bucket ramsizes, and must be the same across all nodes in cluster
  couchbase-cli cluster-init --cluster-init-ramsize=512 --wait

  echo "* Post-transfer bucket-list:"
  couchbase-cli bucket-list
}
