Nut Slam Project
================

Run [Install Software](Install Software) to *install all related software* (except Unity3d and XCode).

Run [Start Servers](Start Servers) to *run the servers*.  A few web pages will open accessing the server and the server's web admin interface.  Please note the IP address of the server in the URL.

Run [Start Unity](Start Unity) to *open the Unity editor*.  Double-click the Delta project and click run to run the client.  Connect to the server IP that was mentioned above.

Read [server/README.md](server/README.md) for information on running the servers.

~~Please [merge into the beta branch](https://github.com/happylatte/warnuts/compare/beta...develop?expand=1) to *trigger Unity Cloud build and beta server updates*.~~

Branches, Versions, Builds, and Content Updates
-----------------------------------------------

Our flow is inspired by [nvie.com's `git flow` git branching model](http://nvie.com/posts/a-successful-git-branching-model/)
([git flow](https://github.com/nvie/gitflow),
[Atlassian tutorial](https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow),
[SourceTree docs](http://blog.sourcetreeapp.com/2012/08/01/smart-branching-with-sourcetree-and-git-flow/),
[cheatsheet](http://danielkummer.github.io/git-flow-cheatsheet/)), but since server and client releases aren't completely synchronized, and we need to track content updates, we have a few changes.  Our branching structure looks like this:

    tags
        v2.1.0                    Client release tag without any content update sub-tags
        v2.1.1                    Client release tag with sub-tags for content updates
            update-1              Asset/content update 1 for v2.1.1
            update-1-soundtrack   Split test version of above
            update-2
        v2.2.0

    branches
        develop                   Latest development branch
        server/                   Server branches for server work done after client submission
            v2.1.1                (merged to develop & release)
            v2.2.0
        release/                  Release branches for live servers
            v2.1.0                (also contains asset updates & server hotfixes, not merged back)
            v2.1.1
            v2.2.0

 Some changes from git flow that means we cannot use the utilities for it are:

  - we rarely have the use for *feature* branches
  - we don't use the *master* branch
  - we tag client app store submissions & content updates as `v2.1.1` and `v2.1.1/update-1` respectively
  - server releases are not tagged, but always off branches: `develop` if latest, `server/v2.1.1` for work not on latest but should be merged back, and `release/v2.1.0` for versions that are live, including client asset updates and hotfixes that should not be merged back
  - old branches are archived by tagging their head, e.g. `archive/minigame-prototype`, and deleting them

See [list of releases](https://github.com/happylatte/warnuts/releases), [list of tags](https://github.com/happylatte/warnuts/tags), and [basics of tagging on github](http://git-scm.com/book/en/v2/Git-Basics-Tagging).

Version numbers follow [semantic versioning](http://semver.org), and build numbers are sequentially incremented for each beta (prepended with `uc`) and app store release build, and just set to `editor` when run in the editor.  For example, `v1.5.2 (uc43)` is version 1.5.2, the 43rd build on Unity Cloud (uc).  Not that versions are prefixed with a lowercase `v`.

In addition, the patch-level (third component of the version number) should be an even number for officially released public versions, and odd number for development versions — so 2.0.2 is official version, 2.0.3 is development version.  We update the version number before an app store submission and after it.

Git Commit Messages
-------------------

Please refer to the relevant Asana tasks in your commit messages using [this syntax](https://github.com/jamieforrest/github-asana#commit-syntax).


Directory Hierarchy
-------------------

    root___README.md
      |__server
               |__etc
               |__game
               |__couchbase
      |__client
      |__common___tools
               |__protocol


Developer Accounts
------------------

 - [HockeyApp](https://rink.hockeyapp.net/manage/dashboard)
 - [Warnuts Facebook App](https://developers.facebook.com/apps/1071596179536136/dashboard/) w/ [analytics](https://www.facebook.com/analytics/1071596179536136/?__aref_src=devsite&__aref_id=app_dashboard)
 - [Warnuts Tableau Stats](http://stats.happylatte.com/workbooks?project=46)
 - [PapertrailApp Log Monitoring](https://papertrailapp.com/groups/1737353)

Using the Battle Stage
----------------------

Load `BattleStage` Unity scene and:

  - Edit `BattleStageLoader` with the slugs for the environment, layout, allies, and enemies.
  - Drag the ground you want to use into the Hierarchy, replacing `mixed_ground`.
  - Run the scene.  Needs to connect to server.  You can only play one wave.
  - Tap `space` to select skills.  Only boss can use boss skills.
  - Add pick-ups/boosts in the pause/debug menu.

Available environments, layouts, and grounds can be found in
`Resources/Arenas/Environment`, `.../Layout`, and `.../Background` respectively.
The ground is optional, but should probably match the environment.

Testing
-------

Use this URL to get Access Token:
https://developers.facebook.com/tools/accesstoken/?app_id=1071596179536136

In non-production environments we have sample data, so you can use *God accounts*:
 - In editor, set `pip_id=god_1` in `configs_loc`
 - On device, in system `Settings>AGC`, turn on Sandbox and log into the `appstore-us@happylatte.com` Apple id

Creating new user accounts:
 - In editor, set `pip_id` to some new userid
 - On device, log into AGC, start game, then log out of AGC, start game - you will be prompted to create a new account

To help debug bugs, here's are some definitions and tips:

 - **Frozen** means the game stops and nothing moves
 - **Crashes** means the game quits back to homescreen on device (and typically causes a core dump)
 - **Locks** means the game doesn't progress normally from the current state, but animations may still work (and is typically caused by coroutine dependencies or resource deadlocks)

When the game freezes, crashes, or locks, if in Unity and before stopping Unity, choose **Edit > Show couroutine debug** and copy the file into the Asana bug task.  It contains the historical and current state of all coroutines.

Testing Metagame without minigame
---------------------------------

- Make sure you have enough energy and ship is not full
- Open the battle popup of the dungeon you want to win/lose
- Press `w` to win or `l` to lose
- Wait about 2s for client & server to exchange messages
- Game will restart and you should be in situation as if you won/lost


Testing Minigame
----------------

- Press `w` to win this wave (kill enemies)
- Press `s` to skip turn
- Press `1` to set player CDs to 1
- Press `t` to set HP=1 for team
- Press `e` to set HP=1 for enemies
- Press `b` to add random boost

Testing Networking
------------------

- Use the `create_slow_app` command in `etc/development.yml`
- Press `F1` to break/pause game
- Press `F2` to background & foreground app immediately
- Press `F3` to send Echo to wrong URL - should be silently ignored
- Press `F4` to send GetCollections to wrong URL - should show error
- Press `F5` to send GetCollections to slow URL - in the end return error
- Press `F6` to send GetCollections to non-existent host - should show error
- Press `F7` to show not enough gems popup
- Press `F8` to send Echo to slow URL
