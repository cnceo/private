//
// EKUesItem.h
//
// ���п���ʹ�õ���Ʒ����
//
// Created by  EasyKit Team's xsj Games, Inc.
// Copyright (c) 2014-2017 Yinjunxu. All Rights Reserved. 
// 

#pragma once


#include "EKUseItem.generated.h"

/**
*
*/
UCLASS(Abstract, Blueprintable)
class EASYKIT_API AEKUseItem : public AActor
{
	GENERATED_UCLASS_BODY()


};