// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#ifndef __EKALLOWWINDOWSPLATFORMTYPE_H__
#define __EKALLOWWINDOWSPLATFORMTYPE_H__

#if PLATFORM_WINDOWS

#include "AllowWindowsPlatformTypes.h"

#endif

#endif // __EKALLOWWINDOWSPLATFORMTYPE_H__
