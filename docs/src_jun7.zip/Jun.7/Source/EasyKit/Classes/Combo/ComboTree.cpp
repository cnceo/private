// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "EasyKit.h"
#include "ComboTree.h"



UComboTree::UComboTree(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}