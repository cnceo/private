// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "EasyKit.h"


// This module must be loaded "PreLoadingScreen" in the .uproject file, otherwise it will not hook in time!


IMPLEMENT_GAME_MODULE(FDefaultGameModuleImpl, EasyKit);

//IMPLEMENT_GAME_MODULE(FShooterGameLoadingScreenModule, EasyKit);