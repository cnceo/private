

#include "EasyKit.h"
#include "EKUseItem.h"


AEKUseItem::AEKUseItem(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

