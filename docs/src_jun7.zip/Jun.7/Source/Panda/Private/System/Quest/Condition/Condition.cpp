// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "System/Quest/Condition/Condition.h"

bool FCondition_KillMonster::DoAction(FConditionInput &input)
{
	bool ret = false;
	//if()

	return ret;
}
