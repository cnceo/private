// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "MainPlayerController.h"
#include "Utils/PandaUtils.h"
#include "PandaGameInstance.h"
#include "WidgetBlueprintLibrary.h"
#include "PandaWidget_Bag1.h"
#include "ResDefine.h"
#include "EKGameFrame.h"
#include "GameFramework/Actor.h"
#include "OthersCharacter.h"
#include "Synchronization/SynchronizationAPI.h"
#include "Procedure_MainCity.h"

static int m_LoadOtherPlayerCounts = 0;
extern bool g_bool_FProcedure_MainCity_InMainCity;

AMainPlayerController::AMainPlayerController()
	: m_pPlayer(nullptr)
{
	m_isPvp = false;
	for(int i = 0; i < (int32)PLAYER_KEY::PLAYER_KEY_MAX; ++i)
	{
		m_arrbPressedKey[i] = false;
	}
}

AMainPlayerController::~AMainPlayerController()
{

}

void AMainPlayerController::LoadOtherPlayer(proto3::PlayerInfo& pi)
{

	FString AssetPath = FString("/Game/BPInstance/Other/OthersCharacter.OthersCharacter_C");
	UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(AssetPath);
	if (!ParentClass) return;

	// Temp position
	auto PandaPlayer = GetMainPlayer();
	AOthersCharacter* PandaPlayerActor = GetWorld()->SpawnActor<AOthersCharacter>(ParentClass,
		FVector(PandaPlayer->GetActorLocation().X + m_LoadOtherPlayerCounts*300, PandaPlayer->GetActorLocation().Y + m_LoadOtherPlayerCounts * 300, 
			PandaPlayer->GetActorLocation().Z), PandaPlayer->GetActorRotation());

	// �����������,������,�����
	PandaPlayerActor->setPlayerInfo(pi);

	// ÿ����һ�����ݼ�1
	m_LoadOtherPlayerCounts++;
}

void AMainPlayerController::RemoveOtherPlayer()
{
	auto m_FsPAPlayerInfoList = FPlayerDataManager::Instance()->getPlayerInfoList();
	auto CurrentPlayerCounts = m_FsPAPlayerInfoList.players.size();
	TArray<AActor*> OutActors;
	UGameplayStatics::GetAllActorsOfClass(GGameInstance, AOthersCharacter::StaticClass(), OutActors);
	auto WorldActorsCounts = OutActors.Num();
	for (TArray<AActor*>::TConstIterator It(OutActors); It; ++It)
	{
		AActor* actor = *It;
		if (actor)
		{
			if (WorldActorsCounts > CurrentPlayerCounts)
			{
				GetWorld()->DestroyActor(actor);
				WorldActorsCounts--;
				m_LoadOtherPlayerCounts--;
			}
		}
	}
}

void AMainPlayerController::UpdateOtherPlayer()
{
	auto player = FPlayerDataManager::Instance()->getNewFreshData();
	auto m_FsPAPlayerInfoList = FPlayerDataManager::Instance()->getPlayerInfoList();
	auto CurrentPlayerCounts = m_FsPAPlayerInfoList.players.size();
	TArray<AActor*> OutActors;
	UGameplayStatics::GetAllActorsOfClass(GGameInstance, AOthersCharacter::StaticClass(), OutActors);
	if (OutActors.GetData() == NULL) return;
	auto WorldActorsCounts = OutActors.Num();
	if (WorldActorsCounts != 0)
	{
		for (TArray<AActor*>::TConstIterator It(OutActors); It; ++It)
		{
			AOthersCharacter* actor = Cast<AOthersCharacter>(*It);
			if (actor)
			{
				if (strcmp(actor->getPlayerInfo().uid().c_str(), player.uid().c_str()) == 0)
				{
					actor->setPlayerInfo(player);
				}
			}
		}
	}
}

void AMainPlayerController::BeginPlayingState()
{
	InputComponent = NewObject<UInputComponent>(this,TEXT("Main_InputComponent"));
	InputComponent->RegisterComponent();
	check(InputComponent);

	InputComponent->BindAction("FangKuai",IE_Pressed,this,&AMainPlayerController::OnFangKuai);
	InputComponent->BindAction("FangKuai",IE_Released,this,&AMainPlayerController::OnFangKuaiEnd);

	InputComponent->BindAction("Quan",IE_Pressed,this,&AMainPlayerController::OnQuan);
	InputComponent->BindAction("Quan",IE_Released,this,&AMainPlayerController::OnQuanEnd);

	InputComponent->BindAction("SanJiao",IE_Pressed,this,&AMainPlayerController::OnSanJiao);
	InputComponent->BindAction("SanJiao",IE_Released,this,&AMainPlayerController::OnSanJiaoEnd);

	InputComponent->BindAction("Cha",IE_Pressed,this,&AMainPlayerController::OnCha);
	InputComponent->BindAction("Cha",IE_Released,this,&AMainPlayerController::OnChaEnd);

	InputComponent->BindAction("L1",IE_Pressed,this,&AMainPlayerController::OnL1);
	InputComponent->BindAction("L1",IE_Released,this,&AMainPlayerController::OnL1End);

	InputComponent->BindAction("R1",IE_Pressed,this,&AMainPlayerController::OnR1);
	InputComponent->BindAction("R1",IE_Released,this,&AMainPlayerController::OnR1End);

	InputComponent->BindAction("L2",IE_Pressed,this,&AMainPlayerController::OnL2);
	InputComponent->BindAction("L2",IE_Released,this,&AMainPlayerController::OnL2End);

	InputComponent->BindAction("R2",IE_Pressed,this,&AMainPlayerController::OnR2);
	InputComponent->BindAction("R2",IE_Released,this,&AMainPlayerController::OnR2End);

	InputComponent->BindAction("Shang", IE_Pressed, this, &AMainPlayerController::OnShang);
	InputComponent->BindAction("Shang", IE_Released, this, &AMainPlayerController::OnShangEnd);

	InputComponent->BindAction("Xia", IE_Pressed, this, &AMainPlayerController::OnXia);
	InputComponent->BindAction("Xia", IE_Released, this, &AMainPlayerController::OnXiaEnd);

	InputComponent->BindAction("Zuo", IE_Pressed, this, &AMainPlayerController::OnZuo);
	InputComponent->BindAction("Zuo", IE_Released, this, &AMainPlayerController::OnZuoEnd);

	InputComponent->BindAction("You", IE_Pressed, this, &AMainPlayerController::OnYou);
	InputComponent->BindAction("You", IE_Released, this, &AMainPlayerController::OnYouEnd);

	InputComponent->BindAxis("MoveForward",this,&AMainPlayerController::OnL3Y);
	InputComponent->BindAxis("MoveRight",this,&AMainPlayerController::OnL3X);

	InputComponent->BindAxis("TurnRate",this,&AMainPlayerController::OnR3X);
	InputComponent->BindAxis("LookUpRate",this,&AMainPlayerController::OnR3Y);

	InputComponent->BindAction("bag", IE_Pressed, this, &AMainPlayerController::OnBagOpen);
	InputComponent->BindAction("bag2", IE_Pressed, this, &AMainPlayerController::OnBagClose);
	InputComponent->BindAction("tab", IE_Pressed, this, &AMainPlayerController::OnTab);
	InputComponent->BindAction("Task", IE_Pressed, this, &AMainPlayerController::OnTask);
	InputComponent->BindAction("pvp", IE_Pressed, this, &AMainPlayerController::OnPvp);
	Super::PushInputComponent(InputComponent);

}

void AMainPlayerController::OnOpenACT()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_Dungeon_ACT);
}

void AMainPlayerController::OnOpenCreateTeam()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_TEAM_CREATE);
}

void AMainPlayerController::OnOpenTeamList()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_TEAM_LIST);
}

void AMainPlayerController::OnOpenSelectRegion()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_Dungeon_SelectRegion);
}

void AMainPlayerController::OnOpenTeamIntoPrompt()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_TEAM_TeamIntoPrompt);
}

void AMainPlayerController::OnOpenTeamOperation()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_TEAM_TeamMemberOperation);
}

void AMainPlayerController::OnOpenTeamMemberList()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_TEAM_MEMBER_LIST);
}

void AMainPlayerController::OnOpenTeamMemberJoinList()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_Team_JoinList);
}
void AMainPlayerController::OnOpenTeamMemberInviteList()
{
	if (GGameInstance)
		GGameInstance->SafeGetUIManager()->OpenUMGAsset(UI_Dungeon_InviteList);
}

void AMainPlayerController::OnBagOpen()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/UI/UMG/bag/bag.bag_C"));
	}
	/*TArray<UUserWidget*> FoundWidgets;

	UWidgetBlueprintLibrary::GetAllWidgetsOfClass(this, FoundWidgets, UPandaWidget_Bag1::StaticClass(), true);*/
}

void AMainPlayerController::OnBagClose()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->CloseUMGAsset(TEXT("/Game/UI/UMG/bag/bag.bag_C"));
	}
}
void AMainPlayerController::OnPvp()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		//FEKGameFrame::Instance()->ProcedureManager()->ChangeCurrentProcedure(GeometrySpace::Procedure::PT_World);
		if (UPandaUtils::getCurrCharacter()->getTargetScope())
		{
			gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/UI/UMG/pvp/OtheInfoMenu.OtheInfoMenu_C"));
		}
	}
}
void AMainPlayerController::OnTask()
{
	auto gameInstance = UPandaGameInstance::Instance();
	
	if (gameInstance)
	{
		if (gameInstance->SafeGetUIManager()->FindInWidgetCache(UMGAssetPath_AcceptTask) != nullptr)
		{
			if (gameInstance->SafeGetUIManager()->FindInWidgetCache(UMGAssetPath_AcceptTask)->GetVisibility() == ESlateVisibility::Visible)
			{
				gameInstance->SafeGetUIManager()->CloseUMGAsset(UMGAssetPath_AcceptTask);
			}
			else
			{
				gameInstance->SafeGetUIManager()->OpenUMGAsset(UMGAssetPath_AcceptTask);
			}
		}
		else
		{
			gameInstance->SafeGetUIManager()->OpenUMGAsset(UMGAssetPath_AcceptTask);
		}	
	}

}

void AMainPlayerController::OnTab()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/UI/UMG/Weapon/WeaponChange.WeaponChange_C"));
	}

// 	if (!m_iscamera)
// 	{
// 		auto gameInstance = UPandaGameInstance::Instance();
// 		if (gameInstance)
// 		{
// 			gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/BPInstance/UI/Weapon/WeaponChange.WeaponChange_C"));
// 		}
// 		m_iscamera = true;
// 	}
// 	else
// 	{
// 		auto gameInstance = UPandaGameInstance::Instance();
// 		if (gameInstance)
// 		{
// 			gameInstance->SafeGetUIManager()->CloseUMGAsset(TEXT("/Game/BPInstance/UI/Weapon/WeaponChange.WeaponChange_C"));
// 		}
// 		m_iscamera = false;
// 	}

}

void AMainPlayerController::OnQuan()
{
	//J on keyboard
	UE_LOG(LogTemp,Warning,TEXT("--------i am J"));
	if(auto p=GetMainPlayer())p->RPCClientDumpPlayers();
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_QUAN, true))
	{
		if (GetMainPlayer())
		{
			if (GetMainPlayer()->GetCharacterMovement()->MovementMode == EMovementMode::MOVE_Flying)
			{
				//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_SKYATTACK);
				GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_SKYATTACK));
			}
			else
			{
				//if (Role < ROLE_Authority)
				//{
				//	GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_ATTACK);
				//}
				//USkillInstance* ptr = GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_ATTACK);
				
				GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_ATTACK));
			}
		}
	}
}

void AMainPlayerController::OnQuanEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_QUAN,false);
}

void AMainPlayerController::OnCha()
{
	//K on keyboard
	UE_LOG(LogTemp,Warning,TEXT("--------i am K"));
	if(auto p=GetMainPlayer())p->RPCServerDumpPlayers();
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_CHA, true))
	{

	}
}

void AMainPlayerController::OnChaEnd()
{
 	OnPressedKey(PLAYER_KEY::PLAYER_KEY_CHA,false);
}

void AMainPlayerController::OnFangKuai()
{
	//G on keyboard
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_FANGKUAI, true))
	{
		if (GetMainPlayer())GetMainPlayer()->OnJump(true);
	}
}

void AMainPlayerController::OnFangKuaiEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_FANGKUAI,false);
	if(GetMainPlayer())GetMainPlayer()->OnJump(false);
}

void AMainPlayerController::OnSanJiao()
{
	if (GetMainPlayer()->TargetNPC)
	{
		if (GetMainPlayer())
			GetMainPlayer()->Talk2Npc();
	}
	else
	{
		//H on keyboard
		if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_SANJIAO, true))
		{
			GetMainPlayer()->ChangeStateToDefence();
		}
	}

}

void AMainPlayerController::OnSanJiaoEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_SANJIAO,false);
	GetMainPlayer()->ClearDefence();
}

void AMainPlayerController::OnL1()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_L1,true);
	//UPandaUtils::SlowCamera(GetMainPlayer(), 0.2f);
}

void AMainPlayerController::OnL1End()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_L1,false);
	//UPandaUtils::SlowCamera(GetMainPlayer(), 1.0f);
}

void AMainPlayerController::OnR1()
{
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_R1, true))
	{
		if (GetMainPlayer())
		{
			GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_CHASE);
			//GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_CHASE));
			//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_CHASE);
		}
	}

}

void AMainPlayerController::OnR1End()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_R1,false);
}

void AMainPlayerController::OnL2()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_L2,true);
	GetMainPlayer()->SetTarget(GetMainPlayer()->FindTarget());
	if(GetMainPlayer()->HasTarget()) GetMainPlayer()->TurnAtTarget();
	UE_LOG(LogTemp, Log, TEXT("OnL2() !!!"));
}

void AMainPlayerController::OnL2End()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_L2,false);
	GetMainPlayer()->ClearTarget();
}

void AMainPlayerController::OnR2()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_R2,true);
	if(GetMainPlayer())GetMainPlayer()->SetMaxWalkSpeed(800);
}

void AMainPlayerController::OnR2End()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_R2,false);
	if(GetMainPlayer())GetMainPlayer()->SetMaxWalkSpeed(350);
}

void AMainPlayerController::OnShang()
{
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_SHANG, true))
	{
		if (GetMainPlayer())
		{
			GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP1));
			//GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP1);
			//GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP1));
			//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP1);
		}
	}
}

void AMainPlayerController::OnShangEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_SHANG, false);
}

void AMainPlayerController::OnXia()
{
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_XIA, true))
	{
		if (GetMainPlayer())
		{
			GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP2));
			//GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP2);
			//GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP2));
			//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP2);
		}
	}
}

void AMainPlayerController::OnXiaEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_XIA, false);
}

void AMainPlayerController::OnZuo()
{
	if(!OnPressedKey(PLAYER_KEY::PLAYER_KEY_ZUO, true))
	{
		if (GetMainPlayer())
		{
			GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP3));
			//GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP3);
			//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP3);
		}
	}
}

void AMainPlayerController::OnZuoEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_ZUO, false);
}

void AMainPlayerController::OnYou()
{
	if (!OnPressedKey(PLAYER_KEY::PLAYER_KEY_YOU, true))
	{
		if (GetMainPlayer())
		{
			GetMainPlayer()->PlaySkillInstance(GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP4));
			//GetMainPlayer()->GetBaseSkill(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP4);
			//GetMainPlayer()->PlaySkillInstance();
			//GetMainPlayer()->ServerPlaySkillInstance(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP4);
		}
	}
}

void AMainPlayerController::OnYouEnd()
{
	OnPressedKey(PLAYER_KEY::PLAYER_KEY_YOU, false);
}

void AMainPlayerController::SendMoveMessage(proto3::eMoveType eMoveType)
{
	if (!g_bool_FProcedure_MainCity_InMainCity) return;
	float x = GetMainPlayer()->GetActorLocation().X;
	float y = GetMainPlayer()->GetActorLocation().Y;
	float z = GetMainPlayer()->GetActorLocation().Z;
	float Roll = GetMainPlayer()->GetActorRotation().Roll;
	float Pitch = GetMainPlayer()->GetActorRotation().Pitch;
	float Yaw = GetMainPlayer()->GetActorRotation().Yaw;
	float fMoveSpeed = GetMainPlayer()->GetCharacterMovement()->MaxWalkSpeed;
	int CHARACTER_STATE = int(GetMainPlayer()->GetState());
	int CHARACTER_SUB_STATE = int(GetMainPlayer()->GetSubState());
	USynchronizationAPI::move(eMoveType, x, y, z, Roll, Pitch, Yaw, fMoveSpeed, CHARACTER_STATE, CHARACTER_SUB_STATE);
}

//ǰ/���ƶ�
void AMainPlayerController::OnL3Y(float Value)
{
	if (Value > -0.0001f && Value < 0.0001f) return;

	if (GetMainPlayer() && GetMainPlayer()->ChangeStateToMove())
	{
		FTimerDelegate MovedTimer;
		MovedTimer.BindUObject(this, &AMainPlayerController::MovedCallback);
		GetWorld()->GetTimerManager().SetTimer(m_MoveHandle, MovedTimer, 0.1f, false);
	
		float fSpeed = GetMainPlayer()->GetCharacterMovement()->MaxWalkSpeed;

		const FRotator Rotation = GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);
		// get forward vector
		const FVector Direction = FRotationMatrix(YawRotation).GetScaledAxis(EAxis::X)/**0.001*/;
		// add movement in that direction
		GetPawn()->AddMovementInput(Direction, Value);
		if (GetMainPlayer()->HasTarget()) GetMainPlayer()->TurnAtTarget();

		// send move message
		SendMoveMessage(proto3::eMoveType::WALK);
	}

}

//��/���ƶ�
void AMainPlayerController::OnL3X(float Value)
{
	if (Value > -0.0001f && Value < 0.0001f) return;

	if (GetMainPlayer() && GetMainPlayer()->ChangeStateToMove())
	{
		FTimerDelegate MovedTimer;
		MovedTimer.BindUObject(this, &AMainPlayerController::MovedCallback);
		GetWorld()->GetTimerManager().SetTimer(m_MoveHandle, MovedTimer, 0.1f, false);

		const FRotator Rotation = GetControlRotation();
		const FRotator YawRotation(0, Rotation.Yaw, 0);
		// get right vector 
		const FVector Direction = (FRotationMatrix(YawRotation).GetScaledAxis(EAxis::Y))/**0.001*/;
		// add movement in that direction
		GetMainPlayer()->AddMovementInput(Direction, Value);
		if (GetMainPlayer()->HasTarget()) GetMainPlayer()->TurnAtTarget();

		// send move message
		SendMoveMessage(proto3::eMoveType::WALK);
	}
	else
	{
		if (GetMainPlayer() && GetMainPlayer()->GetState() == CHARACTER_STATE::CHARACTER_STATE_SKILL
			&& GetMainPlayer()->GetCurSkill() && GetMainPlayer()->GetCurSkill()->IsBeFuse() && !GetMainPlayer()->HasTarget())
		{
			GetMainPlayer()->AddControllerYawInput(Value * 30.0f * GetWorld()->GetDeltaSeconds());
			const FRotator Rotation = GetMainPlayer()->Controller->GetControlRotation();
			const FRotator YawRotation(0, Rotation.Yaw, 0);
			GetMainPlayer()->SetActorRotation(YawRotation);
		}

	}

	//// ��ʱ�޸�
	//if (GetMainPlayer() && GetMainPlayer()->ChangeStateToMove())
	//{
	//	FTimerDelegate MovedTimer;
	//	MovedTimer.BindUObject(this, &AMainPlayerController::MovedCallback);
	//	GetWorld()->GetTimerManager().SetTimer(m_MoveHandle, MovedTimer, 0.1f, false);

	//	const FRotator Rotation = GetControlRotation();
	//	const FRotator YawRotation(0, Rotation.Yaw, 0);
	//	// get right vector 
	//	const FVector Direction = (FRotationMatrix(YawRotation).GetScaledAxis(EAxis::Y))/**0.001*/;
	//	// add movement in that direction
	//	GetMainPlayer()->AddMovementInput(Direction, Value);
	//	if (GetMainPlayer()->HasTarget()) GetMainPlayer()->TurnAtTarget();
	//}
	//else
	//{
	//	if (GetMainPlayer() && GetMainPlayer()->GetState() == CHARACTER_STATE::CHARACTER_STATE_SKILL
	//		&& GetMainPlayer()->GetCurSkill() && GetMainPlayer()->GetCurSkill()->IsBeFuse() && !GetMainPlayer()->HasTarget())
	//	{
	//		GetMainPlayer()->AddControllerYawInput(Value * 30.0f * GetWorld()->GetDeltaSeconds());
	//		const FRotator Rotation = GetMainPlayer()->Controller->GetControlRotation();
	//		const FRotator YawRotation(0, Rotation.Yaw, 0);
	//		GetMainPlayer()->SetActorRotation(YawRotation);
	//	}
	//	else
	//	{
	//		const FRotator Rotation = GetControlRotation();
	//		const FRotator YawRotation(0, Rotation.Yaw, 0);
	//		// get right vector 
	//		const FVector Direction = (FRotationMatrix(YawRotation).GetScaledAxis(EAxis::Y))/**0.001*/;
	//		// add movement in that direction
	//		GetMainPlayer()->AddMovementInput(Direction, Value);
	//		if (GetMainPlayer()->HasTarget()) GetMainPlayer()->TurnAtTarget();
	//	}
	//}
}

//���������ӽ�
void AMainPlayerController::OnR3X(float Rate)
{
	
	if(Rate>-0.0001f && Rate<0.0001f || !GetMainPlayer()) return;
	if (GetMainPlayer()->HasTarget())
	{
		GetMainPlayer()->SetTarget(GetMainPlayer()->FindTarget(Rate));
		return;
	}

	if (GetMainPlayer())GetMainPlayer()->AddControllerYawInput(Rate * 30.0f * GetWorld()->GetDeltaSeconds());

	const FRotator Rotation = GetMainPlayer()->Controller->GetControlRotation();
	const FRotator YawRotation(0, Rotation.Yaw, 0);
	GetMainPlayer()->SetActorRotation(YawRotation);
}

//���������ӽ�
void AMainPlayerController::OnR3Y(float Rate)
{
	if (Rate>-0.0001f && Rate<0.0001f || !GetMainPlayer()) return;
	if (GetMainPlayer())GetMainPlayer()->AddControllerPitchInput(Rate * 30.0f * GetWorld()->GetDeltaSeconds());
}

APlayerCharacter* AMainPlayerController::GetMainPlayer()
{
	if (!m_pPlayer)
		m_pPlayer = Cast<APlayerCharacter>(GetPawn());

	return m_pPlayer;
}

void AMainPlayerController::MovedCallback()
{
	if (GetMainPlayer() && GetMainPlayer()->GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_MOVE)
	{
		GetMainPlayer()->SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
	}

}

bool AMainPlayerController::OnPressedKey(PLAYER_KEY emCurKey, bool bPressed)
{
	m_arrbPressedKey[(int32)emCurKey] = bPressed;
	if(bPressed)
	{
		if (CheckNextSkill(emCurKey))
			return true;

		return CheckComponentKey();
	}

	return false;
}

bool AMainPlayerController::CheckComponentKey()
{
	if(m_arrbPressedKey[(int32)PLAYER_KEY::PLAYER_KEY_QUAN] && m_arrbPressedKey[(int32)PLAYER_KEY::PLAYER_KEY_CHA])
	{
		UE_LOG(LogTemp,Log,TEXT("QUAN+CHA !!!"));
	}

	return false;
}

bool AMainPlayerController::CheckNextSkill(PLAYER_KEY emCurKey)
{
	if (GetMainPlayer() && GetMainPlayer()->GetCurSkill())
	{
		int32 nIndex = GetMainPlayer()->GetCurSkill()->CheckPlayNextByInputKey(m_arrbPressedKey, emCurKey);
		if (nIndex > 0)
		{
			return GetMainPlayer()->GetCurSkill()->PlayNextSkill(nIndex);
		}
	}

	return false;
}