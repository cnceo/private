// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "BaseAnimInstance.h"
#include "Animation/AnimNode_StateMachine.h"

UBaseAnimInstance::UBaseAnimInstance()
	:m_fMaxAnimTime(0)
	, m_fFlowAnimTime(0)
{
	bRunUpdatesInWorkerThreads = true;
}

UBaseAnimInstance::~UBaseAnimInstance()
{

}

void UBaseAnimInstance::OnAnimTick_Implementation(float fTime, const FString& AnimName)
{

}

void UBaseAnimInstance::OnAnimBegin_Implementation(float fTime, const FString& AnimName)
{

}

void UBaseAnimInstance::OnAnimEnd_Implementation(const FString& AnimName)
{

}

void UBaseAnimInstance::OnAnimTickBP(float fTime, const FString& AnimName)
{
	m_fFlowAnimTime += fTime;
	this->Execute_OnAnimTick(this, fTime, AnimName);
}

void UBaseAnimInstance::OnAnimBeginBP(float fTime, const FString& AnimName)
{
	m_fMaxAnimTime = fTime;
	m_fFlowAnimTime = 0;
	this->Execute_OnAnimBegin(this, fTime, AnimName);
}

void UBaseAnimInstance::OnAnimEndBP(const FString& AnimName)
{
	this->Execute_OnAnimEnd(this, AnimName);
}

FName UBaseAnimInstance::GetStateMachineState()
{
	auto pStateMachine = GetStateMachineInstanceFromName(TEXT("State_Machine"));
	if (pStateMachine)
	{
		return pStateMachine->GetCurrentStateName();
	}

	return NAME_None;

}

void UBaseAnimInstance::PreUpdateAnimation(float DeltaSeconds)
{
	Super::PreUpdateAnimation(DeltaSeconds);
}


