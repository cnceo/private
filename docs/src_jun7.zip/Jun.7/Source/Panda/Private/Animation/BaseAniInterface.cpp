#include "panda.h"
#include "BaseAniInterface.h"

UBaseAniInterface::UBaseAniInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


