// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillAtomBullet.h"

ASkillAtomBullet::ASkillAtomBullet()
	: ParticleSystem(nullptr)
	, m_pCharacter(nullptr)
	, m_fCurTime(0)
{
	PrimaryActorTick.bCanEverTick = true;
	m_arrBulletActor.Reset();
	ParticleSystem = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("ParticleSystem"));
}

void ASkillAtomBullet::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	m_fCurTime += DeltaTime;

	if (m_fCurTime > m_TableData.fLifeTime)
	{
		Destroy();
		for (int32 i = 0; i < m_arrBulletActor.Num(); ++i)
		{
			m_arrBulletActor[i]->Destroy();
		}
	}

}

void ASkillAtomBullet::InitByData(int32 nTableID, ABaseCharacter* pCharacter)
{
	m_pCharacter = pCharacter;
	auto gameInstance = UPandaGameInstance::Instance();
	if (!m_pCharacter || !gameInstance) return;

	//�ӵ�ԭ�ӱ�����
	auto BulletData = gameInstance->SafeGetDataManager()->m_AtomBulletTable.Find(nTableID);
	if (BulletData)
	{
		m_TableData = *BulletData;
	}

	//������Ӱ��
	auto EffectSelf = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_TableData.nEffectSelf);
	if (EffectSelf)
	{
		m_sSelfEffectTable = *EffectSelf;
	}

	//���ѷ�Ӱ��
	auto EffectFriend = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_TableData.nEffectFriend);
	if (EffectFriend)
	{
		m_sFriendEffectTable = *EffectFriend;
	}

	//�Եз�Ӱ��
	auto EffectEnemy = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_TableData.nEffectEnemy);
	if (EffectEnemy)
	{
		m_sEnemyEffectTable = *EffectEnemy;
	}

	//�������ӷ�����
	auto sResources = gameInstance->SafeGetDataManager()->m_ResourcesTable.Find(m_TableData.nParticle);
	if (sResources)
	{
		UParticleSystem* pParticle = nullptr;
		if (m_TableData.bNameRules)
		{

		}
		else
		{
			pParticle = UPandaUtils::LoadResource<UParticleSystem>(sResources->strPath.Append(sResources->strName).Append(TEXT(".")).Append(sResources->strName));
		}

		ParticleSystem->SetTemplate(pParticle);

	}

	//�����ӵ�����ײ��
	CreateBulletCollistion();

	//���Ӱ������
	if (BULLET_BIND_TYPE(m_TableData.nParticleBand) == BULLET_BIND_TYPE::BULLET_BIND_SELF)
	{
		ParticleSystem->AttachTo(m_pCharacter->GetRootComponent());
		ParticleSystem->SetRelativeLocation(m_TableData.vLocation);
		ParticleSystem->SetRelativeRotation(m_TableData.rRotation);
	}
	else if (BULLET_BIND_TYPE(m_TableData.nParticleBand) == BULLET_BIND_TYPE::BULLET_BIND_TARGET)
	{
		if (m_pCharacter->GetTarget())
		{
			ParticleSystem->AttachTo(m_pCharacter->GetTarget()->GetRootComponent());
			ParticleSystem->SetRelativeLocation(m_TableData.vLocation);
			ParticleSystem->SetRelativeRotation(m_TableData.rRotation);
		}
		else
		{
			//����
			UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
		}
	}
	else if (BULLET_BIND_TYPE(m_TableData.nParticleBand) == BULLET_BIND_TYPE::BULLET_BIND_COLLISTION)
	{
		if (m_arrBulletActor.Num() > 0)
		{
			ParticleSystem->AttachTo(m_arrBulletActor[0]->GetRootComponent());
			ParticleSystem->SetRelativeLocation(m_TableData.vLocation);
			ParticleSystem->SetRelativeRotation(m_TableData.rRotation);
		}
		else
		{
			//����
			UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
		}
	}
	else
	{
		if (BULLET_REFERENCE_TYPE(m_TableData.nParticleReference) == BULLET_REFERENCE_TYPE::BULLET_REFERENCE_SELF)
		{
			FVector vLocation = m_pCharacter->GetActorForwardVector().RotateAngleAxis(m_TableData.vLocation.X, FVector(0, 0, 1))*m_TableData.vLocation.Y;
			vLocation.Z = m_TableData.vLocation.Z;
			this->SetActorLocation(m_pCharacter->GetActorLocation() + vLocation);
			this->SetActorRotation(m_pCharacter->GetActorRotation() + m_TableData.rRotation);
		}
		else if (BULLET_REFERENCE_TYPE(m_TableData.nParticleReference) == BULLET_REFERENCE_TYPE::BULLET_REFERENCE_TARGET)
		{
			if (m_pCharacter->GetTarget())
			{
				FVector vLocation = m_pCharacter->GetTarget()->GetActorForwardVector().RotateAngleAxis(m_TableData.vLocation.X, FVector(0, 0, 1))*m_TableData.vLocation.Y;
				vLocation.Z = m_TableData.vLocation.Z;
				this->SetActorLocation(m_pCharacter->GetTarget()->GetActorLocation() + vLocation);
				this->SetActorRotation(m_pCharacter->GetTarget()->GetActorRotation() + m_TableData.rRotation);
			}
			else
			{
				//����
				UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
			}
		}
		else if (BULLET_REFERENCE_TYPE(m_TableData.nParticleReference) == BULLET_REFERENCE_TYPE::BULLET_REFERENCE_COLLISTION)
		{
			if (m_arrBulletActor.Num() > 0)
			{
				ParticleSystem->SetWorldLocation(m_arrBulletActor[0]->GetActorLocation() + m_TableData.vLocation);
				ParticleSystem->SetWorldRotation(m_arrBulletActor[0]->GetActorRotation() + m_TableData.rRotation);
			}
			else
			{
				//����
				UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
			}
		}
	}

	ParticleSystem->SetWorldScale3D(m_TableData.vScale);

}

void ASkillAtomBullet::CreateBulletCollistion()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;

	for (int i = 0; i < m_TableData.arrCollision.Num(); ++i)
	{
		auto BulletActorData = gameInstance->SafeGetDataManager()->m_AtomBulletShapeTable.Find(m_TableData.arrCollision[i]);
		if (BulletActorData)
		{
			UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(TEXT("/Game/BPInstance/Actor/SkillBulletCollistionBP.SkillBulletCollistionBP_C"));
			if (!ParentClass)
			{
				return;
			}
			ASkillBulletCollisiton* pActor = GetWorld()->SpawnActor<ASkillBulletCollisiton>(ParentClass, GetActorLocation(), GetActorRotation());
			pActor->SetOwner(this);
			pActor->InitByData(*BulletActorData);
			m_arrBulletActor.Add(pActor);
		}
	}

}
