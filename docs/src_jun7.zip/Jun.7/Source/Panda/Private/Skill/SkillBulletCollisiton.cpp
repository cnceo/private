// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillBulletCollisiton.h"

// Sets default values
ASkillBulletCollisiton::ASkillBulletCollisiton()
	: m_bInterval(false)
	, m_nCheckHitCount(0)
	, m_fLifeTime(0)
	, m_fCurTime(0)
	, m_nBezierIndex(0)
{
	PrimaryActorTick.bCanEverTick = true;
	m_mapTarget.Reset();

}

ASkillBulletCollisiton::~ASkillBulletCollisiton()
{
	if(m_bInterval && IsValid(GetWorld()))
		GetWorld()->GetTimerManager().ClearTimer(m_HitHandle);
}

// Called when the game starts or when spawned
void ASkillBulletCollisiton::BeginPlay()
{
	Super::BeginPlay();
}

void ASkillBulletCollisiton::InitByData(FsAtomBulletShapeTable TableData)
{
	m_TableData = TableData;
	auto pCharacter = GetCharacter();
	auto pAtomBullet = GetAtomBullet();
	if (!pAtomBullet || !pCharacter) return;

	m_fLifeTime = pAtomBullet->m_TableData.fLifeTime;

	//�󶨽�ɫ����
	if (BULLET_BIND_TYPE(pAtomBullet->m_TableData.nCollisionBand) == BULLET_BIND_TYPE::BULLET_BIND_SELF)
	{
		this->AttachRootComponentToActor(pAtomBullet);
		this->SetActorRelativeLocation(m_TableData.vLocation);
		this->SetActorRelativeRotation(m_TableData.rRotation);
	}
	//�󶨵�Ŀ��
	else if (BULLET_BIND_TYPE(pAtomBullet->m_TableData.nCollisionBand) == BULLET_BIND_TYPE::BULLET_BIND_TARGET)
	{
		if (pCharacter->GetTarget())
		{
			this->AttachRootComponentToActor(pCharacter->GetTarget());
			this->SetActorRelativeLocation(m_TableData.vLocation);
			this->SetActorRelativeRotation(m_TableData.rRotation);
		}
		else
		{
			//����
			UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
		}
	}
	//�ް�
	else
	{
		//��ʼλ�������������ɫ
		if (BULLET_REFERENCE_TYPE(pAtomBullet->m_TableData.nCollisionReference) == BULLET_REFERENCE_TYPE::BULLET_REFERENCE_SELF)
		{
		 	FVector vLocation = pCharacter->GetActorForwardVector().RotateAngleAxis(m_TableData.vLocation.X, FVector(0, 0, 1))*m_TableData.vLocation.Y;
			vLocation.Z = m_TableData.vLocation.Z;
			FVector vStart = GetCharacter()->GetActorLocation() + vLocation;
			this->SetActorLocation(vStart);
			this->SetActorRotation(pCharacter->GetActorRotation() + m_TableData.rRotation);
			//�����˶���������
			if (m_TableData.bBezier)
			{
				SetBezierData(pCharacter, vStart);
			}
		}
		//��ʼλ�������Ŀ��
		else if (BULLET_REFERENCE_TYPE(pAtomBullet->m_TableData.nCollisionReference) == BULLET_REFERENCE_TYPE::BULLET_REFERENCE_TARGET)
		{
			if (pCharacter->GetTarget())
			{
				FVector vLocation = pCharacter->GetTarget()->GetActorForwardVector().RotateAngleAxis(m_TableData.vLocation.X, FVector(0, 0, 1))*m_TableData.vLocation.Y;
				vLocation.Z = m_TableData.vLocation.Z;
				FVector vStart = pCharacter->GetTarget()->GetActorLocation() + vLocation;
				this->SetActorLocation(vStart);
				this->SetActorRotation(pCharacter->GetTarget()->GetActorRotation() + m_TableData.rRotation);
				//�����˶���������
				if (m_TableData.bBezier)
				{
					SetBezierData(pCharacter->GetTarget(), vStart);
				}
			}
			else
			{
				//����
				UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
			}
		}
		else 
		{
			//����
			UPandaUtils::Log(FString::Printf(TEXT("")), true, 30);
		}

	}

	//��ײ�г�ʼ����״���С
	if (m_TableData.strShape == TEXT("Sphere"))
	{
		m_SphereComp->SetSphereRadius(m_TableData.vSize.X);
		m_CollisionComp = m_SphereComp;
	}
	else if (m_TableData.strShape == TEXT("Capsule"))
	{
		m_CapsuleComp->SetCapsuleSize(m_TableData.vSize.X, m_TableData.vSize.Y);
		m_CollisionComp = m_CapsuleComp;
	}
	else if (m_TableData.strShape == TEXT("Box"))
	{
		m_BoxComp->SetBoxExtent(m_TableData.vSize);
		m_CollisionComp = m_BoxComp;
	}
	else
	{
		m_CollisionComp = NewObject<UShapeComponent>(this, UShapeComponent::StaticClass(), NAME_None, RF_MarkAsRootSet);
	}

	//������ģʽ����Timer
	if (BULLET_HIT_TYPE(pAtomBullet->m_TableData.nHitType) == BULLET_HIT_TYPE::BULLET_HIT_INTERVAL)
	{
		m_bInterval = true;
		FTimerDelegate Timer;
		Timer.BindUObject(this, &ASkillBulletCollisiton::CheckIntervalHit);
		GetWorld()->GetTimerManager().SetTimer(m_HitHandle, Timer, pAtomBullet->m_TableData.fIntervalTime, true);
	}

}

void ASkillBulletCollisiton::SetBezierData(AActor* pActor, FVector vStart)
{
	TArray<FVector> arrBezierStart;			//���
	TArray<FVector> arrBezierEnd;			//�յ�
	TArray<FVector> arrBezierControl1;		//���Ƶ�1
	TArray<FVector> arrBezierControl2;		//���Ƶ�2
	for (int32 i = 0; i < m_TableData.arrTime.Num(), i < m_TableData.arrEndPoint.Num(), i < m_TableData.arrEndPoint.Num(); ++i)
	{
		i == 0 ? arrBezierStart.Add(vStart) : arrBezierStart.Add(arrBezierEnd[i - 1]);
		i == 0 ? m_arrBezierBeginTime.Add(0) : m_arrBezierBeginTime.Add(m_arrBezierEndTime[i - 1]);

		m_arrBezierEndTime.Add(m_TableData.arrTime[i]*m_fLifeTime);

		FVector vEnd = UPandaUtils::GetLocationByActor(pActor, m_TableData.arrEndPoint[i]);
		arrBezierEnd.Add(vEnd);

		FVector Control_1 = UPandaUtils::GetLocationByActor(pActor, m_TableData.arrControlPoint1[i]);
		arrBezierControl1.Add(Control_1);

		FVector Control_2 = UPandaUtils::GetLocationByActor(pActor, m_TableData.arrControlPoint2[i]);
		arrBezierControl2.Add(Control_2);

	}

	for (int32 i = 0; i < m_arrBezierBeginTime.Num(); ++i)
	{
		TArray<FVector> OutPoints;
		FVector PramPoints[4];
		PramPoints[0] = arrBezierStart[m_nBezierIndex];
		PramPoints[1] = arrBezierControl1[m_nBezierIndex];
		PramPoints[2] = arrBezierControl2[m_nBezierIndex];
		PramPoints[3] = arrBezierEnd[m_nBezierIndex];
		FVector::EvaluateBezier(PramPoints, 100, OutPoints);
		m_arrBezier.Add(OutPoints);
	}

}

ASkillAtomBullet* ASkillBulletCollisiton::GetAtomBullet()
{
	if (GetOwner())
	{
		return Cast<ASkillAtomBullet>(GetOwner());
	}

	return nullptr;
}

ABaseCharacter* ASkillBulletCollisiton::GetCharacter()
{
	if (GetAtomBullet())
	{
		return GetAtomBullet()->GetCharacter();
	}

	return nullptr;
}

void ASkillBulletCollisiton::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	m_fCurTime += DeltaTime;
	auto pAtomBullet = GetAtomBullet();
	if (!pAtomBullet)return;

	//�˺�������
	++m_nCheckHitCount;
	if (m_nCheckHitCount > 32166) m_nCheckHitCount = 0;

	if (!m_bInterval)
	{
		//�����ӵ���ײ�����п��˺�Actor
		TArray<UPrimitiveComponent*> arrComponents;
		m_CollisionComp->GetOverlappingComponents(arrComponents);
		for (int32 index = 0; index < arrComponents.Num(); ++index)
		{
			IActiveActorInterface* pActor = Cast<IActiveActorInterface>(arrComponents[index]->GetOwner());

			if (pActor)
			{
				auto HitResult = m_mapTarget.Find(pActor);
				//ֻ���һ���˺����ʹ���
				if (BULLET_HIT_TYPE(pAtomBullet->m_TableData.nHitType) == BULLET_HIT_TYPE::BULLET_HIT_ONCE)
				{
					if (!HitResult)
						OnHit(pActor, m_nCheckHitCount);
				}

				//ÿ������ײһ�Σ����һ���˺����͵Ĵ���
				if(BULLET_HIT_TYPE(pAtomBullet->m_TableData.nHitType) == BULLET_HIT_TYPE::BULLET_HIT_MORE)
				{
					if (!HitResult)
					{
						OnHit(pActor, m_nCheckHitCount);
					}
					else
					{
						HitResult->nCurHitCount = m_nCheckHitCount;
					}
				}

			}
		}

		//ÿ������ײһ�Σ����һ���˺�����,������β������ڣ�����˺�Ŀ����ɾ��
		if (BULLET_HIT_TYPE(pAtomBullet->m_TableData.nHitType) == BULLET_HIT_TYPE::BULLET_HIT_MORE)
		{
			for (auto It = m_mapTarget.CreateConstIterator(); It;)
			{
				auto HitResult = It.Value();
				if (It.Value().nCurHitCount != m_nCheckHitCount)
				{
					m_mapTarget.Remove(It.Key());
				}
				else
				{
					++It;
				}
			}
		}

	}

	if (m_TableData.bBezier)
	{
		if (m_fCurTime > m_arrBezierEndTime[m_nBezierIndex] && m_nBezierIndex < m_arrBezierBeginTime.Num())
		{
				++m_nBezierIndex;
		}

		if (m_nBezierIndex < m_arrBezierBeginTime.Num() && IsValid(this))
		{
			//�ӵ������ƶ��켣
			float fPercent = (m_fCurTime - m_arrBezierBeginTime[m_nBezierIndex]) / (m_arrBezierEndTime[m_nBezierIndex] - m_arrBezierBeginTime[m_nBezierIndex]);
			int32 nIndex = int32(fPercent * 100) - 1;
			if (m_nBezierIndex < m_arrBezier.Num() && nIndex < m_arrBezier[m_nBezierIndex].Num())
			{
				this->SetActorLocation(m_arrBezier[m_nBezierIndex][nIndex]);
			}
		}

	}
	else
	{
		//�ӵ�ֱ���ƶ��켣
		float fDistance = DeltaTime*m_TableData.fSpeed;
		this->SetActorLocation(GetActorLocation() + GetActorForwardVector()*fDistance);
	}

}

void ASkillBulletCollisiton::CheckIntervalHit()
{
	//�����ӵ���ײ�����п��˺�Actor
	TArray<UPrimitiveComponent*> arrComponents;
	m_CollisionComp->GetOverlappingComponents(arrComponents);
	for (int32 index = 0; index < arrComponents.Num(); ++index)
	{
		IActiveActorInterface* pActor = Cast<IActiveActorInterface>(arrComponents[index]->GetOwner());
		if (pActor)
		{
			OnHit(pActor, m_nCheckHitCount);
		}
	}

}

void ASkillBulletCollisiton::OnHit(IActiveActorInterface* pActor, int32 nHitCount)
{
	//pAtomBullet->nHitType 1=1���˺� 2ÿ������ 3�������
	auto pAtomBullet = GetAtomBullet();
	if (!pAtomBullet) return;
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;
	auto pCharacter = Cast<ABaseCharacter>(pActor);

	FsAtomEffectTable sEffectTable;
	//���Լ�����
	if (pCharacter && pCharacter == GetCharacter() && pAtomBullet->m_sSelfEffectTable.nID != 0)
	{
		sEffectTable = pAtomBullet->m_sSelfEffectTable;
	}

	//���ѷ�

	//�Եз� 
	if (!pCharacter || (pCharacter != GetCharacter() && GetCharacter()->m_emType != pCharacter->m_emType))
	{
		sEffectTable = pAtomBullet->m_sEnemyEffectTable;
	}

	//��Ч��������
	if (sEffectTable.nID == 0) return;

	//���д���
	FsSkillHitResult sHitResult;
	USkillFormula::GetHitResult(sHitResult, sEffectTable, GetCharacter(), Cast<ABaseCharacter>(pActor), nHitCount);
	m_mapTarget.Add(pActor, sHitResult);
	pActor->Execute_OnHit(Cast<AActor>(pActor), GetCharacter(), sHitResult);

}