// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillAtomHit.h"
#include "NeoFurComponent.h"

USkillAtomHit::USkillAtomHit()
{

}

void USkillAtomHit::InitByData(FsAtomExtendTable TableData, ABaseCharacter* pCharacter, USkillInstance* pSkillInstance)
{
	Super::InitByData(TableData, pCharacter, pSkillInstance);
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		auto AtomHitData = gameInstance->SafeGetDataManager()->m_AtomHitTable.Find(TableData.nAtomID);
		if (AtomHitData)
		{
			m_TableData = *AtomHitData;
			SetBaseTable(m_TableData);
		}
	}
}

void USkillAtomHit::ResetAtom()
{
	Super::ResetAtom();
	m_mapTarget.Reset();
}

bool USkillAtomHit::PlaySkillAtom(ABaseCharacter* pReviseTarget)
{
	return Super::PlaySkillAtom(pReviseTarget);
}

bool USkillAtomHit::OnAnimTick(float fTime, const FString& AnimName)
{
	if (Super::OnAnimTick(fTime, AnimName)) return true;

	for (int32 i = 0; i < m_TableData.arrHitCount.Num(); ++i)
	{
		//����Ƿ����˺��ж��׶�
		if (m_fCurTime > m_TableData.arrHitCount[i].fBegin && m_fCurTime < m_TableData.arrHitCount[i].fEnd)
		{
			if (m_TableData.arrCollision.Num() > i)
			{
				TArray<FString> arrCollision;
				int32 nIndex = m_TableData.arrCollision[i].ParseIntoArray(arrCollision, TEXT("_"));
				CheckCollision(i + 1, arrCollision);
			}
		}
	}

	return true;

}

void USkillAtomHit::CheckCollision(int32 nHitCount, TArray<FString> arrCollision)
{
	ABaseCharacter* pPlayer = GetCharacter();

	if (pPlayer)
	{
		//����Ч����ײ�������ײ���
		for (int32 i = 0; i < arrCollision.Num(); ++i)
		{
			CHARACTER_COLLISION_TYPE emCollisionType = CHARACTER_COLLISION_TYPE(FCString::Atoi(*arrCollision[i]));
			//�����ײ��
			UShapeComponent* pComponent = pPlayer->GetCollisionComponent(emCollisionType);
			if (pComponent)
			{
				TArray<UPrimitiveComponent*> arrComponents;
				pComponent->GetOverlappingComponents(arrComponents);
				//������ײ������ײ�����
				for (int32 index = 0; index < arrComponents.Num(); ++index)
				{
					FString strName = arrComponents[index]->GetName();
					auto NeoFur = Cast<UNeoFurComponent>(arrComponents[index]);
					auto Destructible = Cast<UDestructibleComponent>(arrComponents[index]);
					auto SkeletalMesh = Cast<USkeletalMeshComponent>(arrComponents[index]);
					if(strName != TEXT("CollisionCylinder") && !NeoFur && !Destructible && !SkeletalMesh) continue;

					IActiveActorInterface* pActor = Cast<IActiveActorInterface>(arrComponents[index]->GetOwner());
					//�ҳ����Ա����е�Ŀ��Actor(����ȱ�ٵ��ҷ��ж�)
					auto pCharacter = Cast<ABaseCharacter>(pActor);
					if (pActor && pActor != GetCharacter() && pCharacter )//&& GetCharacter()->m_emType != pCharacter->m_emType)
					{
						auto HitResult = m_mapTarget.Find(pActor);
						//����Ѿ��������б��ڣ��������д����ж�
						if (HitResult)
						{
							if ((*HitResult).nCurHitCount == nHitCount)
							{
								continue;
							}
						}

						auto gameInstance = UPandaGameInstance::Instance();
						if (gameInstance)
						{

							//���д���
							FsSkillHitResult sHitResult;
							USkillFormula::GetHitResult(sHitResult, m_sEnemyEffectTable, GetCharacter(), Cast<ABaseCharacter>(pActor), nHitCount);
							m_mapTarget.Add(pActor, sHitResult);
							GetCharacter()->SetServerSkillHitResult(sHitResult);
							//pActor->Execute_OnHit(Cast<AActor>(pActor), GetCharacter(), sHitResult);

						}

					}
				}
			}
		}

	}

}