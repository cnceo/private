// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillAtomBase.h"
#include "SkillAtomBullet.h"

// Sets default values
USkillAtomBase::USkillAtomBase()
	: m_fMaxTime(0)
	, m_fCurTime(0)
	, m_fFuseTime(0)
	, m_bNext(false)
	, m_bNextCheck(false)
	, m_CurHitCount(0)
	, m_pAnimMontage(nullptr)
	, m_pReviseTarget(nullptr)
	, m_pCharacter(nullptr)
	, m_pSkillInstance(nullptr)
{

}

void USkillAtomBase::InitByData(FsAtomExtendTable TableData, ABaseCharacter* pCharacter, USkillInstance* pSkillInstance)
{
	if (!pSkillInstance)
	{
		//����
	}
	m_sAtomExtendData = TableData;
	m_pCharacter = pCharacter;
	m_pSkillInstance = pSkillInstance;

	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		auto EffectSelf = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_sAtomExtendData.nEffectSelf);
		if (EffectSelf)
		{
			m_sSelfEffectTable = *EffectSelf;
		}

		auto EffectFriend = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_sAtomExtendData.nEffectFriend);
		if (EffectFriend)
		{
			m_sFriendEffectTable = *EffectFriend;
		}

		auto EffectEnemy = gameInstance->SafeGetDataManager()->m_AtomEffectTable.Find(m_sAtomExtendData.nEffectEnemy);
		if (EffectEnemy)
		{
			m_sEnemyEffectTable = *EffectEnemy;
		}
	}
}

void  USkillAtomBase::SetBaseTable(FsAtomBaseTable AtomData)
{ 
	m_sBaseAtomData = AtomData;

	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		auto TableData = gameInstance->SafeGetDataManager()->m_ResourcesTable.Find(m_sBaseAtomData.nResourcesID);
		if (TableData)
		{
			m_sResources = *TableData;
		}
	}

}

bool USkillAtomBase::PlaySkillAtom(ABaseCharacter* pReviseTarget)
{
	ABaseCharacter* pPlayer = GetCharacter();
	if (!pPlayer) return false;

	if (pReviseTarget)
	{
		m_pReviseTarget = pReviseTarget;
	}
	else
	{
		if (!CheckPlaySkillAtom()) 
			return false;
	}

	if (m_sSelfEffectTable.nID != 0)
	{
		pPlayer->SetState(CHARACTER_SUB_STATE(m_sSelfEffectTable.nSubState), CHARACTER_STATE(m_sSelfEffectTable.nState));

		if (m_sSelfEffectTable.nMode != 0)
		{
			pPlayer->GetCharacterMovement()->SetMovementMode(EMovementMode(m_sSelfEffectTable.nMode));
		}
		
	}
	
	SetAtomAnim();
	CreateBulletByBegin();
	if (m_sAtomExtendData.nCameraID > 0)
	{
		FTimerDelegate Timer;
		Timer.BindUObject(this, &USkillAtomBase::CameraEffCallBack);
		GetCharacter()->GetWorld()->GetTimerManager().SetTimer(m_CameraHandle, Timer, m_sAtomExtendData.fCameraBegin, false);
	}
	return true;
}

bool USkillAtomBase::CheckPlaySkillAtom()
{
	if (GetCharacter())
	{
		ABaseCharacter* pCharacter = nullptr;
		//���Լ��
		if (GetCharacter()->m_emType == CHARACTER_TYPE::CHARACTER_TYPE_PLAYER)
		{
			auto pPlayer = Cast<APlayerCharacter>(GetCharacter());
			//�������Լ��
			if (m_sBaseAtomData.nHP > pPlayer->BaseDataComponent->GetHP()
				|| m_sBaseAtomData.nMP > pPlayer->BaseDataComponent->GetMP()
				|| m_sBaseAtomData.nPower > pPlayer->BaseDataComponent->GetPower())
			{
				return false;
			}
			pCharacter = pPlayer;
		}
		else
		{
			auto pMonster = Cast<AMonsterCharacter>(GetCharacter());
			if (m_sBaseAtomData.nHP > pMonster->BaseDataComponent->GetHP()
				|| m_sBaseAtomData.nMP > pMonster->BaseDataComponent->GetMP()
				|| m_sBaseAtomData.nPower > pMonster->BaseDataComponent->GetPower())
			{
				return false;
			}
			pCharacter = pMonster;
		}

		//����״̬���
		bool bHas = false;
		for (int32 i = 0; i < m_sBaseAtomData.arrCharacterState.Num(); ++i)
		{
			if ((int32)pCharacter->GetState() == m_sBaseAtomData.arrCharacterState[i])
			{
				bHas = true;
				break;
			}
		}
		if (m_sBaseAtomData.arrCharacterState.Num() > 0 && !bHas) return false;

		//������״̬���
		bHas = false;
		for (int32 i = 0; i < m_sBaseAtomData.arrCharacterSubState.Num(); ++i)
		{
			if ((int32)pCharacter->GetSubState() == m_sBaseAtomData.arrCharacterSubState[i])
			{
				bHas = true;
				break;
			}
		}
		if (m_sBaseAtomData.arrCharacterSubState.Num() > 0 && !bHas) return false;

		//����CharacterMovementMode���
		bHas = false;
		for (int32 i = 0; i < m_sBaseAtomData.arrMovementMode.Num(); ++i)
		{
			if ((int32)pCharacter->GetCharacterMovement()->MovementMode == m_sBaseAtomData.arrMovementMode[i])
			{
				bHas = true;
				break;
			}
		}
		if (m_sBaseAtomData.arrMovementMode.Num() > 0 && !bHas) return false;

		//����BUFF���
		//bHas = false;
		//for (int32 i = 0; i < m_sBaseAtomData.arrBUFF.Num(); ++i)
		//{
		//	if (m_sBaseAtomData.arrBUFF[i])
		//	{
		//		bHas = true;
		//		break;
		//	}
		//}
		//if (m_sBaseAtomData.arrBUFF.Num() > 0 && !bHas) return false;

		//Ŀ����ؼ��
		if (m_sBaseAtomData.bTarget)
		{
			auto pTarget = pCharacter->GetTarget();
			if (!pTarget || pCharacter->GetDistanceTo(pTarget) > m_sBaseAtomData.nDistance)
			{
				return false;

			}

			//Ŀ��״̬���
			bool bTargetHas = false;
			for (int32 i = 0; i < m_sBaseAtomData.arrTargetState.Num(); ++i)
			{
				if ((int32)pTarget->GetState() == m_sBaseAtomData.arrTargetState[i])
				{
					bTargetHas = true;
					break;
				}
			}
			if (m_sBaseAtomData.arrTargetState.Num() > 0 && !bTargetHas) return false;

			//Ŀ����״̬���
			bTargetHas = false;
			for (int32 i = 0; i < m_sBaseAtomData.arrTargetSubState.Num(); ++i)
			{
				if ((int32)pTarget->GetSubState() == m_sBaseAtomData.arrTargetSubState[i])
				{
					bTargetHas = true;
					break;
				}
			}
			if (m_sBaseAtomData.arrTargetSubState.Num() > 0 && !bTargetHas) return false;

			//Ŀ��CharacterMovementMode���
			bTargetHas = false;
			for (int32 i = 0; i < m_sBaseAtomData.arrTargetMovementMode.Num(); ++i)
			{
				if ((int32)pTarget->GetCharacterMovement()->MovementMode == m_sBaseAtomData.arrTargetMovementMode[i])
				{
					bTargetHas = true;
					break;
				}
			}
			if (m_sBaseAtomData.arrTargetMovementMode.Num() > 0 && !bTargetHas) return false;

			//Ŀ��BUFF���
			//bTargetHas = false;
			//for (int32 i = 0; i < m_sBaseAtomData.arrTargetBUFF.Num(); ++i)
			//{
			//	if (m_sBaseAtomData.arrTargetBUFF[i])
			//	{
			//		bTargetHas = true;
			//		break;
			//	}
			//}
			//if (m_sBaseAtomData.arrTargetBUFF.Num() > 0 && !bTargetHas) return false;
		}

	}

	return true;

}

void USkillAtomBase::SetAtomAnim()
{
	if (!m_sResources.strPath.IsEmpty() && !m_sResources.strName.IsEmpty())
	{
		if (m_sResources.strName.Find(TEXT("Montage")))
		{
			m_pAnimMontage = UPandaUtils::LoadResource<UAnimMontage>(m_sResources.strPath);
		}
	}

	if (!m_pAnimMontage)
	{
		UPandaUtils::Log(FString::Printf(TEXT("SkillAnim Load Failed! [ExtendId=%d]  [name=%s]  [path=%s]"), m_sAtomExtendData.nID, *m_sResources.strName, *m_sResources.strPath), true, 5, FColor::Red);
	}
	//else if (GetCharacter())
	//{
	//	GetCharacter()->SetSimulatePlayAnim(m_pAnimMontage);
	//}
}

void USkillAtomBase::ResetAtom()
{
	m_fMaxTime = 0;
	m_fCurTime = 0;
	m_fFuseTime = 0;
	m_bNext = false;
	m_bNextCheck = false;
	m_pAnimMontage = nullptr;
	m_pReviseTarget = nullptr;

	for (int i = 0; i < m_sAtomExtendData.arrBulletAtom.Num(); ++i)
	{
		m_sAtomExtendData.arrBulletAtom[i].param_4 = 0;
	}

	if (m_sAtomExtendData.nCameraID > 0 && m_sAtomExtendData.bCameraBreak)
	{
		GetCharacter()->GetWorld()->GetTimerManager().ClearTimer(m_CameraHandle);
		UPACameraManager* pManager = UPACameraManager::GetCameraManagerInstance();
		pManager->PlayLocCameraEff(m_sAtomExtendData.nCameraID, false);
	}
}

void USkillAtomBase::OnAnimBegin(float fTime, const FString& AnimName)
{
	if (m_sResources.strName != AnimName) return;
	m_fMaxTime = fTime;
	if (m_pReviseTarget)
	{
		GetCharacter()->TurnAtActor(m_pReviseTarget);
	}

}

bool USkillAtomBase::OnAnimTick(float fTime, const FString& AnimName)
{
	if (m_sResources.strName != AnimName) return true;

	m_fCurTime += fTime;

	if (m_sBaseAtomData.nType == (int32)SKILL_ATOM_TYPE::SKILL_ATOM_HIT)
	{
		if (!m_bNext && m_fCurTime > m_sBaseAtomData.fFuseTime)
		{
			m_bNext = true;
			if (GetSkillInstance())
				GetSkillInstance()->OnBeFuseEvent();
		}
	}

	if (m_bNext && !m_bNextCheck)
	{
		m_fFuseTime += fTime;

		if (ATOM_NEXT_TYPE(m_sAtomExtendData.nNextType) == ATOM_NEXT_TYPE::ATOM_NEXT_TIME && m_fFuseTime > m_sAtomExtendData.fNextTime)
		{
			m_bNextCheck = true;
			auto pSkill = GetSkillInstance();
			if (pSkill)
			{
				return pSkill->PlayNextSkill();
			}
		}

	}

	CreateBulletByDelay(m_fCurTime);
	return false;

}

void USkillAtomBase::OnAnimEnd(const FString& AnimName)
{
 	if (m_sResources.strName != AnimName) return;

	auto pSkill = GetSkillInstance();
	if (pSkill)
	{
		pSkill->PlayAtomEnd();
	}

}

void USkillAtomBase::CreateBulletByBegin()
{
	if (m_sAtomExtendData.arrBulletAtom.Num() <= 0) return;
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;

	for (int i = 0; i < m_sAtomExtendData.arrBulletAtom.Num(); ++i)
	{
		if ((int32)m_sAtomExtendData.arrBulletAtom[i].param_4 != 1 && BULLET_TRIGGER_TYPE((int32)m_sAtomExtendData.arrBulletAtom[i].param_2) == BULLET_TRIGGER_TYPE::BULLET_TRIGGER_BEGIN)
		{
			if (!GetCharacter()) break;
			ASkillAtomBullet* pBullet = (ASkillAtomBullet*)GetCharacter()->GetWorld()->SpawnActor(ASkillAtomBullet::StaticClass());
			pBullet->InitByData((int32)m_sAtomExtendData.arrBulletAtom[i].param_1, GetCharacter());
			m_sAtomExtendData.arrBulletAtom[i].param_4 = 1;
		}
	}

}

void USkillAtomBase::CreateBulletByDelay(float fTime)
{
	if (m_sAtomExtendData.arrBulletAtom.Num() <= 0) return;
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;

	for (int i = 0; i < m_sAtomExtendData.arrBulletAtom.Num(); ++i)
	{
		if ((int32)m_sAtomExtendData.arrBulletAtom[i].param_4 != 1
			&& BULLET_TRIGGER_TYPE((int32)m_sAtomExtendData.arrBulletAtom[i].param_2) == BULLET_TRIGGER_TYPE::BULLET_TRIGGER_DELAY
			&& fTime > m_sAtomExtendData.arrBulletAtom[i].param_3)
		{
			if (!GetCharacter()) break;
			ASkillAtomBullet* pBullet = (ASkillAtomBullet*)GetCharacter()->GetWorld()->SpawnActor(ASkillAtomBullet::StaticClass());
			pBullet->InitByData((int32)m_sAtomExtendData.arrBulletAtom[i].param_1, GetCharacter());
			m_sAtomExtendData.arrBulletAtom[i].param_4 = 1;
		}
	}
}

void USkillAtomBase::CreateBulletByCollisiton(EPhysicalSurface emType)
{
	if (m_sAtomExtendData.arrBulletAtom.Num() <= 0) return;
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;

	for (int i = 0; i < m_sAtomExtendData.arrBulletAtom.Num(); ++i)
	{
		if (!GetCharacter()) break;
	}
}

void USkillAtomBase::CameraEffCallBack()
{
	UPACameraManager* pManager = UPACameraManager::GetCameraManagerInstance();
	pManager->PlayLocCameraEff(m_sAtomExtendData.nCameraID, true);
}