// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillFormula.h"

void USkillFormula::GetHitResult(FsSkillHitResult& sHitResult, FsAtomEffectTable TableData, ABaseCharacter* HitCauser, ABaseCharacter* pOtherActor, int32 nHitCount, UPrimitiveComponent* pOtherComp)
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (!gameInstance) return;

	float fHP = 0;
	float fMP = 0;
	float fPower = 0;

	USkillFormula* pHP = gameInstance->SafeGetDataManager()->GetSkillFormula(TableData.nHPBP);
	if (pHP)
	{
		fHP = pHP->GetResult(HitCauser, pOtherActor, TableData.fHPNum);
	}

	USkillFormula* pMP = gameInstance->SafeGetDataManager()->GetSkillFormula(TableData.nMPBP);
	if (pMP)
	{
		fMP = pMP->GetResult(HitCauser, pOtherActor, TableData.fMPNum);
	}

	USkillFormula* pPower = gameInstance->SafeGetDataManager()->GetSkillFormula(TableData.nPowerBP);
	if (pPower)
	{
		fPower = pPower->GetResult(HitCauser, pOtherActor, TableData.fPowerNum);
	}

	sHitResult.Init(TableData, HitCauser, pOtherActor, nHitCount, nullptr, fHP, fMP, fPower);

}