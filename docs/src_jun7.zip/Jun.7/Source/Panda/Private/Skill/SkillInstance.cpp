// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SkillInstance.h"
#include "PandaGameInstance.h"

// Sets default values
USkillInstance::USkillInstance()
	: m_nCurAtomIndex(0)
	, m_nCurArrIndex(0)
	, m_bPlay(false)
	, m_pCharacter(nullptr)
{
	m_OnTick = FTickerDelegate::CreateUObject(this, &USkillInstance::Tick);
}

USkillInstance::~USkillInstance()
{
	for (int32 i = 0; i < m_arrAtomInstance.Num(); ++i)
	{
		for (int32 n = 0; n < m_arrAtomInstance[i].Num(); ++n)
		{
			if (m_arrAtomInstance[i][n])
			{
				m_arrAtomInstance[i][n]->RemoveFromRoot();
				m_arrAtomInstance[i][n]->SetInternalFlags(EInternalObjectFlags::NoStrongReference);
			}
		}
		m_arrAtomInstance[i].Reset();
	}
	m_arrAtomInstance.Reset();
}

void USkillInstance::InitByID(int32 nID, ABaseCharacter* pCharacter)
{
	if (!pCharacter)
	{
		//����
		return;
	}
	m_pCharacter = pCharacter;
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		auto TableData = gameInstance->SafeGetDataManager()->m_SkillTable.Find(nID);
		if (TableData)
		{
			m_sTableData = *TableData;

			for (int32 i = 0; i < m_sTableData.arrAtomExtend.Num(); ++i)
			{
				TArray<FString> arrAtomID;
				TArray<USkillAtomBase*> arrAtom;
				m_sTableData.arrAtomExtend[i].ParseIntoArray(arrAtomID, TEXT("_"));

				for (int32 n = 0; n < arrAtomID.Num(); ++n)
				{
					auto AtomExtend = gameInstance->SafeGetDataManager()->m_AtomExtendTable.Find(FCString::Atoi(*arrAtomID[n]));
					if (AtomExtend)
					{
						switch (AtomExtend->nType)
						{
						case 1:
						{
							USkillAtomHit* pAtom = NewObject<USkillAtomHit>(GGameInstance);
							pAtom->InitByData(*AtomExtend, GetCharacter(), this);
							pAtom->SetInternalFlags(EInternalObjectFlags::RootSet);
							arrAtom.Add(pAtom);
						}
						break;

						case 2:
						{
							USkillAtomChase* pAtom = NewObject<USkillAtomChase>(GGameInstance);
							pAtom->InitByData(*AtomExtend, GetCharacter(), this);
							pAtom->SetInternalFlags(EInternalObjectFlags::RootSet);
							arrAtom.Add(pAtom);
						}
						break;

						default:
							break;
						}
					}

				}

				m_arrAtomInstance.Add(arrAtom);

			}

		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("SkillIInstance Init Faled! nID=%d"), nID);
		}
	}
}

bool USkillInstance::Tick(float DeltaTime)
{
	if (m_bPlay && GetCharacter())
	{
		if (GetCharacter()->GetState() != CHARACTER_STATE::CHARACTER_STATE_SKILL)
		{
			BreakSkill(false);
		}
	}

	return true;
}

void USkillInstance::ResetInstance()
{
	m_bPlay = false;
	m_nCurArrIndex = 0;
	m_nCurAtomIndex = 0;
	APlayerCharacter* pPlayer = Cast<APlayerCharacter>(GetCharacter());
	if (pPlayer)
	{
		pPlayer->BaseDataComponent->UnrealCurrentData.nBreak = 0;
	}

	FTicker::GetCoreTicker().RemoveTicker(m_OnTickHandle);

}

bool USkillInstance::PlaySkill()
{
	if (m_arrAtomInstance.Num() <= 0 || m_arrAtomInstance[0].Num() <= 0) return false;
	AActor* pTarget = nullptr;
	int32 nIndex = GetAngleReviseIndex(0, pTarget);
	bool bPlay = false;
	if (nIndex < 0)
	{
		bPlay = m_arrAtomInstance[0][0]->PlaySkillAtom();
	}
	else
	{
		bPlay = m_arrAtomInstance[0][nIndex]->PlaySkillAtom(Cast<ABaseCharacter>(pTarget));
		m_nCurAtomIndex = nIndex;
	}

	if (bPlay && GetCharacter())
	{
		m_OnTickHandle = FTicker::GetCoreTicker().AddTicker(m_OnTick);
		GetCharacter()->PauseAI();
		m_bPlay = true;

		APlayerCharacter* pPlayer = Cast<APlayerCharacter>(GetCharacter());
		if (pPlayer)
		{
			pPlayer->BaseDataComponent->UnrealCurrentData.nBreak = 20;
		}

	}
	return bPlay;
}

void USkillInstance::GetCharacterSkillAnim()
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num()) return;
	GetCharacter()->SetServerSkillAnim(m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_pAnimMontage);
}

//���ý�ɫ���״̬����
void USkillInstance::ResetCharacterData(bool bChangeState)
{
	auto pCharacter = GetCharacter();
	if (pCharacter)
	{
		pCharacter->ClearCurSkill();
		if (bChangeState && pCharacter->GetState() == CHARACTER_STATE::CHARACTER_STATE_SKILL)
		{
			pCharacter->SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
			pCharacter->GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		}
	}

}

//��ɫ����֪ͨ
void USkillInstance::OnAnimBegin(float fTime, const FString& AnimName)
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num()) return;
	m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->OnAnimBegin(fTime, AnimName);
}

//��ɫ����֪ͨ
void USkillInstance::OnAnimTick(float fTime, const FString& AnimName)
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num()) return;
	m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->OnAnimTick(fTime, AnimName);
}

//��ɫ����֪ͨ
void USkillInstance::OnAnimEnd(const FString& AnimName)
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num()) return;
	m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->OnAnimEnd(AnimName);

}

//������밴���Ƿ񴥷���������.���������±�
int32 USkillInstance::CheckPlayNextByInputKey(bool arrbPressedKey[PLAYER_KEY::PLAYER_KEY_MAX], PLAYER_KEY emCurKey)
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num()) return 0;

	if (ATOM_NEXT_TYPE(m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextType) == ATOM_NEXT_TYPE::ATOM_NEXT_INPUT && m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_bNext)
	{
		auto arr = m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.arrInput;
		for (int32 i = 0; i < arr.Num(); ++i)
		{
			if ((arr[i].nKey_1 == 0 || arrbPressedKey[arr[i].nKey_1])
				&& (arr[i].nKey_2 == 0 || arrbPressedKey[arr[i].nKey_2])
				&& (arr[i].nKey_1 == (int32)emCurKey || arr[i].nKey_2 == (int32)emCurKey)
				)
			{
				return arr[i].nNextIndex;
			}

		}
	}

	return 0;
}

//���ż�������
bool USkillInstance::PlayNextSkill(int32 nNextIndex)
{
	if (nNextIndex == 0)
	{
		nNextIndex = m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextIndex;
	}

	if (m_arrAtomInstance.Num() > nNextIndex && nNextIndex != 0)
	{
		AActor* pTarget = nullptr;
		int32 nIndex = GetAngleReviseIndex(nNextIndex, pTarget);
		bool bPlay = false;
		if (nIndex < 0)
		{
			bPlay = m_arrAtomInstance[nNextIndex][0]->PlaySkillAtom();
			if (bPlay)
			{
				m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->ResetAtom();
				m_nCurArrIndex = nNextIndex;
				m_nCurAtomIndex = 0;
				if (GetCharacter())
					GetCharacter()->PauseAI();

				GetCharacterSkillAnim();

			}
		}
		else
		{
			bPlay = m_arrAtomInstance[nNextIndex][nIndex]->PlaySkillAtom(Cast<ABaseCharacter>(pTarget));
			if (bPlay)
			{
				m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->ResetAtom();
				m_nCurArrIndex = nNextIndex;
				m_nCurAtomIndex = nIndex;
				if (GetCharacter())
					GetCharacter()->PauseAI();

				GetCharacterSkillAnim();
			}
		}

		return bPlay;

	}

	return false;
}

void USkillInstance::PlayAtomEnd()
{
	
	if (ATOM_NEXT_TYPE(m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextType) == ATOM_NEXT_TYPE::ATOM_NEXT_BEEND && m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextIndex != 0)
	{
		bool bPlay = PlayNextSkill(m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextIndex);
		if (bPlay) return;
	}

	BreakSkill();

}

void USkillInstance::OnBeFuseEvent()
{
	if (GetCharacter())
		GetCharacter()->RestartAI();
}

bool USkillInstance::IsBeFuse()
{
	return m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_bNext;
}

bool USkillInstance::IsBeCounterattack()
{
	if (IsBeFuse())
	{
		if (ATOM_NEXT_TYPE(m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_sAtomExtendData.nNextType) == ATOM_NEXT_TYPE::ATOM_NEXT_BEHIT)
			return true;
	}

	return false;
}

void USkillInstance::BreakSkill(bool bChangeState)
{
	if (m_nCurArrIndex > m_arrAtomInstance.Num() || m_nCurAtomIndex > m_arrAtomInstance[m_nCurArrIndex].Num())
	{
		return;
	}

	GetCharacter()->SetServerSkillAnim(nullptr);
	////ֹͣ��ǰ���ŵ���̫��
	//if (m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_pAnimMontage)
	//{
	//	ABaseCharacter* pPlayer = GetCharacter();
	//	if (pPlayer)
	//	{
	//		pPlayer->GetMesh()->GetAnimInstance()->Montage_Stop(0, m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->m_pAnimMontage);
	//	}
	//}

	UPandaUtils::Log("BreakSkill", true);

	m_arrAtomInstance[m_nCurArrIndex][m_nCurAtomIndex]->ResetAtom();
	ResetInstance();
	ResetCharacterData(bChangeState);
}

int32 USkillInstance::GetAngleReviseIndex(int32 arrIndex, AActor*& pOutTarget)
{
	if (GetCharacter() && GetCharacter()->GetCheckSphere() 
		&& !GetCharacter()->GetTarget() && m_arrAtomInstance[arrIndex][0]->m_sAtomExtendData.bAutoAngle)
	{
		TArray<AActor*> arrActor;
		TMap<float, AActor*> mapActor;

		//��ü�����е�ȫ����ɫ
		GetCharacter()->GetCheckSphere()->GetOverlappingActors(arrActor, ABaseCharacter::StaticClass());
		for (int32 i = 0; i < arrActor.Num(); ++i)
		{
			//ֻ�����ж�Ŀ��
			if (GetCharacter() != arrActor[i] && !Cast<ABaseCharacter>(arrActor[i])->IsDead())
			{
				mapActor.Add(FMath::Abs(GetCharacter()->GetDistanceTo(arrActor[i])), arrActor[i]);
			}
		}

		//��������ɽ���Զ����
		mapActor.KeySort([](float a, float b) { return b > a; });

		//����Ŀ������
		for (auto ActorIt = mapActor.CreateConstIterator(); ActorIt; ++ActorIt)
		{
			ActorIt.Key();
			AActor* pActor = ActorIt.Value();
			for (int32 i = 0; i < m_arrAtomInstance[arrIndex].Num(); ++i)
			{
				if (m_arrAtomInstance[arrIndex][i]->m_sAtomExtendData.bAutoAngle)
				{
					//���ܵ����ĽǶȼ��
					FVector distance = pActor->GetActorLocation() - GetCharacter()->GetActorLocation();
					FVector direction = GetCharacter()->GetCapsuleComponent()->GetForwardVector();
					float fAngle = UPandaUtils::VectorAngle(direction, distance);
					for (int32 n = 0; n < m_arrAtomInstance[arrIndex][i]->m_sAtomExtendData.arrHitAngle.Num(); ++n)
					{
						float fBegin = m_arrAtomInstance[arrIndex][i]->m_sAtomExtendData.arrHitAngle[n].fBegin;
						float fEnd = m_arrAtomInstance[arrIndex][i]->m_sAtomExtendData.arrHitAngle[n].fEnd;
						if (fAngle >= fBegin && fAngle <= fEnd)
						{
							//�ҵ��Ƕ��������ϲ��������ͷ������ļ���
							if (m_arrAtomInstance[arrIndex][i]->CheckPlaySkillAtom())
							{
								pOutTarget = pActor;
								return i;
							}
						}
					}

				}

			}
		}


	}

	return -1;
}