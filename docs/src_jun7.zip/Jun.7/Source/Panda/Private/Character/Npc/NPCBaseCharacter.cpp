// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "NPCBaseCharacter.h"

ANPCBaseCharacter::ANPCBaseCharacter()
{
	// Create monster base data component
	// BaseDataComponent = CreateDefaultSubobject<UPAMonsterHeroBaseData>(TEXT("MonsterBaseDataComponent"));

	// Init
	InitCapsuleCollsionData();

	IconMesh = CreateOptionalDefaultSubobject<UStaticMeshComponent>(TEXT("IconMeshComponent"));
	if (IconMesh)
	{
		IconMesh->AlwaysLoadOnClient = true;
		IconMesh->AlwaysLoadOnServer = true;
		IconMesh->bCastDynamicShadow = false;
		IconMesh->bAffectDynamicIndirectLighting = false;
		IconMesh->PrimaryComponentTick.TickGroup = TG_PrePhysics;
		IconMesh->AttachParent = GetRootComponent();
		IconMesh->SetRelativeLocation(FVector(0, 0, GetCapsuleComponent()->GetScaledCapsuleHalfHeight() + 20));
	}
	
	mNPCType = ICONMESH_Invalid;
	// ...
}

void ANPCBaseCharacter::BeginPlay()
{
	Super::BeginPlay();

	if(AMonsterBaseCharacter::GetTaskId() == 0)
		IconMesh->SetVisibility(false);
}

// Called to bind functionality to input
void ANPCBaseCharacter::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);

}

void ANPCBaseCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
}

void ANPCBaseCharacter::InitCapsuleCollsionData()
{
	/*TouchingActorEntryPosition = FVector::ZeroVector;*/
}

bool ANPCBaseCharacter::CheckAIParamComponentExist()
{
	return AMonsterBaseCharacter::CheckAIParamComponentExist();
}

bool ANPCBaseCharacter::CheckHaveTaskId()
{
	return AMonsterBaseCharacter::CheckHaveTaskId();
}

bool ANPCBaseCharacter::CheckNeedToCreateTaskUI()
{
	return AMonsterBaseCharacter::CheckNeedToCreateTaskUI();
}

bool ANPCBaseCharacter::CheckBNPC()
{
	return AMonsterBaseCharacter::CheckBNPC();
}

bool ANPCBaseCharacter::CheckBMonster()
{
	return AMonsterBaseCharacter::CheckBMonster();
}

int32 ANPCBaseCharacter::GetTaskId()
{
	return AMonsterBaseCharacter::GetTaskId();
}

int32 ANPCBaseCharacter::GetNPCId()
{
	return AMonsterBaseCharacter::GetNPCId();
}

/** ����ͷ��ģ�� ����*/
void ANPCBaseCharacter::SetIconMeshType(IconMeshType inType)
{
	if (inType == ICONMESH_Ask)
	{
		UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Meshs/wenhao.wenhao"));
		UStaticMesh* mesh = Cast<UStaticMesh>(itemObj);
		IconMesh->SetStaticMesh(mesh);
		IconMesh->SetVisibility(true);
	}
	else if (inType == ICONMESH_Ask_Invalid)
	{
		UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Meshs/wenhao2.wenhao2"));
		UStaticMesh* mesh = Cast<UStaticMesh>(itemObj);
		IconMesh->SetStaticMesh(mesh);
		IconMesh->SetVisibility(true);
	}
	else if (inType == ICONMESH_Sigh)
	{
		UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Meshs/gantanhao.gantanhao"));
		UStaticMesh* mesh = Cast<UStaticMesh>(itemObj);
		IconMesh->SetStaticMesh(mesh);
		IconMesh->SetVisibility(true);
	} 
	else if (inType == ICONMESH_Sigh_Invalid)
	{
		UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Meshs/gantanhao2.gantanhao2"));
		UStaticMesh* mesh = Cast<UStaticMesh>(itemObj);
		IconMesh->SetStaticMesh(mesh);
		IconMesh->SetVisibility(true);
	}
	else
	{
		IconMesh->SetStaticMesh(nullptr);
		IconMesh->SetVisibility(false);
	}

}