﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "BaseCharacter.h"
#include "Net/UnrealNetwork.h"
#include "Utils/PandaUtils.h"
#include "PandaGameInstance.h"

ABaseCharacter::ABaseCharacter()
	: m_emState(CHARACTER_STATE::CHARACTER_STATE_NORMAL)
	, m_emSubState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL)
	, m_pTargetActor(nullptr)
	, m_pCurSkill(nullptr)
	, m_SkillAnim(nullptr)
	, m_bDead(false)
	, m_fBeHitFlyTime(0)
	, m_fAngle(0)
	, m_weaponId(0)
	, m_bFighting(false)
	, m_emType(CHARACTER_TYPE::CHARACTER_TYPE_NONE)
	, m_nTempCount(0)
	, TargeOther(nullptr)
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;

	m_DelayImpulseComponent = CreateDefaultSubobject<UDelayImpulseComponent>(TEXT("DelayImpulseComponent"));
	MatBillHealth = CreateDefaultSubobject<UMaterialBillboardComponent>(TEXT("UMaterialBillboardComponent"));
	MatBillHealth->AttachParent = GetRootComponent();

	m_mapBaseSkill.Empty();
}

ABaseCharacter::~ABaseCharacter()
{

}

void ABaseCharacter::GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	// 状态
	DOREPLIFETIME_CONDITION(ABaseCharacter, m_emState, COND_SkipOwner);
	DOREPLIFETIME_CONDITION(ABaseCharacter, m_emSubState, COND_SkipOwner);
	// 属性
	DOREPLIFETIME(ABaseCharacter, m_tBaseData);
	// 死亡
	DOREPLIFETIME(ABaseCharacter, m_bDead);
	// 目标对象
	DOREPLIFETIME(ABaseCharacter, m_pTargetActor);

	DOREPLIFETIME(ABaseCharacter, m_SkillAnim);

	DOREPLIFETIME(ABaseCharacter, m_HitResult);

}

void ABaseCharacter::SetMaxWalkSpeed(float fSpeed)
{
	GetCharacterMovement()->MaxWalkSpeed = fSpeed;
	SetServerMaxWalkSpeed(fSpeed);
}

void ABaseCharacter::SetServerMaxWalkSpeed_Implementation(float fSpeed)
{
	GetCharacterMovement()->MaxWalkSpeed = fSpeed;
}

bool ABaseCharacter::SetServerMaxWalkSpeed_Validate(float fSpeed)
{
	return true;
}

void ABaseCharacter::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	GetCapsuleComponent()->CanCharacterStepUpOn = ECanBeCharacterBase::ECB_No;
}

// Called when the game starts or when spawned
void ABaseCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (MatBillHealth)
	{
		UMaterial* HealthDynamicMaterial = LoadObject<UMaterial>(nullptr, TEXT("/Game/UI/HUD/Materials/M_HUD_Health_Bar"), TEXT("M_HUD_Health_Bar"), LOAD_None, nullptr);
		HealthDynamicMat = UMaterialInstanceDynamic::Create(HealthDynamicMaterial, this);
		MatBillHealth->AddElement(HealthDynamicMat, nullptr, false, 6, 60, nullptr);
		MatBillHealth->SetVisibility(true);
	}
}

// Called every frame
void ABaseCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	OnBeHitFly(DeltaTime);
	UpdateMatBillHealth();
}

UShapeComponent* ABaseCharacter::GetCollisionComponent(CHARACTER_COLLISION_TYPE emType)
{
	if (emType == CHARACTER_COLLISION_TYPE::COLLISION_WEAPON_L || emType == CHARACTER_COLLISION_TYPE::COLLISION_WEAPON_R)
	{
		if (IsValid(m_CurWeapon))
		{
			TArray<UActorComponent*> arrUShapeComponent = m_CurWeapon->GetComponentsByTag(UShapeComponent::StaticClass(), FName(*FString::Printf(TEXT("Collision_%d"), (int32)emType)));
			if (arrUShapeComponent.Num() > 0)
			{
				return Cast<UShapeComponent>(arrUShapeComponent[0]);
			}
		}
	}
	else
	{
		TArray<UActorComponent*> arrUShapeComponent = GetComponentsByTag(UShapeComponent::StaticClass(), FName(*FString::Printf(TEXT("Collision_%d"), (int32)emType)));
		if (arrUShapeComponent.Num() > 0)
		{
			return Cast<UShapeComponent>(arrUShapeComponent[0]);
		}
	}

	return nullptr;
}

UShapeComponent* ABaseCharacter::GetCheckSphere(FName strTag)
{
	if (!m_CheckSphere)
	{
		TArray<UActorComponent*> arrUShapeComponent = GetComponentsByTag(UShapeComponent::StaticClass(), strTag);
		if (arrUShapeComponent.Num() > 0)
		{
			m_CheckSphere = Cast<UShapeComponent>(arrUShapeComponent[0]);
		}
	}

	return m_CheckSphere;

}

void ABaseCharacter::SetCollisionOverlapEvents(CHARACTER_COLLISION_TYPE emType, bool bEvent)
{
	if (emType == CHARACTER_COLLISION_TYPE::COLLISION_ALL_MAX)
	{
		for (int32 i = 0; i < (int32)CHARACTER_COLLISION_TYPE::COLLISION_ALL_MAX; ++i)
		{
			UShapeComponent* pCollision = GetCollisionComponent((CHARACTER_COLLISION_TYPE)i);
			if (pCollision)
			{
				pCollision->bGenerateOverlapEvents = bEvent;
			}
		}
	}
	else
	{
		UShapeComponent* pCollision = GetCollisionComponent(emType);
		if (pCollision)
		{
			pCollision->bGenerateOverlapEvents = bEvent;
		}
	}
}

void ABaseCharacter::OnAnimBegin_Implementation(float fTime, const FString& AnimName)
{
	if (Role < ENetRole::ROLE_AutonomousProxy) return;
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_SKILL && GetCurSkill())
	{
		GetCurSkill()->OnAnimBegin(fTime, AnimName);
	}

	//到着陆
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_FALLING)
	{
		//获取动画对应的角色状态
		FString strName(*AnimName);
		int32 nIndex = strName.Find(TEXT("__"));
		if (nIndex <= 0) return;
		strName.RemoveAt(nIndex, strName.Len() - nIndex);
		CHARACTER_SUB_STATE emSub = CHARACTER_SUB_STATE(FCString::Atoi(*strName));

		if (emSub == CHARACTER_SUB_STATE::SUB_STATE_LAND)
		{
			SetState(CHARACTER_SUB_STATE::SUB_STATE_LAND, CHARACTER_STATE::CHARACTER_STATE_FALLING);
		}

	}
}

void ABaseCharacter::OnAnimTick_Implementation(float fTime, const FString& AnimName)
{
	if (Role < ENetRole::ROLE_AutonomousProxy) return;
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_SKILL && GetCurSkill())
	{
		GetCurSkill()->OnAnimTick(fTime, AnimName);
	}
}

void ABaseCharacter::OnAnimEnd_Implementation(const FString& AnimName)
{
	if (Role < ENetRole::ROLE_AutonomousProxy) return;
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_SKILL && GetCurSkill())
	{
		GetCurSkill()->OnAnimEnd(AnimName);
		return;
	}

	//获取动画对应的角色状态
	FString strName(*AnimName);
	int32 nIndex = strName.Find(TEXT("__"));
	if (nIndex <= 0) return;
	strName.RemoveAt(nIndex, strName.Len() - nIndex);
	CHARACTER_SUB_STATE emSub = CHARACTER_SUB_STATE(FCString::Atoi(*strName));

	//动画播放完毕后状态处理
	if (m_emSubState == emSub)
	{
		//到待机
		if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT1 || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT2
			|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT3 || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT4
			|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_TUMBLE || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_GETUP
			|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_HITFLY_LAND || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_REEL1
			|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLAG || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_LAND)
		{
			SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
			RestartAI();
		}
		//到倒地起身
		else if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_TUMBLE || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_HITROLL)
		{
			SetState(CHARACTER_SUB_STATE::SUB_STATE_GETUP, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
		}
		//到漂浮状态
		else if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1 || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT2
				|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY)
		{

		}
		//死亡销毁Character
		else if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_DIE_NORMAL)
		{
			if (m_emType != CHARACTER_TYPE::CHARACTER_TYPE_PLAYER)
			{
				Destroy();
			}
		}
	}
}

void ABaseCharacter::OnAnimTick_BP(float fTime, const FString& AnimName)
{
	if (Role < ROLE_AutonomousProxy) return;
	this->Execute_OnAnimTick(this, fTime, AnimName);
}

void ABaseCharacter::OnAnimBegin_BP(float fTime, const FString& AnimName)
{
	if (Role < ROLE_AutonomousProxy) return;
	this->Execute_OnAnimBegin(this, fTime, AnimName);
}

void ABaseCharacter::OnAnimEnd_BP(const FString& AnimName)
{
	if (Role < ROLE_AutonomousProxy) return;
	this->Execute_OnAnimEnd(this, AnimName);
}

bool ABaseCharacter::SetServerState_Validate(CHARACTER_SUB_STATE emSubState, CHARACTER_STATE emState)
{
	return true;
}

void ABaseCharacter::SetServerState_Implementation(CHARACTER_SUB_STATE emSubState, CHARACTER_STATE emState)
{
	m_emSubState = emSubState;
	m_emState = emState;
}

void ABaseCharacter::OnRep_State()
{
	UE_LOG(LogTemp, Warning, TEXT("--------sync state uid=%d,hp=%f, state=%d"), GetUniqueID(), m_tBaseData.fHP, (int32)m_emState);
}

void ABaseCharacter::OnRep_SubState()
{
	UE_LOG(LogTemp, Warning, TEXT("--------sync sub state uid=%d,hp=%f, state=%d"), GetUniqueID(), m_tBaseData.fHP, (int32)m_emState);
}

void ABaseCharacter::SetState(CHARACTER_SUB_STATE emSubState, CHARACTER_STATE emState)
{
	bool bNeedSync = false;
	if (emSubState != CHARACTER_SUB_STATE::SUB_STATE_NONE && m_emSubState != emSubState)
	{
		m_emSubState = emSubState;
		bNeedSync = true;
	}

	if (emState != CHARACTER_STATE::CHARACTER_STATE_NONE && m_emState != emState)
	{
		m_emState = emState;
		bNeedSync = true;
	}

	if (bNeedSync)
	{
		SetServerState(m_emSubState, m_emState);
	}
}

void ABaseCharacter::OnHit_Implementation(AActor* HitCauser, FsSkillHitResult sHitResult)
{
	FString str = FString::Printf(TEXT("BaseCharacter Be OnHit"));
	UPandaUtils::Log(str, true);
}

void ABaseCharacter::TurnOnRagDoll(bool bSetValue)
{
	if (bSetValue)
	{
		GetMesh()->SetAnimInstanceClass(nullptr);
	}

	GetMesh()->SetAllBodiesSimulatePhysics(bSetValue);
}

void ABaseCharacter::EquipWeapon(int itemId)
{
	if (itemId == m_weaponId)
	{
		return;
	}

	UnequipWeapon();
	//根据道具id获取道具信息，然后生成武器
	//load weapon
	
	UItem* weaponItem =  UPandaGameInstance::Instance()->SafeGetItemManager()->getItemById(itemId);
	if (!weaponItem)
	{
		UE_LOG(LogTemp, Error, TEXT("change weapon failing not weapon !!!!"));
		return;
	}

	FString AssetPath = FString("/Game/BPInstance/Weapon/") + weaponItem->m_LocResItem->WeaponBlueprint;
	UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(AssetPath);

	if (!ParentClass)
	{
		return;
	}
	AAttachWeapon* weapon = GetWorld()->SpawnActor<AAttachWeapon>(ParentClass, GetActorLocation(), GetActorRotation());
	weapon->m_LocDate = weaponItem;

	if (!weapon)
	{
		return;
	}

	weapon->Attach2Pawn(this, GetMesh(), TEXT(""));
	m_CurWeapon = weapon;
	PostEquipWeapon();


}

void ABaseCharacter::UnequipWeapon()
{
	if (m_CurWeapon != nullptr)
	{
		m_CurWeapon->Destroy();
		m_CurWeapon = nullptr;
	}
}

CHARACTER_WEAPON_TYPE ABaseCharacter::GetWeaponType()
{
	if (m_CurWeapon)
	{
		return m_CurWeapon->m_LocDate->m_LocResItem->WeaponTypePanda;
	}

	return CHARACTER_WEAPON_TYPE::WEAPON_NONE;
}

void ABaseCharacter::OnSkillHitEvent(CHARACTER_COLLISION_TYPE emType, AActor* pOtherActor, UPrimitiveComponent* pOtherComp, int32 OtherBodyIndex, bool FromSweep, FHitResult SweepResult)
{

}


bool ABaseCharacter::RPCServerDumpPlayers_Validate(){
	return true;
}

void ABaseCharacter::RPCServerDumpPlayers_Implementation()
{
	//here execute from server
	m_tBaseData.fHP+=1;
	int n=0;
	for(auto it=GetWorld()->GetPlayerControllerIterator();it;++it)
	{
		n++;
		if(auto pawn=(*it)->GetCharacter())
		{
			if(auto p=Cast<ABaseCharacter>(pawn))
				UE_LOG(LogTemp,Warning,TEXT("--------players on server uid=%d,hp=%f, state=%d"),pawn->GetUniqueID(),p->m_tBaseData.fHP,(int32)m_emState);
		}
	}
	UE_LOG(LogTemp,Warning,TEXT("--------server players %d"),n);
}

void ABaseCharacter::RPCClientDumpPlayers_Implementation()
{
	//here execute at client
	int n=0;
	if(auto me=GetWorld()->GetFirstPlayerController())
	{
		if(auto pawn=me->GetCharacter())
		{
			if(auto p=Cast<ABaseCharacter>(pawn))
				UE_LOG(LogTemp,Warning,TEXT("--------my uid=%d,hp=%f, state=%d"),pawn->GetUniqueID(),p->m_tBaseData.fHP,(int32)m_emState);
		}
	}

	UE_LOG(LogTemp,Warning,TEXT("--------server pawns %d"),GetWorld()->GetNumPawns());
	for(auto it=GetWorld()->GetPawnIterator();it;++it)
	{
		if(auto pawn=(*it))
		{
			auto uid=pawn->GetUniqueID();
			if(auto p=Cast<ABaseCharacter>(pawn))
				UE_LOG(LogTemp,Warning,TEXT("--------pawns on server uid=%d,hp=%f, state=%d"),pawn->GetUniqueID(),p->m_tBaseData.fHP,(int32)m_emState);
		}
	}
}


void ABaseCharacter::OnRep_UpdateSkillMontage()
{
	if (GetMesh())
	{
		auto AnimInstance = GetMesh()->GetAnimInstance();
		if (AnimInstance)
		{
			if (m_SkillAnim)
			{
				AnimInstance->Montage_Play(m_SkillAnim);
			}
			else
			{
				AnimInstance->Montage_Stop(0);
			}
		}
	}

}

void ABaseCharacter::OnRep_CurrentWeapon(AAttachWeapon* LastWeapon)
{

}

bool ABaseCharacter::PlaySkillInstance(USkillInstance* pSkill)
{
	// 如果有当前技能
	if (pSkill)
	{
		//当前如果有使用中的其他技能
		if (GetCurSkill())
		{
			if (pSkill != GetCurSkill())
			{	
				//判断技能动作是否可融合
				if (GetCurSkill()->IsBeFuse())
				{
					bool bPlay = pSkill->PlaySkill();
					//中断原技能,并播放新技能
					if (bPlay)
					{
						GetCurSkill()->BreakSkill(false);
						SetCurSkill(pSkill);
						//pSkill->OnAnimInstanceEvent();
						pSkill->GetCharacterSkillAnim();
						return true;
					}
				}
			}

			return false;
		}

		bool bPlay = pSkill->PlaySkill();
		if (bPlay)
		{
			SetCurSkill(pSkill);
			//pSkill->OnAnimInstanceEvent();
			pSkill->GetCharacterSkillAnim();
			return true;
		}
	}

	return false;

}

//获得当前使用技能
USkillInstance*  ABaseCharacter::GetCurSkill() 
{ 
	return m_pCurSkill;
}

//设置当前使用技能
void ABaseCharacter::SetCurSkill(USkillInstance* pSkill) 
{ 
	m_pCurSkill = pSkill; 
}

void ABaseCharacter::ClearCurSkill()
{ 
	m_pCurSkill = nullptr; 
}

USkillInstance* ABaseCharacter::AppendSkill(int32 nID)
{
	USkillInstance* pSkill = NewObject<USkillInstance>(GGameInstance);
	if (pSkill)
	{
		pSkill->InitByID(nID, this);
		pSkill->SetInternalFlags(EInternalObjectFlags::RootSet);
		return pSkill;
	}

	return nullptr;
}

void ABaseCharacter::PlayBeHitFly(AActor* HitCauser)
{
	m_fAngle = UPandaUtils::VectorAngle(GetCapsuleComponent()->GetForwardVector(), HitCauser->GetActorLocation() - GetActorLocation());
	m_fAngle += m_fAngle > 0 ? 360 : -360;
}

void ABaseCharacter::OnBeHitFly(float DeltaSeconds)
{
	if (m_fAngle != 0)
	{
		if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY)
		{
			float fMaxTime = 0.5f;
			float fCurAngle = 0;
			if (m_fBeHitFlyTime + DeltaSeconds > fMaxTime)
			{
				DeltaSeconds = fMaxTime - m_fBeHitFlyTime;
				fCurAngle = DeltaSeconds / fMaxTime*m_fAngle;
				m_fBeHitFlyTime = 0;
				m_fAngle = 0;
			}
			else
			{
				m_fBeHitFlyTime += DeltaSeconds;
				fCurAngle = DeltaSeconds / fMaxTime*m_fAngle;
			}

			FRotator ActorRotator = GetActorRotation();
			ActorRotator.Yaw -= fCurAngle;
			ActorRotator.Normalize();
			SetActorRotation(ActorRotator);
		}
		else
		{
			m_fBeHitFlyTime = 0;
			m_fAngle = 0;
		}
	}

}

void ABaseCharacter::DelayImpulse(float fDelayTime, FVector vDirection, int32 nForce)
{
	if (m_DelayImpulseComponent)
		m_DelayImpulseComponent->DelayImpulse(this, fDelayTime, vDirection, nForce, m_emSubState);
}

int32 ABaseCharacter::GetTempCount()
{ 
	++m_nTempCount; 
	if (m_nTempCount >= 4)
		m_nTempCount = 0;

	return m_nTempCount;

}

void ABaseCharacter::TurnAtActor(AActor *pActor)
{
	if (!pActor) return;
	FVector distance = pActor->GetActorLocation() - GetActorLocation();
	FVector direction = GetCapsuleComponent()->GetForwardVector();
	float fAngle = UPandaUtils::VectorAngle(direction, distance);
	FRotator ActorRotation = GetActorRotation();
	ActorRotation.Yaw -= fAngle;
	ActorRotation.Normalize();
	SetActorRotation(ActorRotation);

}
AActor* ABaseCharacter::getTargetScope()
{
	return TargeOther;
}
void ABaseCharacter::setTargetScope(AActor* target_)
{
	TargeOther = target_;
}

void ABaseCharacter::UpdateMatBillHealth()
{
	if (MatBillHealth && HealthDynamicMat)
	{
		HealthDynamicMat->SetScalarParameterValue("Health Percent", m_tBaseData.fHP/m_tBaseData.fMAX_HP);
		MatBillHealth->SetRelativeLocation(FVector(0,0,GetCapsuleComponent()->GetScaledCapsuleHalfHeight()*1.2));
	}
}

void ABaseCharacter::SetServerSkillAnim_Implementation(UAnimMontage* AnimResour)
{
	//FString str = FString::Printf(TEXT("SetSimulatePlayAnim_Implementation !!!"));
	//UPandaUtils::Log(str, true);
	m_SkillAnim = AnimResour;

	if (GetMesh())
	{
		//FString str = FString::Printf(TEXT("SetSimulatePlayAnim_Implementation has mesh"));
		//UPandaUtils::Log(str, true);

		auto AnimInstance = GetMesh()->GetAnimInstance();
		if (AnimInstance)
		{
			//FString str = FString::Printf(TEXT("SetSimulatePlayAnim_Implementation  has AnimInstance"));
			//UPandaUtils::Log(str, true);
			if (m_SkillAnim)
			{
				AnimInstance->Montage_Play(m_SkillAnim);
				//FString str = FString::Printf(TEXT("server SetSimulatePlayAnim  m_SkillAnim != nullptr name=%s "), *m_SkillAnim->GetName());
				//UPandaUtils::Log(str, true);
			}
			else
			{
				AnimInstance->Montage_Stop(0);
				//FString str = FString::Printf(TEXT("server SetSimulatePlayAnim  m_SkillAnim = nullptr"));
				//UPandaUtils::Log(str, true);
			}
		}
	}

}

bool ABaseCharacter::SetServerSkillAnim_Validate(UAnimMontage* AnimResour)
{
	return true;
}

bool ABaseCharacter::SetServerSkillHitResult_Validate(FsSkillHitResult HitResult)
{
	return true;
}

void ABaseCharacter::SetServerSkillHitResult_Implementation(FsSkillHitResult HitResult)
{
	FString str = FString::Printf(TEXT("SetServerSkillHitResult Be Execute"));
	UPandaUtils::Log(str, true);
	//auto Target = Cast<ABaseCharacter>(HitResult.pHitTarget);
	//if (Target)
	//{
	//	FString str = FString::Printf(TEXT("SetServerSkillHitResult Be Execute Target->m_HitResult = HitResult"));
	//	UPandaUtils::Log(str, true);
	//	Target->m_HitResult = HitResult;
	//}
	
	if (!Cast<APlayerCharacter>(HitResult.pHitTarget))
	{
		HitResult.pHitTarget->Execute_OnHit(HitResult.pHitTarget, HitResult.pHitCauser, HitResult);
		ClearServerSkillHitResult();
	}
	else
	{
		HitResult.pHitTarget->m_HitResult = HitResult;
	}

}

void ABaseCharacter::OnRep_UpdateHitResult()
{
	FString str = FString::Printf(TEXT("OnRep_UpdateHitResult Be Execute"));
	UPandaUtils::Log(str, true);
	if (Role >= ROLE_AutonomousProxy && m_HitResult.bValid)
	{
		//FString str = FString::Printf(TEXT("OnRep_UpdateHitResult Be Execute Execute_OnHit"));
		//UPandaUtils::Log(str, true);
		Execute_OnHit(m_HitResult.pHitTarget, m_HitResult.pHitCauser, m_HitResult);
		ClearServerSkillHitResult();
	}
}

bool ABaseCharacter::ClearServerSkillHitResult_Validate()
{
	return true;
}

void ABaseCharacter::ClearServerSkillHitResult_Implementation()
{
	m_HitResult.bValid = false;
}
