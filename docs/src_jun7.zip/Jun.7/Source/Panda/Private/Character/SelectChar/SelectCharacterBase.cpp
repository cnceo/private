// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "SelectCharacterBase.h"


// Sets default values
ASelectCharacterBase::ASelectCharacterBase()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void ASelectCharacterBase::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASelectCharacterBase::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

}

// Called to bind functionality to input
void ASelectCharacterBase::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);

}

// Called to bind functionality to input
void ASelectCharacterBase::InitSelectCharacter()
{

}

// ����ѡ���Ķ���
void ASelectCharacterBase::PlaySelectedAnim()
{
	if (SelectedAnim)
	{
		GetMesh()->PlayAnimation(SelectedAnim, false);
		float AnimTime = GetMesh()->GetSingleNodeInstance()->GetAnimAssetPlayerLength(SelectedAnim);
		FTimerHandle TimerHandle;
		GetWorldTimerManager().SetTimer(TimerHandle, this, &ASelectCharacterBase::PlayGameIdleAnim, AnimTime, false);
	}
}

// ����ȷ��ѡ���Ķ���
void ASelectCharacterBase::PlayConfirmAnim()
{
	if (ConfirmAnim)
	{
		GetMesh()->PlayAnimation(ConfirmAnim, false);
	}
}

// ����ȡ��ѡ��Ĵ�������
void ASelectCharacterBase::PlayCancelSelectAnim()
{
	if (CancelSelectAnim)
	{
		GetMesh()->PlayAnimation(CancelSelectAnim, false);
		float AnimTime = GetMesh()->GetSingleNodeInstance()->GetAnimAssetPlayerLength(CancelSelectAnim);
		FTimerHandle TimerHandleCancelSelect;
		GetWorldTimerManager().SetTimer(TimerHandleCancelSelect, this, &ASelectCharacterBase::PlayGameIdleAnim, AnimTime, false);
	}
}

// ����ת
void ASelectCharacterBase::PlayRotatAnim()
{

}

void ASelectCharacterBase::PlayIdleAnim()
{
	if (IdleAnim)
	{
		GetMesh()->PlayAnimation(IdleAnim, true);
	}
}

void ASelectCharacterBase::PlayGameIdleAnim()
{
	if (GameIdleAnim)
	{
		GetMesh()->PlayAnimation(GameIdleAnim, true);
	}
}

// ���Ŵ������ɶ���
void ASelectCharacterBase::PlayIdleInterimAnim()
{
	if (IdleInterimAnim)
	{
		GetMesh()->PlayAnimation(IdleInterimAnim, false);
		float AnimTime = GetMesh()->GetSingleNodeInstance()->GetAnimAssetPlayerLength(IdleInterimAnim);
		FTimerHandle TimerHandleCancelSelect;
		GetWorldTimerManager().SetTimer(TimerHandleCancelSelect, this, &ASelectCharacterBase::PlayIdleAnim, AnimTime, false);
	}
}