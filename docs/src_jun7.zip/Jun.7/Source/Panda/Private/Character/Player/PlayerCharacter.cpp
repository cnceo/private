// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PlayerCharacter.h"
#include "PandaGameInstance.h"
#include "PandaWidget_Talk2Npc.h"
#include "MonsterBaseCharacter.h"
#include "Kismet/KismetSystemLibrary.h"
#include "MainPlayerController.h"
#include "PAWidget_Dungeon_Chapter.h"
#include "PandaWidget_AcceptTask.h"
#include "PandaUtils.h"
#include "PandaHUD.h"


class UWorld;
class AAttachObjBase;
class AAttachWeapon;
class UEngine;

APlayerCharacter::APlayerCharacter()
	: m_nMaxJumpNum(2) 
	, m_nJumpCount(2)
	, TargetNPC(nullptr)
{
	m_emType = CHARACTER_TYPE::CHARACTER_TYPE_PLAYER;
	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 540.0f, 0.0f); // ...at this rotation rate
	GetCharacterMovement()->JumpZVelocity = 600.0f;
	GetCharacterMovement()->AirControl = 0.2f;
	JumpMaxHoldTime = 0.2f;
	SetMaxWalkSpeed(350);

	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->AttachTo(RootComponent);
	CameraBoom->TargetArmLength = 300.0f; // The camera follows at this distance behind the character	
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller

	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->AttachTo(CameraBoom,USpringArmComponent::SocketName); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm

	// Note: The skeletal mesh and anim blueprint references on the Mesh component (inherited from Character) 
	// are set in the derived blueprint asset named MyCharacter (to avoid direct content references in C++)

	m_QuestHandler = CreateDefaultSubobject<UQuestComponent>(TEXT("QuestComponent"));
	if (m_QuestHandler)
	{
		m_QuestHandler->SetNetAddressable();
		m_QuestHandler->SetIsReplicated(true);
	}
	bReplicates = true;
	
	// Add UserHeroBase data
	BaseDataComponent = CreateDefaultSubobject<UPAUserHeroBaseData>(TEXT("UserBaseDataComponent"));
}

void APlayerCharacter::GetLifetimeReplicatedProps(TArray< FLifetimeProperty > & OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME_CONDITION(APlayerCharacter, m_nMaxJumpNum, COND_OwnerOnly);
	DOREPLIFETIME_CONDITION(APlayerCharacter, m_nJumpCount, COND_OwnerOnly);
}

APlayerCharacter::~APlayerCharacter()
{
	for (auto It = m_mapBaseSkill.CreateConstIterator(); It; ++It)
	{
		It.Value()->RemoveFromRoot();
		It.Value()->SetInternalFlags(EInternalObjectFlags::NoStrongReference);
	}
	m_mapBaseSkill.Reset();
}

// Called every frame
void APlayerCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// Synchronization jump and send message
	if ( (GetCharacterMovement()->IsFalling() || GetCharacterMovement()->IsFlying() ) &&
		( m_emState == CHARACTER_STATE::CHARACTER_STATE_FALLING || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FALL || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP 
			|| m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP2 ))
	{
		auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(GGameInstance));
		if (controller)
			controller->SendMoveMessage(proto3::eMoveType::FALLING);
	}
}

void APlayerCharacter::SetState(CHARACTER_SUB_STATE emSubState, CHARACTER_STATE emState)
{
	bool bNeedSync = false;

	if (m_bFighting && emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL)
	{
		emState = CHARACTER_STATE::CHARACTER_STATE_STAND;
		emSubState = CHARACTER_SUB_STATE::SUB_STATE_FIGHTING;
	}

	if (emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL)
	{
		SetPoseTimer();
	}

	if (emSubState != CHARACTER_SUB_STATE::SUB_STATE_NONE && m_emSubState != emSubState)
	{
		m_emSubState = emSubState;
		bNeedSync = true;
	}

	if (emState != CHARACTER_STATE::CHARACTER_STATE_NONE && m_emState != emState)
	{
		m_emState = emState;
		bNeedSync = true;
	}

	if (bNeedSync)
	{
		SetServerState(m_emSubState, m_emState);
		auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(GGameInstance));
		controller->SendMoveMessage(proto3::eMoveType::WALK);
	}

}


void APlayerCharacter::NotifyHit(UPrimitiveComponent * MyComp, AActor * Other, UPrimitiveComponent * OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult & Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);
}

void APlayerCharacter::BeginPlay()
{
	Super::BeginPlay();
	SetPoseTimer();
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_ATTACK, AppendSkill(1));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_CHASE, AppendSkill(2));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_SKYATTACK, AppendSkill(4));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP1, AppendSkill(11));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP2, AppendSkill(12));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP3, AppendSkill(13));
	m_mapBaseSkill.Add(PLAYER_SKILL_TYPE::PLAYER_SKILL_TEMP4, AppendSkill(14));

	GetCapsuleComponent()->OnComponentBeginOverlap.RemoveDynamic(this, &APlayerCharacter::OnBeginOverlap);
	GetCapsuleComponent()->OnComponentBeginOverlap.AddDynamic(this, &APlayerCharacter::OnBeginOverlap);
	GetCapsuleComponent()->OnComponentEndOverlap.RemoveDynamic(this, &APlayerCharacter::OnEndOverlap);
	GetCapsuleComponent()->OnComponentEndOverlap.AddDynamic(this, &APlayerCharacter::OnEndOverlap);
}

void APlayerCharacter::OnBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* Other, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (Other != NULL && OtherComp != NULL)
	{
		auto DisplayName = UKismetSystemLibrary::GetDisplayName(Other);

		// ײ��MainScene����Ĵ�����
		if (DisplayName == "TriggerVolume_chuansongmen01")
		{
			// do once
			// static bool bUIExsit = true;
			if (GGameInstance)
			{
				// ���ýӿ�_���ô���ݵĽӿ�
				FEKGameFrame::Instance()->ProcedureManager()->ChangeCurrentProcedure(GeometrySpace::Procedure::PT_Club);
			}
		}
		// �������������MainCity,ײ��������м�����
		else if (DisplayName == "TriggerVolume_MainCity")
		{
			// ̸��UI,ѡ��ȥ����һ���м�����
			if (GGameInstance)
			{
				auto controller = UPandaUtils::GetLocalPlayerController(GGameInstance);
				if (controller) {
					auto mainController = Cast<AMainPlayerController>(controller);
					if (mainController){
						// ���м��������
						mainController->OnOpenSelectRegion();
					}
				}
			}
		}
		// �м������Trigger,����ͨ����ͬ�ĸ���
		else if(DisplayName == "TriggerVolume_chuansongmen1" || DisplayName == "TriggerVolume_chuansongmen2"
			|| DisplayName == "TriggerVolume_chuansongmen3" || DisplayName == "TriggerVolume_chuansongmen4"){
			if (GGameInstance)
			{
				auto controller = UPandaUtils::GetLocalPlayerController(GGameInstance);
				if (controller) {
					auto mainController = Cast<AMainPlayerController>(controller);
					if (mainController)
						mainController->OnOpenACT();
				}
				
				/*auto ACTWidget = (GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_ACT));
				if (ACTWidget)
				{
					auto obj = Cast<UPAWidget_Dungeon_Chapter>(ACTWidget);
					obj->m_nCurrentDungeonGroupID = 1;
				}*/
			}
		}
		else if(Cast<AOthersCharacter>(Other)&& OtherComp->GetName() == FString("TargetCapsule2"))
		{
			if (!TargeOther)
			{
				if (UPandaUtils::getActorComponent(Other,99))
				{
					Cast<USceneComponent>((UPandaUtils::getActorComponent(Other, 99)))->SetHiddenInGame(false);
				}
				TargeOther = Cast<AOthersCharacter>(Other);
			}
		}
	}
}

void APlayerCharacter::OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* Other, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
// 	if (Other != NULL && OtherComp != NULL)
// 	{
// 		auto DisplayName = UKismetSystemLibrary::GetDisplayName(Other);
// 		if (DisplayName == "TriggerVolume_chuansongmen01")
// 		{
// 			// do once
// 			// static bool bUIExsit = true;
// 		}
// 	}
	 if (OtherComp->GetName() == FString("TargetCapsule2"))
	{
		Cast<USceneComponent>((UPandaUtils::getActorComponent(Other, 99)))->SetHiddenInGame(true);
		TargeOther = nullptr;
	}
}

USkillInstance* APlayerCharacter::GetBaseSkill(PLAYER_SKILL_TYPE emType)
{ 
	auto pSkill = m_mapBaseSkill.Find(emType);
	if (pSkill)
	{
		return *pSkill;
	}	

	return nullptr;
}
bool APlayerCharacter::CheckTarget(ABaseCharacter* start, AActor* target, float& fDistance, float& fAngle)
{
	fDistance = target->GetDistanceTo(start);
	if (fDistance > 1000) return false;
	FVector distance = target->GetActorLocation() - start->GetActorLocation();
	FVector direction = start->GetCapsuleComponent()->GetForwardVector();
	fAngle = UPandaUtils::VectorAngle(direction, distance);
	if (FMath::Abs(fAngle) > 75) return false;
	return true;
}

ABaseCharacter* APlayerCharacter::FindTarget(float fAxis)
{
	ABaseCharacter* pCurTarget = GetTarget();
	ABaseCharacter* pNewTarget = pCurTarget;
	float fCurDistance = 0;
	if (pCurTarget != nullptr) fCurDistance = pCurTarget->GetDistanceTo(this);
	float fCurAngle = 75;
	if (fAxis > 0) fCurAngle = -75;
	//�����ؿ���ȫ��BaseCharacter
	for (auto it = GetWorld()->GetPawnIterator(); it; ++it) 
	{
		if (auto pPawn = (*it)) 
		{
			if (auto pActor = Cast<ABaseCharacter>(pPawn))
			{
				//û��Ŀ��ʱ,�����õ�1���������������Ŀ��
				if (!pNewTarget)
				{			
					float fDistance = 0;
					float fAngle = 0;
					if (this->CheckTarget(this, pActor, fDistance, fAngle))
					{
						pNewTarget = pActor;
						fCurDistance = fDistance;
					}		
				}
				//��Ŀ���,���бȽ�.(�˲��ֹ���δ����ʵ��)
				else
				{
					//�����ǰ�Ѿ���������ģʽ.�ٴ����б���Ϊ���ص��л�
					if (pCurTarget)
					{
						float fDistance = 0;
						float fAngle = 0;
						//������ҡ�˵���/�����룬�ҳ����뵱ǰĿ����/�����������Ŀ��
						if (pCurTarget != pActor && this->CheckTarget(this, pActor, fDistance, fAngle) && fAxis != 0.0f)
						{
							if (fAxis > 0 && fAngle < 0 && fAngle > fCurAngle)
							{
								pNewTarget = pActor;
								fCurDistance = fDistance;
								fCurAngle = fAngle;
							}
							else if (fAxis < 0 && fAngle > 0 && fAngle < fCurAngle)
							{
								pNewTarget = pActor;
								fCurDistance = fDistance;
								fCurAngle = fAngle;
							}
						}
					}
					//Ѱ�ҳ��������������Ŀ��
					else
					{
						float fDistance = 0;
						float fAngle = 0;
						if (this->CheckTarget(this, pActor, fDistance, fAngle) && fDistance < fCurDistance)
						{
							pNewTarget = pActor;
							fCurDistance = fDistance;
						}
					}
				}
			}
		}
	}
	return pNewTarget;
}

void APlayerCharacter::TurnAtTarget()
{
	if (!HasTarget()) return;
	if (GetTarget()->GetState() == CHARACTER_STATE::CHARACTER_STATE_DIE || GetTarget()->IsPendingKill())
	{
		ClearTarget();
		return;
	}
	FVector distance = GetTarget()->GetActorLocation() - this->GetActorLocation();
	FVector direction = this->GetCapsuleComponent()->GetForwardVector();
	float fAngle = UPandaUtils::VectorAngle(direction, distance);
	if (FMath::Abs(fAngle) < 1.0f) return;
	FRotator ActorRotation = this->GetActorRotation();
	ActorRotation.Yaw -= fAngle;
	ActorRotation.Normalize();
	this->SetActorRotation(ActorRotation);

}

void APlayerCharacter::AcceptQuest(int id)
{
	if (m_QuestHandler)
	{
		m_QuestHandler->Rpc2ServerAccept(id);
	}

}

void APlayerCharacter::UpdateQuest(int taskId)
{
	if (m_QuestHandler)
	{
		m_QuestHandler->Rpc2ServerUpdate(taskId);
	}

}

void APlayerCharacter::CommitQuest(int taskId)
{
	if (m_QuestHandler )
	{
		// ��ʱ�����ж�
		m_QuestHandler->Rpc2ServerCommit(taskId);
	}
}

// ��ý���
void APlayerCharacter::AcquireQuestReward(int taskId)
{
	if (GGameInstance != nullptr)
	{
		FsTaskInfo* taskInfo = GGameInstance->SafeGetDataManager()->m_FsTaskInfo.Find(taskId);
		// ���Ӿ���
		AddPlayerExp(taskInfo->RewardEXP);
		// ���ӽ��
		FPlayerDataManager::Instance()->addPlayerGold(taskInfo->RewardGold);

		// ��������Ч
		UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Particles/jiaorenwu.jiaorenwu"));
		UParticleSystem* Particle = Cast<UParticleSystem>(itemObj);
		UGameplayStatics::SpawnEmitterAtLocation(this, Particle, GetActorLocation(), GetActorRotation());
	}
}

void APlayerCharacter::OpenTaskPanel()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->OpenUMGAsset(UMGAssetPath_AcceptTask);
	}
}

void APlayerCharacter::CloseTaskPanel()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->CloseUMGAsset(UMGAssetPath_AcceptTask);
	}
}

void APlayerCharacter::OpenBlur(bool bVisible/* = true*/)
{

	
}

void APlayerCharacter::Talk2Npc()
{
	if (TargetNPC == nullptr)
		return;

	//��ͷ�л�
	APlayerController* cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance());
	UPACameraManager* pac = UPACameraManager::GetCameraManagerInstance();
	pac->PlayTaskCameraAnim(TargetNPC->GetRootComponent());

	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		GetQuestHandler()->FindNPC(TargetNPC->GetNPCId());

		class UPandaWidget_Talk2Npc* NPCTalk;
		if (gameInstance->SafeGetUIManager()->FindInWidgetCache(UMGAssetPath_NPCTalk) == nullptr)
		{
			gameInstance->SafeGetUIManager()->OpenUMGAsset(UMGAssetPath_NPCTalk);
			NPCTalk = Cast<UPandaWidget_Talk2Npc>(gameInstance->SafeGetUIManager()->FindInWidgetCache(UMGAssetPath_NPCTalk));
			NPCTalk->InitTalk2NPC(TargetNPC->GetNPCId(), this, TargetNPC);
			GetQuestHandler()->FindNPC(TargetNPC->GetNPCId());

			// �µĶ�����ʽ
			//UObject *Object = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(UMGAssetPath_NPCTalk);
			//class UPandaWidget_Talk2Npc* NPCTalk = Cast<UPandaWidget_Talk2Npc>(FEKGameFrame::Instance()->HUDManager()->InstancdeUMGwidget(Object));
		}
		NPCTalk = Cast<UPandaWidget_Talk2Npc>(gameInstance->SafeGetUIManager()->FindInWidgetCache(UMGAssetPath_NPCTalk));
		if (NPCTalk->GetVisibility() == ESlateVisibility::Visible)
			return;

		NPCTalk->InitTalk2NPC(TargetNPC->GetNPCId(), this,TargetNPC);
		NPCTalk->SetVisibility(ESlateVisibility::Visible);
		NPCTalk->AddToViewport();	
	}
}

void APlayerCharacter::LeaveNpc(int npcId)
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		gameInstance->SafeGetUIManager()->CloseUMGAsset(UMGAssetPath_NPCTalk);
	}
}

bool APlayerCharacter::CanJumpInternal_Implementation() const
{
	const bool bCanHoldToJumpHigher = (GetJumpMaxHoldTime() > 0.0f) && IsJumpProvidingForce();
	return !bIsCrouched && GetCharacterMovement() && (GetCharacterMovement()->IsMovingOnGround() || bCanHoldToJumpHigher) && GetCharacterMovement()->IsJumpAllowed() && !GetCharacterMovement()->bWantsToCrouch;
}

bool APlayerCharacter::IsJumpProvidingForce() const
{
	if(m_emState == CHARACTER_STATE::CHARACTER_STATE_FALLING && (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP2))
	{
		if (JumpKeyHoldTime > 0.0f && JumpKeyHoldTime < GetJumpMaxHoldTime())
		{
			return true;
		}
	}
	return false;
}

void APlayerCharacter::OnJump(bool bJump)
{
	if (bJump)
	{
		if (!ChangeStateToJump())
		{
			return;
		}

		if (m_nJumpCount > 0)
		{
			bPressedJump = true;
			JumpKeyHoldTime = 0.0f;
			m_nJumpCount = m_nJumpCount - 1;
		}
		SetJumpHoldTimer();
	}
	else
	{
		bPressedJump = false;
		JumpKeyHoldTime = 0.0f;
		GetWorld()->GetTimerManager().ClearTimer(m_JumpHoldTimerHandle);
	}


}

void APlayerCharacter::SetJumpHoldTimer()
{
	FTimerDelegate HoldTimer;
	HoldTimer.BindUObject(this, &APlayerCharacter::JumpHoldTimerCallback);
	GetWorld()->GetTimerManager().SetTimer(m_JumpHoldTimerHandle, HoldTimer, JumpMaxHoldTime, false);
}

void APlayerCharacter::JumpHoldTimerCallback()
{
	bPressedJump = false;
}

void APlayerCharacter::ClearJumpInput()
{
	if (GetCharacterMovement()->IsFalling())
	{
		//UE_LOG(LogTemp, Warning, TEXT("GetCharacterMovement()->Velocity=%f"), GetCharacterMovement()->Velocity.Z);
		if (m_emState != CHARACTER_STATE::CHARACTER_STATE_FALLING)
		{
			if (m_emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL || m_emState == CHARACTER_STATE::CHARACTER_STATE_STAND || m_emState == CHARACTER_STATE::CHARACTER_STATE_ACTION)
			{
				SetState(CHARACTER_SUB_STATE::SUB_STATE_FALL, CHARACTER_STATE::CHARACTER_STATE_FALLING);
			}
		}

		if (m_emState == CHARACTER_STATE::CHARACTER_STATE_FALLING)
		{
			if (GetCharacterMovement()->Velocity.Z < 5.0f)
			{
				if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP2)
				{
					GetCharacterMovement()->GravityScale = 20.f;
				}
				else //if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP)
				{
					GetCharacterMovement()->GravityScale = 8.f;
				}
			}
		}
	}

}

void APlayerCharacter::Landed(const FHitResult& Hit)
{
	Super::Landed(Hit);
	m_nJumpCount = m_nMaxJumpNum;
	GetCharacterMovement()->GravityScale = 1.f;
	JumpMaxHoldTime = 0.2f;
	GetCharacterMovement()->JumpZVelocity = 600.0f;

	//����������½
	if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_DIE_FLY)
	{
		TurnOnRagDoll(true);
	}
	//���ػ�����½
	else if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_BEHEAVY)
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECollisionResponse::ECR_Block);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_PhysicsBody, ECollisionResponse::ECR_Block);
		SetState(CHARACTER_SUB_STATE::SUB_STATE_TUMBLE, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
	}
	//�����ɵ����к���½
	else if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY || GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_HITFLY_FLOATING
		|| GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1 || GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT2
		|| GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_HITFLY_FALLING)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_REEL1, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
		DelayImpulse(0.3f, FVector(-100, 0, 0), 2000);
	}
	else if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_FLY_HITFALL)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_FLY_HITROLL, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
	}

}

void APlayerCharacter::SetFightingTimer()
{
	FTimerDelegate FightingTimer;
	FightingTimer.BindUObject(this, &APlayerCharacter::FightingTimerCallback);
	GetWorld()->GetTimerManager().SetTimer(m_FightingTimerHandle, FightingTimer, 6.0f, false);
	m_bFighting = true;
}

void APlayerCharacter::FightingTimerCallback()
{
	m_bFighting = false;
	if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_FIGHTING)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
	}
}

void APlayerCharacter::SetPoseTimer()
{
	FTimerDelegate PoseTimer;
	PoseTimer.BindUObject(this, &APlayerCharacter::PoseTimerCallback);
	GetWorld()->GetTimerManager().SetTimer(m_PoseTimerHandle, PoseTimer, 20.0f, false);
}

void APlayerCharacter::PoseTimerCallback()
{
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL)
	{
		float fRand = FMath::FRand();
		CHARACTER_SUB_STATE emPose(CHARACTER_SUB_STATE::SUB_STATE_POSE1);

		if (fRand > 0.5f)
			emPose = CHARACTER_SUB_STATE::SUB_STATE_POSE2;

		SetState(emPose, CHARACTER_STATE::CHARACTER_STATE_STAND);
	}
}

bool APlayerCharacter::ChangeStateToJump()
{
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL || m_emState == CHARACTER_STATE::CHARACTER_STATE_STAND || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_MOVE)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_JUMP, CHARACTER_STATE::CHARACTER_STATE_FALLING);
		GetCharacterMovement()->GravityScale = 1.5f;
		return true;
	} 
	else if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_JUMP)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_JUMP2, CHARACTER_STATE::CHARACTER_STATE_FALLING);
		GetCharacterMovement()->GravityScale = 1.0f;
		JumpMaxHoldTime = 0.05f;
		GetCharacterMovement()->JumpZVelocity = 800.0f;
		return true;
	}

	return false;
}

bool APlayerCharacter::ChangeStateToMove()
{
	if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_MOVE)
		return true;

	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL || m_emState == CHARACTER_STATE::CHARACTER_STATE_STAND)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_MOVE, CHARACTER_STATE::CHARACTER_STATE_ACTION);
		return true;
	}

	return false;
}

bool APlayerCharacter::ChangeStateToDodge()
{
	return false;
}

bool APlayerCharacter::ChangeStateToDefence()
{
	if (m_emState == CHARACTER_STATE::CHARACTER_STATE_NORMAL || m_emState == CHARACTER_STATE::CHARACTER_STATE_STAND || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_MOVE)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_DEFENCE, CHARACTER_STATE::CHARACTER_STATE_ACTION);
		return true;
	}
	else if (m_emState == CHARACTER_STATE::CHARACTER_STATE_SKILL && GetCharacterMovement()->MovementMode == EMovementMode::MOVE_Walking)
	{
		if (GetCurSkill() && GetCurSkill()->IsBeFuse())
		{
			GetCurSkill()->BreakSkill(false);
			SetState(CHARACTER_SUB_STATE::SUB_STATE_DEFENCE, CHARACTER_STATE::CHARACTER_STATE_ACTION);
			return true;
		}
	}

	return false;
}

void APlayerCharacter::ClearDefence()
{
	if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_DEFENCE)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
	}
}

bool APlayerCharacter::PlaySkillInstance(USkillInstance* pSkill)
{
	bool bPlay = Super::PlaySkillInstance(pSkill);
	if (bPlay)
	{
		TurnAtTarget();
		SetFightingTimer();
	}

	return bPlay;
}

void APlayerCharacter::SetPlayerInfo(FsPAPlayerInfo PlayerInfo)
{
	FPlayerDataManager::Instance()->setPlayerInfo(PlayerInfo);
}

FsPAPlayerInfo APlayerCharacter::GetPlayerInfo()
{
	return FPlayerDataManager::Instance()->getPlayerInfo();
}

void APlayerCharacter::SetPlaceInfo(FsPAPlaceInfo PlaceInfo)
{
	FPlayerDataManager::Instance()->setPlaceInfo(PlaceInfo);
}

FsPAPlaceInfo APlayerCharacter::GetPlaceInfo()
{
	return FPlayerDataManager::Instance()->getPlaceInfo();
}

void APlayerCharacter::SetPlayerExtraInfo(FsPAPlayerExtraInfo PlayerExtraInfo)
{
	FPlayerDataManager::Instance()->setPlayerExtraInfo(PlayerExtraInfo);
}

FsPAPlayerExtraInfo APlayerCharacter::GetPlayerExtraInfo()
{
	return FPlayerDataManager::Instance()->getPlayerExtraInfo();
}

// Add PlayerExp
void APlayerCharacter::AddPlayerExp(int inExp)
{
	int CurrentExp = FPlayerDataManager::Instance()->getPlayerExp();
	int CurrentLeve = FPlayerDataManager::Instance()->getPlayerLevel();

	FsPAUserUpgradeBaseData* data = GGameInstance->SafeGetDataManager()->m_FsPAUserUpgradeBaseData.Find(CurrentLeve);

	// ���Ӿ��� �ж����� �п��ܻ����ܶ༶
	int SunExp = CurrentExp + inExp;
	while (SunExp > data->nExperience)
	{
		// ����
		PlayerUpLeve();
		SunExp -= data->nExperience;
	} 

	// ��֤���鲻�ᳬ���ȼ���Ҫ����
	FPlayerDataManager::Instance()->setPlayerExp(SunExp);
}

// Player level up
void APlayerCharacter::PlayerUpLeve()
{
	// ��ǰ�ȼ�
	int CurrentLeve = FPlayerDataManager::Instance()->getPlayerLevel();
	FPlayerDataManager::Instance()->setPlayerLevel(CurrentLeve+1);

	// ������Ч
	UObject *itemObj = FEKGameFrame::Instance()->ResourceManager()->GetEKObject(TEXT("/Game/VFX/Skill/Particles/shengji02.shengji02"));
	UParticleSystem* Particle = Cast<UParticleSystem>(itemObj);
	UGameplayStatics::SpawnEmitterAtLocation(this, Particle, GetActorLocation(), GetActorRotation());
	// HUD����
	FUMGPanel* panel = FEKGameFrame::Instance()->HUDManager()->GetUMGPanelByName("PlayerMain");
	if (panel)
	{
		FPanelMain* panelMain = static_cast<FPanelMain*>(panel);
		if (panelMain)
		{
			panelMain->UpdatePlayerLevel();
		}
	}

	// ��������

	// ����ϵͳ

	// ��Ѫ ����

	// ...........
}
void APlayerCharacter::OnHit_Implementation(AActor* HitCauser, FsSkillHitResult sHitResult)
{
	//FString str = FString::Printf(TEXT("playercharacter  Be OnHit"));
	//UPandaUtils::Log(str, true);

	if (sHitResult.sTableData.bDamage)
	{

		//�Ƿ�����˴ι���
		if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_DEFENCE && sHitResult.sTableData.nHitLevel < int32(EFFECT_HIT_LEVEL::EFFECT_HIT_POFANG))
		{
			return;
		}

		//�Ƿ񴥷�����
		if (sHitResult.sTableData.nHitLevel < int32(EFFECT_HIT_LEVEL::EFFECT_HIT_POJIAZHAO) && GetCurSkill())
		{
			if (GetCurSkill()->IsBeCounterattack() && GetCurSkill()->PlayNextSkill())
			{
				return;
			}
		}

		//�Ƿ����ܴ˴ι���
		if (GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_DODGE && sHitResult.sTableData.nHitLevel < int32(EFFECT_HIT_LEVEL::EFFECT_HIT_POSHANBI))
		{
			return;
		}

	}

	//���Ը���
	if (!m_bDead)
	{
		m_tBaseData.fHP += sHitResult.nCurHP;
		m_tBaseData.fMP += sHitResult.nCurMP;

		// ��ʾ�˺�
		AHUD* obj = GWorld->GetFirstPlayerController()->GetHUD();
		if (obj)
		{
			class APandaHUD* HUD = Cast<APandaHUD>(obj);
			if (HUD)
			{
				FHarm obj;
				obj.actor = this;
				obj.HarmVula = sHitResult.nCurHP;
				obj.ElapseTime = 0.0f;
				HUD->AddHarm(obj);
			}
		}
		// += sHitResult.nCurPower;
	}

	//��������
	if (!m_bDead && m_tBaseData.fHP <= 0)
	{
		m_bDead = true;
	}

	//�����ж�
	if (m_bDead)
	{
		//ǿ�ƴ�������
		if (sHitResult.sTableData.nBreak >= 0 && sHitResult.sTableData.bCombo)
		{
			PlayHit(HitCauser, sHitResult);
		}
		//��������
		else
		{
			CHARACTER_SUB_STATE emHit = CHARACTER_SUB_STATE(sHitResult.sTableData.nSubState);
			if (emHit == CHARACTER_SUB_STATE::SUB_STATE_BEHEAVY || emHit == CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY)
			{
				PlayDeadFly(HitCauser);
			}
			else
			{
				SetState(CHARACTER_SUB_STATE::SUB_STATE_DIE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_DIE);
			}

		}
	}
	else
	{
		//���ֵ����
		if (sHitResult.sTableData.nBreak >= BaseDataComponent->UnrealCurrentData.nBreak)
		{
			PlayHit(HitCauser, sHitResult);
		}
	}
}

void APlayerCharacter::ProcessHitConfirmed()
{
	// Handle damage


	// Play FX on remote clients


	// Play FX locally
}

CHARACTER_SUB_STATE APlayerCharacter::GetPlayHitSubState(CHARACTER_SUB_STATE emSubState)
{
	if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1 || emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT2)
	{
		if (GetCharacterMovement()->MovementMode != EMovementMode::MOVE_Falling)
			return CHARACTER_SUB_STATE::SUB_STATE_BEHIT1;
	}
	else if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_HITFALL)
	{
		if (GetCharacterMovement()->MovementMode != EMovementMode::MOVE_Falling)
			return CHARACTER_SUB_STATE::SUB_STATE_TUMBLE;
	}

	return emSubState;
}

void APlayerCharacter::PlayHit(AActor* HitCauser, FsSkillHitResult sHitResult)
{
	FString str = FString::Printf(TEXT("playercharacter  Be PlayHit"));
	UPandaUtils::Log(str, true);

	CHARACTER_SUB_STATE emSubState = GetPlayHitSubState(CHARACTER_SUB_STATE(sHitResult.sTableData.nSubState));
	UE_LOG(LogTemp, Warning, TEXT("PlayHit SubState=%d, GetPlayHitSubState=%d"), sHitResult.sTableData.nSubState, (int32)emSubState);
	PauseAI();

	//��ͨ����
	if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT1 || emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT2)
	{
		CHARACTER_SUB_STATE emNextState = CHARACTER_SUB_STATE(int32(CHARACTER_SUB_STATE::SUB_STATE_BEHIT1) + GetTempCount());
		//CHARACTER_SUB_STATE emNextState = GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_BEHIT1 ? CHARACTER_SUB_STATE::SUB_STATE_BEHIT2 : CHARACTER_SUB_STATE::SUB_STATE_BEHIT1;
		SetState(emNextState, CHARACTER_STATE::CHARACTER_STATE_BEHIT);

		FString str = FString::Printf(TEXT("playercharacter  Be SUB_STATE_BEHIT1"));
		UPandaUtils::Log(str, true);

		//FTimerDelegate Timer;
		//Timer.BindUObject(this, &APlayerCharacter::TestCallBack);
		//GetWorld()->GetTimerManager().SetTimer(TestHandle, Timer, 0.8f, false);

	}
	//���ػ�
	else if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHEAVY)
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECollisionResponse::ECR_Ignore);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_PhysicsBody, ECollisionResponse::ECR_Ignore);
		SetState(CHARACTER_SUB_STATE::SUB_STATE_BEHEAVY, CHARACTER_STATE::CHARACTER_STATE_BEHIT);

	}
	//������(���ɵ��߿�)
	else if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_BEHITFLY, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
		PlayBeHitFly(HitCauser);
	}
	//�����ܻ�
	else if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1 || emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT2)
	{
		CHARACTER_SUB_STATE emNextState = GetSubState() == CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1 ? CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT2 : CHARACTER_SUB_STATE::SUB_STATE_FLY_BEHIT1;
		SetState(emNextState, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
	}
	//���б�����
	else if (emSubState == CHARACTER_SUB_STATE::SUB_STATE_FLY_HITFALL)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_FLY_HITFALL, CHARACTER_STATE::CHARACTER_STATE_BEHIT);
	}

	if (sHitResult.sTableData.nForce > 0)
	{
		GetCharacterMovement()->Velocity = FVector::ZeroVector;
		GetCharacterMovement()->SetPendingImpulseToApply(FVector::ZeroVector);
		FRotationMatrix CauserMatrix(HitCauser->GetActorRotation());
		FVector Impulse = FVector(CauserMatrix.TransformVector(sHitResult.sTableData.vDirection)).GetSafeNormal() * sHitResult.sTableData.nForce;
		GetCharacterMovement()->AddImpulse(Impulse, true);
	}

	if (sHitResult.sTableData.vVelocity != FVector::ZeroVector)
	{
		GetCharacterMovement()->Velocity = FVector::ZeroVector;
		GetCharacterMovement()->SetPendingImpulseToApply(FVector::ZeroVector);
		FRotationMatrix CauserMatrix(HitCauser->GetActorRotation());
		FVector vVelocity = FVector(CauserMatrix.TransformVector(sHitResult.sTableData.vVelocity));
		GetCharacterMovement()->Velocity = vVelocity;
	}

}

void APlayerCharacter::TestCallBack()
{
	if (m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT1 || m_emSubState == CHARACTER_SUB_STATE::SUB_STATE_BEHIT2)
	{
		SetState(CHARACTER_SUB_STATE::SUB_STATE_NORMAL, CHARACTER_STATE::CHARACTER_STATE_NORMAL);
	}
}

void APlayerCharacter::PlayDeadFly(AActor* HitCauser)
{
	Super::PlayDeadFly(HitCauser);
	if (HitCauser)
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECollisionResponse::ECR_Ignore);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_PhysicsBody, ECollisionResponse::ECR_Ignore);
		FRotationMatrix CauserMatrix(HitCauser->GetActorRotation());
		FVector Impulse = FVector(CauserMatrix.TransformVector(FVector(100, 0, 80))).GetSafeNormal() * 1000;
		GetCharacterMovement()->AddImpulse(Impulse, true);
		SetState(CHARACTER_SUB_STATE::SUB_STATE_DIE_FLY, CHARACTER_STATE::CHARACTER_STATE_DIE);
	}

}