// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "OthersCharacter.h"


// Sets default values
AOthersCharacter::AOthersCharacter()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AOthersCharacter::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AOthersCharacter::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
}

// Called to bind functionality to input
void AOthersCharacter::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);

}

// Fresh postion when need to do
void AOthersCharacter::ReFreshPosition()
{
	int zid = m_PlayerInfo.lastplace().zid();
	int nmapid = m_PlayerInfo.lastplace().nmapid();
	float x = m_PlayerInfo.lastplace().x();
	float y = m_PlayerInfo.lastplace().y();
	float z = m_PlayerInfo.lastplace().z();
	float Roll = m_PlayerInfo.lastplace().roll();
	float Pitch = m_PlayerInfo.lastplace().pitch();
	float Yaw = m_PlayerInfo.lastplace().yaw();
	float fMoveSpeed = m_PlayerInfo.lastplace().fmovespeed();
	int character_state = m_PlayerInfo.lastplace().character_state();
	int character_sub_state = m_PlayerInfo.lastplace().character_sub_state();
	proto3::eMoveType moveType = m_PlayerInfo.lastplace().movetype();
	// set state
	SetState((CHARACTER_SUB_STATE)character_sub_state, (CHARACTER_STATE)character_state);

	if (moveType == eMoveType::FALLING)
	{
		GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Falling);
	}
	else
	{
		GetCharacterMovement()->SetMovementMode(EMovementMode::MOVE_Walking);
	}
	//// set state
	//SetState((CHARACTER_SUB_STATE)character_sub_state, (CHARACTER_STATE)character_state);
	
	// set location
	FVector loation;
	loation.X = x;
	loation.Y = y;
	loation.Z = z;
	SetActorLocation(loation);

	// set rotation
	FRotator rotat;
	rotat.Yaw = Yaw-90.f;
	rotat.Pitch = Pitch;
	rotat.Roll = Roll;
	SetActorRotation(rotat);

	// set Character Movement
	SetMaxWalkSpeed(fMoveSpeed);
}

// Current PlayerInfo
void AOthersCharacter::setPlayerInfo(proto3::PlayerInfo& pi)
{
	m_PlayerInfo.CopyFrom(pi);
	// ˢ������
	ReFreshPosition();
}

proto3::PlayerInfo AOthersCharacter::getPlayerInfo()
{
	return m_PlayerInfo;
}