// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PACameraManager.h"
#include "PandaUtils.h"
#include "PandaGameInstance.h"
#include "MainPlayerController.h"

//=================��ͷ������Ч========================
UPACameraEff::UPACameraEff()
{
}

void UPACameraEff::startCameraEff()
{
	UCameraComponent* camera = Cast<APlayerCharacter>(UPandaUtils::getCurrCharacter())->FollowCamera;
	const FsCameraEffTab* cameraInfo = UPandaGameInstance::Instance()->SafeGetDataManager()->getCameraEffInfo(m_effId);
	UMaterial* test = Cast<UMaterial>(UPandaUtils::CreateAsset(FString("/Game/CameraAnim/") + cameraInfo->MaterialName));
	
	
	if (camera->PostProcessSettings.WeightedBlendables.Array.Num() >0)
	{
		camera->PostProcessSettings.WeightedBlendables.Array.RemoveAt(0);
		GWorld->GetTimerManager().ClearTimer(m_TimerHandle);
	}

	UMaterialInstanceDynamic* mat = UMaterialInstanceDynamic::Create(test, UPandaGameInstance::Instance());
	FWeightedBlendable weighte;
	weighte.Object = mat;
	camera->PostProcessSettings.WeightedBlendables.Array.Add(weighte);
	camera->PostProcessSettings.WeightedBlendables.Array[0].Weight = 1;

	if (cameraInfo->nDelayed > 0.01)
	{
		FTimerDelegate battleTiem;
		battleTiem.BindUObject(this, &UPACameraEff::endCamerEff);
		GWorld->GetTimerManager().SetTimer(m_TimerHandle, battleTiem, cameraInfo->nDelayed, false);
	}
}
void UPACameraEff::endCamerEff()
{
	GWorld->GetTimerManager().ClearTimer(m_TimerHandle);
	UCameraComponent* camera = Cast<APlayerCharacter>(UPandaUtils::getCurrCharacter())->FollowCamera;

	if (camera->PostProcessSettings.WeightedBlendables.Array.Num()>0)
	{
		camera->PostProcessSettings.WeightedBlendables.Array[0].Weight = 0.0f;
		camera->PostProcessSettings.WeightedBlendables.Array.RemoveAt(0);
	}
}
//========================camera DouDong=================
UPACameraManJingTou::UPACameraManJingTou()
{

}
void UPACameraManJingTou::startCameraEff()
{
	const FsCameraEffTab* camerInfo = UPandaGameInstance::Instance()->SafeGetDataManager()->getCameraEffInfo(m_effId);

	UGameplayStatics::SetGlobalTimeDilation(UPandaGameInstance::Instance(), camerInfo->nSpeed);
	if (camerInfo->nDelayed > 0.01)
	{
		FTimerDelegate battleTiem;
		battleTiem.BindUObject(this, &UPACameraManJingTou::endCamerEff);
		GWorld->GetTimerManager().SetTimer(m_TimerHandle, battleTiem, camerInfo->nDelayed, false);
	}
}
void UPACameraManJingTou::endCamerEff()
{
	UGameplayStatics::SetGlobalTimeDilation(UPandaGameInstance::Instance(), 1);
	GWorld->GetTimerManager().ClearTimer(m_TimerHandle);
}
//========================camera ManJingTou=================
UPACameraDouDong::UPACameraDouDong()
{

}
void UPACameraDouDong::startCameraEff()
{
	const FsCameraEffTab* cameraInfo = UPandaGameInstance::Instance()->SafeGetDataManager()->getCameraEffInfo(m_effId);
	//TSubclassOf<class UCameraShake>* Shake = Cast<TSubclassOf<class UCameraShake>>(UPandaUtils::CreateAsset(FString("/Game/CameraAnim/") + cameraInfo->ShakeName)) ;
// 	if (UPandaGameInstance::Instance())
// 	{
// 		APlayerController* cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance());
// 		if (cont && Shake)
// 		{
// 			//cont->ClientPlayCameraShake(*Shake);
// 		}
// 	}

	if (cameraInfo->nDelayed > 0.01)
	{
		FTimerDelegate battleTiem;
		battleTiem.BindUObject(this, &UPACameraDouDong::endCamerEff);
		GWorld->GetTimerManager().SetTimer(m_TimerHandle, battleTiem, cameraInfo->nDelayed, false);
	}
}
void UPACameraDouDong::endCamerEff()
{
	GWorld->GetTimerManager().ClearTimer(m_TimerHandle);
}
//========================camera manager=================
UPACameraManager* GCameraManager = nullptr;
UPACameraManager::UPACameraManager()
{
	GCameraManager = this;
	BlurRadius = .0f;
	m_CameraEff = NewObject<UPACameraEff>(this, "UPACameraEff1", RF_MarkAsRootSet);
	m_CameraDouDong = NewObject<UPACameraDouDong>(this, "m_CameraDouDong", RF_MarkAsRootSet);
	m_CameraManJingTou = NewObject<UPACameraManJingTou>(this, "m_CameraManJingTou", RF_MarkAsRootSet);
}
UPACameraManager* UPACameraManager::GetCameraManagerInstance()
{
	return GCameraManager;
}
void UPACameraManager::PlayTaskCameraAnim(USceneComponent* pCom)
{
	if (!pCom)
	{
		UE_LOG(LogTemp, Log, TEXT("task Actor is null....."));
		return;
	}
	pCom->SetActive(true);
	//��������
	AMainPlayerController* contro = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	APlayerCharacter* character = contro->GetMainPlayer();
	character->SetActorHiddenInGame(true);
	//character->
	//FTransform transf;
	//transf.SetLocation(FVector(0, 190, 10));
	//transf.SetRotation(FQuat(0, 0, -90, 0));
	//ACameraActor* camerA = GWorld->SpawnActor<ACameraActor>();
	//UCameraComponent* camerA = NewObject<UCameraComponent>(UCameraComponent::StaticClass());
	//camerA->AttachTo(pCom);
	//camerA->AttachTo(pCom);
	//camerA->K2_AttachRootComponentTo(pCom);
	//camerA->SetActorRelativeTransform(transf);
	auto cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance());
	cont->SetViewTargetWithBlend(pCom->GetOwner(),0.5);

	//camerA->Deactivate
}

void UPACameraManager::StopTaskCameraAnim(USceneComponent* pcom)
{
	if (!pcom)
	{
		UE_LOG(LogTemp, Log, TEXT("task Actor is null....."));
		return;  
	}
	//��ʾ����
	AMainPlayerController* contro = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	APlayerCharacter* character = contro->GetMainPlayer();
	character->SetActorHiddenInGame(false);

	APlayerController* cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance());
	cont->SetViewTargetWithBlend(cont->GetPawn(),0.5);
	pcom->SetActive(false);
// 	TArray<USceneComponent*> Children;
// 	pcom->GetChildrenComponents(false , Children);
// 	for (USceneComponent* chidl : Children)
// 	{
// 		UE_LOG(LogTemp, Log, TEXT("%s"), *chidl->GetName());
// 		if (chidl->GetName() == TEXT("SceneComponent"))
// 		{
// 			ACameraActor* camer = Cast<ACameraActor>(chidl->GetOwner());
// 			if (chidl->GetOwner())
// 			{
// 				chidl->DestroyComponent();
// 				GWorld->DestroyActor(chidl->GetOwner());
// 				
// 				//camer->getActorRelativeTransform()
// 				//camer->actorrelativetrans
// 
// 			}
// 		}
// 	}
}
void UPACameraManager::PlayLocCameraAnim(int id)
{
	UObject* test = UPandaUtils::CreateAsset(TEXT("/Game/CameraAnim/skill_LuoHanQuan.skill_LuoHanQuan"));
	if (UPandaGameInstance::Instance())
	{
		auto cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance());
		if (cont)
		{
			cont->PlayerCameraManager->PlayCameraAnim(Cast<UCameraAnim>(test));
		}
	}
}
void UPACameraManager::PlayLocCameraEff(int id, bool isOpen, float delayed)
{
	const FsCameraEffTab* cameraeff = UPandaGameInstance::Instance()->SafeGetDataManager()->getCameraEffInfo(id);
	switch (cameraeff->cameraType)
	{
	case emCameraEffType::ManJingTou:
		break;
	case emCameraEffType::DouDong:
		break;
	case emCameraEffType::JingXiangMoHu:
		if (isOpen)
		{
			const FsCameraEffTab* cameraInfo = UPandaGameInstance::Instance()->SafeGetDataManager()->getCameraEffInfo(id);
			m_CameraEff->m_effId = cameraInfo->nID;
			m_CameraEff->startCameraEff();
		}
		else
		{
			m_CameraEff->endCamerEff();
		}
		break;
	case emCameraEffType::BianSe:
		break;
	default:
		break;
	}

}
void UPACameraManager::PreLoad()
{

}
void UPACameraManager::removeCameraEff(int id)
{

}