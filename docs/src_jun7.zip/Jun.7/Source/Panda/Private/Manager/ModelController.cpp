// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "ModelController.h"
#include "PAWidget_common_MessageBox.h"


void UModelController::MessageBoxCallBack(int mes)
{
	MsgCZChallengeAgree agree;
	agree.set_mid(eMsg::MSG_CZ_CHALLENGE_AGREE);
	agree.set_result(eResult::SUCCEESS);
	*agree.add_challengers() = pvpimsg.challengers(0); //(TCHAR_TO_UTF8(*imsg.challengers(0)));
	agree.set_opposites(pvpimsg.opposites(0));

	PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, agree);
}
void UModelController::pvpInvite(MsgZCChallengeInvite imsg)
{
// 	auto gameInstance = UPandaGameInstance::Instance();
// 	UPAWidget_common_MessageBox* message = Cast<UPAWidget_common_MessageBox>(gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/UI/UMG/commonMessageBox.commonMessageBox_C")));
// 	message->setCallBack(std::bind(&UModelController::MessageBoxCallBack, this, std::placeholders::_1));
// 	pvpimsg = imsg;

	MsgCZChallengeAgree agree;
	agree.set_mid(eMsg::MSG_CZ_CHALLENGE_AGREE);
	agree.set_result(eResult::SUCCEESS);
	*agree.add_challengers() = imsg.challengers(0); //(TCHAR_TO_UTF8(*imsg.challengers(0)));
	agree.set_opposites(imsg.opposites(0));

	PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, agree);
}
void UModelController::sendPvpCreate()
{
	auto data = FPlayerDataManager::Instance()->getPlayerInfo();
	AMainPlayerController* playerController = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	APlayerCharacter* playerchar = Cast<APlayerCharacter>(playerController->GetPawn());
	AOthersCharacter* targetco = Cast<AOthersCharacter>(playerchar->getTargetScope());
	if (!targetco)
	{
		return;
	}
	proto3::PlayerInfo pi = targetco->m_PlayerInfo;
	MsgCZChallengeCreate msg;
	msg.set_mid(eMsg::MSG_CZ_CHALLENGE_CREATE);
//	*msg.add_challengers() = (TCHAR_TO_UTF8 (*data.uid));
	*msg.add_opposites() = pi.uid();

	PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, msg);
	//AOthersCharacter 
}
void UModelController::pvpStart(MsgZCChallengeStart imsg)
{
	UPandaUtils::EnterArena(0);
}