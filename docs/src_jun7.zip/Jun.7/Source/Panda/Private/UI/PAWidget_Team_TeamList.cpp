// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_TeamList.h"
#include "ResDefine.h"


void UPAWidget_Team_TeamList::NativeConstruct()
{
	Super::NativeConstruct();

	/* Init data */
	Init();

	// ����UI�ؼ�
	ParseUIControllers();

	// ��ʼ������
	InitCurrentInterface();
	// ...
}

void UPAWidget_Team_TeamList::Init()
{
	auto m_FsPATeamList = FPlayerDataManager::Instance()->getTeamList();
	// set current list counts
	m_nCurrentListCounts = m_FsPATeamList.team.size();
	// deafult:1
	m_nCurrentIdx = 1;
}

void UPAWidget_Team_TeamList::InitCurrentInterface()
{

	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = GGameInstance->SafeGetUIManager()->CreateChildUI(UI_TEAM_LIST_CELL);
		if (ScrollBox_RegionList_Left && cell) 
		{
			auto name = FString(*FString::Printf(TEXT("TeamListCell_%d"), i));
			ScrollBox_RegionList_Left->AddChild(cell);

			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));
			auto Cell_TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DungeonName"));
			auto Cell_TextBlock_DifficultyLevelName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DifficultyLevelName"));
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));
			auto Cell_TextBlock_TeamPlayerCount = Cast<UTextBlock>(getChildByName(cell, "TextBlock_TeamPlayerCount"));
			Cell_Image_Background_1->SetVisibility(ESlateVisibility::Visible);
			Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);

			if (i == m_nCurrentIdx)
			{
				Cell_Image_Background_2->SetVisibility(ESlateVisibility::Visible);
			}

			// ���öӳ����� m_FsPATeamList.team[i] = TeamInfo
			auto m_FsPATeamList = FPlayerDataManager::Instance()->getTeamList();
			std::string title = m_FsPATeamList.team[i - 1].title();
			int curSize = m_FsPATeamList.team[i - 1].members_size();
			int totalSize = m_FsPATeamList.team[i - 1].capacity();
			FString myString = title.c_str();
			if (Cell_TextBlock_LeaderName)
			{
				Cell_TextBlock_LeaderName->SetText(FText::FromString(myString));
			}			

			// ���õ�ǰ�����е�����(��ǰ����/��ǰ�����п��Գ��ص�������)
			if (Cell_TextBlock_TeamPlayerCount)
			{
				Cell_TextBlock_TeamPlayerCount->SetText(FText::FromString(*FString::Printf(TEXT("%d/%d"), (int32)(curSize), totalSize)));
			}			

			int members_size = m_FsPATeamList.team[i - 1].members_size();
			// ���öӳ��ȼ�
			if ((members_size > 0) && Cell_TextBlock_LeaderLevel)
			{
				int leaderLevel = m_FsPATeamList.team[i - 1].mutable_members(0)->level(); //��һ��Ϊ�ӳ�
				Cell_TextBlock_LeaderLevel->SetText(FText::FromString(*FString::Printf(TEXT("Lv.%d"), (int32)(leaderLevel))));
			}

			// current team dungeon id 
			int dungeonId = m_FsPATeamList.team[i - 1].dungeonid();
			if (dungeonId != 0)
			{
				auto data = GGameInstance->SafeGetDataManager()->m_FsPADungeonData.Find((int32)dungeonId);
				// ��������_�ı� _��Ӧ����ĸ�����ť
				if (Cell_TextBlock_DungeonName)
				{
					auto nameIdArray = data->nNameId;
					int nNum = nameIdArray.Num();
					int32 nCurrentDungeonDifficulty = 0;
					auto stringData = GGameInstance->SafeGetDataManager()->m_StringTable.Find(nameIdArray[nCurrentDungeonDifficulty]);
					Cell_TextBlock_DungeonName->SetText(FText::FromString(stringData->strDesc));
				}

				// ���ø����Ѷ�
				if (Cell_TextBlock_DifficultyLevelName)
				{
					/* Current Dungeon Diffcult, default = 1    /1 ��/ 2 ��ͨ/ 3 Ӣ��/ 4 ��Ԩ, ��ǰѡ�еĸ����Ѷ� */
					auto nDiffArray = data->nDifficulty;
					int32 nCurrDiffculty = nDiffArray[0];
					switch (nCurrDiffculty)
					{
					case 1:
						Cell_TextBlock_DifficultyLevelName->SetText(FText::FromString("EASY_EASY"));
						break;
					case 2:
						Cell_TextBlock_DifficultyLevelName->SetText(FText::FromString("NORMAL_NORMAL"));
						break;
					case 3:
						Cell_TextBlock_DifficultyLevelName->SetText(FText::FromString("HERO_HERO"));
						break;
					case 4:
						Cell_TextBlock_DifficultyLevelName->SetText(FText::FromString("ABYSS_ABYSS"));
						break;
					default:
						Cell_TextBlock_DifficultyLevelName->SetText(FText::FromString("error_error"));
						break;
					}
				}
			}
		}
	}

	// interface update
	UpdateInterface();
}

void UPAWidget_Team_TeamList::UpdateInterface()
{
	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(i - 1));
		if (cell)
		{
			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));
			auto Cell_TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DungeonName"));
			auto Cell_TextBlock_DifficultyLevelName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DifficultyLevelName"));
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));
			auto Cell_TextBlock_TeamPlayerCount = Cast<UTextBlock>(getChildByName(cell, "TextBlock_TeamPlayerCount"));
			Cell_Image_Background_1->SetVisibility(ESlateVisibility::Visible);
			Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);

			if (i == m_nCurrentIdx)
			{
				Cell_Image_Background_2->SetVisibility(ESlateVisibility::Visible);
			}
		}
	}

	//�����Զ�����
	if (m_nCurrentIdx == 1) {	
		ScrollBox_RegionList_Left->ScrollToStart();
	}
	else if (m_nCurrentIdx == m_nCurrentListCounts) {	
		ScrollBox_RegionList_Left->ScrollToEnd();
	}
	else {
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(m_nCurrentIdx - 1));
		ScrollBox_RegionList_Left->ScrollWidgetIntoView(cell);
	}
	// ...
}

void UPAWidget_Team_TeamList::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);
}

// Exit Interface
void UPAWidget_Team_TeamList::OnCross()
{
	Super::OnCross();

	// show bottom ui
	auto panel = Cast<UPAWidget_Dungeon_SelectRegion>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_SelectRegion));
	if(panel)
		panel->SetVisibility(ESlateVisibility::Visible);
	// ...
}

// Enter
void UPAWidget_Team_TeamList::OnCircle()
{
	Super::OnCircle();

	if (m_nCurrentListCounts == 0) return;
	// Request to add current selected team
	int32 nTeamId = m_nCurrentIdx;
	SendAddTeamMessage(nTeamId);

	// ...
}

/* ���ͼ���������Ϣ */
void UPAWidget_Team_TeamList::SendAddTeamMessage(int32 nTeamId)
{
	// send message begin, ���ͼ��������Ϣ

	auto m_FsPATeamList = FPlayerDataManager::Instance()->getTeamList();
	auto ti = m_FsPATeamList.team[m_nCurrentIdx - 1];
	UTeamAPI::join(ti);

	// ���� join ��ʱ�����ʾ���ͳɹ�
	const FString str = TEXT("���ͼ��������Ϣ�ɹ�!!!");
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
	// send message end�����ͼ��������Ϣ
}

void UPAWidget_Team_TeamList::OnTriangle()
{
	Super::OnTriangle();

	// visible this ui
	this->SetVisibility(ESlateVisibility::Hidden);

	// Team: Open create team interface
	auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	controller->OnOpenCreateTeam();
	// ...
}

void UPAWidget_Team_TeamList::OnLeft()
{
	
	// ...
}

void UPAWidget_Team_TeamList::OnRight()
{
	
	// ...
}

void UPAWidget_Team_TeamList::OnUp()
{
	m_nCurrentIdx--;
	if (m_nCurrentIdx <= 0)
	{
		m_nCurrentIdx = m_nCurrentListCounts;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_TeamList::OnDown()
{
	m_nCurrentIdx++;
	if (m_nCurrentIdx > m_nCurrentListCounts)
	{
		m_nCurrentIdx = 1;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_TeamList::ParseUIControllers()
{
	// ����ͼƬ_ͼƬ
	Image_background_1 = Cast<UImage>(getChildByName(this, "Image_background_1"));
	// ������ʾ_ͼƬ
	Image_KeyTips = Cast<UImage>(getChildByName(this, "Image_KeyTips"));
	// ���Լ���Ķ����б�
	ScrollBox_RegionList_Left = Cast<UScrollBox>(getChildByName(this, "ScrollBox_RegionList_Left"));

	if (ScrollBox_RegionList_Left)
		ScrollBox_RegionList_Left->ClearChildren();
}