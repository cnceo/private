// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_JoinList.h"

void UPAWidget_Team_JoinList::SendGetCurrentTeamListMessage()
{
	
}

void UPAWidget_Team_JoinList::Init()
{
	// ��ȡ��ǰ��ҵĶ����б�
	SendGetCurrentTeamListMessage();

	auto team = FPlayerDataManager::Instance()->getTeamInfo();
	auto dataSize = team.joins_size();

	// test counts
	m_nCurrentListCounts = dataSize;
	// deafult:1
	m_nCurrentIdx = 1;
}

void UPAWidget_Team_JoinList::NativeConstruct()
{
	Super::NativeConstruct();

	/* Init data */
	Init();

	//// ����ID �� ������Ϣ_Client
	//for (auto& Dungeon : GGameInstance->SafeGetDataManager()->m_FsPADungeonData)
	//{
	//	int nID = Dungeon.Value.nID;
	//	auto data = Dungeon.Value;
	//	m_DungeonData.Add(nID, data);
	//}

	// ����UI�ؼ�
	ParseUIControllers();

	//// ͬ����ǰѡ�еĸ�����Ϣ
	//m_CurrentDungeonData = m_DungeonData.Find(m_nCurrentSelectedDungenonId);

	// ��ʼ������
	InitCurrentInterface();

	// ...
}

void UPAWidget_Team_JoinList::InitCurrentInterface()
{
	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = GGameInstance->SafeGetUIManager()->CreateChildUI(UI_Team_JoinList_Cell);
		if (ScrollBox_RegionList_Left && cell)
		{
			auto name = FString(*FString::Printf(TEXT("TeamMemberListCell_%d"), i));
			ScrollBox_RegionList_Left->AddChild(cell);

			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));	// ����
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));	// �ȼ�
			auto TextBlock_LeaderVocation = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderVocation"));	// ְҵ
			auto Image_Leader = Cast<UImage>(getChildByName(cell, "Image_Leader"));								// �ӳ���ʶ

			auto team = FPlayerDataManager::Instance()->getTeamInfo();

			auto joinData = team.joins(i-1);
			
			// hide image for leader
			if(Image_Leader)
				Image_Leader->SetVisibility(ESlateVisibility::Hidden);


			// ���öӳ����� m_FsPATeamList.team[i] = TeamInfo
			std::string playrerName = joinData.name();
			int level = joinData.level();
			int vocation = 1;
			FString myString = playrerName.c_str();

			if (Cell_TextBlock_LeaderName)
			{
				Cell_TextBlock_LeaderName->SetText(FText::FromString(myString));
			}
			if (Cell_TextBlock_LeaderLevel)
			{
				Cell_TextBlock_LeaderLevel->SetText(FText::FromString(*FString::Printf(TEXT("Lv.%d"), (int32)(level))));
			}
			if (TextBlock_LeaderVocation)
			{
				if (i == 1)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("ADC"));
				}
				else if (i == 2)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("APC"));
				}
				else if (i == 3)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("DPS"));
				}
				else if (i == 4)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("ASSIST"));
				}
			}
		}
	}

	// interface update
	UpdateInterface();
}

void UPAWidget_Team_JoinList::UpdateInterface()
{

	/*if (!m_CurrentDungeonData)
		return;*/

	//// ��������
	//auto nameIdArray = m_CurrentDungeonData->nNameId;
	//auto nameId = nameIdArray[m_nCurrentDungeonDifficulty - 1];
	//auto stringData = GGameInstance->SafeGetDataManager()->m_StringTable.Find(nameId);
	//TextBlock_DungeonName->SetText(FText::FromString(stringData->strDesc));

	//// ���õ�ǰ�����Ѷ�(Pattern(ģʽ))
	//auto nDiffArray = m_CurrentDungeonData->nDifficulty;
	//int32 nCurrDiffculty = nDiffArray[m_nCurrentDungeonDifficulty - 1];
	//switch (nCurrDiffculty)
	//{
	//case 1:
	//	TextBlock_DifficultyLevel->SetText(FText::FromString("EASY_EASY"));
	//	break;
	//case 2:
	//	TextBlock_DifficultyLevel->SetText(FText::FromString("NORMAL_NORMAL"));
	//	break;
	//case 3:
	//	TextBlock_DifficultyLevel->SetText(FText::FromString("HERO_HERO"));
	//	break;
	//case 4:
	//	TextBlock_DifficultyLevel->SetText(FText::FromString("ABYSS_ABYSS"));
	//	break;
	//default:
	//	TextBlock_DifficultyLevel->SetText(FText::FromString("error_error"));
	//	break;
	//}

	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(i - 1));
		if (cell)
		{
			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));	// ����
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));	// �ȼ�
			auto TextBlock_LeaderVocation = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderVocation"));	// ְҵ
			auto Image_Leader = Cast<UImage>(getChildByName(cell, "Image_Leader"));								// �ӳ���ʶ

			Cell_Image_Background_1->SetVisibility(ESlateVisibility::Visible);
			Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);

			if (i == m_nCurrentIdx)
			{
				Cell_Image_Background_2->SetVisibility(ESlateVisibility::Visible);
			}
		}
	}

	//�����Զ�����
	if (m_nCurrentIdx == 1) {
		ScrollBox_RegionList_Left->ScrollToStart();
	}
	else if (m_nCurrentIdx == m_nCurrentListCounts) {
		ScrollBox_RegionList_Left->ScrollToEnd();
	}
	else {
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(m_nCurrentIdx - 1));
		ScrollBox_RegionList_Left->ScrollWidgetIntoView(cell);
	}
	// ...
}

void UPAWidget_Team_JoinList::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);

	// ...
}

// Exit Interface
void UPAWidget_Team_JoinList::OnCross()
{
	Super::OnCross();

	// ...
}

// Enter,ͬ������m_nCurrentIdx�ڵ��ϵ�������ݼ����ҵĶ���
void UPAWidget_Team_JoinList::OnCircle()
{
	Super::OnCircle();

	// close Interface
	Super::OnCross();
	// sure to enter join the game, and send message to apply join the team

	// Send Apply Join MyTeam Message
	auto team = FPlayerDataManager::Instance()->getTeamInfo();
	auto pi = team.joins(m_nCurrentIdx-1);
	UTeamAPI::apply(pi,true);
	// send message end

	// ...
}

// Refused Join MyTeam
void UPAWidget_Team_JoinList::OnTriangle()
{
	Super::OnTriangle();

	// �򿪶����������,�����޸Ķ�������,���Ƶȼ�,��Ҫ����ĸ���

	Super::OnCross();

	// Send Refused Join MyTeam Message
	auto team = FPlayerDataManager::Instance()->getTeamInfo();
	auto pi = team.joins(m_nCurrentIdx - 1);
	UTeamAPI::apply(pi, false);

	// ...
}

void UPAWidget_Team_JoinList::OnLeft()
{

	// ...
}

void UPAWidget_Team_JoinList::OnRight()
{

	// ...
}

void UPAWidget_Team_JoinList::OnUp()
{
	m_nCurrentIdx--;
	if (m_nCurrentIdx <= 0)
	{
		m_nCurrentIdx = m_nCurrentListCounts;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_JoinList::OnDown()
{
	m_nCurrentIdx++;
	if (m_nCurrentIdx > m_nCurrentListCounts)
	{
		m_nCurrentIdx = 1;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_JoinList::ParseUIControllers()
{
	// ����ͼƬ_ͼƬ
	Image_background_1 = Cast<UImage>(getChildByName(this, "Image_background_1"));
	// ������ʾ_ͼƬ
	Image_KeyTips = Cast<UImage>(getChildByName(this, "Image_KeyTips"));
	// ���Լ���Ķ����б�
	ScrollBox_RegionList_Left = Cast<UScrollBox>(getChildByName(this, "ScrollBox_RegionList_Left"));

	if (ScrollBox_RegionList_Left)
		ScrollBox_RegionList_Left->ClearChildren();

	// �������ƺ͸����Ѷȵذ�_ͼƬ
	Image_Base = Cast<UImage>(getChildByName(this, "Image_Base"));

	// ��������_�ı�
	TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(this, "TextBlock_DungeonName"));

	// �����Ѷ�_�ı�
	TextBlock_DifficultyLevel = Cast<UTextBlock>(getChildByName(this, "TextBlock_DifficultyLevel"));
}