// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_CreateTeam.h"
#include "PAWidget_Team_TeamList.h"

// ����һ���ж����п��Բ���
#define TBCurrentInterfaceRow 5
// ����һ���ж����п��Բ���
#define LRCurrentInterfaceRow 2
// �Ѷȵȼ�
#define MAX_Difficulty_Level 4


void UPAWidget_Team_CreateTeam::Init()
{

	// ��ǰ�����������ʼ��
	m_nCurrentTBIdx = 1;
	m_nCurrentLRIdx = 1;

	/* ��ǰҳǩ��ѡ�񸱱��б�����, ��ǰ�ĸ���Cell */
	m_nCurrentTeamListIndex = 0;
	/* ��ǰҳǩ��ѡ�񸱱��б����棬һ���ж��ٸ�Cell */
	m_nCurrentTeamListAllCounts = 0;

	// ��ǰѡ�е����ĸ�����ID
	m_nCurrentSelectedDungenonId = 1;

	// ��ǰ�ĸ����Ѷ�
	m_nCurrentDungeonDifficulty = 1;

	// ��ǰ���Ƶȼ�
	m_nCurrentLimitLevel = 0;

	// ��ʼ����ǰ������������
	m_nCurrentLimitPlayerNums = 4;
	m_nCurrentExcelLimitPlayerNums = m_nCurrentLimitPlayerNums;

	// ���ø�������
	m_DungeonData.Reset();

	// ������ȼ�
	PLAYERMAXLEVEL = 0;

	// ��ǰѡ�е�ͼƬ�İ�ť�����ű���
	xyBigScale = 1.4f;
	xyNormalScale = 1.f;
	
	int nCount = 0;
	int32 m_FsPAUserUpgradeBaseDataTotalCounts = GGameInstance->SafeGetDataManager()->m_FsPAUserUpgradeBaseData.Num();
	// ��ɫ��������_Client
	for (auto& UserUpgrade : GGameInstance->SafeGetDataManager()->m_FsPAUserUpgradeBaseData)
	{
		int nID = UserUpgrade.Value.nID;
		auto data = UserUpgrade.Value;

		nCount++;
		if (nCount == m_FsPAUserUpgradeBaseDataTotalCounts)
		{
			// ������ȼ�,��Init�����л����������¸�ֵ
			PLAYERMAXLEVEL = data.nID;
		}
	}
}

void UPAWidget_Team_CreateTeam::NativeConstruct()
{
	Super::NativeConstruct();

	/* Init data */
	Init();

	// ����ID �� ������Ϣ_Client
	for (auto& Dungeon : GGameInstance->SafeGetDataManager()->m_FsPADungeonData)
	{
		int nID = Dungeon.Value.nID;
		auto data = Dungeon.Value;
		m_DungeonData.Add(nID, data);
	}

	// m_nCurrentSelectedDungenonId, Deafult:1, ����������˺�����ڷ���˽��л�ȡ��ֵ

	// ͬ����ǰѡ�еĸ�����Ϣ
	m_CurrentDungeonData = m_DungeonData.Find(m_nCurrentSelectedDungenonId);
	
	// ����UI�ؼ�
	ParseUIControllers();

	/* init current interface */
	InitCurrentInterface();
	// ...
}

void UPAWidget_Team_CreateTeam::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);
	UpdateSelf(InDeltaTime);
}

void UPAWidget_Team_CreateTeam::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);

	/// every frame to tick 
	//// When the team create successed, show self team member's UI, and refresh others head ui icon. logic end.
	//bool bTrue = FTeamDataManager::Instance()->Tick(deltaTime);
	//if (bTrue)
	//{
		//OnCross();
	//}
	// ...
}

void UPAWidget_Team_CreateTeam::InitCurrentInterface()
{
	/* update interface */
	UpdateInterface();

	// update current interface show needs data
	UpdateInterfaceNeedData();
	// update interface label
	UpdateInterfaceLabel();

	// ...
}

/* �Ե�ǰ������Ҫ���µ����ݽ��и��� */
void UPAWidget_Team_CreateTeam::UpdateInterfaceNeedData()
{
	if (!m_CurrentDungeonData)
		return;

	// ��������
	auto nameIdArray = m_CurrentDungeonData->nNameId;
	auto nameId = nameIdArray[m_nCurrentDungeonDifficulty - 1];
	auto stringData = GGameInstance->SafeGetDataManager()->m_StringTable.Find(nameId);
	m_nCurrentDungeonName = stringData->strDesc;

	// �����Ƽ��ȼ�
	auto nLevelArray = m_CurrentDungeonData->nLevel;
	int32 nCurrLevel = nLevelArray[m_nCurrentDungeonDifficulty - 1];
	m_nCurrentLimitLevel = nCurrLevel;

	// ���õ�ǰ�����Ѷ�(Pattern(ģʽ))
	// ...

	// ��������_�ı�
	auto nLimitPlayerArray = m_CurrentDungeonData->LimitPlayer;
	int32 nCurrnLimitPlayer = nLimitPlayerArray[m_nCurrentDungeonDifficulty - 1];
	m_nCurrentLimitPlayerNums = nCurrnLimitPlayer;
	m_nCurrentExcelLimitPlayerNums = nCurrnLimitPlayer;
}

void UPAWidget_Team_CreateTeam::UpdateInterface()
{
	// update interface arrow
	FVector2D fBigSacle = FVector2D(xyBigScale, xyBigScale);
	FVector2D fNormalSacle = FVector2D(xyNormalScale, xyNormalScale);
	switch (m_nCurrentTBIdx)
	{
	case 1:
		{
			Image_Selected_1->SetVisibility(ESlateVisibility::Visible);
			Image_Selected_2->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_3->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_4->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_5->SetVisibility(ESlateVisibility::Hidden);
			switch (m_nCurrentLRIdx)
			{
			case 1:
			case 2:
			{
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			}
		}
		break;
	case 2:
		{
			Image_Selected_1->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_2->SetVisibility(ESlateVisibility::Visible);
			Image_Selected_3->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_4->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_5->SetVisibility(ESlateVisibility::Hidden);
			switch (m_nCurrentLRIdx)
			{
			case 1:
			case 2:
			{
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			}
		}
		break;
	case 3:
		{
			Image_Selected_1->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_2->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_3->SetVisibility(ESlateVisibility::Visible);
			Image_Selected_4->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_5->SetVisibility(ESlateVisibility::Hidden);
			switch (m_nCurrentLRIdx)
			{
			case 1:
			{
				Image_arrow_1->SetRenderScale(fBigSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			break;
			case 2:
			{
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fBigSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			break;
			}
		}
		break;
	case 4:
		{
			Image_Selected_1->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_2->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_3->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_4->SetVisibility(ESlateVisibility::Visible);
			Image_Selected_5->SetVisibility(ESlateVisibility::Hidden);
			switch (m_nCurrentLRIdx)
			{
			case 1:
			{
				Image_arrow_2->SetRenderScale(fBigSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			break;
			case 2:
			{
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fBigSacle);
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
			}
			break;
			}
		}
		break;
	case 5:
		{
			Image_Selected_1->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_2->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_3->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_4->SetVisibility(ESlateVisibility::Hidden);
			Image_Selected_5->SetVisibility(ESlateVisibility::Visible);
			switch (m_nCurrentLRIdx)
			{
			case 1:
			{
				Image_arrow_3->SetRenderScale(fBigSacle);
				Image_arrow_6->SetRenderScale(fNormalSacle);
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
			}
			break;
			case 2:
			{
				Image_arrow_3->SetRenderScale(fNormalSacle);
				Image_arrow_6->SetRenderScale(fBigSacle);
				Image_arrow_1->SetRenderScale(fNormalSacle);
				Image_arrow_4->SetRenderScale(fNormalSacle);
				Image_arrow_2->SetRenderScale(fNormalSacle);
				Image_arrow_5->SetRenderScale(fNormalSacle);
			}
			break;
			}
		}
		break;
	default:
		break;
	}
	// ...
}

void UPAWidget_Team_CreateTeam::UpdateInterfaceLabel()
{
	if (!m_CurrentDungeonData)
		return;

	// ��������
	TextBlock_TargetName_Right->SetText(FText::FromString(m_nCurrentDungeonName));

	// �����Ƽ��ȼ�
	auto nLevelArray = m_CurrentDungeonData->nLevel;
	int32 nCurrLevel = nLevelArray[m_nCurrentDungeonDifficulty - 1];
	TextBlock_TargetName_Left->SetText(FText::FromString(*FString::Printf(TEXT("Lv.%d"), (int32)(nCurrLevel))));

	// ���õ�ǰ�����Ѷ�(Pattern(ģʽ))
	auto nDiffArray = m_CurrentDungeonData->nDifficulty;
	int32 nCurrDiffculty = nDiffArray[m_nCurrentDungeonDifficulty - 1];
	switch (nCurrDiffculty)
	{
	case 1:
		TextBlock_Pattern->SetText(FText::FromString("EASY_EASY"));
		break;
	case 2:
		TextBlock_Pattern->SetText(FText::FromString("NORMAL_NORMAL"));
		break;
	case 3:
		TextBlock_Pattern->SetText(FText::FromString("HERO_HERO"));
		break;
	case 4:
		TextBlock_Pattern->SetText(FText::FromString("ABYSS_ABYSS"));
		break;
	default:
		TextBlock_Pattern->SetText(FText::FromString("error_error"));
		break;
	}

	// ���ø������Ƶȼ�
	TextBlock_Level->SetText(FText::FromString(*FString::Printf(TEXT("Limit Lv. %d"), (int32)(m_nCurrentLimitLevel))));

	// ��������_�ı�
	TextBlock_Total->SetText(FText::FromString(*FString::Printf(TEXT("Limit %dP"), (int32)(m_nCurrentLimitPlayerNums))));
}

void UPAWidget_Team_CreateTeam::OnCross()
{

	if (ScrollBox_DungeonList->GetChildrenCount() == 0) {

		Super::OnCross();

		// show bottom ui
		auto panel = Cast<UPAWidget_Team_TeamList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_LIST));
		if(panel)
			panel->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		ScrollBox_DungeonList->ClearChildren();
		Image_DungeonList->SetVisibility(ESlateVisibility::Hidden);
	}

	// ...
}

/* message legal check */
bool UPAWidget_Team_CreateTeam::Message_Check()
{
	bool bSucessed = true;
	auto fText = EditableTextBox_1->GetText();
	auto fString = fText.ToString();
	if (fString.IsEmpty())
	{
		const FString str = TEXT("��������ʧ��,������������� !!!");
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, str);
		bSucessed = false;
	}

	return bSucessed;
}

/* send message to create team */
void UPAWidget_Team_CreateTeam::SendCreateTeamMsg()
{
	// check can send_message?
	bool bSucessed = Message_Check();
	if (!bSucessed)
		return;

	if (UPandaUtils::getOffline()) return;

	OnCross();

	// send message begin, create team
	auto fText = EditableTextBox_1->GetText();
	auto fString = fText.ToString();
	const std::string title = (TCHAR_TO_UTF8(*fString));
	UTeamAPI::create(title, m_nCurrentLimitPlayerNums, m_nCurrentSelectedDungenonId, m_nCurrentDungeonDifficulty);

	//auto panel_teamlist = Cast<UPAWidget_Team_TeamList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_LIST));
	//if (panel_teamlist) {
	//	if (panel_teamlist->IsInViewport())
	//	{
	//		//panel_teamlist->OnCross();
	//		panel_teamlist->StopBindingAction();
	//		panel_teamlist->RemoveFromViewport();
	//		panel_teamlist->RemoveFromParent();
	//	}
	//}

	//// show bottom ui
	//auto panel_selectregion = Cast<UPAWidget_Dungeon_SelectRegion>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_SelectRegion));
	//if (panel_selectregion) {
	//	if (panel_selectregion->IsInViewport())
	//	{
	//		//panel_selectregion->OnCross();
	//		panel_selectregion->StopBindingAction();
	//		panel_selectregion->RemoveFromViewport();
	//		panel_selectregion->RemoveFromParent();
	//	}
	//}

	// ... 
}

void UPAWidget_Team_CreateTeam::SendEditTeamMsg()
{
	// check can send_message?
	bool bSucessed = Message_Check();
	if (!bSucessed)
		return;

	if (UPandaUtils::getOffline()) return;

	// �ж��Լ��Ƿ��ж���
	auto uid = FPlayerDataManager::Instance()->getuid(); //FString����
	bool bHaveTeam = false; // bHaveTeam?
	auto teaminfo = FPlayerDataManager::Instance()->getTeamInfo();
	if (teaminfo.members_size() > 0 && teaminfo.uid() != "")
	{
		bHaveTeam = true;
	}
	if (!bHaveTeam) return;

	OnCross();

	// send message begin, edit team information
	const std::string title = (TCHAR_TO_UTF8(*(EditableTextBox_1->GetText().ToString())));
	UTeamAPI::edit(teaminfo, title, m_nCurrentLimitPlayerNums, m_nCurrentSelectedDungenonId, m_nCurrentDungeonDifficulty);
}

// Create Team
void UPAWidget_Team_CreateTeam::OnCircle()
{

	if (ScrollBox_DungeonList->GetChildrenCount() == 0) {

		// �ж��Լ��Ƿ��ж���
		auto uid = FPlayerDataManager::Instance()->getuid(); //FString����

		bool bHaveTeam = false; // bHaveTeam?
		auto teaminfo = FPlayerDataManager::Instance()->getTeamInfo();
		if (teaminfo.members_size() > 0 && teaminfo.uid() != "")
		{
			bHaveTeam = true;
		}

		// ����Լ��ж���
		if (bHaveTeam)
		{
			Super::OnCircle();

			// sure to edit team
			SendEditTeamMsg();
		}
		// ����Լ�û�ж���
		else
		{

			Super::OnCircle();

			// sure to create team
			SendCreateTeamMsg();

			// ...
		}
	}
	else
	{
		// Fisrt close the dungeon list
		ScrollBox_DungeonList->ClearChildren();
		Image_DungeonList->SetVisibility(ESlateVisibility::Hidden);
		// set current selected data
		//m_CurrentDungeonData = m_DungeonData.Find();


		int32 nCount = 0;
		for (TMap<int32, FsPADungeonData>::TConstIterator It(m_DungeonData); It; ++It)
		{
			auto key = It.Key();
			auto data = It.Value();
			int32 nID = data.nID;
			nCount++;
			if (nCount == m_nCurrentTeamListIndex)
			{
				m_nCurrentSelectedDungenonId = nID;
				m_CurrentDungeonData = m_DungeonData.Find(nID);
			}
		}

		// update current interface show needs data
		UpdateInterfaceNeedData();
		// update interface label
		UpdateInterfaceLabel();
	}

	// ...
}

// Sure Edit
void UPAWidget_Team_CreateTeam::OnTriangle()
{
	Super::OnTriangle();

	// ���ǵ�ʱ����Ҫ���ݵ�ǰ��괦����һ�������д���
	switch (m_nCurrentTBIdx)
	{
	case 1:
		{
			EditableTextBox_1->SetKeyboardFocus();
		}
		break;
	case 2:
		{
			if (ScrollBox_DungeonList->GetChildrenCount() == 0)
			{
				int32 nCount = m_DungeonData.Num();

				int32 nDungeonAllCounts = 0;
				Image_DungeonList->SetVisibility(ESlateVisibility::Visible);
				for (TMap<int32, FsPADungeonData>::TConstIterator It(m_DungeonData); It; ++It)
				{
					auto key = It.Key();
					auto data = It.Value();
					int32 nID = data.nID;

					nDungeonAllCounts++;
					auto cell = GGameInstance->SafeGetUIManager()->CreateChildUI(UI_TEAM_CREATE_CELL);
					if (ScrollBox_DungeonList && cell)
					{
						auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
						auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
						auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
						auto Cell_TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DungeonName"));
						auto Cell_TextBlock_RecommendLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_RecommendLevel"));

						Cell_Image_Background_1->SetVisibility(ESlateVisibility::Hidden);
						Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);
						ScrollBox_DungeonList->AddChild(cell);

						//Cell_TextBlock_DungeonName
						// ��������
						auto nameIdArray = data.nNameId;
						auto nameId = nameIdArray[0];
						auto stringData = GGameInstance->SafeGetDataManager()->m_StringTable.Find(nameId);
						Cell_TextBlock_DungeonName->SetText(FText::FromString(stringData->strDesc));

						// �����Ƽ��ȼ�
						auto nLevelArray = data.nLevel;
						int32 nCurrLevel = nLevelArray[0];
						Cell_TextBlock_RecommendLevel->SetText(FText::FromString(*FString::Printf(TEXT("Lv.%d"), (int32)(nCurrLevel))));
					}

				}
				// ͬ�� ��ǰҳǩ��ѡ�񸱱��б����棬һ���ж��ٸ�Cell
				m_nCurrentTeamListAllCounts = nDungeonAllCounts;
				// If current teamlist all counts > 0, m_nCurrentTeamListIndex -> deafult:1
				if (m_nCurrentTeamListAllCounts > 0)
					m_nCurrentTeamListIndex = 1;

				// update current dungeon list
				UpdateCurrentDungeonScrollBoxList();
			}
		}
		break;
	case 3:
		{
			switch (m_nCurrentLRIdx)
			{
			case 1:
				{
					m_nCurrentDungeonDifficulty--;
					if (m_nCurrentDungeonDifficulty <= 0)
					{
						m_nCurrentDungeonDifficulty = MAX_Difficulty_Level;
					}
					// update current interface show needs data
					UpdateInterfaceNeedData();
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			case 2:
				{
					m_nCurrentDungeonDifficulty++;
					if (m_nCurrentDungeonDifficulty > MAX_Difficulty_Level)
					{
						m_nCurrentDungeonDifficulty = 1;
					}
					// update current interface show needs data
					UpdateInterfaceNeedData();
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			}
		}
		break;
	case 4:
		{
			// ע:��ҵĲ����ȼ�ֻ��������1-MAXLevel֮��
			switch (m_nCurrentLRIdx)
			{
			case 1:
				{
					m_nCurrentLimitLevel--;
					if (m_nCurrentLimitLevel <= 0)
					{
						m_nCurrentLimitLevel = 1;
					}
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			case 2:
				{
					m_nCurrentLimitLevel++;
					if (m_nCurrentLimitLevel > PLAYERMAXLEVEL)
					{
						m_nCurrentLimitLevel = PLAYERMAXLEVEL;
					}
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			}
		}
		break;
	case 5:
		{
			switch (m_nCurrentLRIdx)
			{
			case 1:
				{
					m_nCurrentLimitPlayerNums--;
					if (m_nCurrentLimitPlayerNums <= 0)
					{
						m_nCurrentLimitPlayerNums = 1;
					}
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			case 2:
				{
					m_nCurrentLimitPlayerNums++;
					if (m_nCurrentLimitPlayerNums > m_nCurrentExcelLimitPlayerNums)
					{
						m_nCurrentLimitPlayerNums = m_nCurrentExcelLimitPlayerNums;
					}
					/*  update interface label show */
					UpdateInterfaceLabel();
				}
				break;
			}
		}
		break;
	}
	// ...
}

void UPAWidget_Team_CreateTeam::OnLeft()
{
	Super::OnLeft();

	m_nCurrentLRIdx--;
	if (m_nCurrentLRIdx <= 0)
	{
		m_nCurrentLRIdx = 1/*LRCurrentInterfaceRow*/;
	}

	/* Update Interface */
	UpdateInterface();

	OnTriangle();
	// ...
}

void UPAWidget_Team_CreateTeam::OnRight()
{
	Super::OnRight();
	m_nCurrentLRIdx++;
	if (m_nCurrentLRIdx > LRCurrentInterfaceRow)
	{
		m_nCurrentLRIdx = LRCurrentInterfaceRow/*1*/;
	}

	/* Update Interface */
	UpdateInterface();

	OnTriangle();
	// ...
}

void UPAWidget_Team_CreateTeam::OnUp()
{
	Super::OnUp();

	if (ScrollBox_DungeonList->GetChildrenCount() == 0)
	{
		m_nCurrentTBIdx--;
		if (m_nCurrentTBIdx <= 0)
		{
			m_nCurrentTBIdx = TBCurrentInterfaceRow;
		}

		/* Update Interface */
		UpdateInterface();
	}
	else
	{
		// ���������б�
		m_nCurrentTeamListIndex--;
		if (m_nCurrentTeamListIndex <= 0)
		{
			m_nCurrentTeamListIndex = m_nCurrentTeamListAllCounts;
		}

		// update current dungeon list
		UpdateCurrentDungeonScrollBoxList();
	}

	// ...
}

void UPAWidget_Team_CreateTeam::OnDown()
{
	Super::OnDown();

	if (ScrollBox_DungeonList->GetChildrenCount() == 0)
	{
		m_nCurrentTBIdx++;
		if (m_nCurrentTBIdx > TBCurrentInterfaceRow)
		{
			m_nCurrentTBIdx = 1;
		}

		/* Update Interface */
		UpdateInterface();
	}
	else
	{
		// ���������б�
		m_nCurrentTeamListIndex++;
		if (m_nCurrentTeamListIndex > m_nCurrentTeamListAllCounts)
		{
			m_nCurrentTeamListIndex = 1;
		}

		// update current dungeon list
		UpdateCurrentDungeonScrollBoxList();
	}

	// ...
}

/* update current dungeon list */
void UPAWidget_Team_CreateTeam::UpdateCurrentDungeonScrollBoxList()
{
	for (int32 i = 1; i <= m_nCurrentTeamListAllCounts; i++)
	{
		auto cell = Cast<UUserWidget>(ScrollBox_DungeonList->GetChildAt(i - 1));
		if (cell)
		{
			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_DungeonName"));
			auto Cell_TextBlock_RecommendLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_RecommendLevel"));
			Cell_Image_Background_1->SetVisibility(ESlateVisibility::Visible);
			Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);

			if (i == m_nCurrentTeamListIndex)
			{
				Cell_Image_Background_2->SetVisibility(ESlateVisibility::Visible);
			}
		}
	}

	//�����Զ�����
	if (m_nCurrentTeamListIndex == 1) {
		ScrollBox_DungeonList->ScrollToStart();
	}
	else if (m_nCurrentTeamListIndex == m_nCurrentTeamListAllCounts) {
		ScrollBox_DungeonList->ScrollToEnd();
	}
	else {
		auto cell = Cast<UUserWidget>(ScrollBox_DungeonList->GetChildAt(m_nCurrentTeamListIndex - 1));
		ScrollBox_DungeonList->ScrollWidgetIntoView(cell);
	}
}

void UPAWidget_Team_CreateTeam::ParseUIControllers()
{
	// ��ǰѡ����һ��_ѡ�е�1��_ͼƬ
	Image_Background_1 = Cast<UImage>(getChildByName(this, "Image_Background_1"));

	// ��ǰѡ����һ��_ѡ�е�1��_ͼƬ
	Image_Selected_1 = Cast<UImage>(getChildByName(this, "Image_Selected_1"));

	// ��ǰѡ����һ��_ѡ�е�2��_ͼƬ
	Image_Selected_2 = Cast<UImage>(getChildByName(this, "Image_Selected_2"));

	// ��ǰѡ����һ��_ѡ�е�3��_ͼƬ
	Image_Selected_3 = Cast<UImage>(getChildByName(this, "Image_Selected_3"));

	// ��ǰѡ����һ��_ѡ�е�4��_ͼƬ
	Image_Selected_4 = Cast<UImage>(getChildByName(this, "Image_Selected_4"));

	// ��ǰѡ����һ��_ѡ�е�5��_ͼƬ
	Image_Selected_5 = Cast<UImage>(getChildByName(this, "Image_Selected_5"));

	// �༭��������_�ؼ�
	EditableTextBox_1 = Cast<UEditableTextBox>(getChildByName(this, "EditableTextBox_1"));

	// �����Ѷ�_�ı�
	TextBlock_Pattern = Cast<UTextBlock>(getChildByName(this, "TextBlock_Pattern"));

	// ���Ƶȼ�_�ı�
	TextBlock_Level = Cast<UTextBlock>(getChildByName(this, "TextBlock_Level"));

	// ��������_�ı�
	TextBlock_Total = Cast<UTextBlock>(getChildByName(this, "TextBlock_Total"));

	// Pattern(ģʽ)���_ͼƬ
	Image_arrow_1 = Cast<UImage>(getChildByName(this, "Image_arrow_1"));

	// Pattern(ģʽ)�ұ�_ͼƬ
	Image_arrow_4 = Cast<UImage>(getChildByName(this, "Image_arrow_4"));

	// Level(���Ƶȼ�)���_ͼƬ
	Image_arrow_2 = Cast<UImage>(getChildByName(this, "Image_arrow_2"));

	// Level(���Ƶȼ�)�ұ�_ͼƬ
	Image_arrow_5 = Cast<UImage>(getChildByName(this, "Image_arrow_5"));

	// Total(��������)���_ͼƬ
	Image_arrow_3 = Cast<UImage>(getChildByName(this, "Image_arrow_3"));

	// Total(��������)�ұ�_ͼƬ
	Image_arrow_6 = Cast<UImage>(getChildByName(this, "Image_arrow_6"));

	// ���½ǽ���İ�����ʾ_ͼƬ
	Image_Tips_1 = Cast<UImage>(getChildByName(this, "Image_Tips_1"));
	
	// ѡ�еĸ������Ƽ��ȼ�_�ı�
	TextBlock_TargetName_Left = Cast<UTextBlock>(getChildByName(this, "TextBlock_TargetName_Left"));
	// ѡ�еĸ����ĸ�������_�ı�
	TextBlock_TargetName_Right = Cast<UTextBlock>(getChildByName(this, "TextBlock_TargetName_Right"));

	// ����List����_������
	ScrollBox_DungeonList = Cast<UScrollBox>(getChildByName(this, "ScrollBox_DungeonList"));
	if (ScrollBox_DungeonList)
		ScrollBox_DungeonList->ClearChildren();

	// ����list��ͼ
	Image_DungeonList = Cast<UImage>(getChildByName(this, "Image_DungeonList"));
	if(Image_DungeonList)
		Image_DungeonList->SetVisibility(ESlateVisibility::Hidden);
}