// Fill out your copyright notice in the Description page of Project Settings.
#include "panda.h"
#include "protocol/game_protocol.pb.h"
#include "PandaWidget_OtheInfoMenu.h"
#include "PandaGameInstance.h"
#include "EKGameFrame.h"
#include "PandaUtils.h"

using namespace proto3;

UPandaWidget_OtheInfoMenu::UPandaWidget_OtheInfoMenu()
{

}
UPandaWidget_OtheInfoMenu::~UPandaWidget_OtheInfoMenu()
{

}
void UPandaWidget_OtheInfoMenu::NativeConstruct()
{
	UPandaWidget::NativeConstruct();

	SetSelIdx(1);

	m_SelIdx = 0;
	m_WaitTime = 0;
	bflag = nullptr;
	itemMesh = nullptr;
}

void UPandaWidget_OtheInfoMenu::WaitTime()
{

	if (itemMesh)
	{
		ABaseCharacter* currChar = UPandaUtils::getCurrCharacter();
// 			FString uts = FString("/Game/BPInstance/UI/pvp/flag.flag_C");
// 			UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(uts);
// 			itemMesh = GetWorld()->SpawnActor<AActor>(ParentClass, currChar->GetActorLocation(), FRotator(0, 0, 0));
		itemMesh->GetRootComponent()->DetachFromParent(true);

		GetWorld()->GetTimerManager().ClearTimer(m_TimerHandle);

		UParticleSystemComponent* parti = Cast<UParticleSystemComponent>(UPandaUtils::getActorComponent(itemMesh, 101));
		parti->SetHiddenInGame(false);
	}

	m_WaitTime += 0.1f;

}
void UPandaWidget_OtheInfoMenu::OnLeft()
{
	
}

void UPandaWidget_OtheInfoMenu::OnRight()
{
	
}
void UPandaWidget_OtheInfoMenu::OnBag()
{
	RemoveFromParent();
}
void UPandaWidget_OtheInfoMenu::OnUp()
{
	SetSelIdx(m_SelIdx - 1);
}
void UPandaWidget_OtheInfoMenu::OnDown()
{
	SetSelIdx(m_SelIdx + 1);
}
void UPandaWidget_OtheInfoMenu::OnCircle()
{
	switch (m_SelIdx)
	{
	case 1:
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	case 5:
	{

		GGameInstance->SafeGetModeManager()->sendPvpCreate();
		
		//�������뵽������
		ABaseCharacter* currChar = UPandaUtils::getCurrCharacter();
		// Send to Server

		FTimerDelegate battleTiem;
		battleTiem.BindUObject(this, &UPandaWidget_OtheInfoMenu::WaitTime);
		GetWorld()->GetTimerManager().SetTimer(m_TimerHandle, battleTiem, 0.45f, false);


		FTimerDelegate battleTiem2;
		battleTiem2.BindUObject(this, &UPandaWidget_OtheInfoMenu::PreLoadMap);
		GetWorld()->GetTimerManager().SetTimer(m_TimerHandle2, battleTiem2, 10, false);


		RemoveFromViewport();

		if (currChar->GetState() == CHARACTER_STATE::CHARACTER_STATE_NORMAL)
		{
			currChar->SetState(CHARACTER_SUB_STATE::SUB_STATE_FLAG, CHARACTER_STATE::CHARACTER_STATE_STAND);
		}
			


		//
		FString uts = FString("/Game/UI/UMG/pvp/flag.flag_C");
		UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(uts);

		itemMesh = GetWorld()->SpawnActor<AActor>(ParentClass, currChar->GetActorLocation(), FRotator(0, 0, 0));

		UParticleSystemComponent* parti = Cast<UParticleSystemComponent>(UPandaUtils::getActorComponent(itemMesh, 101));
		parti->SetHiddenInGame(true);
// 		FString uts2 = FString("/Game/Model/Items/items_flag_001/Meshs/Items_flag_001.Items_flag_001");
// 		UObject* asset = UPandaUtils::CreateAsset(uts2);
// 		if (asset)
// 		{
// 			USkeletalMesh* SkeletalMesh = CastChecked<USkeletalMesh>(asset);
// 			USkeletalMeshComponent * SkeletalMeshComponent = bflag->GetSkeletalMeshComponent();
// 			SkeletalMeshComponent->UnregisterComponent();
// 			SkeletalMeshComponent->SetSkeletalMesh(SkeletalMesh);
// 			SkeletalMeshComponent->RegisterComponent();
// 
			USkeletalMeshSocket const* Socket = currChar->GetMesh()->GetSocketByName("weapon");
			if (Socket)
			{

				itemMesh->GetRootComponent()->AttachTo(currChar->GetMesh(), Socket->SocketName, EAttachLocation::SnapToTarget);

				itemMesh->SetOwner(currChar);
			}
// 		}

	}
		break;
	case 6:

		break;
	case 7:
		break;
	case 8:
		break;
	default:
		break;
	}
}
void UPandaWidget_OtheInfoMenu::OpenSelPage()
{

}
void UPandaWidget_OtheInfoMenu::SetSelIdx(int cIdx)
{
	if (cIdx > 8 || cIdx < 1 )
		return;

	if (m_SelIdx == 0)
	{
		m_SelIdx = 1;
	}
	UCanvasPanel* oldMenu = Cast<UCanvasPanel>(getChildByName(this, FString::Printf(TEXT("menu%d"), m_SelIdx)));
	UWidget* Image_white = getSoltByName(oldMenu, FString::Printf(TEXT("Image_white%d"), m_SelIdx));
	UWidget* Image_black = getSoltByName(oldMenu, FString::Printf(TEXT("Image_black%d"), m_SelIdx));
	Image_white->SetVisibility(ESlateVisibility::Hidden);
	Image_black->SetVisibility(ESlateVisibility::Visible);


	UCanvasPanel* currMenu = Cast<UCanvasPanel>(getChildByName(this, FString::Printf(TEXT("menu%d"), cIdx)));
	UWidget* cImage_white = getSoltByName(currMenu, FString::Printf(TEXT("Image_white%d"), cIdx));
	UWidget* cImage_black = getSoltByName(currMenu, FString::Printf(TEXT("Image_black%d"), cIdx));
	cImage_white->SetVisibility(ESlateVisibility::Visible);
	cImage_black->SetVisibility(ESlateVisibility::Hidden);

	m_SelIdx = cIdx;
}
void UPandaWidget_OtheInfoMenu::PreLoadMap()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		GetWorld()->GetTimerManager().ClearTimer(m_TimerHandle2);
		//FEKGameFrame::Instance()->ProcedureManager()->ChangeCurrentProcedure(GeometrySpace::Procedure::PT_Club);

		RemoveFromParent();
		itemMesh->Destroy();
	}
}
void UPandaWidget_OtheInfoMenu::DestroyFlag()
{
	if (bflag)
	{
		bflag->Destroy();
		bflag = nullptr;
	}
	
}