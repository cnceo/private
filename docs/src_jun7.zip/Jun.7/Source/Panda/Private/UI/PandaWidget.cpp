// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PandaWidget.h"
#include "PandaUtils.h"
#include "MainPlayerController.h"
#include "PandaGameInstance.h"


void UPandaWidget::NativeConstruct()
{
	
	Super::NativeConstruct();

	SetOwningLocalPlayer(UPandaGameInstance::Instance()->GetLocalPlayerByIndex(0));

	// binding action
	BindingAction();
	setSettingDim();
}

void UPandaWidget::StopBindingAction()
{
	// ��� FOnInputAction ����
	ClearBindingActionState();
	// ֹͣ���а�
	StopListeningForAllInputActions();
}

/* ��� FOnInputAction ���� */
void UPandaWidget::ClearBindingActionState()
{
	OnInputleft.Clear();
	OnInputRight.Clear();
	OnInputUp.Clear();
	OnInputDown.Clear();
	OnInput_Circle.Clear();
	OnInput_Cross.Clear();
	OnInput_Square.Clear();
	OnInput_Triangle.Clear();
	OnInput_R1.Clear();
	OnInput_R2.Clear();
	OnInput_L1.Clear();
	OnInput_L2.Clear();
	OnInput_closeBag.Clear();
}

void UPandaWidget::BindingAction()
{
	// ��� FOnInputAction ����
	ClearBindingActionState();

	//init input
	bStopAction = true; // stopplayerAction

	//DpadLeft
	OnInputleft.BindUFunction(this, FName(TEXT("OnLeft")));
	ListenForInputAction(FName(TEXT("DpadLeft")), IE_Pressed, 1, OnInputleft);
	//DpadRight
	OnInputRight.BindUFunction(this, FName(TEXT("OnRight")));
	ListenForInputAction(FName(TEXT("DpadRight")), IE_Pressed, 1, OnInputRight);
	//DpadUP
	OnInputUp.BindUFunction(this, "OnUp");
	ListenForInputAction(FName(TEXT("DpadUP")), IE_Pressed, 1, OnInputUp);
	//DpadDown
	OnInputDown.BindUFunction(this, FName(TEXT("OnDown")));
	ListenForInputAction(FName(TEXT("DpadDown")), IE_Pressed, 1, OnInputDown);
	//Circle
	OnInput_Circle.BindUFunction(this, "OnCircle");
	ListenForInputAction(FName(TEXT("Quan")), IE_Pressed, 1, OnInput_Circle);
	//cross
	OnInput_Cross.BindUFunction(this, "OnCross");
	ListenForInputAction(FName(TEXT("Cha")), IE_Pressed, 1, OnInput_Cross);
	//square
	OnInput_Square.BindUFunction(this, "OnSquare");
	ListenForInputAction(FName(TEXT("FangKuai")), IE_Pressed, 1, OnInput_Square);
	//triangle
	OnInput_Triangle.BindUFunction(this, "OnTriangle");
	ListenForInputAction(FName(TEXT("SanJiao")), IE_Pressed, 1, OnInput_Triangle);
	//R1
	OnInput_R1.BindUFunction(this, "OnR1");
	ListenForInputAction(FName(TEXT("R1")), IE_Pressed, 1, OnInput_R1);
	//R2
	OnInput_R2.BindUFunction(this, "OnR2");
	ListenForInputAction(FName(TEXT("R2")), IE_Pressed, 1, OnInput_R2);
	//L1
	OnInput_L1.BindUFunction(this, "OnL1");
	ListenForInputAction(FName(TEXT("L1")), IE_Pressed, 1, OnInput_L1);
	//L2
	OnInput_L2.BindUFunction(this, "OnL2");
	ListenForInputAction(FName(TEXT("L2")), IE_Pressed, 1, OnInput_L2);
	//�ر�bag
	OnInput_closeBag.BindUFunction(this, "OnBag");
	ListenForInputAction(FName(TEXT("bag2")), IE_Pressed, 1, OnInput_closeBag);
}

void UPandaWidget::ReBindingAction()
{
	BindingAction();
}

void UPandaWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);
	UpdateSelf(InDeltaTime);
}

void UPandaWidget::UpdateSelf(float deltaTime)
{
	if (!IsInViewport())
		return;
}

void UPandaWidget::CloseSelf(bool bDestory /*= false*/)
{
	this->RemoveFromViewport();
	SetVisibility(ESlateVisibility::Hidden);	
}

void UPandaWidget::OnCross()
{
	CloseSelf();
	StopBindingAction();

	//Destruct();	
}

UWidget* UPandaWidget::getChildByName(UUserWidget* widget, FString nodeName)
{
	TArray<class UWidget*> Widgets;
	widget->WidgetTree->GetAllWidgets(Widgets);
	FString ExistingName;

	UWrapBox* box_ = nullptr;
	for (UWidget* Widget : Widgets)
	{

		Widget->GetName(ExistingName);
		if (ExistingName.Equals(nodeName, ESearchCase::IgnoreCase))
		{
			return Widget;
		}
	}
	return nullptr;
}
UWidget* UPandaWidget::getSoltByName(UPanelWidget* widget, FString myName)
{
	const TArray<UPanelSlot*>& slots = widget->GetSlots();
	for (int i = 0; i < slots.Num();i++)
	{
		 UPanelSlot* slot = slots[i];
		 if (slot->Content->GetName() == myName)
		 {
			 return slot->Content;
		 }
		  
	}
	return nullptr;
}
void UPandaWidget::setSettingDim()
{
	AMainPlayerController* pc = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	FPostProcessSettings fps;
	fps.DepthOfFieldFocalDistance = 100;
	fps.DepthOfFieldFocalRegion = 100;
	fps.DepthOfFieldNearTransitionRegion = 100;
	fps.DepthOfFieldFarTransitionRegion = 100;
	fps.DepthOfFieldScale = .5f;
	fps.DepthOfFieldMaxBokehSize = 3;
	fps.DepthOfFieldSizeThreshold = .08f;

	pc->GetMainPlayer()->FollowCamera->PostProcessSettings = fps;

}



