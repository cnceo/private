// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_MemberList.h"

void UPAWidget_Team_MemberList::Init()
{
	m_teaminfo = FPlayerDataManager::Instance()->getTeamInfo();

	// test counts
	m_nCurrentListCounts = m_teaminfo.members_size();
	// deafult:1
	m_nCurrentIdx = 1;

	// ��ǰѡ�е����ĸ�����ID
	m_nCurrentSelectedDungenonId = m_teaminfo.dungeonid();
	// ��ǰ�ĸ����Ѷ�
	m_nCurrentDungeonDifficulty = 1;
	// ���ø�������
	m_DungeonData.Reset();
}

void UPAWidget_Team_MemberList::NativeConstruct()
{
	Super::NativeConstruct();

	/* Init data */
	Init();

	// ����ID �� ������Ϣ_Client
	for (auto& Dungeon : GGameInstance->SafeGetDataManager()->m_FsPADungeonData)
	{
		int nID = Dungeon.Value.nID;
		auto data = Dungeon.Value;
		m_DungeonData.Add(nID, data);
	}

	// ����UI�ؼ�
	ParseUIControllers();

	// ͬ����ǰѡ�еĸ�����Ϣ
	m_CurrentDungeonData = m_DungeonData.Find(m_nCurrentSelectedDungenonId);

	// ��ʼ������
	InitCurrentInterface();

	// ...
}

void UPAWidget_Team_MemberList::InitCurrentInterface()
{
	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = GGameInstance->SafeGetUIManager()->CreateChildUI(UI_TEAM_MEMBER_LIST_CELL);
		if (ScrollBox_RegionList_Left && cell)
		{
			auto name = FString(*FString::Printf(TEXT("TeamMemberListCell_%d"), i));
			ScrollBox_RegionList_Left->AddChild(cell);

			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));	// ����
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));	// �ȼ�
			auto TextBlock_LeaderVocation = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderVocation"));	// ְҵ
			auto Image_Leader = Cast<UImage>(getChildByName(cell, "Image_Leader"));								// �ӳ���ʶ
			
			if (i == 1)
			{
				if (Image_Leader)
					Image_Leader->SetVisibility(ESlateVisibility::Visible);
			}
			else
			{
				if (Image_Leader)
					Image_Leader->SetVisibility(ESlateVisibility::Hidden);
			}
			// ���öӳ����� m_FsPATeamList.team[i] = TeamInfo
			std::string playrerName = m_teaminfo.members(i - 1).name();
			int level = m_teaminfo.members(i - 1).level();
			int vocation = 1;
			FString myString = playrerName.c_str();

			if (Cell_TextBlock_LeaderName)
			{
				Cell_TextBlock_LeaderName->SetText(FText::FromString(myString));
			}
			if (Cell_TextBlock_LeaderLevel)
			{
				Cell_TextBlock_LeaderLevel->SetText(FText::FromString(*FString::Printf(TEXT("Lv.%d"), (int32)(level))));
			}
			if (TextBlock_LeaderVocation)
			{
				if (i == 1)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("ADC"));
				}
				else if (i == 2)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("APC"));
				}
				else if (i == 3)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("DPS"));
				}
				else if (i == 4)
				{
					TextBlock_LeaderVocation->SetText(FText::FromString("ASSIST"));
				}
			}
		}
	}

	// interface update
	UpdateInterface();
}

void UPAWidget_Team_MemberList::UpdateInterface()
{

	if (!m_CurrentDungeonData)
		return;

	// ��������
	auto nameIdArray = m_CurrentDungeonData->nNameId;
	auto nameId = nameIdArray[m_nCurrentDungeonDifficulty - 1];
	auto stringData = GGameInstance->SafeGetDataManager()->m_StringTable.Find(nameId);
	TextBlock_DungeonName->SetText(FText::FromString(stringData->strDesc));

	// ���õ�ǰ�����Ѷ�(Pattern(ģʽ))
	auto nDiffArray = m_CurrentDungeonData->nDifficulty;
	int32 nCurrDiffculty = nDiffArray[m_nCurrentDungeonDifficulty - 1];
	switch (nCurrDiffculty)
	{
	case 1:
		TextBlock_DifficultyLevel->SetText(FText::FromString("EASY_EASY"));
		break;
	case 2:
		TextBlock_DifficultyLevel->SetText(FText::FromString("NORMAL_NORMAL"));
		break;
	case 3:
		TextBlock_DifficultyLevel->SetText(FText::FromString("HERO_HERO"));
		break;
	case 4:
		TextBlock_DifficultyLevel->SetText(FText::FromString("ABYSS_ABYSS"));
		break;
	default:
		TextBlock_DifficultyLevel->SetText(FText::FromString("error_error"));
		break;
	}

	for (int32 i = 1; i <= m_nCurrentListCounts; i++)
	{
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(i - 1));
		if (cell)
		{
			auto Cell_Image_Background_1 = Cast<UImage>(getChildByName(cell, "Image_Background_1"));
			auto Cell_Image_Background_2 = Cast<UImage>(getChildByName(cell, "Image_Background_2"));
			auto Cell_CanvasPanel_inside = Cast<UCanvasPanel>(getChildByName(cell, "CanvasPanel_inside"));
			auto Cell_TextBlock_LeaderName = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderName"));	// ����
			auto Cell_TextBlock_LeaderLevel = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderLevel"));	// �ȼ�
			auto TextBlock_LeaderVocation = Cast<UTextBlock>(getChildByName(cell, "TextBlock_LeaderVocation"));	// ְҵ
			auto Image_Leader = Cast<UImage>(getChildByName(cell, "Image_Leader"));								// �ӳ���ʶ
			
			Cell_Image_Background_1->SetVisibility(ESlateVisibility::Visible);
			Cell_Image_Background_2->SetVisibility(ESlateVisibility::Hidden);

			if (i == m_nCurrentIdx)
			{
				Cell_Image_Background_2->SetVisibility(ESlateVisibility::Visible);
			}
		}
	}

	//�����Զ�����
	if (m_nCurrentIdx == 1) {
		ScrollBox_RegionList_Left->ScrollToStart();
	}
	else if (m_nCurrentIdx == m_nCurrentListCounts) {
		ScrollBox_RegionList_Left->ScrollToEnd();
	}
	else {
		auto cell = Cast<UUserWidget>(ScrollBox_RegionList_Left->GetChildAt(m_nCurrentIdx - 1));
		ScrollBox_RegionList_Left->ScrollWidgetIntoView(cell);
	}
	// ...
}

void UPAWidget_Team_MemberList::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);

	// ...
}

// Exit Interface
void UPAWidget_Team_MemberList::OnCross()
{
	Super::OnCross();

	// ...
}

// �����ӳ�,Capatin
void UPAWidget_Team_MemberList::OnCircle()
{
	Super::OnCircle();

	const FString str = TEXT("���������ӳ���Ϣ,��û������ӿ�!!!");
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
	// ...
}

// �߳�����,Sign Out
void UPAWidget_Team_MemberList::OnSquare()
{
	Super::OnSquare();

	const FString str = TEXT("�����߳�������Ϣ,��û������ӿ�!!!");
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
	// ...
}

// �༭���
void UPAWidget_Team_MemberList::OnTriangle()
{
	Super::OnTriangle();

	// �򿪶����������,�����޸Ķ�������,���Ƶȼ�,��Ҫ����ĸ���

	//Super::OnCross();
	
	// open test team operation ui
	auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	controller->OnOpenTeamOperation();

	auto CurUI = GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_TeamMemberOperation);
	if (CurUI->IsInViewport())
	{
		auto pi = m_teaminfo.members(m_nCurrentIdx - 1);
		auto MemberOperationUI = Cast<UPAWidget_Team_MemberOperation>(CurUI);
		MemberOperationUI->setCurrentSelectPlayerData(pi);
		MemberOperationUI->setCurrentSelectIdx(m_nCurrentIdx);
	}
	// ...
}

void UPAWidget_Team_MemberList::OnLeft()
{

	// ...
}

void UPAWidget_Team_MemberList::OnRight()
{

	// ...
}

void UPAWidget_Team_MemberList::OnUp()
{
	m_nCurrentIdx--;
	if (m_nCurrentIdx <= 0)
	{
		m_nCurrentIdx = m_nCurrentListCounts;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_MemberList::OnDown()
{
	m_nCurrentIdx++;
	if (m_nCurrentIdx > m_nCurrentListCounts)
	{
		m_nCurrentIdx = 1;
	}

	// interface update
	UpdateInterface();

	// ...
}

void UPAWidget_Team_MemberList::ParseUIControllers()
{
	// ����ͼƬ_ͼƬ
	Image_background_1 = Cast<UImage>(getChildByName(this, "Image_background_1"));
	// ������ʾ_ͼƬ
	Image_KeyTips = Cast<UImage>(getChildByName(this, "Image_KeyTips"));
	// ���Լ���Ķ����б�
	ScrollBox_RegionList_Left = Cast<UScrollBox>(getChildByName(this, "ScrollBox_RegionList_Left"));

	if (ScrollBox_RegionList_Left)
		ScrollBox_RegionList_Left->ClearChildren();

	// �������ƺ͸����Ѷȵذ�_ͼƬ
	Image_Base = Cast<UImage>(getChildByName(this, "Image_Base"));

	// ��������_�ı�
	TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(this, "TextBlock_DungeonName"));

	// �����Ѷ�_�ı�
	TextBlock_DifficultyLevel = Cast<UTextBlock>(getChildByName(this, "TextBlock_DifficultyLevel"));
}