// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PandaWidgt_ChangeWeapon.h"
#include "PandaUtils.h"
#include "ItemManager.h"
#include "PandaGameInstance.h"
#include "MainPlayerController.h"
#include "PAWidget_common_MessageBox.h"

UPandaWidgt_ChangeWeapon::UPandaWidgt_ChangeWeapon()
{
	weapons.Empty();
	m_rollPos = FVector2D(1, 3);
}
UPandaWidgt_ChangeWeapon::~UPandaWidgt_ChangeWeapon()
{

}
void UPandaWidgt_ChangeWeapon::NativeConstruct()
{
	UPandaWidget::NativeConstruct();

	UItemManager* itemM = nullptr;
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		itemM = gameInstance->SafeGetItemManager();
	}

	UHorizontalBox* HorizontalBox_30 = Cast<UHorizontalBox>(getChildByName(this, "HorizontalBox_30"));
	HorizontalBox_30->ClearChildren();
	weapons = itemM->getWeapons();
	for (int i = 0; i < weapons.Num();i++)
	{
		UObject *inObject = UPandaUtils::CreateAsset(TEXT("/Game/UI/UMG/Weapon/weapon_unit.weapon_unit_C"));
		if (inObject && ensure(inObject))
		{
			UUserWidget* obj = CreateWidget<UUserWidget>(GWorld, Cast<UClass>(inObject));
			HorizontalBox_30->AddChild(obj);

			auto CanvasPanel_83 = Cast<UHorizontalBox>(getChildByName(obj, "HorizontalBox_30"));
		}
	}
	setItemIndex(0);
}

void UPandaWidgt_ChangeWeapon::setItemIndex(int index)
{
	int oldInded = m_itemIndex;
	int itemSize = weapons.Num();
	if (itemSize <= 0)
	{
		return;
	}
	if (index >= itemSize || index < 0)
	{
		return;
	}
	//����ѡ��Ч��
	int myIndex = index;
	UHorizontalBox* box_ = Cast<UHorizontalBox>(getChildByName(this, "HorizontalBox_30"));
	UUserWidget* slot = Cast<UUserWidget>(box_->GetChildAt(myIndex));
	UUserWidget* currSlot = Cast<UUserWidget>(box_->GetChildAt(m_itemIndex));
	if (currSlot)
	{
		//UImage* currSelImage = Cast<UImage>(getChildByName(currSlot, "Image_66"));
		//currSelImage->SetVisibility(ESlateVisibility::Hidden);

		UImage* currdImage = Cast<UImage>(getChildByName(currSlot, "Image_66"));
		currdImage->SetVisibility(ESlateVisibility::Hidden);
	}
	if (slot)
	{
		//UImage* SelImage = Cast<UImage>(getChildByName(slot, "Image_66"));
		//SelImage->SetVisibility(ESlateVisibility::Visible);

		UImage* oldImage = Cast<UImage>(getChildByName(slot, "Image_66"));
		oldImage->SetVisibility(ESlateVisibility::Visible);
	}
	m_itemIndex = myIndex;

	//�����Զ�����
	UScrollBox* ScrollBox_213 = Cast<UScrollBox>(getChildByName(this, "ScrollBox_57"));

	int youbiao = m_itemIndex + 1;
	if (youbiao > m_rollPos.Y)
	{
		ScrollBox_213->SetScrollOffset(ScrollBox_213->GetScrollOffset() + 390);
		m_rollPos.X += 1;
		m_rollPos.Y += 1;
	}
	else if (youbiao < m_rollPos.X)
	{
		ScrollBox_213->SetScrollOffset(ScrollBox_213->GetScrollOffset() - 390);
		m_rollPos.X -= 1;
		m_rollPos.Y -= 1;
	}

	//����ѡ��Ч��
	playerEff(oldInded, m_itemIndex);

}
void UPandaWidgt_ChangeWeapon::changeWeapon(int id)
{
	AMainPlayerController* contro = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance())) ;
	APlayerCharacter* character = contro->GetMainPlayer();
	switch (id)
	{
	case 1:
		character->UnequipWeapon();
		character->EquipWeapon(40);
		RemoveFromParent();
		break;
	case 5:
		character->UnequipWeapon();
		character->EquipWeapon(41);
		RemoveFromParent();
		break;
	default:
		break;
	}

}
void UPandaWidgt_ChangeWeapon::OnLeft()
{
	setItemIndex(m_itemIndex - 1);
}

void UPandaWidgt_ChangeWeapon::OnRight()
{
	setItemIndex(m_itemIndex + 1);
}

void UPandaWidgt_ChangeWeapon::OnUp()
{
	setItemIndex(m_itemIndex - 3);
}

void UPandaWidgt_ChangeWeapon::OnDown()
{
	setItemIndex(m_itemIndex + 3);
}
void UPandaWidgt_ChangeWeapon::OnCircle()
{
	int id = weapons[m_itemIndex];

	UItemManager* itemM = nullptr;
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		itemM = gameInstance->SafeGetItemManager();
	}
	changeWeapon(id);
}
void UPandaWidgt_ChangeWeapon::mescall(int aa)
{
	int ab = aa;

}
void UPandaWidgt_ChangeWeapon::createMath()
{
	auto gameInstance = UPandaGameInstance::Instance();
	
	
	UPAWidget_common_MessageBox* message = Cast<UPAWidget_common_MessageBox>(gameInstance->SafeGetUIManager()->OpenUMGAsset(TEXT("/Game/UI/UMG/commonMessageBox.commonMessageBox_C"))) ;

	message->setCallBack(std::bind(&UPandaWidgt_ChangeWeapon::mescall, this, std::placeholders::_1));

// 	UPACameraManager* pac = UPACameraManager::GetCameraManagerInstance();
// 	pac->PlayLocCameraEff(1,true,0);
	//messageBox����


	//����������Ҹı�������ת
// 	APlayerCharacter* character = Cast<APlayerCharacter>(UPandaUtils::getCurrCharacter());
// 	ACameraActor* camer = GWorld->SpawnActor<ACameraActor>();
// 	camer->AttachRootComponentTo(character->GetRootComponent());
// 	camer->GetRootComponent()->SetRelativeLocation(FVector());
// 	camer->GetRootComponent()->SetRelativeRotation(FRotator());
// 	APlayerController* cont = UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()); 
// 	cont->SetViewTargetWithBlend(camer);
// 
// 	character->FollowCamera->bUsePawnControlRotation = false;
// 	character->FollowCamera->SetRelativeRotation(FRotator(-50, 0, 0));


// 	UItem* uitem = UPandaGameInstance::Instance()->SafeGetItemManager()->getItemById(10);
// 	uitem->getItemMesh(FVector(-9660, 11520, 420), GetWorld());
	
	// �л�װ��
 	//AActor* myActor = UPandaUtils::getCurrActorByTag(101);
// 	UActorComponent* childCom = UPandaUtils::getActorComponent(myActor,101);
// 	UClass* classname = childCom->GetClass();
// 	UChildActorComponent* pl = Cast<UChildActorComponent>(childCom);
// 	ABaseCharacter* bchar = Cast<ABaseCharacter>(pl->ChildActor);
// 	bchar->EquipWeapon("");
	 
	//�л�ʱװ,�����л�
// 	ABaseCharacter* character =	UPandaUtils::getCurrCharacter();
// 
// 	USkeletalMeshComponent* childCom = Cast<USkeletalMeshComponent>(UPandaUtils::getActorComponent(character, 103));
// 	UObject* myshtou = UPandaUtils::CreateAsset(FString("/Game/matinee/qqdr01/Po_Shoe_01.Po_Shoe_01"));
// 	UMaterialInterface* materia = Cast<UMaterialInterface>(myshtou);
// 	childCom->CreateDynamicMaterialInstance(1, materia);

	//��̬����mesh
// 	FVector myActorLoc = FVector(-9660,11520,420);//myActor->GetActorLocation();
// 
// 	FString AssetPath = "/Game/BPInstance/UI/Weapon/MyBlueprint.MyBlueprint_C";
// 	UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(AssetPath);
// 	
// 	AStaticMeshActor* weapon = GetWorld()->SpawnActor<AStaticMeshActor>(AStaticMeshActor::StaticClass(), myActorLoc, myActor->GetActorRotation());
// 	
// 	UE_LOG(LogTemp,Error,TEXT("%f-%f-%f"),myActorLoc.X, myActorLoc.Y, myActorLoc.Z);
// 
//  	UObject* asset =  UPandaUtils::CreateAsset(FString("/Game/Environment/Meshes/Rocks/SM_Cave_Rock_Large_01a.SM_Cave_Rock_Large_01a"));
//  
// 	UStaticMesh* StaticMesh = CastChecked<UStaticMesh>(asset);
// 	UStaticMeshComponent* StaticMeshComponent = weapon->GetStaticMeshComponent();
// 	StaticMeshComponent->UnregisterComponent();
// 	StaticMeshComponent->SetStaticMesh(StaticMesh);
// 	StaticMeshComponent->RegisterComponent();


	//AStaticMeshActor* weapon2 = GetWorld()->SpawnActor<AStaticMeshActor>(ParentClass, myActorLoc, myActor->GetActorRotation());

// 	AStaticMeshActor* ac = GWorld->SpawnActor<AStaticMeshActor>();
// 	ac->SetActorLocation(FVector(-9660, 11000, 420));
// 	AStaticMeshActor* ac2 = nullptr;
// 	TArray<AActor*> meshActors;
// 	UGameplayStatics::GetAllActorsOfClass(UPandaGameInstance::Instance(), AStaticMeshActor::StaticClass(), meshActors);
// 
// 	for (AActor* meshactro : meshActors)
// 	{
// 		TArray<FName> tags = Cast<AStaticMeshActor>(meshactro)->Tags;
// 
// 		if (tags.Num() > 0)
// 		{
// 			FString name = tags[0].ToString();
// 			if (name == "101")
// 			{
// 				
// 				
// 				ac = GWorld->SpawnActor<AStaticMeshActor>();// Cast<AStaticMeshActor>(meshactro);
// 				UE_LOG(LogTemp, Error, TEXT("%s"), *name);
// 			}
// 			
// 		}
// 
// 	}
	//ac2 = DuplicateObject(ac, NULL,FName("aaaaaa"));

	//ac2->SetActorTransform(transf);
	//ac->SetActorLocation(FVector(-9660, 11000, 420));
	//ac2->GetRootComponent()->Activate(true);
	//ac2->SetActorHiddenInGame(false);

	//FActorSpawnParameters fasp;
	//fasp.Name = TEXT("ac");


	//APlayerCharacter* player_ = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()))->GetMainPlayer();
	//ac->GetRootComponent()->AttachTo(player_->GetRootComponent());
	//ac->K2_AttachRootComponentTo(player_->GetRootComponent(),TEXT("aaaaaa"), EAttachLocation::SnapToTarget);


// 
// 	UObject* myshtou = UPandaUtils::CreateAsset(FString("/Game/BPInstance/UI/Weapon/MyBlueprint.MyBlueprint"));
// 	UObject* asset =  UPandaUtils::CreateAsset(FString("/Game/Environment/Meshes/Rocks/SM_Cave_Rock_Large_01a.SM_Cave_Rock_Large_01a"));
// 
// 	AStaticMeshActor* ac3 = NewObject<AStaticMeshActor>(myshtou,AStaticMeshActor::StaticClass(),TEXT("ac3"));
// 	ac3->K2_AttachRootComponentTo(player_->GetRootComponent());

	//UStaticMesh* StaticMesh = CastChecked<UStaticMesh>(asset);
	//ac3->SetActorLocation(FVector(-9660, 11000, 420));
//	UStaticMeshComponent* StaticMeshComponent = nullptr; //ac3->GetStaticMeshComponent();

	//check(StaticMeshComponent);
	//StaticMeshComponent->UnregisterComponent();
	//StaticMeshComponent->SetStaticMesh(StaticMesh);
	// Init Component
	//StaticMeshComponent->RegisterComponent();

	//ac->SetOwner(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));


}