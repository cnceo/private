// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_IntoPrompt.h"

#define MaxCountDownTime 60




void UPAWidget_Team_IntoPrompt::Init()
{

}

void UPAWidget_Team_IntoPrompt::NativeConstruct()
{
	Super::NativeConstruct();

	/* Init data */
	Init();

	// ����UI�ؼ�
	ParseUIControllers();

	// timer 
	UpdateTimeDisplay();

	CountdownReset();
	GetWorld()->GetTimerManager().SetTimer(CountdownTimerHandle, this, &UPAWidget_Team_IntoPrompt::AdvanceTimer, 1.0f, true);
	m_bTimerExist = true;

	// init current interface
	InitCurrentInterface();

	// ...
}

void UPAWidget_Team_IntoPrompt::InitCurrentInterface()
{
	//// �ӳ������˸�������_�ı�
	//TextBlock_Tips_1->SetText(FText::FromString("�ӳ������˸�������"));

	//// ��������_�ı�
	//TextBlock_DungeonName->SetText(FText::FromString("���ߴ�½"));

	//// �Ƿ����һ�����?_�ı�
	//TextBlock_Tips_2->SetText(FText::FromString("�Ƿ����һ�����?"));
}

void UPAWidget_Team_IntoPrompt::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);

	// ...
}

// Exit
void UPAWidget_Team_IntoPrompt::OnCross()
{
	// �رոý���
	Super::OnCross();

	if (m_bTimerExist)
	{
		GetWorld()->GetTimerManager().ClearTimer(CountdownTimerHandle);
		m_bTimerExist = false;
	}

	// open test team operation ui
	auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	controller->OnOpenTeamOperation();
	// ...
}

// ȷ��
void UPAWidget_Team_IntoPrompt::OnCircle()
{	
	Super::OnCircle();

	// �رոý���
	OnCross();

	if (m_bTimerExist)
	{
		GetWorld()->GetTimerManager().ClearTimer(CountdownTimerHandle);
		m_bTimerExist = false;
	}

	// open test team operation ui
	auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
	controller->OnOpenTeamOperation();

	// ...
}

void UPAWidget_Team_IntoPrompt::OnTriangle()
{
	// ...
}

void UPAWidget_Team_IntoPrompt::OnLeft()
{
	// ...
}

void UPAWidget_Team_IntoPrompt::OnRight()
{
	// ...
}

void UPAWidget_Team_IntoPrompt::OnUp()
{
	// ...
}

void UPAWidget_Team_IntoPrompt::OnDown()
{
	// ...
}

void UPAWidget_Team_IntoPrompt::UpdateTimeDisplay()
{
	// ����ʣ�࿪��ʱ�䵹��ʱ_�ı�
	TextBlock_Time->SetText(FText::FromString(*FString::Printf(TEXT("%d"), (int32)(m_CountdownTime))));
}

void UPAWidget_Team_IntoPrompt::AdvanceTimer()
{
	--m_CountdownTime;

	UpdateTimeDisplay();

	if (m_CountdownTime < 1)
	{
		GetWorld()->GetTimerManager().ClearTimer(CountdownTimerHandle);
		CountdownHasFinished();

		//CountdownReset();
	}
}
void UPAWidget_Team_IntoPrompt::CountdownHasFinished_Implementation()
{
	TextBlock_Time->SetText(FText::FromString("GO!"));

	//// �رոý���
	//OnCross();
}

void UPAWidget_Team_IntoPrompt::CountdownReset_Implementation()
{
	m_CountdownTime = MaxCountDownTime;
}

void UPAWidget_Team_IntoPrompt::ParseUIControllers()
{
	// ���½ǵİ�����ʾ_ͼƬ
	Image_KeyTips = Cast<UImage>(getChildByName(this, "Image_KeyTips"));

	// ����ͼƬ�׿�_ͼƬ
	Image_background_1 = Cast<UImage>(getChildByName(this, "Image_background_1"));

	// ��ǰ�ĸ�����ͼƬ_ͼƬ
	Image_background_dungeon = Cast<UImage>(getChildByName(this, "Image_background_dungeon"));

	// ����ʱ_�ı�
	TextBlock_Time = Cast<UTextBlock>(getChildByName(this, "TextBlock_Time"));

	// �ӳ������˸�������_�ı�
	TextBlock_Tips_1 = Cast<UTextBlock>(getChildByName(this, "TextBlock_Tips_1"));

	// ��������_�ı�
	TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(this, "TextBlock_DungeonName"));

	// �Ƿ����һ�����?_�ı�
	TextBlock_Tips_2 = Cast<UTextBlock>(getChildByName(this, "TextBlock_Tips_2"));
}