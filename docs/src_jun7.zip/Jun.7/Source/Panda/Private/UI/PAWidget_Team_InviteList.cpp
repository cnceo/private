// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_InviteList.h"



void UPAWidget_Team_InviteList::NativeConstruct()
{
	Super::NativeConstruct();
}

// Exit Interface
void UPAWidget_Team_InviteList::OnCross()
{
	Super::OnCross();

	// ...
}

// Enter
void UPAWidget_Team_InviteList::OnCircle()
{
	Super::OnCircle();

	// ...
}

void UPAWidget_Team_InviteList::OnTriangle()
{
	Super::OnTriangle();
}


void UPAWidget_Team_InviteList::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);

	// ...
}

void UPAWidget_Team_InviteList::OnLeft()
{

	// ...
}

void UPAWidget_Team_InviteList::OnRight()
{

	// ...
}

void UPAWidget_Team_InviteList::OnUp()
{
}

void UPAWidget_Team_InviteList::OnDown()
{
}

void UPAWidget_Team_InviteList::ParseUIControllers()
{
	// ����ͼƬ_ͼƬ
	Image_background_1 = Cast<UImage>(getChildByName(this, "Image_background_1"));
	// ������ʾ_ͼƬ
	Image_KeyTips = Cast<UImage>(getChildByName(this, "Image_KeyTips"));
	// ���Լ���Ķ����б�
	ScrollBox_RegionList_Left = Cast<UScrollBox>(getChildByName(this, "ScrollBox_RegionList_Left"));

	if (ScrollBox_RegionList_Left)
		ScrollBox_RegionList_Left->ClearChildren();

	// �������ƺ͸����Ѷȵذ�_ͼƬ
	Image_Base = Cast<UImage>(getChildByName(this, "Image_Base"));

	// ��������_�ı�
	TextBlock_DungeonName = Cast<UTextBlock>(getChildByName(this, "TextBlock_DungeonName"));

	// �����Ѷ�_�ı�
	TextBlock_DifficultyLevel = Cast<UTextBlock>(getChildByName(this, "TextBlock_DifficultyLevel"));
}