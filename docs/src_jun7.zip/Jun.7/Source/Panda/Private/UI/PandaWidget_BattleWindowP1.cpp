// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PandaWidget_BattleWindowP1.h"
#include "PlayerDataManager.h"
#include "PandaUtils.h"
#include "PandaGameInstance.h"
#include "EKGameFrame.h"
#include "WidgetBlueprintLibrary.h"


void UPandaWidget_BattleWindowP1::OnBag()
{
	RemoveFromParent();
}
void UPandaWidget_BattleWindowP1::NativeConstruct()
{
	 m_battleTime = Cast<UTextBlock>(getChildByName(this,"TextBlock_time"));

	FTimerDelegate battleTiem;
	battleTiem.BindUObject(this, &UPandaWidget_BattleWindowP1::BattleTimeCallBack);
	GetWorld()->GetTimerManager().SetTimer(m_TimerHandle, battleTiem, 1.0f, true);

	UUserWidget* BattleOverP1_362 = Cast<UUserWidget>(getChildByName(this,"BattleOverP1_362"));
	BattleOverP1_362->SetVisibility(ESlateVisibility::Hidden);

	m_CurrTime = 10;
	UpdateHreoInfo();
}
void UPandaWidget_BattleWindowP1::BattleTimeCallBack()
{
	m_CurrTime -= 1;
	int Min_ = m_CurrTime / 60;
	int sec = m_CurrTime % 60;

	m_battleTime->SetText(FText::FromString((*FString::Printf(TEXT("%02d : %02d"), Min_, sec))));
	
	if (m_CurrTime == 5)
	{
		createBattleComplete();
	}
	if (m_CurrTime == 0)
	{
		UWidgetBlueprintLibrary::SetInputMode_GameOnly(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
		FEKGameFrame::Instance()->ProcedureManager()->ChangeCurrentProcedure(GeometrySpace::Procedure::PT_World);
		RemoveFromParent();
		GetWorld()->GetTimerManager().ClearTimer(m_TimerHandle);
	}

}
void UPandaWidget_BattleWindowP1::UpdateHreoInfo()
{
	FsPAPlayerInfo myPlayer = FPlayerDataManager::Instance()->getPlayerInfo();
	UTextBlock* myName = Cast<UTextBlock>(getChildByName(this, "TextBlock_myName"));
	myName->SetText(FText::FromString(myPlayer.name));

	UProgressBar* myHp = Cast<UProgressBar>(getChildByName(this, "ProgressBar_myHp"));
	myHp->SetPercent(0.9);
	
}
void UPandaWidget_BattleWindowP1::createBattleComplete()
{
	UObject* inObject = UPandaUtils::CreateAsset("/Game/UI/UMG/pvp/BattleOverP1.BattleOverP1_C");
	if (ensure(inObject))
	{
		UUserWidget* obj = CreateWidget<UUserWidget>(GWorld, Cast<UClass>(inObject));
		UUserWidget* BattleOverP1_362 = Cast<UUserWidget>(getChildByName(this,"BattleOverP1_362"));
		BattleOverP1_362->SetVisibility(ESlateVisibility::Visible);

		auto Image_panda = Cast<UImage>(getChildByName(BattleOverP1_362, TEXT("Image_panda")));
		Image_panda->SetVisibility(ESlateVisibility::Hidden);

		UWidgetBlueprintLibrary::SetInputMode_UIOnly(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));

	}
}