// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_common_MessageBox.h"


void UPAWidget_common_MessageBox::NativeConstruct()
{
	m_cancel = Cast<UButton>(getChildByName(this, "Button_154"));
	m_confirm = Cast<UButton>(getChildByName(this, "Button_375"));

}

void UPAWidget_common_MessageBox::setCallBack(std::function<void(int)> callBack)
{
	messageCallBack = callBack;
}
void UPAWidget_common_MessageBox::selCallBack(int idx)
{
	messageCallBack(idx);
}
