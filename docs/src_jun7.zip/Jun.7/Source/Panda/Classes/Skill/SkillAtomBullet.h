// Fill out your copyright notice in the Description page of Project Settings.
//add by yang 20160503
#pragma once
#include "SkillBulletCollisiton.h"
#include "SkillAtomBullet.generated.h"

UCLASS()
class PANDA_API ASkillAtomBullet : public AActor
{
	GENERATED_BODY()
	
public:
	ASkillAtomBullet();

	virtual void Tick(float DeltaSeconds) override;

	//��ʼ��
	void InitByData(int32 nTableID, ABaseCharacter* pCharacter);

	//�����ӵ�����ײ��
	void CreateBulletCollistion();

	ABaseCharacter* GetCharacter() { return m_pCharacter; }

public:
	//�ӵ���������
	FsAtomBulletTable m_TableData;

	//ԭ�Ӷ��Լ���Ӱ��
	FsAtomEffectTable m_sSelfEffectTable;

	//ԭ�Ӷ��ѷ���Ӱ��
	FsAtomEffectTable m_sFriendEffectTable;

	//ԭ�ӶԵ��˵�Ӱ��
	FsAtomEffectTable m_sEnemyEffectTable;

	ABaseCharacter* m_pCharacter;
private:
	float m_fCurTime;
	class UParticleSystemComponent* ParticleSystem;
	TMap<IActiveActorInterface*, FsSkillHitResult> m_mapTarget;
	TArray<ASkillBulletCollisiton*> m_arrBulletActor;
	
};
