// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Character.h"
#include "OthersCharacter.generated.h"

UCLASS()
class PANDA_API AOthersCharacter : public APlayerCharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AOthersCharacter();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;

	// Fresh postion when need to do
	void ReFreshPosition();

	// Current PlayerInfo
	proto3::PlayerInfo m_PlayerInfo;
	void setPlayerInfo(proto3::PlayerInfo& pi);
	proto3::PlayerInfo getPlayerInfo();
};
