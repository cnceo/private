// Fill out your copyright notice in the Description page of Project Settings.
//
//  BossCharacter.h.cpp
//  Panda: NPC Base Class
//  Revision: 2586
//  Created by White.tian on 2016-4-5 17:33:04
//  Copyright (c) 2016�� White.tian All rights reserved.
//
#pragma once

#include "MonsterCharacter.h"
#include "BossCharacter.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API ABossCharacter : public AMonsterCharacter
{
	GENERATED_BODY()
	
	
	
	
};
