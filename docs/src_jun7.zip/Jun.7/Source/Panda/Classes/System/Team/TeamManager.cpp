#include "panda.h"
#include "TeamManager.h"
#include "MainPlayerController.h"
#include "PAWidget_Team_CreateTeam.h"
#include "EKGameFrame.h"
#include "Panelmain.h"

static FTeamDataManager *s_pSharedFTeamDataManager = NULL;

FTeamDataManager::FTeamDataManager()
	: m_bLogPrint(true)
{

}

FTeamDataManager::~FTeamDataManager()
{

}

bool FTeamDataManager::Init()
{
	setLogPrint(true);

	return true;
}

FTeamDataManager * FTeamDataManager::Instance()
{
	if (!s_pSharedFTeamDataManager)
	{
		s_pSharedFTeamDataManager = new FTeamDataManager();
		s_pSharedFTeamDataManager->Init();
	}

	return s_pSharedFTeamDataManager;
}

void FTeamDataManager::purgedFTeamDataManager()
{
	//CC_SAFE_RELEASE_NULL(s_pSharedFTeamDataManager);
}

bool FTeamDataManager::Tick(float deltaTime)
{
	switch (m_emTEAM_SERVER_RETURN_STATE)
	{
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_NONE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_UPDATE:
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_CREATE_SUCCESS:
	{
			setTeamState(TEAM_SERVER_RETURN_STATE::SUB_STATE_NONE);
			// When the team create successed, show self team member's UI, and refresh others head ui icon. logic center.
			auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
			controller->OnOpenTeamMemberList();
			// ...

			// HUD����
			FUMGPanel* panel = FEKGameFrame::Instance()->HUDManager()->GetUMGPanelByName("PlayerMain");
			if (panel)
			{
				FPanelMain* panelMain = static_cast<FPanelMain*>(panel);
				if (panelMain)
				{
					panelMain->UpdateOtherPlayerInfo();
				}
			}
			return true;
		}
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE1:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE3:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE4:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE5:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_POSE6:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_WIN:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_LOSE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_AWKWARD:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_TAUNT:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_LOVELY:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_HELLO:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_PICK:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DRINK:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FLAG:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_MOVE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DEFENCE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DODGE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DODGE_TARGET:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_TUMBLE_DODGE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_JUMP:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_JUMP2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FALL:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_LAND:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_HIT:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_CHASE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_GUIDE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DIE_NORMAL:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DIE_FLOOR:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DIE_FLY:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHIT1:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHIT2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHIT3:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHIT4:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_REEL1:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_TUMBLE:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_GETUP:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_DIZZY:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHEAVY:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHEAVY_GETUP:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_REEL2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_REEL3:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_GETUP_QUICK:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_TUMBLE_HIT1:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_TUMBLE_HIT2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_BEHITFLY:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_HITFLY_FLOATING:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_HITFLY_FALLING:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_HITFLY_LAND:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FLY_BEHIT1:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FLY_BEHIT2:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FLY_HITFALL:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_FLY_HITROLL:
		break;
	case TEAM_SERVER_RETURN_STATE::SUB_STATE_MAX:
		break;
	default:
		break;
	}
	return false;
}