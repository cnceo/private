//
//  TeamManager.h
//  Panda
//
//  Created by White.tian on 2016-06-03 21:52:11.
//  Copyright (c) 2016年 White.tian All rights reserved.
//

#ifndef __TEAMMANAGER__
#define __TEAMMANAGER__

#include <string>
#include "CCPlatformMacros.h"


//组队返回的状态
UENUM(BlueprintType)
enum class TEAM_SERVER_RETURN_STATE :uint8
{
	//默认
	SUB_STATE_NONE = 0			UMETA(DisplayName = "None"),
	//创建成功
	SUB_STATE_CREATE_SUCCESS = 1			UMETA(DisplayName = "TEAM_CREATE_SUCCESS"),
	//队伍更熟
	SUB_STATE_UPDATE = 2			UMETA(DisplayName = "TEAM_UPDATE"),

	//**************站立状态子状态*********************
	//摆造型
	SUB_STATE_POSE1 = 3			UMETA(DisplayName = "ZHANLI_POSE1"),
	//摆造型
	SUB_STATE_POSE2 = 4			UMETA(DisplayName = "ZHANLI_POSE2"),
	//摆造型
	SUB_STATE_POSE3 = 5			UMETA(DisplayName = "ZHANLI_POSE3"),
	//摆造型
	SUB_STATE_POSE4 = 6			UMETA(DisplayName = "ZHANLI_POSE4"),
	//摆造型
	SUB_STATE_POSE5 = 7			UMETA(DisplayName = "ZHANLI_POSE5"),
	//摆造型
	SUB_STATE_POSE6 = 8			UMETA(DisplayName = "ZHANLI_POSE6"),
	//胜利表情
	SUB_STATE_WIN = 9				UMETA(DisplayName = "ZHANLI_WIN"),
	//失败表情
	SUB_STATE_LOSE = 10			UMETA(DisplayName = "ZHANLI_LOSE"),
	//尴尬表情
	SUB_STATE_AWKWARD = 11			UMETA(DisplayName = "ZHANLI_AWKWARD"),
	//挑衅表情
	SUB_STATE_TAUNT = 12			UMETA(DisplayName = "ZHANLI_TAUNT"),
	//卖萌表情
	SUB_STATE_LOVELY = 13			UMETA(DisplayName = "ZHANLI_LOVELY"),
	//打招呼表情
	SUB_STATE_HELLO = 14			UMETA(DisplayName = "ZHANLI_HELLO"),
	//拾取物品
	SUB_STATE_PICK = 15			UMETA(DisplayName = "ZHANLI_PICK"),
	//喝东西
	SUB_STATE_DRINK = 16			UMETA(DisplayName = "ZHANLI_DRINK"),
	//插旗帜
	SUB_STATE_FLAG = 17			UMETA(DisplayName = "ZHANLI_FLAG"),

	//**************行动状态子状态*********************
	//行走
	SUB_STATE_MOVE = 21				UMETA(DisplayName = "XINGDONG_MOVE"),
	//防御
	SUB_STATE_DEFENCE = 22				UMETA(DisplayName = "XINGDONG_DEFENCE"),
	//闪避
	SUB_STATE_DODGE = 23				UMETA(DisplayName = "XINGDONG_DODGE"),
	//锁定目标闪避
	SUB_STATE_DODGE_TARGET = 24		UMETA(DisplayName = "XINGDONG_DODGE_TARGET"),
	//倒地打滚闪避
	SUB_STATE_TUMBLE_DODGE = 25		UMETA(DisplayName = "XINGDONG_TUMBLE_DODGE"),

	//**************跳跃与下落子状态*********************
	//跳跃
	SUB_STATE_JUMP = 41			UMETA(DisplayName = "FALLING_JUMP"),
	//二段跳跃
	SUB_STATE_JUMP2 = 42			UMETA(DisplayName = "FALLING_JUMP2"),
	//自由下落状态
	SUB_STATE_FALL = 43			UMETA(DisplayName = "FALLING_FALL"),
	//着地状态
	SUB_STATE_LAND = 44			UMETA(DisplayName = "FALLING_LAND"),

	//**************技能状态子状态*********************
	//命中原子
	SUB_STATE_HIT = 61			UMETA(DisplayName = "JINENG_HIT"),
	//追击原子
	SUB_STATE_CHASE = 62			UMETA(DisplayName = "JINENG_CHASE"),
	//引导原子
	SUB_STATE_GUIDE = 63			UMETA(DisplayName = "JINENG_GUIDE"),

	//**************死亡状态子状态*********************
	//普通死亡	
	SUB_STATE_DIE_NORMAL = 81			UMETA(DisplayName = "SIWANG_DIE_NORMAL"),

	//被击倒后死亡	
	SUB_STATE_DIE_FLOOR = 82			UMETA(DisplayName = "SIWANG_DIE_FLOOR"),

	//死亡被击飞	
	SUB_STATE_DIE_FLY = 90				UMETA(DisplayName = "SIWANG_DIE_FLY"),

	//**************被击状态子状态*********************
	//被攻击(挨打1)
	SUB_STATE_BEHIT1 = 121				UMETA(DisplayName = "BEIJI_BEHIT1"),
	//被攻击(挨打2)
	SUB_STATE_BEHIT2 = 122				UMETA(DisplayName = "BEIJI_BEHIT2"),
	//被攻击(挨打3)
	SUB_STATE_BEHIT3 = 123				UMETA(DisplayName = "BEIJI_BEHIT3"),
	//被攻击(挨打4)
	SUB_STATE_BEHIT4 = 124				UMETA(DisplayName = "BEIJI_BEHIT4"),
	//趔趄1
	SUB_STATE_REEL1 = 125				UMETA(DisplayName = "BEIJI_REEL1"),
	//被击倒(倒地)
	SUB_STATE_TUMBLE = 126				UMETA(DisplayName = "BEIJI_TUMBLE"),
	//倒地起身
	SUB_STATE_GETUP = 127			UMETA(DisplayName = "BEIJI_GETUP"),
	//眩晕
	SUB_STATE_DIZZY = 128			UMETA(DisplayName = "BEIJI_DIZZY"),
	//被重击
	SUB_STATE_BEHEAVY = 129			UMETA(DisplayName = "BEIJI_BEHEAVY"),
	//被重击后起身
	SUB_STATE_BEHEAVY_GETUP = 130		UMETA(DisplayName = "BEIJI_BEHEAVY_GETUP"),
	//趔趄2
	SUB_STATE_REEL2 = 131				UMETA(DisplayName = "BEIJI_REEL2"),
	//趔趄3
	SUB_STATE_REEL3 = 132				UMETA(DisplayName = "BEIJI_REEL3"),
	//被击倒后立刻起身
	SUB_STATE_GETUP_QUICK = 133			UMETA(DisplayName = "BEIJI_GETUP_QUICK"),
	//倒地被击1
	SUB_STATE_TUMBLE_HIT1 = 134		UMETA(DisplayName = "BEIJI_TUMBLE_HIT1"),
	//倒地被击2
	SUB_STATE_TUMBLE_HIT2 = 135		UMETA(DisplayName = "BEIJI_TUMBLE_HIT2"),
	//被击飞到空中
	SUB_STATE_BEHITFLY = 151			UMETA(DisplayName = "BEIJI_BEHITFLY"),
	//被击飞在空中漂浮
	SUB_STATE_HITFLY_FLOATING = 152		UMETA(DisplayName = "BEIJI_HITFLY_FLOATING"),
	//被击飞开始下落
	SUB_STATE_HITFLY_FALLING = 153		UMETA(DisplayName = "BEIJI_HITFLY_FALLING"),
	//被击飞漂浮后着陆
	SUB_STATE_HITFLY_LAND = 154		UMETA(DisplayName = "BEIJI_HITFLY_LAND"),
	//空中被攻击(挨打1)
	SUB_STATE_FLY_BEHIT1 = 155			UMETA(DisplayName = "BEIJI_FLY_BEHIT1"),
	//空中被攻击(挨打2)
	SUB_STATE_FLY_BEHIT2 = 156			UMETA(DisplayName = "BEIJI_FLY_BEHIT2"),
	//空中被击落(快速下落)
	SUB_STATE_FLY_HITFALL = 157		UMETA(DisplayName = "BEIJI_FLY_HITFALL"),
	//空中被击落倒地后打滚
	SUB_STATE_FLY_HITROLL = 158		UMETA(DisplayName = "BEIJI_FLY_HITROLL"),

	SUB_STATE_MAX = 255,
};

/**
*
*/
namespace proto3 {
	//class PlayerInfo;
};


#define PANDA_TeamManager (FTeamDataManager::Instance())


class FTeamDataManager
{

	FTeamDataManager();
	~FTeamDataManager();
public:

	static FTeamDataManager * Instance();
	static void purgedFTeamDataManager();
private:

	bool Init();
	// Print Log?
	CC_SYNTHESIZE(bool, m_bLogPrint, LogPrint);
	
	// Tick
	bool Tick(float deltaTime);

public:

	/*
	*	当前的队伍状态
	*
	*	setTeamState:	设置状态
	*	setTeamState:	获取状态
	*/
	TEAM_SERVER_RETURN_STATE m_emTEAM_SERVER_RETURN_STATE;
	void setTeamState(TEAM_SERVER_RETURN_STATE tmState) {	m_emTEAM_SERVER_RETURN_STATE = tmState;	}
	TEAM_SERVER_RETURN_STATE getTeamState() { return m_emTEAM_SERVER_RETURN_STATE; }
};

#endif /* defined(__TEAMMANAGER__) */