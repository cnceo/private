//
//  PlayerDataManager.h
//  Panda
//
//  Created by White.tian on 2016-05-23 10:08:44.
//  Copyright (c) 2016年 White.tian All rights reserved.
//

#ifndef __FPLAYERDATAMANAGER__
#define __FPLAYERDATAMANAGER__

#include "CCPlatformMacros.h"
#include "PAUserData.h"
#include "Data/DataParse.h"
#include <string>
/**
*
*/
namespace proto3 {
	class PlayerInfo;
	class MsgZCTeamJoinAsk;
	class MsgZCSyncPlayers;
	class MsgZCBroadcastPlayer;
	class MsgZCExit;
};


#define PANDA_PlayerManager (FPlayerDataManager::Instance())


class FPlayerDataManager
{

	FPlayerDataManager();
	~FPlayerDataManager();
public:

	static FPlayerDataManager * Instance();
	static void purgedFPlayerDataManager();
private:

	bool Init();
	// Print Log?
	CC_SYNTHESIZE(bool, m_bLogPrint, LogPrint);
public:
	/*
	*	Player Data
	*	
	*	member: PlayerInfoData, like playerLevel, playerExp...
	*	member: PlaceInfoData,	like last_place_x_y_z
	*	member: PlayerExtraInfoData, like...
	*/

	///* Player Information, player base data, server data */
	//UPROPERTY(EditAnywhere, replicated)
	//FsPAPlayerInfo PlayerInfoData;
	//UPROPERTY(EditAnywhere, replicated)
	//FsPAPlaceInfo PlaceInfoData; 
	//UPROPERTY(EditAnywhere, replicated)
	//FsPAPlayerExtraInfo PlayerExtraInfoData;
	//
	//// PlayerData,  Get player Base Information
	//FsPAPlayerInfo GetPlayerInfo() { return PlayerInfoData; }
	//// SynchronyPlayerInfo. Set and Synchrony player information
	//void SetPlayerInfo(FsPAPlayerInfo PlayerInfo);

	CC_SYNTHESIZE(FsPAPlayerInfo, m_PlayerInfoData, PlayerInfo);

	//// PlayerPlaceData,  Get player Place Information
	//FsPAPlaceInfo GetPlaceInfo() { return PlaceInfoData; }
	//// SynchronyPlaceInfo. Set and Synchrony player placeInfo information
	//void SetPlaceInfo(FsPAPlaceInfo PlaceInfo);

	CC_SYNTHESIZE(FsPAPlaceInfo, m_PlaceInfoData, PlaceInfo);

	//// PlayerExtraData,  Get player Extra Information
	//FsPAPlayerExtraInfo GetPlayerExtraInfo() { return PlayerExtraInfoData; }
	//// SynchronyPlayerExtraInfo. Set and Synchrony player playerExtraInfo information
	//void SetPlayerExtraInfo(FsPAPlayerExtraInfo PlayerExtraInfo);

	CC_SYNTHESIZE(FsPAPlayerExtraInfo, m_PlayerExtraInfoData, PlayerExtraInfo);
	
	// 同步当前在使用的teamInfo(属于当前玩家)
	proto3::TeamInfo m_TeamInfo;
	void setTeamInfo(proto3::TeamInfo ti);
	proto3::TeamInfo getTeamInfo() { return m_TeamInfo; }


	/*
	*	同步全部的队伍列表
	*
	*	setTeamList:	设置队伍列表,设置前会清空数据
	*	getTeamList:	获取队伍列表
	*/
	FsPATeamList m_FsPATeamList;
	void setTeamList(proto3::MsgZCTeamBroadcast imsg);
	FsPATeamList getTeamList();

	/* 
	*	同步当前的玩家list 
	*
	*	setPlayerInfoList: 直接设置玩家数据数组,会初始化清空该数据
	*	addPlayerInfoList  直接添加一个玩家数据到数组中
	*	removePlayerInfoList  删除一个用户数组从所有的玩家数组中,根据userid
	*	
	*	getPlayerInfoList  获取用户列表
	*/
	FsPAPlayerInfoList m_FsPAPlayerInfoList;
	std::map<std::string, proto3::PlayerInfo>::iterator it;
	void setPlayerInfoList(proto3::MsgZCSyncPlayers imsg);
	void addPlayerInfoList(proto3::MsgZCBroadcastPlayer imsg);
	void removePlayerInfoList(proto3::MsgZCExit imsg);
	FsPAPlayerInfoList getPlayerInfoList();
	//proto3::
	

	// 新登陆的用户的数据在其他玩家那里的储存方式
	// 强制刷新数据
	CC_SYNTHESIZE(bool, m_bForceToRefresh, ForceToRefresh);
	proto3::PlayerInfo NewFreshData;
	void setNewFreshData(proto3::PlayerInfo pi) { NewFreshData.CopyFrom(pi); }
	proto3::PlayerInfo getNewFreshData() { return NewFreshData; }

	
	/*
	*	getuid:				获取udid
	*	setPlayerInfoUid:	设置udid(临时的方法,理论上应获取机器码,如mac地址)
	*/
	std::string _uid;
	const char* getuid();
	/* get and set user id */
	void setPlayerInfoUid(FString uid);


	/* get and set player level */
	int32 getPlayerLevel();
	void setPlayerLevel(int32 nLevel);

	/* get and set Martialclub ID */
	int32 getMartialclubID();
	void setMartialclubID(int32 nID);

	/* get and set player exp */
	int32 getPlayerExp();
	void setPlayerExp(int32 nExp);

	/* get and set player Gold */
	int32 getPlayerGold();
	void setPlayerGold(int32 nGold);
	void addPlayerGold(int32 nGold);

	/* get and set player energy */
	int32 getPlayerEnergy();
	void setPlayerEnergy(int32 nEnergy);

	/* get and set player Task */
	TArray<int32>& getFinishTaskContainer();
	void setFinishTaskContainer(TArray<int32>& inFinishTaskContainer);

	/* get and set player Task */
	TMap<int32, UTask*>& getCurrentTaskContainer();
	void setCurrentTaskContainer(TMap<int32, UTask*>& inCurrentTaskContainer);
};

#endif /* defined(__FPlayerDataManager__) */