// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PandaGameInstance.h"
#include "ItemManager.h"
#include "EKGameFrame.h"
#include "PandaUtils.h"
TEnumAsByte<enum emItemType> UItem::getItemType()
{
	return m_LocResItem->itemType;
}
UImage* UItem::getItemIcon()
{
	auto gameInstance = UPandaGameInstance::Instance();
	if (gameInstance)
	{
		UItemManager* itemM = gameInstance->SafeGetItemManager();
		UImage* icon = nullptr;
		icon = NewObject<UImage>(this);

		UObject* test = UPandaUtils::CreateAsset(FString(TEXT("/Game/UI/Icon/Item/")) + m_LocResItem->icon);
		icon->Brush.SetResourceObject(test);
		icon->Brush.ImageSize = FVector2D(120, 200);

		return icon;
	}
	return nullptr;
}
AItemMesh* UItem::getItemMesh(FVector actorLoc,UWorld* currWorld)
{
	FVector myActorLoc = FVector(-9660, 11520, 420);//myActor->GetActorLocation();
	FRotator myActorRot = FRotator(0, 0, 0);
// 	FString AssetPath = "/Game/BPInstance/UI/Weapon/MyBlueprint.MyBlueprint_C";
// 	UBlueprintGeneratedClass* ParentClass = UPandaUtils::GetAssetFromPath(AssetPath);

	AItemMesh* itemMesh = currWorld->SpawnActor<AItemMesh>(AItemMesh::StaticClass(), actorLoc+150,myActorRot);
	int a = 10;
	UE_LOG(LogTemp, Error, TEXT("%f-%f-%f"), actorLoc.X, actorLoc.Y, actorLoc.Z);
	UE_LOG(LogTemp, Error, TEXT("%s"), *m_LocResItem->staticMesh);
	FString uts = FString("/Game/Environment/Meshes/WarSpoils/") + m_LocResItem->staticMesh;
	UObject* asset = UPandaUtils::CreateAsset(uts);
	if (asset)
	{
		UStaticMesh* StaticMesh = CastChecked<UStaticMesh>(asset);
		UStaticMeshComponent* StaticMeshComponent = itemMesh->GetStaticMeshComponent();
		StaticMeshComponent->UnregisterComponent();
		StaticMeshComponent->SetStaticMesh(StaticMesh);
		StaticMeshComponent->RegisterComponent();
		return itemMesh;
	}

	return nullptr;
}
//================UitemManager=================
UItemManager::UItemManager()
{
	m_cretaeId = 100;
}
bool UItemManager::init()
{
	m_items.Empty();
	m_selWeapons.Empty();
	DataManager* itemM = UPandaGameInstance::Instance()->SafeGetDataManager();
	loadItems(itemM);

	m_useWeapon = 0;
	return true;
}

UItem* UItemManager::getItemById(int id)
{
	for (UItem* temItem : m_items)
	{
		if (temItem->getItemId() == id)
		{
			return temItem;
		}
	}
	return nullptr;
}
void UItemManager::removeItemById(int id)
{
	for (UItem* temItem : m_items)
	{
		if (temItem->getItemId() == id)
		{
			m_items.Remove(temItem);
			game_ItemInfo itemInfo;
			itemInfo.set_mid(eMsg::MSG_CZ_REMOVE_ITEM);
			itemInfo.set_itemid(id);
			PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, itemInfo);
			return;
		}
	}
}

TArray<UItem*> UItemManager::getItemsByType(TArray<UItem*>& temArr,TEnumAsByte<enum emItemTypeDefine> itemTye)
{
	for (UItem* temItem : m_items)
	{
		if (temItem->getItemType() == itemTye)
		{
			temArr.Push(temItem);
		}
	}
	return temArr;
}

UObject * UItemManager::GetEKObject(const FString&  fsPath)
{
	FStringAssetReference ref = fsPath;
	UObject* uoTmp = ref.ResolveObject();
	if (uoTmp == nullptr)
	{
		FStreamableManager EKAssetLoader;

		uoTmp = EKAssetLoader.SynchronousLoad(ref);
	}
	return uoTmp;
}
void UItemManager::synItems(game_itemInfos& img)
{
	DataManager* dataM = UPandaGameInstance::Instance()->SafeGetDataManager();
	m_items.Empty();
	for (int i = 0; i < img.iteminfos().size(); i++)
	{
		int itemId = img.iteminfos(i).itemid();
		int dataItemId = img.iteminfos(i).itemdataid();
		
		UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), i), RF_MarkAsRootSet);
		obj->m_LocResItem = dataM->getItemLocInfo(dataItemId);
		m_items.Add(obj);
		obj->m_id = itemId;
	}
}
void UItemManager::loadItems(DataManager* dataM)
{
// 	for (int i = 20; i < 35; i++)
// 	{
// 		UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), i), RF_MarkAsRootSet);
// 		obj->m_LocResItem = dataM->getItemLocInfo(2);
// 		m_items.Add(obj);
// 		obj->m_id = i;
// 		
// 	}
// 
// 	for (int i = 35; i < 40; i++)
// 	{
// 		UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), i), RF_MarkAsRootSet);
// 		obj->m_LocResItem = dataM->getItemLocInfo(3);
// 		m_items.Add(obj);
// 		obj->m_id = i;
// 
// 	}
	//����
	for (int i = 40; i < 41; i++)
	{
		UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), i), RF_MarkAsRootSet);
		obj->m_LocResItem = dataM->getItemLocInfo(4);
		m_items.Add(obj);
		obj->m_id = i;

	}

	for (int i = 41; i < 42; i++)
	{
		UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), i), RF_MarkAsRootSet);
		obj->m_LocResItem = dataM->getItemLocInfo(5);
		m_items.Add(obj);
		obj->m_id = i;

	}
	m_selWeapons.Add(1);
	m_selWeapons.Add(5);
}
UItem* UItemManager::addItem()
{
	DataManager* dataM = UPandaGameInstance::Instance()->SafeGetDataManager();
	int createId = createItemId();
	UItem*  obj = NewObject<UItem>(this, *FString::Printf(TEXT("Item%d"), createId), RF_MarkAsRootSet);
	obj->m_LocResItem = dataM->getItemLocInfo(1);
	m_items.Add(obj);
	obj->m_id = createId;

	return obj;
}
int UItemManager::createItemId()
{
	return m_cretaeId += 1;

}

int UItemManager::getUseWeapon()
{
	return m_useWeapon;
}
void UItemManager::setUseWeapon(int id)
{
	m_useWeapon = id;
}

UItem* UItemManager::getWeaponByIdx(int idx)
{
	if (m_selWeapons.Num() > idx)
	{
		int itemId = m_selWeapons[idx];
		return getItemById(itemId);
	}
	return nullptr;
}