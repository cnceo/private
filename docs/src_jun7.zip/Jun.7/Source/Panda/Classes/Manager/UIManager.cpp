// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "UIManager.h"
#include "PandaUtils.h"
#include "PandaGameInstance.h"


void UIManager::Init()
{
	//OpenUMGAsset(UMGAssetPath_AcceptTask);
}

UUserWidget* UIManager::OpenUMGAsset(FString AssetPath)
{
	FStringAssetReference StringRef = AssetPath;

	//check cache
	auto checkRet = FindInWidgetCache(AssetPath);
	if (checkRet != nullptr)
	{
		checkRet->SetVisibility(ESlateVisibility::Visible);
		if (checkRet->IsInViewport())
		{
			return checkRet;
		}
		checkRet->AddToViewport();
		return checkRet;
	}

	return CreateFromAsset(StringRef);
	//{
		//AsynLoad
		//StreamableManager.RequestAsyncLoad(StringRef, FStreamableDelegate::CreateUObject(this, &UIManager::OnAsynLoadNotify, StringRef));
	//}

}

void UIManager::CloseUMGAsset(FString AssetPath, bool bDestory)
{
	auto ret = FindInWidgetCache(AssetPath);

	if (ret != nullptr)
	{
		ret->RemoveFromViewport();
		ret->SetVisibility(ESlateVisibility::Hidden);
		if (bDestory)
		{
			m_PandaWidgetCache.Remove(ret);
			ret->ConditionalBeginDestroy();			
		}
	}

}

UPandaWidget* UIManager::CreateFromAsset(FStringAssetReference StringRef)
{
	UPandaWidget* bResult = nullptr;

	UObject* inObject = UPandaUtils::CreateAsset(StringRef.ToString());
	if (inObject)
	{
		UPandaWidget* obj = CreateWidget<UPandaWidget>(GGameInstance, Cast<UClass>(inObject));
		if (obj)
		{
			obj->m_AssetPath = StringRef.ToString();
			m_PandaWidgetCache.Add(obj);
			obj->SetVisibility(ESlateVisibility::Visible);
			obj->AddToViewport();
		}

		bResult = obj;
	}

	return bResult;
}

UUserWidget* UIManager::CreateChildUI(FString AssetPath)
{
	FStringAssetReference ref = AssetPath;
	UObject* uoTmp = UPandaUtils::CreateAsset(ref.ToString());
	if (uoTmp)
	{
		UUserWidget* obj = CreateWidget<UUserWidget>(GGameInstance, Cast<UClass>(uoTmp));
		if (obj)
		{
			int32 nNum = m_UserWidgetCache.Num();
			m_UserWidgetCache.Add(nNum, obj);
		}
		return obj;
	}

	return nullptr;
}

void UIManager::OnAsynLoadNotify(FStringAssetReference StringRef)
{
	CreateFromAsset(StringRef);
}

UPandaWidget* UIManager::FindInWidgetCache(FString AssetPath)
{

	if (m_PandaWidgetCache.Num() == 0)
		return nullptr;

	UPandaWidget* ppWidget = nullptr;
	//UPandaWidget** ppWidget = m_PandaWidgetCache.FindByPredicate(
	//	[&](const UPandaWidget* widget)
	//{
	//	if (widget == nullptr)
	//	{
	//		m_PandaWidgetCache.Remove(**widget);
	//		return nullptr;
	//	}
	//	return widget->m_AssetPath == AssetPath;
	//}
	//);
	for (auto var : m_PandaWidgetCache)
	{
		if (var)
		{
			if(var->m_AssetPath == AssetPath)
				ppWidget = var;
		}
		else
		{
			m_PandaWidgetCache.Remove(var);
		}
	}


	return ppWidget;
}
