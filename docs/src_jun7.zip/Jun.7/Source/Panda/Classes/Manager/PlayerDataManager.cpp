#include "panda.h"
#include "PlayerDataManager.h"
#include <string>
#include <stdio.h>
#include <time.h>
#include "OthersCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "PandaUtils.h"
#include "MainPlayerController.h"
#include "UMGPanel.h"
#include "EKGameFrame.h"
#include "Team/TeamManager.h"
#include "PAWidget_Team_CreateTeam.h"
#include "PAWidget_Team_IntoPrompt.h"
#include "PAWidget_Team_MemberOperation.h"
#include "PAWidget_Team_TeamList.h"
#include "PAWidget_Team_MemberList.h"
#include "PAWidget_Team_InviteList.h"
#include "PAWidget_Team_JoinList.h"
#include "PAWidget_Dungeon_SelectRegion.h"
#include "PAWidget_Dungeon_Chapter.h"

static FPlayerDataManager *s_pSharedFPlayerDataManager = NULL;

FPlayerDataManager::FPlayerDataManager()
	: m_bLogPrint(true)
{

}

FPlayerDataManager::~FPlayerDataManager()
{

}

bool FPlayerDataManager::Init()
{
	setLogPrint(true);
	m_FsPAPlayerInfoList.players.clear();

	return true;
}

FPlayerDataManager * FPlayerDataManager::Instance()
{
	if (!s_pSharedFPlayerDataManager)
	{
		s_pSharedFPlayerDataManager = new FPlayerDataManager();
		s_pSharedFPlayerDataManager->Init();
	}

	return s_pSharedFPlayerDataManager;
}

void FPlayerDataManager::purgedFPlayerDataManager()
{
	//CC_SAFE_RELEASE_NULL(s_pSharedFPlayerDataManager);
}

int32 FPlayerDataManager::getPlayerLevel()
{
	return m_PlayerInfoData.level;
}

void FPlayerDataManager::setPlayerLevel(int32 nLevel)
{
	m_PlayerInfoData.level = nLevel;
}

/* get and set Martialclub ID */
int32 FPlayerDataManager::getMartialclubID()
{
	return m_PlayerInfoData.MartialclubID;
}

void FPlayerDataManager::setMartialclubID(int32 nID)
{
	m_PlayerInfoData.MartialclubID = nID;
}

int32 FPlayerDataManager::getPlayerExp()
{
	return m_PlayerInfoData.exp;
}

void FPlayerDataManager::setPlayerExp(int32 nExp)
{
	m_PlayerInfoData.exp = nExp;
}

/* get and set player exp */
int32 FPlayerDataManager::getPlayerGold()
{
	return m_PlayerInfoData.gold;
}

void FPlayerDataManager::setPlayerGold(int32 nGold)
{
	m_PlayerInfoData.gold = nGold;
}

void FPlayerDataManager::addPlayerGold(int32 nGold)
{
	m_PlayerInfoData.gold += nGold;
}

int32 FPlayerDataManager::getPlayerEnergy()
{
	return m_PlayerInfoData.energy;
}

void FPlayerDataManager::setPlayerEnergy(int32 nEnergy)
{
	m_PlayerInfoData.energy = nEnergy;
}

/* get and set player Task */
TArray<int32>& FPlayerDataManager::getFinishTaskContainer()
{
	return m_PlayerInfoData.m_FinishTaskContainer;
}
void FPlayerDataManager::setFinishTaskContainer(TArray<int32>& inFinishTaskContainer)
{
	m_PlayerInfoData.m_FinishTaskContainer = inFinishTaskContainer;
}

/* get and set player Task */
TMap<int32, UTask*>& FPlayerDataManager::getCurrentTaskContainer()
{
	return m_PlayerInfoData.m_CurrentTaskContainer;
}

void FPlayerDataManager::setCurrentTaskContainer(TMap<int32, UTask*>& inCurrentTaskContainer)
{
	m_PlayerInfoData.m_CurrentTaskContainer = inCurrentTaskContainer;
}

void FPlayerDataManager::setPlayerInfoUid(FString uid)
{
	m_PlayerInfoData.uid = uid;
}

/* get user id */
const char* FPlayerDataManager::getuid(){
	if(_uid.empty()){
		char buf[64];
		sprintf_s(buf,"%zd",keye::ticker());
		//sprintf_s(buf,"%zd",(size_t)time(nullptr));
		_uid=buf;
	}
	return _uid.c_str();
	return TCHAR_TO_ANSI(*FPlatformMisc::GetUniqueDeviceId());
}

// ֱ�����������������,���ʼ����ո�����
void FPlayerDataManager::setPlayerInfoList(MsgZCSyncPlayers imsg)
{
	//m_FsPAPlayerInfoList.players.clear();
	for (int i = 0;i < imsg.players_size();++i)
	{
		auto& player = imsg.players().Get(i);
		m_FsPAPlayerInfoList.players[player.uid()].CopyFrom(player);
	}

	UE_LOG(LogTemp, Log, TEXT("-------- setPlayerInfoList's m_FsPAPlayerInfoList.players.size() =%d"), m_FsPAPlayerInfoList.players.size());
}

// ֱ������һ��������ݵ�������
void FPlayerDataManager::addPlayerInfoList(MsgZCBroadcastPlayer imsg)
{
	auto player = imsg.player();
	//it = m_FsPAPlayerInfoList.players.find(player.uid());
	m_FsPAPlayerInfoList.players[player.uid()].CopyFrom(player);
	
	setForceToRefresh(true);
	setNewFreshData(player);

	//auto CurrentPlayerCounts = m_FsPAPlayerInfoList.players.size();
	//TArray<AActor*> OutActors;
	//UGameplayStatics::GetAllActorsOfClass(GGameInstance, AOthersCharacter::StaticClass(), OutActors);
	//if (OutActors.GetData() == NULL) return;
	//auto WorldActorsCounts = OutActors.Num();
	//if (WorldActorsCounts != 0)
	//{
	//	for (TArray<AActor*>::TConstIterator It(OutActors); It; ++It)
	//	{
	//		AOthersCharacter* actor = Cast<AOthersCharacter>(*It);
	//		if (actor)
	//		{
	//			if (strcmp(actor->getPlayerInfo().uid().c_str(), player.uid().c_str()) == 0)
	//			{
	//				actor->setPlayerInfo(player);
	//			}
	//		}
	//	}
	//}

	UE_LOG(LogTemp, Log, TEXT("-------- addPlayerInfoList's m_FsPAPlayerInfoList.players.size() =%d"), m_FsPAPlayerInfoList.players.size());
}

// ɾ��һ���û���������е����������, ����userid
void FPlayerDataManager::removePlayerInfoList(MsgZCExit imsg)
{
	auto uid = imsg.player().uid();
	it = m_FsPAPlayerInfoList.players.find(uid);
	if (it != m_FsPAPlayerInfoList.players.end())
	{
		m_FsPAPlayerInfoList.players.erase(it);
	}

	/*auto& player = imsg.player();
	m_FsPAPlayerInfoList.players[m_FsPAPlayerInfoList.players.size()].CopyFrom(player);

	UE_LOG(LogTemp, Log, TEXT("-------- addPlayerInfoList's m_FsPAPlayerInfoList.players.size() =%d"), m_FsPAPlayerInfoList.players.size());*/
}

// ��ȡ�û������б�
FsPAPlayerInfoList FPlayerDataManager::getPlayerInfoList()
{
	return m_FsPAPlayerInfoList;
}

// ����ȫ���Ķ����б�,����ǰ���������
void FPlayerDataManager::setTeamList(MsgZCTeamBroadcast imsg)
{
	m_FsPATeamList.team.clear();
	for (int i = 0;i < imsg.team_size();++i)
	{
		// ��ǰ�� single_team
		auto& team = imsg.team().Get(i);
		m_FsPATeamList.team[i].CopyFrom(team);

		// ͬ���Լ���TeamInfo
		if (team.uid() == getuid())
		{
			setTeamInfo(team);
		}		
	}
}

// ��ȡȫ���Ķ����б�
FsPATeamList FPlayerDataManager::getTeamList()
{
	return m_FsPATeamList;
}

void FPlayerDataManager::setTeamInfo(proto3::TeamInfo ti)
{
	// First to close all in the viewReport ui, and second show need to show ui
	auto panel_1 = Cast<UPAWidget_Team_CreateTeam>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_CREATE));
	if (panel_1)
		panel_1->CloseSelf(true);

	auto panel_2 = Cast<UPAWidget_Team_IntoPrompt>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_TeamIntoPrompt));
	if (panel_2)
		panel_2->CloseSelf(true);

	auto panel_3 = Cast<UPAWidget_Team_MemberOperation>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_TeamMemberOperation));
	if (panel_3)
		panel_3->CloseSelf(true);

	auto panel_4 = Cast<UPAWidget_Team_TeamList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_LIST));
	if (panel_4)
		panel_4->CloseSelf(true);

	auto panel_5 = Cast<UPAWidget_Team_MemberList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_TEAM_MEMBER_LIST));
	if (panel_5)
		panel_5->CloseSelf(true);

	auto panel_6 = Cast<UPAWidget_Dungeon_Chapter>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_ACT));
	if (panel_6)
		panel_6->CloseSelf(true);

	auto panel_7 = Cast<UPAWidget_Dungeon_SelectRegion>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_SelectRegion));
	if (panel_7)
		panel_7->CloseSelf(true);

	auto panel_8 = Cast<UPAWidget_Team_JoinList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Team_JoinList));
	if (panel_8)
		panel_8->CloseSelf(true);

	auto panel_9 = Cast<UPAWidget_Team_InviteList>(GGameInstance->SafeGetUIManager()->FindInWidgetCache(UI_Dungeon_InviteList));
	if (panel_9)
		panel_9->CloseSelf(true);

	const FString str = TEXT("�Լ��Ķ��鷢���仯,�밴��End���鿴�Լ��Ķ����б�!!!");
	GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
	m_TeamInfo.CopyFrom(ti);

	// �������Ϣ���غ�,�����Լ���״̬����.��GameThread�ڵ���һ֡��������
	// When the team create successed, show self team member's UI, and refresh others head ui icon. logic begin.
	FTeamDataManager::Instance()->setTeamState(TEAM_SERVER_RETURN_STATE::SUB_STATE_UPDATE);
}