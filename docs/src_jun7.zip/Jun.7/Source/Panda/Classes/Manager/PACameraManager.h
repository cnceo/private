// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Object.h"
#include "PACameraManager.generated.h"

/**
 * 
 */
UENUM(BlueprintType)
enum class emCameraEffType : uint8
{
	JingXiangMoHu = 1,//��ͷģ��
	ManJingTou,//��ͷ����
	DouDong, //��ͷ����
	BianSe,//��ͷ��ɫ

};
enum class emCameraAnimType : uint8
{
	camerAnim_LuoHanQuan,//��ͷ����
};

UCLASS()
class PANDA_API UPACameraEffInstance : public UObject
{
	GENERATED_BODY()
public:
	virtual void startCameraEff() {};
	virtual void endCamerEff() {};
	int m_effId;
	FTimerHandle m_TimerHandle;
};

//��ͷ������Ч
UCLASS()
class PANDA_API UPACameraEff : public UPACameraEffInstance
{
	GENERATED_BODY()
public:
	UPACameraEff();
	virtual void startCameraEff() override;
	virtual void endCamerEff() override;
protected:
public:

};

//����ͷ
UCLASS()
class PANDA_API UPACameraManJingTou : public UPACameraEffInstance
{
	GENERATED_BODY()
public:
	UPACameraManJingTou();
	virtual void startCameraEff() override;
	virtual void endCamerEff() override;
protected:
public:
};

//��ͷ����
UCLASS()
class PANDA_API UPACameraDouDong : public UPACameraEffInstance
{
	GENERATED_BODY()
public:
	UPACameraDouDong();
	virtual void startCameraEff() override;
	virtual void endCamerEff() override;
protected:
public:

};
UCLASS()
class PANDA_API UPACameraManager : public UObject
{
	GENERATED_BODY()
public:
	UPACameraManager();
	UFUNCTION(BlueprintCallable, Category = "CameraAnimNotifyState")
	static UPACameraManager* GetCameraManagerInstance();
	//��������ͷ
	UFUNCTION(BlueprintCallable, Category = "CameraAnimNotifyState")
	void PlayTaskCameraAnim(USceneComponent* pCom);

	UFUNCTION(BlueprintCallable, Category = "CameraAnimNotifyState")
	void StopTaskCameraAnim(USceneComponent* pCom);

	//����id���ž�ͷ����
	UFUNCTION(BlueprintCallable, Category = "CameraAnimNotifyState")
	void PlayLocCameraAnim(int id);

	//����id���ž�ͷ��Ч
	UFUNCTION(BlueprintCallable, Category = "CameraAnimNotifyState")
	void PlayLocCameraEff(int id, bool isOpen, float delayed = 0.f);
	void PreLoad();

	void removeCameraEff(int id);
private: 
	UPACameraEff*  m_CameraEff;
	UPACameraDouDong* m_CameraDouDong;
	UPACameraManJingTou* m_CameraManJingTou;

	float BlurRadius;
};
