//
//  DataManager.h
//  demo003
//
//  Created by White.tian on 16-2-2.
//  Copyright (c) 2016年 White.tian All rights reserved.
//

#ifndef __APPRESDEFINE__
#define __APPRESDEFINE__

//#pragma mark - ===============================================================
//#pragma mark - ============================conf加载============================
//#pragma mark - ===============================================================

#define  MakeTablePath(ContentDir,TablePath)  FString((ContentDir) + (TablePath))

#define CONF_STRINGTABLE "Conf/StringTable.json"
#define CONF_RESOURCESTABLE "Conf/ResourcesTable.json"
#define CONF_SampleTask "Conf/task1.json"
#define CONF_MONSTERHEROBASEDATA "Conf/MonsterHeroBaseData.json"
#define CONF_USERHEROBASEDATA "Conf/UserHeroBaseData.json"
#define CONF_USERUPGRADEDATA "Conf/UserUpgrade.json"
#define CONF_NPCBASEDATA "Conf/NpcBaseData.json"
#define CONF_ATOMEFFECTTABLE "Conf/AtomEffectTable.json"
#define CONF_ATOMEXTENDTABLE "Conf/AtomExtendTable.json"
#define CONF_ATOMHITTABLE "Conf/AtomHitTable.json"
#define CONF_ATOMCHASETABLE "Conf/AtomChaseTable.json"
#define CONF_ATOMBULLETTABLE "Conf/AtomBulletTable.json"
#define CONF_ATOMBULLETSHAPETABLE "Conf/AtomBulletShapeTable.json"
#define CONF_SKILLTTABLE "Conf/SkillTable.json"
#define CONF_ITEM "Conf/item.json"
#define CONF_MARTIALCLUB "Conf/Martialclub.json"
#define CONF_CAMERAEFF "Conf/camerEff.json"

#define CONF_CENTERAREADATA "Conf/centerArea.json"
#define CONF_CHAPTERDATA "Conf/dungeon_group.json"
#define CONF_STAGEDATA "Conf/dungeon.json"
#define CONF_STAGELOOTREWARDDATA "Conf/dungeon_collect.json"
#define CONF_STAGEMONSTERPOSITIONDATA "Conf/dungeon_monster.json"

#define CONF_TablePath_TaskInfo	"Conf/TaskData.json"

/* UI DEFINE */
#define UI_TEAM_OtherHeadIcon TEXT("/Game/UI/UMG/Team/Team_OtherHeadIcon.Team_OtherHeadIcon_C")
#define UI_TEAM_CREATE TEXT("/Game/UI/UMG/Team/CreateTeam.CreateTeam_C")
#define UI_TEAM_TeamIntoPrompt TEXT("/Game/UI/UMG/Team/TeamIntoPrompt.TeamIntoPrompt_C")
#define UI_TEAM_TeamMemberOperation TEXT("/Game/UI/UMG/Team/TeamMemberOperation.TeamMemberOperation_C")
#define UI_TEAM_CREATE_CELL TEXT("/Game/UI/UMG/Team/CreateTeamCell.CreateTeamCell_C")
#define UI_TEAM_LIST TEXT("/Game/UI/UMG/Team/TeamList.TeamList_C")
#define UI_TEAM_LIST_CELL TEXT("/Game/UI/UMG/Team/TeamListCell.TeamListCell_C")
#define UI_TEAM_MEMBER_LIST TEXT("/Game/UI/UMG/Team/TeamMemberList.TeamMemberList_C")
#define UI_TEAM_MEMBER_LIST_CELL TEXT("/Game/UI/UMG/Team/TeamMemberListCell.TeamMemberListCell_C")
#define UI_Dungeon_ACT TEXT("/Game/UI/UMG/Dungeon/ACT.ACT_C")
#define UI_Dungeon_SelectRegion TEXT("/Game/UI/UMG/Dungeon/SelectRegion.SelectRegion_C")
#define UI_Team_JoinList TEXT("/Game/UI/UMG/Team/TeamJoinList.TeamJoinList_C")
#define UI_Team_JoinList_Cell TEXT("/Game/UI/UMG/Team/TeamJoinListCell.TeamJoinListCell_C")
#define UI_Dungeon_InviteList TEXT("/Game/UI/UMG/Team/TeamInviteList.TeamInviteList_C")
#define UI_Dungeon_InviteList_Cell TEXT("/Game/UI/UMG/Team/TeamInviteListCell.TeamInviteListCell_C")

/* UI Resources Define */
#define UI_DIFFICULT_01 TEXT("/Game/UI/UMG_UI/Team/ui_dungeons_difficulty_01.ui_dungeons_difficulty_01")
#define UI_DIFFICULT_02 TEXT("/Game/UI/UMG_UI/Team/ui_dungeons_difficulty_02.ui_dungeons_difficulty_02")
#endif /*__APPRESDEFINE__*/