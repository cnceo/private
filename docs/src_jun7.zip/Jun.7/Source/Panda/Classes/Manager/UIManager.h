// Fill out your copyright notice in the Description page of Project Settings.
//************************************************************************
//* Desc. UMG asset management
//*
//* Created by ZP
//************************************************************************
#pragma once
#include "Object.h"
#include "PandaWidget.h"
#include "UIManager.generated.h"



enum UMGAssetName
{
	UAN_None,
	UAN_Max
};
/**
 *
 */
UCLASS()
class PANDA_API UIManager : public UObject
{
	GENERATED_BODY()
public:
	void Init();

public:
	// Asyn load asset from AssetPath
	UUserWidget* OpenUMGAsset(FString AssetPath);
	// Hidden specified Asset
	void CloseUMGAsset(FString AssetPath , bool bDestory = false );
	// Call this in openUMGAsset first
	UPandaWidget* FindInWidgetCache(FString AssetPath);
	// Create UI and return this
	UUserWidget* CreateChildUI(FString AssetPath);
private:
	UPandaWidget* CreateFromAsset(FStringAssetReference StringRef);
	//show asset 
	void OnAsynLoadNotify(FStringAssetReference StringRef);

public:
	UPROPERTY(transient)
	FStreamableManager	StreamableManager;

	UPROPERTY()
	TArray<UPandaWidget*>   m_PandaWidgetCache;

	/* �ӽڵ���Ҫʹ��UUserWidget���󴴽�,ʹ��UPandaWidget�ᰴ����ͻ. */
	UPROPERTY()
	TMap<int32, UUserWidget*>   m_UserWidgetCache;

};
