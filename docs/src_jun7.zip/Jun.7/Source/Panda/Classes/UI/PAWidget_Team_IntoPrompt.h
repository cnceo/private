// Fill out your copyright notice in the Description page of Project Settings.
//
//  PAWidget_Team_IntoPrompt.h
//  Panda
//  PA, When the team leader selected enter into dungeon, tips this ui to other(teams other)
//  Created by White.tian on 2016-05-24 21:58:40.
//  Copyright (c) 2016�� White.tian All rights reserved.
//

#pragma once

#include "UI/PandaWidget.h"
#include "PAWidget_Team_IntoPrompt.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API UPAWidget_Team_IntoPrompt : public UPandaWidget
{
	GENERATED_BODY()

public:

	/*
	*	Key Down
	*/
	virtual void NativeConstruct() override;
	virtual void UpdateSelf(float deltaTime) override;

	// Exit
	virtual void OnCross() override;
	// Create Team
	virtual void OnCircle() override;
	// Sure Edit
	virtual void OnTriangle() override;
	// left, right, up, down
	virtual void OnLeft() override;
	virtual void OnRight() override;
	virtual void OnUp() override;
	virtual void OnDown() override;

public:

	/*
	*	Data
	*/

	void Init();

	/* Init current inferface */
	void InitCurrentInterface();

public:

	/*
	*	����ʱ
	*/

	// text var desc
	UPROPERTY(EditAnywhere)
	int32 m_CountdownTime;

	void UpdateTimeDisplay();

	void AdvanceTimer();

	UFUNCTION(BlueprintNativeEvent)
	void CountdownHasFinished();
	virtual void CountdownHasFinished_Implementation();
	FTimerHandle CountdownTimerHandle;

	UFUNCTION(BlueprintNativeEvent)
	void CountdownReset();
	virtual void CountdownReset_Implementation();

	// ��ʱ���Ƿ����
	bool m_bTimerExist;

public:

	/*
	*	UI Controllers
	*/

	/* Parse UI Controllers */
	void ParseUIControllers();

	// ���½ǵİ�����ʾ_ͼƬ
	UImage* Image_KeyTips;

	// ����ͼƬ�׿�_ͼƬ
	UImage* Image_background_1;

	// ��ǰ�ĸ�����ͼƬ_ͼƬ
	UImage* Image_background_dungeon;

	// ����ʱ_�ı�
	UTextBlock* TextBlock_Time;

	// �ӳ������˸�������_�ı�
	UTextBlock* TextBlock_Tips_1;

	// ��������_�ı�
	UTextBlock* TextBlock_DungeonName;

	// �Ƿ����һ�����?_�ı�
	UTextBlock* TextBlock_Tips_2;
};