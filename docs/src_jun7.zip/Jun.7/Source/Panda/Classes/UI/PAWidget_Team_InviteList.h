// Fill out your copyright notice in the Description page of Project Settings.
//
//  PAWidget_Team_JoinList.h
//  Panda
//  PA current join list
//  Created by White.tian on 2016-05-27 23:03:01.
//  Copyright (c) 2016�� White.tian All rights reserved.
//

#pragma once

#include "UI/PandaWidget.h"
#include "PAWidget_Team_InviteList.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API UPAWidget_Team_InviteList : public UPandaWidget
{
	GENERATED_BODY()
	
public:

	/*
	*	Key Down
	*/
	virtual void NativeConstruct() override;
	virtual void UpdateSelf(float deltaTime) override;

	// Exit
	virtual void OnCross() override;
	// Send add current selected team message to server
	virtual void OnCircle() override;
	// Open create team interface
	virtual void OnTriangle() override;
	// left, right, up, down
	virtual void OnLeft() override;
	virtual void OnRight() override;
	virtual void OnUp() override;
	virtual void OnDown() override;

public:

	/*
	*	UI Controllers
	*/

	/* Parse UI Controllers */
	void ParseUIControllers();

	// ����ͼƬ_ͼƬ
	UImage* Image_background_1;

	// ������ʾ_ͼƬ
	UImage* Image_KeyTips;

	// ���Լ���Ķ����б�
	UScrollBox* ScrollBox_RegionList_Left;

	// �������ƺ͸����Ѷȵذ�_ͼƬ
	UImage* Image_Base;

	// ��������_�ı�
	UTextBlock* TextBlock_DungeonName;

	// �����Ѷ�_�ı�
	UTextBlock* TextBlock_DifficultyLevel;
};