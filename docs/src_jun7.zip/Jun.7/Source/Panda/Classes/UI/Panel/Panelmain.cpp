// Copyright 1998-2014 xishanju Games, Inc. All Rights Reserved.

#include "panda.h"
#include "PanelMain.h"
#include "EKGameFrame.h"
#include "PandaGameInstance.h"
#include "PlayerDataManager.h"


FPanelMain::FPanelMain()
{

}

FPanelMain::~FPanelMain()
{

}


bool FPanelMain::BreakToLogin()
{
	return false;
}

void FPanelMain::UpdateOtherPlayerInfo()
{
	// Before Add, first to remove all child.
	InitPlayerProperty();

	auto ti = FPlayerDataManager::Instance()->getTeamInfo();
	auto otherSize = ti.members_size();
	//if (otherSize >= 1)
	//{
	//	// ��ȥ�Լ�
	//	otherSize = otherSize - 1;
	//}

	for (int i = 0; i < otherSize; i++)
	{
		auto single_member = ti.members(i);
		auto cell = GGameInstance->SafeGetUIManager()->CreateChildUI(UI_TEAM_OtherHeadIcon);

		UCanvasPanel* PlayerInfoPanel = nullptr;
		UProgressBar* HPBar = nullptr;
		UProgressBar* MPBar = nullptr;
		UImage* HeadIcon = nullptr;
		UTextBlock* PlayerName = nullptr;
		UTextBlock* PlayerLevel = nullptr;
		UTextBlock* HP = nullptr;
		UTextBlock* MaxHP = nullptr;
		UTextBlock* MP = nullptr;
		UTextBlock* MaxMP = nullptr;
		UImage* Image_Leader = nullptr;


		TArray<UWidget*> WidgetList;
		cell->WidgetTree->GetAllWidgets(WidgetList);
		for (UWidget* Widget : WidgetList)
		{
			if (Widget->GetName() == "PlayerIconInfo")
			{
				PlayerInfoPanel = Cast<UCanvasPanel>(Widget);
			}
			if (Widget->GetName() == "HPBar")
			{
				HPBar = Cast<UProgressBar>(Widget);
			}
			if (Widget->GetName() == "MPBar")
			{
				MPBar = Cast<UProgressBar>(Widget);
			}
			if (Widget->GetName() == "Player_HeadIcon")
			{
				HeadIcon = Cast<UImage>(Widget);
			}
			if (Widget->GetName() == "PlayerName")
			{
				PlayerName = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "PlayerLevel")
			{
				PlayerLevel = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "Text_HP")
			{
				HP = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "Text_MaxHP")
			{
				MaxHP = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "Text_MP")
			{
				MP = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "Text_MaxMP")
			{
				MaxMP = Cast<UTextBlock>(Widget);
			}
			if (Widget->GetName() == "Image_Leader")
			{
				Image_Leader = Cast<UImage>(Widget);
			}
		}

		if (i == 0 && CanvasPanel_Other_1)
		{
			auto a = CanvasPanel_Other_1->AddChildToCanvas(cell);
			a->SetAutoSize(true);
		}
		if (i == 1 && CanvasPanel_Other_2)
		{
			auto a = CanvasPanel_Other_2->AddChildToCanvas(cell);
			a->SetAutoSize(true);
		}
		if (i == 2 && CanvasPanel_Other_3)
		{
			auto a = CanvasPanel_Other_3->AddChildToCanvas(cell);
			a->SetAutoSize(true);
		}
		if (i == 3 && CanvasPanel_Other_4)
		{
			auto a = CanvasPanel_Other_4->AddChildToCanvas(cell);
			a->SetAutoSize(true);
		}

		// ֻ�жӳ��Ż���ʾ�ӳ���ʶ
		if (i == 0)
		{
			if (Image_Leader)
			{
				Image_Leader->SetVisibility(ESlateVisibility::Visible);
			}
		}
		else {
			if (Image_Leader)
			{
				Image_Leader->SetVisibility(ESlateVisibility::Hidden);
			}
		}
		// �����������
		if (PlayerName)
		{
			PlayerName->SetText(FText::FromString(single_member.name().c_str()));
		}

		if (HP)
		{
			HP->SetText(FText::FromString(*FString::Printf(TEXT("%d"), (int32)(single_member.hp()))));
		}
		if (MaxHP)
		{
			MaxHP->SetText(FText::FromString(*FString::Printf(TEXT("%d"), (int32)(single_member.maxhp()))));
		}
		if (MP)
		{
			MP->SetText(FText::FromString(*FString::Printf(TEXT("%d"), (int32)(single_member.mp()))));
		}
		if (MaxMP)
		{
			MaxMP->SetText(FText::FromString(*FString::Printf(TEXT("%d"), (int32)(single_member.maxmp()))));
		}
	}

	// update interface


}

void FPanelMain::UpdatePlayerLevel()
{
	if (PlayerLevel)
	{
		FsPAPlayerInfo playerInfo = FPlayerDataManager::Instance()->getPlayerInfo();

		PlayerLevel->Text = FText::FromString(FString::FromInt(playerInfo.level));
		PlayerLevel->SynchronizeProperties();	
	}
}

void FPanelMain::Init()
{
	TArray<UWidget*> WidgetList;
	Window->WidgetTree->GetAllWidgets(WidgetList);
	for (UWidget* Widget : WidgetList)
	{
		if (Widget->GetName() == "PlayerIconInfo")
		{
			PlayerInfoPanel = Cast<UCanvasPanel>(Widget);
		}
		if (Widget->GetName() == "HPBar")
		{
			HPBar = Cast<UProgressBar>(Widget);
		}
		if (Widget->GetName() == "MPBar")
		{
			MPBar = Cast<UProgressBar>(Widget);
		}
		if (Widget->GetName() == "Player_HeadIcon")
		{
			HeadIcon = Cast<UImage>(Widget);
		}
		if (Widget->GetName() == "PlayerName")
		{
			PlayerName = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "PlayerLevel")
		{
			PlayerLevel = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "Text_HP")
		{ 
			HP = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "Text_MaxHP")
		{
			MaxHP = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "Text_MP")
		{
			MP = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "Text_MaxMP")
		{
			MaxMP = Cast<UTextBlock>(Widget);
		}
		if (Widget->GetName() == "CanvasPanel_Other_1")
		{
			CanvasPanel_Other_1 = Cast<UCanvasPanel>(Widget);
		}
		if (Widget->GetName() == "CanvasPanel_Other_2")
		{
			CanvasPanel_Other_2 = Cast<UCanvasPanel>(Widget);
		}
		if (Widget->GetName() == "CanvasPanel_Other_3")
		{
			CanvasPanel_Other_3 = Cast<UCanvasPanel>(Widget);
		}
		if (Widget->GetName() == "CanvasPanel_Other_4")
		{
			CanvasPanel_Other_4 = Cast<UCanvasPanel>(Widget);
		}
	}

	InitPlayerProperty();
}

void FPanelMain::InitOtherPlayerProperty()
{

	if (CanvasPanel_Other_1)
	{
		if (CanvasPanel_Other_1->GetChildAt(0))
		{
			CanvasPanel_Other_1->RemoveChildAt(0);
		}
	}
	if (CanvasPanel_Other_2)
	{
		if (CanvasPanel_Other_2->GetChildAt(0))
		{
			CanvasPanel_Other_2->RemoveChildAt(0);
		}
	}
	if (CanvasPanel_Other_3)
	{
		if (CanvasPanel_Other_3->GetChildAt(0))
		{
			CanvasPanel_Other_3->RemoveChildAt(0);
		}
	}
	if (CanvasPanel_Other_4)
	{
		if (CanvasPanel_Other_4->GetChildAt(0))
		{
			CanvasPanel_Other_4->RemoveChildAt(0);
		}
	}
}

void FPanelMain::InitPlayerProperty()
{
	FsPAPlayerInfo playerInfo = FPlayerDataManager::Instance()->getPlayerInfo();

	if (MaxHP)
	{
		MaxHP->Text = FText::FromString(FString::FromInt(playerInfo.MaxHP));
		MaxHP->SynchronizeProperties();
	}
	if (MaxMP)
	{
		MaxMP->Text = FText::FromString(FString::FromInt(playerInfo.MaxMP));
		MaxMP->SynchronizeProperties();
	}
	if (HP)
	{
		HP->Text = FText::FromString(FString::FromInt(playerInfo.HP));
		HP->SynchronizeProperties();
	}
	if (MP)
	{
		MP->Text = FText::FromString(FString::FromInt(playerInfo.MP));
		MP->SynchronizeProperties();
	}
	if (PlayerLevel)
	{
		PlayerLevel->Text = FText::FromString(FString::FromInt(playerInfo.level));
		PlayerLevel->SynchronizeProperties();
	}
	if (PlayerName)
	{
		PlayerName->Text = FText::FromString(playerInfo.name);
		PlayerName->SynchronizeProperties();
	}
	if (HPBar)
	{
		HPBar->SetPercent(1);
		HPBar->SynchronizeProperties();
	}
	if (MPBar)
	{
		MPBar->SetPercent(1);
		MPBar->SynchronizeProperties();
	}

	InitOtherPlayerProperty();

	PlayerInfoPanel->SynchronizeProperties();
}