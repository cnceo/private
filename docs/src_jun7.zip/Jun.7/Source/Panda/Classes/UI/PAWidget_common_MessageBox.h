// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include <functional>
#include "UI/PandaWidget.h"
#include "PAWidget_common_MessageBox.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API UPAWidget_common_MessageBox : public UPandaWidget
{
	GENERATED_BODY()
public:
	
	virtual void NativeConstruct() override;

 	void setCallBack(std::function<void(int)>callBack);

	UFUNCTION(BlueprintCallable, Category = "common_MessageBox")
	void selCallBack(int idx);

private:
	UButton* m_confirm;
	UButton* m_cancel;
	std::function<void(int)> messageCallBack;
};
