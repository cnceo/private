// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#pragma  once

#include "EKHUD.h"
#include "PandaHUD.generated.h"

//USTRUCT()
struct FHarm
{

	FHarm() : HarmVula(0), ElapseTime(0), actor(nullptr) {}

	float HarmVula;
	float ElapseTime;
	class AActor* actor;
};


UCLASS()
class PANDA_API APandaHUD : public AEKHUD
{
	GENERATED_UCLASS_BODY()

public:

	UMaterial* HealthDynamicMaterial;
	UMaterial* StarMat;

	TArray<FHarm> HarmList;

	UPROPERTY()
	TArray<UMaterialInstanceDynamic*>  HealthDynamicMaterialList;

	/** Main HUD update loop. */
	virtual void DrawHUD() override;

	virtual void BeginPlay() override;
	/**
	 * Sent from pawn hit, used to calculate hit notification overlay for drawing.
	 *
	 * @param	DamageTaken		The amount of damage.
	 * @param	DamageEvent		The actual damage event.
	 * @param	PawnInstigator	The pawn that did the damage.
	 */
	//void NotifyHit(float DamageTaken, struct FDamageEvent const& DamageEvent, class APawn* PawnInstigator);

	/** Sent from ShooterWeapon, shows NO AMMO text. */
	void NotifyOutOfAmmo();

	/** Notifies we have hit the enemy. */
	void NotifyEnemyHit();

	/** Called every time game is started. */
	virtual void PostInitializeComponents() override;

	/** 
	 * Converts floating point seconds to MM:SS string.
	 *
	 * @param TimeSeconds		The time to get a string for.
	 */
	FString GetTimeString(float TimeSeconds);

	void AddHarm(FHarm& inInfo);

	/** Draw death messages. */
	void DrawDeathMessages();

	/** Temporary helper for drawing text-in-a-box. */
	void DrawDebugInfoString(const FString& Text, float PosX, float PosY, bool bAlignLeft, bool bAlignTop, const FColor& TextColor);

	/** helper for getting uv coords in normalized top,left, bottom, right format */
	void MakeUV(FCanvasIcon& Icon, FVector2D& UV0, FVector2D& UV1, uint16 U, uint16 V, uint16 UL, uint16 VL);

	/*
	 * Create the chat widget if it doesn't already exist.
	 *
	 * @return		true if the widget was created.
	 */
	bool TryCreateChatWidget();

	/*
	 * Add information string that will be displayed on the hud. They are added as required and rendered together to prevent overlaps 
	 * 
	 * @param InInfoString	InInfoString
	*/
	void AddMatchInfoString(const FCanvasTextItem InfoItem);

	/*
	* Render the info messages.
	*
	* @param YOffset	YOffset from top of canvas to start drawing the messages
	* @param ScaleUI	UI Scale factor
	* @param TextScale	Text scale factor
	*
	* @returns The next Y position to draw any further strings
	*/
	float ShowInfoItems(float YOffset, float ScaleUI, float TextScale);


	virtual void DrawLogo();
	virtual void DrawIcon();
	/** ��Ѫ�� */
	virtual void DrawHealth();
	/** ������ */
	virtual void DrawName();
	/** ����ͼ */
	virtual void DrawMap();
	/** ����ť */
	virtual void DrawButton(FVector2D inPostinon, FVector2D inSize);

	void ReceiveHitBoxClick(const FName BoxName);
};