// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "UI/PandaWidget.h"
#include "IDelegateInstance.h"
#include "Animation/SkeletalMeshActor.h"
#include "PandaWidget_OtheInfoMenu.generated.h"


/**
 * 
 */
UCLASS()
class PANDA_API UPandaWidget_OtheInfoMenu : public UPandaWidget
{
	GENERATED_BODY()
public:
	UPandaWidget_OtheInfoMenu();
	~UPandaWidget_OtheInfoMenu();
	virtual void NativeConstruct() override;
public:
	UFUNCTION()
		virtual void OnLeft()override;
	UFUNCTION()
		virtual void OnRight()override;
	UFUNCTION()
		virtual void OnUp()override;
	UFUNCTION()
		virtual void OnDown()override;
	UFUNCTION()
		virtual void OnCircle()override;
	UFUNCTION()
		virtual void OnBag() override;
public:
	void OpenSelPage();
	void SetSelIdx(int cidx);
	void PreLoadMap();
	void WaitTime();
	void DestroyFlag();
private:
	float m_WaitTime;
	FTimerHandle m_TimerHandle;
	FTimerHandle m_TimerHandle2;
	AActor* itemMesh;
	ASkeletalMeshActor* bflag;
	int m_SelIdx;//��ǰѡ��������
};
