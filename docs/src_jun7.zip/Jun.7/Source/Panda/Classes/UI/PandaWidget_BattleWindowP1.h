// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "UI/PandaWidget.h"
#include "PandaWidget_BattleWindowP1.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API UPandaWidget_BattleWindowP1 : public UPandaWidget
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct()override;
	virtual	void OnBag()override;
	void BattleTimeCallBack();
	void UpdateHreoInfo();
	void createBattleComplete();
	FTimerHandle m_TimerHandle;
	UTextBlock* m_battleTime;
	int m_CurrTime;
};
