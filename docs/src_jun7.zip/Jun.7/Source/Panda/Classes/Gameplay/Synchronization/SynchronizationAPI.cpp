// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "Engine.h"
#include <Engine/GameEngine.h>
#include "Networking/NetworkingFwd.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Synchronization/SynchronizationAPI.h"

using namespace proto3;

void USynchronizationAPI::move(proto3::eMoveType eMoveType, float x, float y, float z, float Roll, float Pitch, float Yaw, float fMoveSpeed, int CHARACTER_STATE, int CHARACTER_SUB_STATE)
{
	if (UPandaUtils::getOffline()) return;
	if (GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZMove msg;
		msg.set_mid(eMsg::MSG_CZ_MOVE);
		msg.set_type(eMoveType);
		proto3::PlaceInfo place;
		place.set_zid(1);
		place.set_nmapid(0);
		place.set_x(x);
		place.set_y(y);
		place.set_z(z);
		place.set_roll(Roll);
		place.set_pitch(Pitch);
		place.set_yaw(Yaw);
		place.set_fmovespeed(fMoveSpeed);
		place.set_character_state(CHARACTER_STATE);
		place.set_character_sub_state(CHARACTER_SUB_STATE);
		place.set_movetype(eMoveType);
		auto pl = msg.mutable_to()->Add();
		pl->CopyFrom(place);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, msg);
	}
}