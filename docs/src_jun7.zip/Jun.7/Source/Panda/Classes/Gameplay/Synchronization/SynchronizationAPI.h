// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "SynchronizationAPI.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API USynchronizationAPI : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	// move
	static void move(proto3::eMoveType eMoveType, float x, float y, float z, float Roll, float Pitch, float Yaw, float fMoveSpeed, int CHARACTER_STATE, int CHARACTER_SUB_STATE);
};