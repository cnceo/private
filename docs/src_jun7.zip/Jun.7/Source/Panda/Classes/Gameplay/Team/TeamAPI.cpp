// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PandaUtils.h"
#include "Engine.h"
#include "BaseCharacter.h"
#include <Engine/GameEngine.h>
#include "Networking/NetworkingFwd.h"
#include "BaseAIController.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "PandaGameInstance.h"
#include "CString.h"
#include "MainPlayerController.h"
#include "Team/TeamAPI.h"

using namespace proto3;

void UTeamAPI::create(const std::string& title, int nTotals, int nDungeonID, int nDifficulty)
{
	if (UPandaUtils::getOffline()) return;
	if (GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamCreate msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_CREATE);
		msg.mutable_team()->set_title(title);
		msg.mutable_team()->set_capacity(nTotals);
		msg.mutable_team()->set_dungeonid(nDungeonID);
		msg.mutable_team()->set_difficulty(nDifficulty);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, msg);
	}
}

void UTeamAPI::edit(const proto3::TeamInfo& ti, const std::string& title, int nTotals, int nDungeonID, int nDifficulty)
{
	if (UPandaUtils::getOffline()) return;
	if (GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamEdit msg;
		msg.mutable_team()->CopyFrom(ti);
		msg.set_mid(eMsg::MSG_CZ_TEAM_EDIT);
		msg.mutable_team()->set_uid(ti.uid());
		msg.mutable_team()->set_title(title);
		msg.mutable_team()->set_capacity(nTotals);
		msg.mutable_team()->set_dungeonid(nDungeonID);
		msg.mutable_team()->set_difficulty(nDifficulty);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, msg);
	}
}

void UTeamAPI::exit(const proto3::TeamInfo& ti)
{
	if (UPandaUtils::getOffline()) return;
	if (GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamLeave msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_LEAVE);
		msg.mutable_team()->CopyFrom(ti);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient, msg);
	}
}

void UTeamAPI::kick(const proto3::TeamInfo& ti, const proto3::PlayerInfo& pi)
{

	if (UPandaUtils::getOffline()) return;
	if(GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamKick msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_KICK);
		msg.mutable_team()->CopyFrom(ti);
		msg.mutable_targets()->CopyFrom(pi);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient,msg);
	}
}

void UTeamAPI::recruit(const proto3::TeamInfo& ti, proto3::MsgCZTeamRecruitStart msg)
{
	//auto shid=GGameInstance->pandanet->clientZConnection.handler.shClient->id();
	//PlayerInfo& pi=GGameInstance->pandanet->clientZConnection.find(shid)->player;
	if (UPandaUtils::getOffline()) return;
	if(GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		msg.set_mid(eMsg::MSG_CZ_TEAM_RECRUIT_START);
		msg.mutable_team()->CopyFrom(ti);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient,msg);
	}
}

void UTeamAPI::invite(const proto3::TeamInfo& ti, bool ok)
{

	if (UPandaUtils::getOffline()) return;
	if(GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamRecruitReply msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_RECRUIT_REPLY);
		msg.mutable_team()->CopyFrom(ti);
		msg.set_result(ok?eResult::SUCCEESS:eResult::CANCELLED);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient,msg);
	}
}

void UTeamAPI::join(const proto3::TeamInfo& ti)
{
	if (UPandaUtils::getOffline()) return;
	if(GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamJoinStart msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_JOIN_START);
		msg.mutable_team()->CopyFrom(ti);
		msg.mutable_team()->set_uid(ti.uid());
		msg.mutable_team()->set_title(ti.title());
		msg.mutable_team()->set_levellimit(ti.levellimit());
		msg.mutable_team()->set_professionlimit(ti.professionlimit());
		msg.mutable_team()->set_dungeonid(ti.dungeonid());
		msg.mutable_team()->set_difficulty(ti.difficulty());
		msg.mutable_team()->set_capacity(ti.capacity());
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient,msg);
	}
}

void UTeamAPI::apply(const proto3::PlayerInfo& pi, bool ok)
{
	if (UPandaUtils::getOffline()) return;
	if(GGameInstance&&GGameInstance->pandanet&&GGameInstance->pandanet->clientZConnection.handler.shClient)
	{
		MsgCZTeamJoinReply msg;
		msg.set_mid(eMsg::MSG_CZ_TEAM_JOIN_REPLY);
		msg.mutable_applicant()->CopyFrom(pi);
		msg.set_result(ok?eResult::SUCCEESS:eResult::CANCELLED);
		PBHelper::Send(*GGameInstance->pandanet->clientZConnection.handler.shClient,msg);
	}
}