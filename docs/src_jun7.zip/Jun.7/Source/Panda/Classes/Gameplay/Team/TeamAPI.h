// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "TeamAPI.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API UTeamAPI : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	// create
	static void create(const std::string& title, int nTotals, int nDungeonID, int nDifficulty);

	// edit
	static void edit(const proto3::TeamInfo& ti, const std::string& title, int nTotals, int nDungeonID, int nDifficulty);

	// exit
	static void exit(const proto3::TeamInfo& ti);

	// kick
	static void kick(const proto3::TeamInfo& ti, const proto3::PlayerInfo& pi);

	// recruit
	static void recruit(const proto3::TeamInfo& ti, proto3::MsgCZTeamRecruitStart msg);
	static void invite(const proto3::TeamInfo& ti, bool);

	// join
	static void join(const proto3::TeamInfo& ti);
	static void apply(const proto3::PlayerInfo& pi, bool);
};