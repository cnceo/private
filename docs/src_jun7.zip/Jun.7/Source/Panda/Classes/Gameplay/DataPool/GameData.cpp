// Copyright 1998-2014 xishanju Games, Inc. All Rights Reserved.

#include "panda.h"
#include "GameData.h"


FGameData::FGameData()
{

}

FGameData::~FGameData()
{

}

void FGameData::Init()
{

}

void FGameData::Serialize()
{

}

