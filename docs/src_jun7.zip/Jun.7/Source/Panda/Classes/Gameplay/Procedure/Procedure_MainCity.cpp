// Copyright 1995-2016. All Rights Reserved.
// Created by White.tian 


#include "panda.h"
#include "MoviePlayer.h"
#include "EKGameFrame.h"
#include "EKHUDManager.h"
#include "EKProcedureManager.h"
#include "PandaGameInstance.h"
#include "Procedure_SelectChar.h"
#include "MainPlayerController.h"
#include "PandaUtils.h"
#include "PlayerDataManager.h"
#include "OthersCharacter.h"
#include "Team/TeamManager.h"

// �Ƿ���������,���ǵĵ�ͼ�Ƿ񴴽����
extern bool g_bool_FProcedure_MainCity_InMainCity;

FProcedure_MainCity::FProcedure_MainCity(uint64 inID)
	:FEKProcedureBase(inID)
	/*,isSendLogin(false)*/
{

}

void FProcedure_MainCity::Init()
{
	m_bMapPostEnd = false;
	g_bool_FProcedure_MainCity_InMainCity = false;
	return FEKProcedureBase::Init();
}

void FProcedure_MainCity::Tick(float inDeltaTime)
{
	FEKProcedureBase::Tick(inDeltaTime);

	// every frame to tick 
	// When the team create successed, show self team member's UI, and refresh others head ui icon. logic end.
	bool bTrue = FTeamDataManager::Instance()->Tick(inDeltaTime);
	if (bTrue)
	{
		int nSuccessed = 1;
		//OnCross();
	}

	//if (m_bMapPostEnd)
	if(g_bool_FProcedure_MainCity_InMainCity)
	{
		// ���ݸ���,�µ��û���¼���ͬ��
		RefreshOtherPlayer();

		if (FPlayerDataManager::Instance()->getForceToRefresh())
		{
			// ��¼�����û������ݸ���
			//UE_LOG(LogTemp, Warning, TEXT(" TICK NEED LESS "));
			auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
			controller->UpdateOtherPlayer();
			FPlayerDataManager::Instance()->setForceToRefresh(false);
		}
	}
	else if (FPlayerDataManager::Instance()->getForceToRefresh())
	{

	}
	else
	{

	}
}

// ���ݸ���,�µ��û���¼���ͬ��
void FProcedure_MainCity::RefreshOtherPlayer()
{
	//if (m_bMapPostEnd)
	if (g_bool_FProcedure_MainCity_InMainCity)
	{
		auto m_FsPAPlayerInfoList = FPlayerDataManager::Instance()->getPlayerInfoList();
		auto count = m_FsPAPlayerInfoList.players.size();

		TArray<AActor*> OutActors;
		UGameplayStatics::GetAllActorsOfClass(GGameInstance, AOthersCharacter::StaticClass(), OutActors);
		auto OutActorsCounts = OutActors.Num();
		
		if (count > OutActorsCounts)
		{
			// ��Ҫ����other character

			/*auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
			controller->LoadOtherPlayer();*/

			//////////////////////////////////////////////////////////////////////////

			int nCount = 0;
			auto PlayerInfoList = FPlayerDataManager::Instance()->getPlayerInfoList();
			std::map<std::string, proto3::PlayerInfo>::iterator All_SingelIt;

			int nTotalCount = PlayerInfoList.players.size();
			bool bAdded = false;
			for (All_SingelIt = PlayerInfoList.players.begin(); All_SingelIt != PlayerInfoList.players.end(); All_SingelIt++)	//��ǰȫ����PlayerInfoList
			{
				if (bAdded) return;
				for (TArray<AActor*>::TConstIterator It(OutActors); It; ++It)	//��ǰ�����е�OthersCharacters
				{
					if (bAdded) return;
					AOthersCharacter* actor = Cast<AOthersCharacter>(*It);
					if ( strcmp(actor->getPlayerInfo().uid().c_str(), All_SingelIt->second.uid().c_str()) != 0 )
					{
						//////////////////////////////////////////////////////////////////////////
						auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
						controller->LoadOtherPlayer(All_SingelIt->second);
						//////////////////////////////////////////////////////////////////////////
						bAdded = true;
					}
				}

				nCount++;
			}
			//////////////////////////////////////////////////////////////////////////


			//UE_LOG(LogTemp, Warning, TEXT(" TICK NEED ADD "));
		}
		else if (count == OutActorsCounts)
		{
			// ���
			//UE_LOG(LogTemp, Warning, TEXT(" TICK NEED EQUAR "));
		}
		else
		{
			// ��Ҫ����
			//UE_LOG(LogTemp, Warning, TEXT(" TICK NEED LESS "));
			auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
			controller->RemoveOtherPlayer();
		}

	}
}

void FProcedure_MainCity::Enter()
{
	FEKProcedureBase::Enter();

	UE_LOG(LogScript, Warning, TEXT("Enter Procedure MainCity %d"), n_ID);

	if (FEKGameFrame::Instance()->SceneManager()->LoadMap(TEXT("City_01")))
	{
		//����loading���档
		if (GWorld != nullptr)
		{
			// ����ͼ����
			if (true)
			{
				FEKGameFrame::Instance()->SceneManager()->CreateLoadingScreen();
			}
		}

		//ע��Pre Load Mapί�У��ڸ�ί�к����в���loading���档
		delegateHandle = FCoreUObjectDelegates::PreLoadMap.AddRaw(this, &FProcedure_MainCity::PreLoadMap);
	}
}

void FProcedure_MainCity::PreLoadMap()
{
	UE_LOG(LogScript, Warning, TEXT("Enter Procedure MainCity %d PreLoadMap()"), n_ID);

	//FCoreUObjectDelegates::PreLoadMap.RemoveRaw(this, &FProcedure_Login::PreLoadMap);
	FCoreUObjectDelegates::PreLoadMap.Remove(delegateHandle);

	//isAsyncLoadingFinish.exchange(false);

	//if (GetMoviePlayer()->PlayMovie())
	//{
	//	//����ɹ�����loading���棬ע��Post Load Mapί�У��ڸ�ί���н���loading����
	//	FCoreUObjectDelegates::PostLoadMap.AddRaw(this, &FProcedure_Login::PostLoadMap);
	//}

	GetMoviePlayer()->PlayMovie();
	delegateHandle = FCoreUObjectDelegates::PostLoadMap.AddRaw(this, &FProcedure_MainCity::PostLoadMap);
}

void FProcedure_MainCity::PostLoadMap()
{


	UE_LOG(LogScript, Warning, TEXT("Enter Procedure MainCity %d PostLoadMap()"), n_ID);

	//FCoreUObjectDelegates::PostLoadMap.RemoveRaw(this, &FProcedure_Login::PostLoadMap);
	FCoreUObjectDelegates::PostLoadMap.Remove(delegateHandle);

	//���������������̬loading������ʽloading��
	FEKGameFrame::Instance()->HUDManager()->ShowWindow("PlayerMain");
	// ��ʼ��������
	FUMGPanel* panel = FEKGameFrame::Instance()->HUDManager()->GetCurrentUMGPanel();
	panel->Init();
	//while (!isAsyncLoadingFinish)
	//{
	//	//�������������ģ�����Ҫ�첽ִ�е�loading���ݣ����Ƽ�ʹ������ʽloading��
	//	UE_LOG(LogScript, Warning, TEXT(" !!!! Waiting Loading !!!! "));
	//	//Sleep(1000);
	//}

	/*APlayerController* PC = GWorld->GetFirstLocalPlayerFromController()->GetPlayerController(GWorld);
	ASelectCharPC* SelectPC = Cast<ASelectCharPC>(PC);
	if (SelectPC)
	{
		SelectPC->InitSelectCharScene();
	}*/

	//����loading����
	GetMoviePlayer()->WaitForMovieToFinish();


	//////////////////////////////////////////////////////////////////////////
	// ���ε�¼,�������е���ҽ�ɫ

	int nCount = 0;
	auto PlayerInfoList = FPlayerDataManager::Instance()->getPlayerInfoList();
	std::map<std::string, proto3::PlayerInfo>::iterator it;

	int nTotalCount = PlayerInfoList.players.size();

	for (it = PlayerInfoList.players.begin(); it != PlayerInfoList.players.end(); it++)
	{
		nCount++;
		//////////////////////////////////////////////////////////////////////////
		auto controller = Cast<AMainPlayerController>(UPandaUtils::GetLocalPlayerController(UPandaGameInstance::Instance()));
		controller->LoadOtherPlayer(it->second);
		//////////////////////////////////////////////////////////////////////////
	}
	//////////////////////////////////////////////////////////////////////////

	// ��ͼ�������
	m_bMapPostEnd = true;
	g_bool_FProcedure_MainCity_InMainCity = true;
}

void FProcedure_MainCity::Leave()
{
	m_bMapPostEnd = false;
	g_bool_FProcedure_MainCity_InMainCity = false;
	FEKProcedureBase::Leave();

	//FEKGameFrame::Instance()->HUDManager()->HideWindow("Login");

	FEKGameFrame::Instance()->HUDManager()->HideWindow("PlayerMain", true);

	UE_LOG(LogScript, Warning, TEXT("Leave Procedure MainCity %d"), n_ID);
}
