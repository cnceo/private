//
//  DataParse.h
//  Panda
// 
//  解析服务端数据类，解析完成进行对客户端数据持有化对象的赋值，只处理服务端下发消息的回调部分
// 
//  Created by White.tian on 2016-05-26 16:50:17.
//  Copyright (c) 2016年 White.tian All rights reserved.
//

#ifndef __FDATAPARSE__
#define __FDATAPARSE__

#include "CCPlatformMacros.h"
#include "PAUserData.h"
/**
*
*/
namespace proto3 {
	class PlayerInfo;
	class TeamInfo;
};

// 所有的队伍列表
struct FsPATeamList
{
public:
	int mid;
	std::map<int, proto3::TeamInfo> team;  // 对应 MsgZCTeamBroadcast 中 team
};

// 所有的玩家列表
struct FsPAPlayerInfoList
{
public:
	std::map<std::string, proto3::PlayerInfo> players;  // 对应 MsgZCSyncPlayers 中 players
};

#define PANDA_FDataParse (FDataParse::Instance())


class FDataParse
{
	FDataParse();
	~FDataParse();
	bool Init();

public:

	static FDataParse * Instance();
	static void purgedFDataParse();

public:
	/* Parse server data, and after set client data */
	void ParsePlayerData(proto3::PlayerInfo& playerInfo);
};

#endif /* defined(__FDATAPARSE__) */