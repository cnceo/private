// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Tickable.h"
#include <memory>

#ifndef UNREAL_SOCKET

class PANDA_API ArenaCHandler:public BaseHandler{
public:
	void on_message(keye::svc_handler&,keye::PacketWrapper&);
	void connect(){}
	void login(){}
};

// Client: communicates with Gateway
class PANDA_API ClientGHandler:public BaseHandler{
public:
	void on_message(keye::svc_handler&,keye::PacketWrapper&);

	void connect();
	void login();

	proto3::MsgGCLogin msgGCLogin;
};

// Arena: communicates with Zone
class PANDA_API ClientAHandler:public BaseHandler{
public:
	void on_message(keye::svc_handler&,keye::PacketWrapper&);

	void connect();
	void login();

	proto3::MsgZCEnterArena	EnterArena;
private:
	bool enterArena();
};

// Client: communicates with Zone
class PANDA_API ClientZHandler:public BaseHandler{
public:
	void on_message(keye::svc_handler&,keye::PacketWrapper&);

	void connect();
	void login();

	void on_close(keye::svc_handler& sh);

	void preEnterArena(proto3::MsgZCEnterArena&);
	std::string testName;
	proto3::ZoneInfo zoneInfo;

	//// op, like teamCreate...
	//void opCode(proto3::eTeamOp op);

	// error code, like successed, failed, repeated...
	void errorCode(proto3::eResult result, proto3::eTeamOp op);
private: 
};

// Client: communicates with Arena
class PANDA_API ArenaZHandler:public BaseHandler{
public:
	void on_message(keye::svc_handler&,keye::PacketWrapper&);

	void connect();
	void login();
};
#endif // UNREAL_SOCKET

