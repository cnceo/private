// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "Networking/NetworkingFwd.h"
#include "MainPlayerController.h"
#include "Data/DataParse.h"
#include "PlayerDataManager.h"
#include "Team/TeamManager.h"
#include "Procedure_MainCity.h"

#ifndef UNREAL_SOCKET
using namespace proto3;

// �Ƿ���������,���ǵĵ�ͼ�Ƿ񴴽����
extern bool g_bool_FProcedure_MainCity_InMainCity;

// zone close
void ClientZHandler::on_close(keye::svc_handler& sh)
{
	UE_LOG(LogTemp, Warning, TEXT("-------- Zone Server Closed ---------------"));
	
	// ��ʾ Zone Server�Ѿ��ر�
	const FString str = TEXT("-------- Zone Server Closed --------------- Please Restart Game, �������������,��Ҫ�����������������,�����ﴦ���ӿ� !!!!");
	GEngine->AddOnScreenDebugMessage(-1, 10.f, FColor::Red, str);

	// �������������,��Ҫ�����������������
	if (g_bool_FProcedure_MainCity_InMainCity)
	{
		//GGameInstance->InitNetwork();
		g_bool_FProcedure_MainCity_InMainCity = false;
		FEKGameFrame::Instance()->ProcedureManager()->ChangeCurrentProcedure(GeometrySpace::Procedure::PT_Login);
		// ...
	}
}

// Client connection to Zone
void ClientZHandler::on_message(keye::svc_handler& sh,keye::PacketWrapper& pw)
{
	PBHelper pb(pw);

	auto mid=pb.Id();

	UE_LOG(LogTemp,Warning,TEXT("--------Zone on_message %d(%s:%d)"),(int)mid,ANSI_TO_TCHAR(sh.address().c_str()),sh.port());

	if(mid<=eMsg::MSG_CZ_BEGIN||mid>=eMsg::MSG_CZ_END)return;

	switch(mid)
	{
	case MSG_ZC_ENTER:
		{
		// ͬ����봴����ɫ����
		proto3::MsgZCEnter imsg;
		pb.Parse(imsg);
		bLogin = true;
		imsg.clear_mid();
		
		// ͬ��playerInfo����
		if (auto sess = GGameInstance->pandanet->clientZConnection.find(sh.id())) {
			// ��ʱ����
			//PlayerInfo& pi = sess->player;
			//FDataParse::Instance()->ParsePlayerData(pi);
		}

		//auto controller = UPandaUtils::GetLocalPlayerController(GGameInstance);
		//if (controller) {
		//	auto SelectPC = Cast<ASelectCharPC>(controller);
		//	if (SelectPC)
		//	{
		//		//SelectPC->NetLogin(imsg);
		//		SelectPC->EnterGame();
		//	}
		//}

		/*APlayerCharacter* pMainPlayer = Cast<APlayerCharacter>(GGameInstance->GetFirstLocalPlayerController()->GetPawn());
		if (pMainPlayer)
		{
			auto SelectPC = Cast<ASelectCharPC>(pMainPlayer->GetController());
			if (SelectPC)
			{
				SelectPC->NetLogin(imsg);
			}
		}*/

		UE_LOG(LogTemp,Warning,TEXT("--------entered Zone(%s:%d)"),ANSI_TO_TCHAR(sh.address().c_str()),sh.port());
/*
		MsgCZCreatePlayer omsg;
		omsg.set_mid(eMsg::MSG_CZ_CREATE_PLAYER);
		omsg.mutable_playerinfo()->set_name("PlayerName");
		PBHelper::Send(sh,omsg);
		*/
		break;
	}
	case MSG_ZC_ENTER_ARENA:
		{
		if(GGameInstance&&GGameInstance->pandanet){
			auto& h=GGameInstance->pandanet->clientAConnection.handler;
			auto& imsg=h.EnterArena;
			if(pb.Parse(imsg)){
				UE_LOG(LogTemp, Log, TEXT("--------Retrieved Arena: aid=%d, host=%s, port=%d, key=%s, level=%s"),
					imsg.aid(),ANSI_TO_TCHAR(imsg.host().c_str()),imsg.port(),ANSI_TO_TCHAR(imsg.key().c_str()),ANSI_TO_TCHAR(imsg.level().c_str()));

				preEnterArena(imsg);
			}
		}
		break;
	}
	case MSG_ZC_MOVE:
	{
		MsgZCMove imsg;
		if (pb.Parse(imsg)) {
			if (imsg.result() == eResult::SUCCEESS)
			{
				// sure to move
				int a = 1;
				if (imsg.type() == proto3::eMoveType::WALK)
				{
				}else if (imsg.type() == proto3::eMoveType::FALLING) //��Ӧfalling
				{
				}
			}
		}
		break;
	}
	case MSG_ZC_EXIT:
	{
		// ��һ���û��˳���Ϸ��,������Ҷ����յ�EXIT����Ϣ����
		UE_LOG(LogTemp, Warning, TEXT(" MSG_ZC_EXIT  MSG_ZC_EXIT MSG_ZC_EXIT MSG_ZC_EXIT  1"));
		MsgZCExit imsg;
		if (pb.Parse(imsg)) {
			UE_LOG(LogTemp, Warning, TEXT(" MSG_ZC_EXIT  MSG_ZC_EXIT MSG_ZC_EXIT MSG_ZC_EXIT  2"));
			FPlayerDataManager::Instance()->removePlayerInfoList(imsg);
		}
		break;
	}
	case MSG_ZC_BROADCAST_PLAYER: {
		MsgZCBroadcastPlayer imsg;
		if(pb.Parse(imsg)){
			FPlayerDataManager::Instance()->addPlayerInfoList(imsg);
		}
		break;
	}
	case MSG_ZC_SYNC_PLAYERS: {
		MsgZCSyncPlayers imsg;
		if(pb.Parse(imsg)){
			UE_LOG(LogTemp, Log, TEXT("--------MsgZCSyncPlayers players=%d"), imsg.players_size());
			for(auto& pi:imsg.players()){
				//all players
			}
			FPlayerDataManager::Instance()->setPlayerInfoList(imsg);
		}
		break;
	}
	case MSG_CZ_TEAM_RECRUIT_ASK:
		{
		if (GGameInstance&&GGameInstance->pandanet) {
			MsgZCTeamRecruitAsk imsg;
			if (pb.Parse(imsg)) {
				int a = 1;
				UTeamAPI::invite(imsg.team(), true);
			}
		}
	}
		break;
	case MSG_ZC_TEAM_JOIN_ASK:
		{
		if (GGameInstance&&GGameInstance->pandanet) {
			MsgZCTeamJoinAsk imsg;
			if (pb.Parse(imsg)) {

				// �Է����ͼ���join����Ϣ,�����ö�����˻��յ������˵���Ϣ
				const FString str = TEXT("���˼�����Ķ��飬��򿪼����Ա�б��鿴!!!����PageUp���鿴!!!!");
				GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);

				// ͬ����ǰ����ʹ�õ�team Info(���ڵ�ǰ���)
				FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
				/*for (auto& pi : imsg.team().joins())
					UTeamAPI::apply(pi, true);*/
			}
		}
	}
		break;
	case MSG_ZC_TEAM_BROADCAST:
		{
			if (GGameInstance&&GGameInstance->pandanet) {
				MsgZCTeamBroadcast imsg;
				if (pb.Parse(imsg)) {

					// ���ö����б�,����ǰ���������
					FPlayerDataManager::Instance()->setTeamList(imsg);
				}
			}
		}
		break;
	case MSG_ZC_TEAM_UPDATE:
		{
			if (GGameInstance&&GGameInstance->pandanet) {
				MsgZCTeamUpdate imsg;
				if (pb.Parse(imsg)) {

					if (imsg.result() == eResult::SUCCEESS)
					{
						switch (imsg.op())
						{
						case eTeamOp::CREATE:	// CREATE							
						{
							const FString str = TEXT("���鴴���ɹ�!!!");
							GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
							FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
							
							// �������Ϣ���غ�,�����Լ���״̬����.��GameThread�ڵ���һ֡��������
							// When the team create successed, show self team member's UI, and refresh others head ui icon. logic begin.
							FTeamDataManager::Instance()->setTeamState(TEAM_SERVER_RETURN_STATE::SUB_STATE_CREATE_SUCCESS);
						}
						break;
						case eTeamOp::DISMISS:		// DISMISS
						{}
						break;
						case eTeamOp::APPLY:		// APPLY
						{
							const FString str = TEXT("ͬ��������ɹ�!!!");
							GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
							FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
						}
						break;
						case eTeamOp::LEAVE:		// LEAVE
						{
							const FString str = TEXT("�뿪����ɹ�!!!");
							GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
							FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
						}
						break;
						case eTeamOp::KICK:		// KICK
						{
							const FString str = TEXT("�߳�����ɹ�!!!");
							GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
							FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
						}
						break;
						case eTeamOp::INVITE:		// INVITE
						{}
						break;
						case eTeamOp::BROADCAST:		// BROADCAST
						{}
						break;
						case eTeamOp::EDIT:		// EDIT
						{
							const FString str = TEXT("�༭������Ϣ�ɹ�!!!");
							GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, str);
							FPlayerDataManager::Instance()->setTeamInfo(imsg.team());
						}
						break;
						}
					}
					else
					{
						errorCode(imsg.result(), imsg.op());
					}
				}
			}
		}
		break;
	case MSG_ZC_SYN_ITEM:
	{
		if (GGameInstance&&GGameInstance->pandanet)
		{
			game_itemInfos imsg;

			if (pb.Parse(imsg))
			{
				GGameInstance->SafeGetItemManager()->synItems(imsg);
			}
		}
	}
		break;
	case MSG_ZC_CHALLENGE_INVITE:
	{
		if (GGameInstance&&GGameInstance->pandanet)
		{
			MsgZCChallengeInvite imsg;

			if (pb.Parse(imsg))
			{
				GGameInstance->SafeGetModeManager()->pvpInvite(imsg);
			}
		}
	}
		break;
	case MSG_ZC_CHALLENGE_START:
	{
		if (GGameInstance&&GGameInstance->pandanet)
		{
			MsgZCChallengeStart imsg;
			if (pb.Parse(imsg))
			{
				GGameInstance->SafeGetModeManager()->pvpStart(imsg);
			}
		}
	}
	break;
	default:
		break;
	}
}

void ClientZHandler::errorCode(proto3::eResult result, proto3::eTeamOp op)
{
	switch (result)
	{
	case proto3::SUCCEESS:
		break;
	case proto3::FAILED:
		{
			switch (op)
			{
			case eTeamOp::CREATE:		// CREATE
			{
				const FString str = TEXT("����ʧ��,�����Ѵ��� !!!");
				GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, str);
			}
			break;
			case eTeamOp::DISMISS:		// DISMISS
			{}
			break;
			case eTeamOp::APPLY:		// APPLY
			{}
			break;
			case eTeamOp::LEAVE:		// LEAVE
			{}
			break;
			case eTeamOp::KICK:			// KICK
			{
				const FString str = TEXT("Ȩ�޲��� !!!");
				GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, str);
			}
			break;
			case eTeamOp::INVITE:		// INVITE
			{}
			break;
			case eTeamOp::BROADCAST:	// BROADCAST
			{}
			break;
			case eTeamOp::EDIT:		// EDIT
			{}
			break;
			}
		}
		break;
	case proto3::CANCELLED:
		break;
	case proto3::ERR_PROTOCOL:
		break;
	case proto3::ERR_PARAM:
		break;
	case proto3::ERR_DUPLICATED:
		{
			switch (op)
			{
			case eTeamOp::CREATE:		// CREATE
			{
				const FString str = TEXT("�����ظ�,ʧ��,�����Ѵ��� !!!");
				GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, str);
			}
			break;
			case eTeamOp::DISMISS:		// DISMISS
			{}
			break;
			case eTeamOp::APPLY:		// APPLY
			{
				const FString str = TEXT("���ж���,�����ٴμ��� !!!");
				GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, str);
			}
			break;
			case eTeamOp::LEAVE:		// LEAVE
			{
			}
			break;
			case eTeamOp::KICK:		// KICK
			{}
			break;
			case eTeamOp::INVITE:		// INVITE
			{}
			break;
			case eTeamOp::BROADCAST:		// BROADCAST
			{}
			break;
			case eTeamOp::EDIT:		// EDIT
			{}
			break;
			}
		}
		break;
	case proto3::UNKNOWN:
		break;
	case proto3::eResult_INT_MIN_SENTINEL_DO_NOT_USE_:
		break;
	case proto3::eResult_INT_MAX_SENTINEL_DO_NOT_USE_:
		break;
	default:
		break;
	}
}

void ClientZHandler::preEnterArena(proto3::MsgZCEnterArena& imsg){
	auto& h=GGameInstance->pandanet->clientAConnection.handler;
	if(h.shClient)	h.login();
	else			h.connect();
}

void ClientZHandler::connect(){
	//need connect to Zone
	auto zoneHost=zoneInfo.ip().c_str();
	auto zoneCPort=zoneInfo.port();
	GGameInstance->pandanet->clientZConnection.connect(zoneHost,zoneCPort);
	UE_LOG(LogTemp,Warning,TEXT("connect to Zone(%s:%d)"),ANSI_TO_TCHAR(zoneHost),zoneCPort);
}

void ClientZHandler::login(){
	auto udid = FPlayerDataManager::Instance()->getuid();
	MsgGCLogin& imsg=GGameInstance->pandanet->clientGConnection.handler.msgGCLogin;
	auto& zone=imsg.zoneinfo(0);
	MsgCZEnter msg;
	msg.set_mid(eMsg::MSG_CZ_ENTER);
	msg.set_sid(imsg.sid());
	msg.set_uid(udid);
	PBHelper::Send(*shClient,msg);
	UE_LOG(LogTemp,Warning,TEXT("--------entering Zone(%s:%d)"),ANSI_TO_TCHAR(zone.ip().c_str()),zone.port());
}

#endif //UNREAL_SOCKET