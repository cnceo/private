// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "EasyKit.h"

#include "EKNetworkSession.h"
#include "EKNetworkBaes.h"
//
//
//using namespace xsjme;
//
//
//// ����
//FEKNetworkSession::FEKNetworkSession()
//{
//	
//}
//
//bool FEKNetworkSession::Init()
//{
//
//	return true;
//}
//
//bool FEKNetworkSession::IsConnect()
//{
//	return true;
//}
//
//bool FEKNetworkSession::Connect()
//{
//
//	return true;
//}
//
//bool FEKNetworkSession::SendToSever(ProtocolPacketBase& protocolSerializer, int64_t sessionId)
//{
//
//	return true;
//}
//
//
//void FEKNetworkSession::RegisterProtocol(ushort protocolId, ProtocolProcessor func)
//{
//
//}
//
//void FEKNetworkSession::Tick(float DeltaSeconds)
//{
//	FEKNetworkBaes::Tick(DeltaSeconds);
//
//
//}

