// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "EasyKit.h"

#if WITH_EDITOR

#endif // WITH_EDITOR

#include "EKNetworkBaes.h"
//#include "Net/ClientSocket.h"
//#include "Net/SocketContext.h"
//#include "Foundation/Others.h"
//#include "CommonProcessor.h"
//
//
//using namespace xsjme;
//
//// ��̬��ʼ��
//volatile bool  FEKNetworkBaes::bIsConnect = false;
//volatile bool FEKNetworkBaes::bUseNetwork = true;
//
//// ����
//FEKNetworkBaes::FEKNetworkBaes()
//{
//	
//}
//
//void FEKNetworkBaes::Tick(float DeltaSeconds)
//{
//	if (bUseNetwork == false)
//		return ;
//}
//
//// ע��Э�鵽���������
//void FEKNetworkBaes::AddProtocol(class FProcessor* Processor)
//{
//	ProcessorArray.Add(Processor);
//}
//
