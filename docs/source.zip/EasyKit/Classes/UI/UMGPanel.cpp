// Copyright 1998-2014 xishanju Games, Inc. All Rights Reserved.

#include "EasyKit.h"
#include "UMGPanel.h"


FUMGPanel::FUMGPanel() :
sWidgetPath(""), 
sWidgetName(""), 
nMutexLevel(1), 
Window(nullptr)
{

}

FUMGPanel::~FUMGPanel()
{

}

void FUMGPanel::Init()
{

}



