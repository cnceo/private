// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "SlateBasics.h"

class FEKStyle
{
//public:
//	
//	static void Initialize();
//
//	static void Shutdown();
//
//	/** reloads textures used by slate renderer */
//	static void ReloadTextures();
//
//	/** @return The Slate style set for the Vehicle game */
//	static const ISlateStyle& Get();
//
//	static FName GetStyleSetName();
//
//private:
//
//	static TSharedRef< class FSlateStyleSet > Create();
//
//private:
//
//	static TSharedPtr< class FSlateStyleSet > EKStyleInstance;
};