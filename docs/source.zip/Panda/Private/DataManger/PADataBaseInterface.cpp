#include "panda.h"
#include "BaseAniInterface.h"

UPADataBaseInterface::UPADataBaseInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


