// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PADungeonData.h"

PACombatCopyData::PACombatCopyData()
{
}

PACombatCopyData::~PACombatCopyData()
{
}
