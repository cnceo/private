#include "panda.h"
#include "ActiveActorInterface.h"

UActiveActorInterface::UActiveActorInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


