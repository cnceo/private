// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Dungeon_Stage.h"


UPAWidget_Dungeon_Stage::UPAWidget_Dungeon_Stage()
{
}

UPAWidget_Dungeon_Stage::~UPAWidget_Dungeon_Stage()
{
}

void UPAWidget_Dungeon_Stage::NativeConstruct()
{
	Super::NativeConstruct();

	// ...
}

void UPAWidget_Dungeon_Stage::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);
}

void UPAWidget_Dungeon_Stage::OnCross()
{
	Super::OnCross();
}

void UPAWidget_Dungeon_Stage::OnCircle()
{
	Super::OnCircle();
}