// Fill out your copyright notice in the Description page of Project Settings.

#include "panda.h"
#include "PAWidget_Team_CreateTeam.h"

UPAWidget_Team_CreateTeam::UPAWidget_Team_CreateTeam()
{
}

UPAWidget_Team_CreateTeam::~UPAWidget_Team_CreateTeam()
{
}

void UPAWidget_Team_CreateTeam::NativeConstruct()
{
	Super::NativeConstruct();

	// ...
}

void UPAWidget_Team_CreateTeam::UpdateSelf(float deltaTime)
{
	UPandaWidget::UpdateSelf(deltaTime);
}

void UPAWidget_Team_CreateTeam::OnCross()
{
	Super::OnCross();
}

void UPAWidget_Team_CreateTeam::OnCircle()
{
	Super::OnCircle();
}