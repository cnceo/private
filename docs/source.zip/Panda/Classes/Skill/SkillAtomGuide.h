// Fill out your copyright notice in the Description page of Project Settings.
//add by yang 20160503
#pragma once

#include "Skill/SkillAtomBase.h"
#include "SkillAtomGuide.generated.h"

/**
 * 
 */
UCLASS()
class PANDA_API ASkillAtomGuide : public ASkillAtomBase
{
	GENERATED_BODY()
	
	
	
	
};
