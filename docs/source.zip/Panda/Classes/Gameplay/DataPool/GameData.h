//
// GameData.h
//
// ���ݱ� ���ݵ�Ԫ
//
// Created by  EasyKit Team's Geometry Games, Inc.
// Copyright (c) 2014-2017 Yinjunxu. All Rights Reserved. 
//

#pragma once



class FGameData
{

public:

	FGameData();
	~FGameData();

	virtual void Init();
	virtual void Serialize();
	
};


