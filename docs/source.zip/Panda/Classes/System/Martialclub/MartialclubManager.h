// Fill out your copyright notice in the Description page of Project Settings.

#pragma once


/**
 *
 */
class PANDA_API FMartialclubManager
{

public:

	FMartialclubManager();
public:
	// ��ʼ��
	void InitDefaults(int TaskId);
	// �����������
	bool CreateClubCondition();
	// 

public:


};
